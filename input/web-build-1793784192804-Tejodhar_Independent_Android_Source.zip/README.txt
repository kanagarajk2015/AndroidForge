TEJODHAR INDEPENDENT ANDROID APP - VERSION 2.0

This project is a standalone Android WebView app. It does not include the Median.co SDK,
Median demo screen, Median branding, or Median account dependency.

Website:
https://www.tejodhar.in/

Included:
- Native Android WebView shell
- Fingerprint / device credential unlock
- JavaScript and DOM storage
- File chooser upload support
- Camera and microphone permission handling for tejodhar.in
- HTTPS certificate validation (invalid certificates are rejected)
- External handling for tel:, mailto: and other non-web links
- Back navigation
- Blank-page detection and retry screen
- Tejodhar launcher icon and splash assets

BUILD APK:
1. Create a GitHub repository.
2. Extract all files from this ZIP into the repository root.
3. Commit and push to the main branch.
4. Open GitHub > Actions > Build Independent Tejodhar APK.
5. Run workflow, then download the Tejodhar-Independent-APK artifact.
6. Extract app-debug.apk and install it on the Android phone.

IMPORTANT:
- This is source code, not a prebuilt APK.
- The APK must be built and tested on a real device before release.
- Website login, HR portal, team chat, and other features remain hosted by tejodhar.in.
- This removes the Median app-builder dependency, not any third-party service that your
  website itself may use.
- Fingerprint unlock requires a biometric or supported device screen lock to be configured.
