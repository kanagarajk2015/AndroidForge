package in.tejodhar.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.view.View;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

public class MainActivity extends FragmentActivity {
    private static final int FILE_CHOOSER = 1001;
    private static final int WEB_PERMISSION = 1002;
    private static final String HOME_URL = "https://www.tejodhar.in/";
    private static final String ALT_URL = "https://tejodhar.in/";
    private static final String RETRY_SCHEME = "tejodhar-retry";

    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private PermissionRequest pendingWebPermission;
    private boolean unlocked = false;
    private boolean authenticating = false;
    private boolean triedAlternate = false;
    private boolean pageFailed = false;
    private String lastMainUrl = null;
    private final StringBuilder jsErrors = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF14243A);
        getWindow().setNavigationBarColor(0xFF14243A);
        createWebView();
        showBiometricUnlock();
    }

    private void createWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFFFFFFF);
        webView.setVisibility(View.INVISIBLE);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        setContentView(webView);
        // Android 15 draws apps edge-to-edge; keep the page clear of status/navigation bars.
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });
        getWindow().getDecorView().setBackgroundColor(0xFF14243A);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        // Some servers/WAFs serve a blank or stripped page to the default WebView user agent
        // ("; wv" marker). Present the same user agent as the phone's browser.
        try {
            String ua = s.getUserAgentString();
            ua = ua.replace("; wv", "").replaceAll(" Version/\\d+\\.\\d+", "");
            s.setUserAgentString(ua);
        } catch (Exception ignored) { }

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    uploadCallback = null;
                    Toast.makeText(MainActivity.this, "Unable to open file picker", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR && jsErrors.length() < 600) {
                    jsErrors.append(m.message()).append(" @").append(m.sourceId() == null ? "" : m.sourceId().replaceAll(".*/", ""))
                            .append(":").append(m.lineNumber()).append("\n");
                }
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingWebPermission == request) pendingWebPermission = null;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleNavigation(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleNavigation(Uri.parse(url));
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                lastMainUrl = url;
                pageFailed = false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && url.startsWith("https://") && !pageFailed) triedAlternate = false;

                // Suppress the old DEBUG Toast. Detect a genuinely empty HTML document
                // and show a useful retry screen instead of leaving a blank white WebView.
                if (url != null && url.startsWith("https://")) {
                    final WebView loadedView = view;
                    loadedView.postDelayed(() -> {
                        if (webView != loadedView || pageFailed) return;
                        loadedView.evaluateJavascript(
                            "(function(){try{return !document.documentElement || " +
                            "document.documentElement.outerHTML.length < 200;}catch(e){return true;}})()",
                            value -> {
                                if ("true".equals(value) && webView == loadedView && !pageFailed) {
                                    pageFailed = true;
                                    showLoadError("The website responded, but its page is empty. " +
                                        "Check the website hosting or server-side PHP response, then tap Retry.");
                                }
                            });
                    }, 5000);
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, android.webkit.WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);
                if (request.isForMainFrame() && errorResponse != null) {
                    int code = errorResponse.getStatusCode();
                    if (code >= 500 || code == 403) {
                        pageFailed = true;
                        if (!loadAlternate()) showLoadError("Server returned HTTP " + code + " for " + request.getUrl());
                    }
                }
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                super.onPageCommitVisible(view, url);
                view.setBackgroundColor(0xFFFFFFFF);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    String detail = Build.VERSION.SDK_INT >= 23 ? String.valueOf(error.getDescription()) : "Network error";
                    pageFailed = true;
                    if (!loadAlternate()) showLoadError(detail + "\nURL: " + request.getUrl());
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // Always reject invalid certificates (never proceed()). Only a failure of the
                // main page is shown/handled; favicon and other subresources are ignored.
                handler.cancel();
                String failedUrl = error != null ? error.getUrl() : null;
                if (isMainDocument(failedUrl)) {
                    pageFailed = true;
                    if (!loadAlternate()) {
                        showLoadError("HTTPS certificate rejected: " + describeSslError(error)
                                + "\nURL: " + failedUrl
                                + "\nCheck device date/time and the server certificate chain.");
                    }
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                if (view != null) {
                    view.destroy();
                    if (webView == view) webView = null;
                }
                createWebView();
                if (unlocked && webView != null) { webView.setVisibility(View.VISIBLE); triedAlternate = false; webView.loadUrl(HOME_URL); }
                return true;
            }
        });
    }

    private static String norm(String u) {
        if (u == null) return "";
        int h = u.indexOf('#');
        if (h >= 0) u = u.substring(0, h);
        return u.endsWith("/") ? u.substring(0, u.length() - 1) : u;
    }

    // True when the failing URL is the page being loaded (not favicon/css/js/images).
    private boolean isMainDocument(String failedUrl) {
        if (failedUrl == null) return true;
        if (norm(failedUrl).equalsIgnoreCase(norm(lastMainUrl))) return true;
        try {
            Uri failed = Uri.parse(failedUrl);
            String host = failed.getHost();
            String path = failed.getPath();
            boolean ours = host != null && (host.equalsIgnoreCase("tejodhar.in") || host.equalsIgnoreCase("www.tejodhar.in"));
            return ours && (path == null || path.isEmpty() || "/".equals(path));
        } catch (Exception e) {
            return false;
        }
    }

    // First failure: retry once on the other host (www <-> apex). Returns false if already tried.
    private boolean loadAlternate() {
        if (triedAlternate || webView == null) return false;
        triedAlternate = true;
        final WebView w = webView;
        String cur = norm(lastMainUrl).toLowerCase();
        final String target = cur.startsWith("https://tejodhar.in") ? HOME_URL : ALT_URL;
        w.post(() -> w.loadUrl(target));
        return true;
    }

    // Keep all normal web navigation inside WebView, including login/payment redirects.
    // Only hand off non-web links such as tel:, mailto: and intent: to Android.
    private boolean handleNavigation(Uri uri) {
        if (uri == null) return true;
        String scheme = uri.getScheme();
        if (RETRY_SCHEME.equalsIgnoreCase(scheme)) {
            triedAlternate = false;
            if (webView != null) webView.loadUrl(HOME_URL);
            return true;
        }
        if (scheme == null || "https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) return false;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {
            Toast.makeText(this, "No app available to open this link", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private String describeSslError(SslError error) {
        if (error == null) return "Unknown TLS certificate error";
        switch (error.getPrimaryError()) {
            case SslError.SSL_DATE_INVALID: return "Certificate date is invalid (device clock or certificate validity)";
            case SslError.SSL_EXPIRED: return "Certificate has expired";
            case SslError.SSL_IDMISMATCH: return "Certificate hostname does not match the website address";
            case SslError.SSL_NOTYETVALID: return "Certificate is not valid yet";
            case SslError.SSL_UNTRUSTED: return "Certificate issuer or certificate chain is not trusted by Android";
            default: return "Certificate validation failed (code " + error.getPrimaryError() + ")";
        }
    }

    private void showLoadError(String detail) {
        if (webView == null) return;
        String safe = detail == null ? "Connection problem" : detail.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
                "<body style='font-family:Arial,sans-serif;background:#f5f7fa;color:#14243a;padding:28px'>" +
                "<h2>Tejodhar could not load</h2><p>" + safe + "</p>" +
                "<p>Check your internet connection, then try again.</p>" +
                "<button style='padding:12px 22px;background:#14243a;color:white;border:0;border-radius:6px' onclick=\"location.href='" + RETRY_SCHEME + "://now'\">Retry</button>" +
                "</body></html>";
        // Use data: origin so the fallback page does not request /favicon.ico from the
        // failing HTTPS host and trigger another SSL callback loop.
        webView.loadData(html, "text/html", "UTF-8");
    }

    private void showBiometricUnlock() {
        if (authenticating || unlocked) return;
        // DEVICE_CREDENTIAL combined with biometrics is only supported on Android 11+ (API 30).
        int authenticators = Build.VERSION.SDK_INT >= 30
                ? (BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                : BiometricManager.Authenticators.BIOMETRIC_WEAK;
        BiometricManager manager = BiometricManager.from(this);
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Set up fingerprint, face unlock or a phone screen lock, then reopen Tejodhar.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        authenticating = true;
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                authenticating = false;
                unlocked = true;
                if (webView == null) return;
                webView.setVisibility(View.VISIBLE);
                triedAlternate = false;
                webView.loadUrl(HOME_URL);
            }

            @Override
            public void onAuthenticationFailed() {
                Toast.makeText(MainActivity.this, "Not recognised. Try again.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                authenticating = false;
                Toast.makeText(MainActivity.this, "Tejodhar remains locked.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        BiometricPrompt.PromptInfo.Builder info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Tejodhar")
                .setSubtitle("Use fingerprint, face unlock or your phone screen lock")
                .setAllowedAuthenticators(authenticators);
        if (Build.VERSION.SDK_INT < 30) info.setNegativeButtonText("Exit");
        prompt.authenticate(info.build());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // If still locked and no prompt is showing, show it again instead of leaving
        // the user on the plain logo screen.
        if (!unlocked && !authenticating) showBiometricUnlock();
    }

    private void handleWebPermission(PermissionRequest request) {
        Uri origin = request.getOrigin();
        String host = origin == null ? null : origin.getHost();
        if (host == null || !(host.equalsIgnoreCase("tejodhar.in") || host.equalsIgnoreCase("www.tejodhar.in") || host.toLowerCase().endsWith(".tejodhar.in"))) {
            request.deny();
            return;
        }
        List<String> needed = new ArrayList<>();
        List<String> allowed = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) allowed.add(resource);
                else { needed.add(Manifest.permission.CAMERA); allowed.add(resource); }
            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) allowed.add(resource);
                else { needed.add(Manifest.permission.RECORD_AUDIO); allowed.add(resource); }
            }
        }
        if (needed.isEmpty()) request.grant(allowed.toArray(new String[0]));
        else {
            if (pendingWebPermission != null) pendingWebPermission.deny();
            pendingWebPermission = request;
            List<String> distinct = new ArrayList<>();
            for (String p : needed) if (!distinct.contains(p)) distinct.add(p);
            ActivityCompat.requestPermissions(this, distinct.toArray(new String[0]), WEB_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == WEB_PERMISSION && pendingWebPermission != null) {
            boolean allGranted = grantResults.length > 0;
            for (int result : grantResults) if (result != PackageManager.PERMISSION_GRANTED) allGranted = false;
            if (allGranted) {
                List<String> resources = new ArrayList<>();
                for (String resource : pendingWebPermission.getResources()) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) resources.add(resource);
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) resources.add(resource);
                }
                if (!resources.isEmpty()) pendingWebPermission.grant(resources.toArray(new String[0]));
                else pendingWebPermission.deny();
            } else pendingWebPermission.deny();
            pendingWebPermission = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && uploadCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            uploadCallback.onReceiveValue(result);
            uploadCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (uploadCallback != null) { uploadCallback.onReceiveValue(null); uploadCallback = null; }
        if (pendingWebPermission != null) { pendingWebPermission.deny(); pendingWebPermission = null; }
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
