Copy the "res" folder contents into app/src/main/res/ (merge, overwrite).
In app/src/main/AndroidManifest.xml, on the <application ...> tag add:
    android:icon="@mipmap/ic_launcher"
    android:roundIcon="@mipmap/ic_launcher_round"
Delete any old ic_launcher* files in other folders (e.g. drawable) that conflict.
playstore_icon_512.png = upload to Play Console (App icon, 512x512).
