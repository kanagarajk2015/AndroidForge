from pathlib import Path
required = [
    "settings.gradle.kts",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/pockethost/server/MainActivity.kt",
    "app/src/main/java/com/pockethost/server/HostingService.kt",
    ".github/workflows/android.yml",
]
missing = [f for f in required if not Path(f).is_file()]
assert not missing, f"Missing project files: {missing}"
manifest = Path(required[2]).read_text()
service = Path(required[4]).read_text()
assert 'android.permission.INTERNET' in manifest
assert '0.0.0.0", 8080' in service
assert 'contains("..")' in service
print("Project structure smoke test: PASS")
