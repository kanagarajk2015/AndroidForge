from pathlib import Path
root = Path(".")
main = (root / "app/src/main/java/com/pockethost/server/MainActivity.kt").read_text()
php = (root / "app/src/main/java/com/pockethost/server/PhpRuntimeManager.kt").read_text()
db = (root / "app/src/main/java/com/pockethost/server/MariaDbManager.kt").read_text()
secrets = (root / "app/src/main/java/com/pockethost/server/DbSecretStore.kt").read_text()
gradle = (root / "app/build.gradle.kts").read_text()
workflow = (root / ".github/workflows/android.yml").read_text()
builder = (root / "scripts/build_mariadb_rootfs.py").read_text()
assert "php -v" in main and "phpInstalled = success" in main
assert "mysqlExtensionStatus()" in php
assert 'listOf("Dashboard", "Websites", "Files", "Databases")' in main
assert "MariaDbManager" in main and "Create database" in main
assert "127.0.0.1:$PORT" in db and "--bind-address=127.0.0.1" in db
assert "CREATE DATABASE" in db and "DROP DATABASE" in db
assert "CREATE USER" in db and "GRANT ALL PRIVILEGES" in db
assert "lastDbCredentials" in main and "DatabaseCredential" in main
assert "AndroidKeyStore" in secrets and "AES/GCM/NoPadding" in secrets
assert "mariadb-rootfs.tar.gz" in db and "SHA-256 mismatch" in db
assert "verifyMariaDbAssets" in gradle
assert "buildMariaDbRuntime" in gradle
assert "dependsOn(buildMariaDbRuntime)" in gradle
assert 'commandLine("python3", mariadbBuilder.absolutePath)' in gradle
assert "actual four ELF bytes" not in builder or 'b"\\x7fELF"' in builder
assert "PINNED_MARIADB_VERSION" in builder and "SHA256" in builder
assert "build_mariadb_rootfs.py" in workflow and "mariadb-rootfs.tar.gz" in workflow
assert "assets/mariadb-rootfs.tar.gz" in workflow
assert "PocketHostServer-v5.4.7-debug" in workflow
assert "org.mariadb.jdbc:mariadb-java-client:3.5.6" in gradle
assert 'INDEX_PATH = "/dists/stable/main/binary-aarch64/Packages.bz2"' in builder
assert "bz2.decompress(raw)" in builder
assert "Packages.xz" not in builder
assert "https://ftp.fau.de/termux/termux-main" in builder
assert "https://termux.librehat.com/apt/termux-main" in builder
assert "https://packages.termux.dev/apt/termux-main" in builder
assert "https://packages-cf.termux.dev/apt/termux-main" in builder
assert "https://mirrors.in.sahilister.net/termux/termux-main" in builder
assert "Repository unavailable; trying next mirror." in builder
assert 'versionName = "5.4.7"' in gradle
assert "versionCode = 23" in gradle
hosting = (root / "app/src/main/java/com/pockethost/server/HostingService.kt").read_text()
assert "resolveDirectoryIndex" in hosting and '"index.php"' in hosting
assert 'php.absolutePath, "-n", "-S"' in php
assert "pthreads CLI-server incompatibility" in php
assert "APK root assets found:" in db
print("PocketHost v5.4.6 source smoke checks: PASS")
