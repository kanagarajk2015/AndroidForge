## v5.4.6 update

- Fixed header version: now reads installed APK version dynamically rather than hardcoded v5.4.0.
- Bumped Android versionCode to 21 and versionName to 5.4.6.
- Retains v5.4.4 MariaDB Termux package index and APK verification fixes.
- GitHub Actions artifact name updated to v5.4.6.
- APK installation and PHP/MariaDB runtime behavior still require device testing.

# PocketHost Server v5.0 — Android starter

An Android-hosted **local static website server** and a GitHub Actions APK build pipeline.
Designed as the foundation for the PocketHost project. No Termux is required.

## Current implemented scope
- Android foreground service keeps the HTTP server active while the app is backgrounded (subject to Android battery/background restrictions).
- HTTP server listens on port `8080` on the device network interfaces.
- Serves files from the app's private `files/www` directory.
- Creates a default `index.html` on first launch.
- Basic path traversal protection and GET/HEAD-only request handling.
- Simple control panel with Start / Stop and website folder creation.
- GitHub Actions builds a debug APK on push or manual workflow dispatch.

## Not implemented in this starter
PHP execution, MySQL/MariaDB daemon, Python, Rust, Ruby, FTP, multi-tenant cPanel, registrar integration, authoritative DNS, public certificate issuance, automatic backups, and public internet ingress are **not included**. The dashboard deliberately reports these as unavailable instead of pretending they work.

## Build on GitHub
1. Create a repository named `PocketHostServer` (or upload this folder to your existing repository).
2. Push the contents to the `main` branch.
3. Open **Actions → Build PocketHost Android APK → Run workflow**.
4. Download the `PocketHostServer-debug` artifact from the completed workflow.
5. Install the APK on your Android phone.

You can also build locally with JDK 17 and Gradle:
```bash
gradle :app:assembleDebug
```

## Test the static server
1. Install and open the app.
2. Tap **Start server**.
3. From the phone, open `http://127.0.0.1:8080`.
4. From another device on the same Wi-Fi, open `http://PHONE_LAN_IP:8080` if the router/firewall allows device-to-device traffic.

## Important deployment constraints
- Android may stop long-running work due to battery optimization, thermal limits, memory pressure, or vendor power management. Keep the app unrestricted in battery settings for longer sessions.
- A public hosting service needs a stable public ingress endpoint. Most mobile networks use carrier-grade NAT and block inbound ports; port forwarding on Wi-Fi does not solve mobile-network CGNAT.
- A real hosting platform needs isolated per-site processes/containers, resource limits, authentication, abuse controls, database lifecycle management, and security patching. Do not expose this starter server directly to the public internet.
- Domain registration and nameserver delegation require a registrar or DNS provider. TLS certificates require a publicly reachable validation path or DNS challenge and secure private-key storage.
- MySQL is a server daemon, not the same as Android's built-in SQLite database.

## Next engineering milestones
1. Bundle and validate an ARM64 PHP runtime and FastCGI process manager.
2. Add MariaDB only after proving a stable ARM64 Android build, data durability, backup and recovery.
3. Add isolated Python/Ruby runtimes and a Rust toolchain (large storage and memory footprint).
4. Add authenticated admin API, per-site users, quotas, logs, backups and file uploads.
5. Add a public ingress/tunnel or a remote Linux host for domains, DNS and HTTPS.
6. Implement the cPanel-style UI only after the backend services are real and secured.

## Security
This is a development starter, not a production shared-hosting platform. Do not put confidential or customer data on it.


## v5.1 app dashboard upgrade
- Native in-app dashboard with Dashboard / Websites / Files navigation.
- Create multiple isolated static site folders.
- Browse each site's top-level files, create new files, upload files through Android document picker, edit text-based web files, and delete files.
- Preview a site inside the app using an embedded WebView.
- Site URLs use `http://127.0.0.1:8080/<site-name>/`.

The file manager stores files in the app's private storage. Uninstalling the app removes this private data unless separately exported/backed up. The editor intentionally limits editable file types and file size to avoid loading large/binary files into memory.

PHP and database files may be uploaded/stored but are not executed. PHP/MySQL and other language runtimes remain future milestones.


## v5.2 — experimental PHP 8.4 runtime
- Dashboard includes an on-demand PHP 8.4 ARM64 runtime installer.
- Downloads the pinned Android ARM64 PHP package from the PMMP PHP-Binaries release and verifies its SHA-256 before extraction.
- Extracts into app-private `files/php-runtime` (not inside `www`, so existing sites are preserved).
- Checks the PHP executable with `php -v` before marking installation complete.
- Requests for `.php` files are proxied to a per-website PHP built-in server bound to `127.0.0.1`; PHP source is never served as a static file when the runtime is unavailable.
- PHP server processes are stopped when the hosting foreground service is stopped.

### PHP v5.2 limitations and safety
- This is an experimental ARM64 runtime integration. The PMMP distribution is built for PocketMine-MP and is not a general-purpose hosting-certified PHP package. Extension availability and compatibility with arbitrary PHP apps must be tested on the target phone.
- The runtime installer and process launch have not been device-tested in this build environment. The app must pass the GitHub Actions build and then be tested on the target Android phone.
- PHP scripts run with the Android app's UID and are not isolated from each other. Do not run untrusted PHP code or expose this development server to the public internet.
- No MySQL/MariaDB server is included. PHP database extensions are not a substitute for a database daemon.
- The PHP package release repository is archived upstream; the URL and SHA-256 are pinned so package changes cannot silently alter the download.


## v5.2.1 — PHP archive extraction fix
- Fixes the installer failure reported as `Unsafe path in PHP archive`.
- Normalizes standard `./` tar entry prefixes while rejecting absolute archive entry paths and `..` traversal.
- Safely retains only relative symlinks whose resolved targets remain inside the private extraction directory; skips unsafe optional links rather than aborting the whole install.
- Hard links are retained only when their archive-relative target is inside the extraction root and already exists.
- The official PHP archive SHA-256 remains pinned and verified before extraction.


## v5.2.2 — executable permission fix
- Explicitly sets the PHP CLI binary executable bit before the `php -v` verification and after final installation.
- Uses Android `Os.chmod` as a fallback when Java `File.setExecutable` does not persist the mode.
- Reports a clear storage execution-permission error if Android still refuses to execute the binary.
- Existing site storage remains outside the PHP runtime directory.


## v5.2.3 — Android native-library PHP packaging
- Root cause of `error=13 Permission denied`: modern Android blocks execution of downloaded binaries from writable app-private data directories (W^X / SELinux policy). `chmod` cannot override that policy.
- PHP executable is now staged by GitHub Actions into `app/src/main/jniLibs/arm64-v8a/libphp.so` before APK compilation.
- All `.so` dependencies are staged in the same ABI directory and extracted by Android Package Manager into `ApplicationInfo.nativeLibraryDir`.
- Manifest enables `android:extractNativeLibs="true"` and Gradle enables legacy JNI library extraction.
- App now executes PHP only from `nativeLibraryDir`; the runtime installer no longer downloads or tries to execute binaries from `filesDir`.
- PHP configuration/resources are packaged as assets and copied to app-private storage; executable code remains in the APK-managed native library directory.
- ARM64-only APK target for the requested Motorola Edge 50 Fusion.
- GitHub Actions verifies the published SHA-256 before unpacking the release.
- Existing website data remains in `filesDir/www` and is not deleted by this migration.

### v5.2.3 validation notes
The source and workflow are prepared, but a real GitHub Actions build and on-device `php -v` test are still required. The PMMP PHP build is a PocketMine-oriented distribution; extension availability and compatibility with ordinary PHP hosting workloads must be tested. Do not expose PHP sites publicly until process isolation and security controls exist.


### v5.2.3 UI behavior
- PHP runtime is now included during GitHub Actions APK packaging; the app no longer downloads executable code at runtime.
- Dashboard button changes to **Test PHP 8.4** and is enabled only when the APK contains the ARM64 native executable.


## v5.2.4 — enforce PHP APK inclusion and diagnostics
- PHP CLI discovery no longer depends on archive executable mode bits; workflow explicitly chmods the discovered binary before staging.
- GitHub Actions now fails if the PHP CLI is missing, if the staged executable is empty, or if `lib/arm64-v8a/libphp.so` is absent from the final APK.
- Dashboard reports the app's actual `nativeLibraryDir` and the files Android extracted there, making stale APKs or packaging failures diagnosable.
- Bumped versionCode/versionName to 11 / 5.2.4.


## v5.2.5 — PHP archive discovery and APK proof
- Root-cause hypothesis: the earlier workflow searched only regular files named `php`/`php7`, which can miss symlinked PHP launchers or differently versioned executable names. The new workflow resolves symlinks and selects an ARM64 ELF CLI by file type.
- Prints archive members and all PHP-like files when discovery fails.
- Verifies ARM64 ELF headers before staging.
- Preserves the PHP executable during native-library packaging.
- Verifies the final APK contains `lib/arm64-v8a/libphp.so`, extracts it from the APK and checks its ELF header and size.
- Uploads APK plus native-library and extracted-APK diagnostics in one artifact.
- Dashboard diagnostic uses actual line breaks.
- Version bumped to 5.2.5 / versionCode 12.
- Must still be verified by a successful GitHub Actions run and a new installation on the Android phone.


## v5.3.0 — Download PHP into app-private storage
- Removes the previous PHP-in-APK native-library packaging workflow.
- Adds on-demand download of the Android ARM64 PHP 8.4 runtime from the published PMMP PHP-Binaries release (archived upstream, checksum pinned).
- Pins the published SHA-256 checksum and verifies the archive before extraction.
- Safely extracts the runtime to `filesDir/php-runtime`, rejecting absolute paths and `..` traversal.
- Executes the Bionic-linked PHP CLI through `/system/bin/linker64` instead of directly exec'ing a writable app-data binary. This follows the Android `system_linker_exec` compatibility technique documented by Termux; it is Android-specific and may be unsuitable for Google Play policy.
- The PHP built-in web server is launched through the same linker path and proxied by the existing NanoHTTPD site server.
- Existing website directories remain in `filesDir/www` and are not removed or migrated.
- GitHub Actions builds the ordinary APK and verifies that PHP is not bundled inside it.
- Runtime package is PocketMine-MP's Android PHP build; extension/module availability is checked on-device using `php -m`. It may not provide every extension needed for generic hosting, especially MySQL, until verified.


## v5.3.1 — Shared phone storage access
- Adds Android Storage Access Framework folder selection via `OpenDocumentTree`.
- Persists read/write access to the user-selected folder across app restarts.
- Supports importing the selected folder's files into the currently selected website.
- Supports exporting a website into `Selected folder/PocketHost/<website-name>/`.
- Uses `DocumentFile`; does not request broad `MANAGE_EXTERNAL_STORAGE` or legacy storage permissions.
- Existing app-private website storage remains the live hosting root; shared-folder access is explicit import/export, not an automatic move.
- User must select Downloads or another folder manually in Android's folder picker.
- PHP runtime/linker compatibility is separate and remains unverified; this storage change does not fix the PHP `unexpected e_type: 2` error.


## v5.3.3 — PHP runtime verification UI
- Dashboard no longer treats the presence of `libphp.so` as proof PHP executes.
- PHP starts in an unverified state when the bundled ELF is detected.
- Adds an actionable Test PHP 8.4 button that runs the existing `php -v` self-test.
- Shows verified/failed output from the actual process result.
- Allows retesting after a successful check.
- Does not alter website files, shared-folder permissions, or the bundled PHP binary.
- MySQL, Python, Rust, and Ruby remain unimplemented in this release.


## v5.4.0 — experimental MariaDB database manager
- Adds a MariaDB database tab with Start / Stop, create database, list databases, refresh and delete actions.
- Uses the Termux aarch64 MariaDB package and resolves its declared runtime dependencies from the Termux stable ARM64 package index. The upstream package recipe describes MariaDB as a drop-in MySQL server and lists its runtime dependencies.
- GitHub Actions downloads each package over HTTPS, verifies the SHA-256 recorded in the package index, extracts the Termux prefix and bundles it as an app asset. MariaDB package version is pinned to `2:13.0.2`; the workflow intentionally fails if upstream changes that version.
- App verifies the generated runtime archive SHA-256 before safe extraction into app-private storage.
- Launches the ARM64 PIE daemon using Android's `/system/bin/linker64`, with Termux runtime libraries and environment paths.
- Database daemon binds only to `127.0.0.1:3306`; it is not exposed to Wi-Fi/LAN.
- Initializes MariaDB with normal root authentication, generates an administrator password and stores it encrypted using Android Keystore AES-GCM.
- Database names are validated before SQL execution. System schemas cannot be deleted.
- Each new database gets a restricted `127.0.0.1` database user with a generated password. Credentials are displayed once after creation; passwords are encrypted at rest with Android Keystore AES-GCM.
- PHP dashboard checks for `mysqli` and `pdo_mysql`; extension availability is reported, not assumed.
- This is experimental and is not yet a production-ready MySQL hosting service. MariaDB binary startup, initialization, JDBC authentication, PHP extension compatibility, persistence and device lifecycle must be tested on the target Android device. No claim of a successful Android build or phone test is made until GitHub Actions and the device test pass.
- Existing PHP runtime, website files and shared-storage selection are preserved by this source update. Database files live separately under app-private `files/mariadb-data`.


## v5.4.1 — fix missing MariaDB runtime asset
- Fixes the runtime builder's ELF magic check: it now compares the actual four ELF bytes (`0x7f 45 4c 46`) instead of a literal backslash sequence.
- Makes the app report a clear build/package instruction if `mariadb-rootfs.tar.gz` or its checksum is missing.
- Adds a Gradle `preBuild` verification task so a broken APK cannot be produced when the runtime assets were not generated.
- Adds CI checks that both MariaDB assets are actually packaged inside the APK.
- Bumps Android version to 5.4.1 / versionCode 17.


## v5.4.2 — automatic MariaDB runtime generation
- Fixes the AndroidForge generic-build failure where Gradle reached `verifyMariaDbAssets` before the MariaDB archive had been generated.
- Adds a Gradle `buildMariaDbRuntime` Exec task that runs `python3 scripts/build_mariadb_rootfs.py` automatically from the repository root.
- Makes `verifyMariaDbAssets` depend on runtime generation; direct Gradle builds now prepare the required assets without relying on a project-specific GitHub Actions workflow.
- Bumps Android version to 5.4.2 / versionCode 18.


## v5.4.3 — Termux repository mirror fallback
- Fixes the v5.4.2 build failure caused by HTTP 404 from the configured Cloudflare Termux package-index URL.
- Tries the official primary Termux repository first, then the official Cloudflare endpoint, then the documented India mirror.
- Uses the same repository that supplied the package index for all package downloads, preserving consistent package metadata and SHA-256 verification.
- Reports each unavailable repository and a useful final error if every source fails.
- Bumps Android version to 5.4.3 / versionCode 19.


## v5.4.4 — Termux package index format correction
- Fixes v5.4.3: the build log showed HTTP 404 from every configured mirror because the script requested `Packages.xz`, which is not published by the current Termux main repository directory.
- Downloads `Packages.bz2` and decodes it with Python's `bz2` module.
- Adds the FAU and Librehat Termux mirrors as additional fallbacks.
- Keeps package SHA-256 validation and version pinning.
- Bumps Android version to 5.4.4 / versionCode 20.


## v5.4.6 fixes
- PHP site server first launches with `-n` to avoid php.ini auto-loading the pthreads extension, which rejects the PHP CLI-server SAPI.
- Website root and directory routing now resolves `index.php` before `index.html` and `index.htm`.
- MariaDB asset-open failures now report the APK's root asset inventory and the underlying exception, rather than an unhelpful generic missing-package message.
- Version code 22 / version name 5.4.6.

## v5.4.7 — MariaDB runtime asset lookup
- MariaDB now accepts either `assets/mariadb-rootfs.tar.gz` or a bare `assets/mariadb-rootfs.tar`. A phone APK was seen with only the bare name, which caused "Expected mariadb-rootfs.tar.gz" even though the build log produced the .gz file.
- The archive format is detected from its gzip magic bytes, not the file name. The SHA-256 check against `mariadb-rootfs.sha256` still runs before extraction.
- Not fixed in this release: PHP web serving. The bundled PHP is a CLI-only build (see the notes below). The v5.4.6 `php -S` approach cannot run on it.
- Version code 23 / version name 5.4.7.

### Known PHP limitation (found during v5.4.7 review)
- The bundled PMMP PHP 8.4 Android build is configured with `--enable-cli`, `--disable-cgi`, `--disable-session`, and `--enable-pmmpthread` (statically linked). The `cli-server` SAPI is therefore unavailable, because pmmpthread refuses it. `-n` cannot skip a statically linked extension.
- The CLI SAPI discards `header()` and `setcookie()` output (`headers_list()` is empty), so a CLI-per-request bridge would lose `Location` and `Set-Cookie`. Login redirects and sessions would break.
- PHP web hosting needs a PHP build with a CGI or FPM SAPI and the session extension.
