package com.pockethost.server

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLConnection

class HostingService : Service() {
    private var server: SiteServer? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification())
        val root = File(filesDir, "www").apply { mkdirs() }
        server = SiteServer(root, PhpRuntimeManager(this)).also {
            it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
        }
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        server?.stop()
        server?.stopPhp()
        server = null
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "PocketHost server", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("PocketHost is hosting")
            .setContentText("Local web server listening on port 8080")
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setOngoing(true)
            .build()

    private class SiteServer(
        private val root: File,
        private val php: PhpRuntimeManager
    ) : NanoHTTPD("0.0.0.0", 8080) {

        fun stopPhp() = php.stopAll()

        override fun serve(session: IHTTPSession): Response {
            if (session.method != Method.GET && session.method != Method.HEAD &&
                session.method != Method.POST && session.method != Method.PUT &&
                session.method != Method.DELETE && session.method != Method.OPTIONS) {
                return newFixedLengthResponse(Response.Status.METHOD_NOT_ALLOWED, MIME_PLAINTEXT, "Method not allowed")
            }

            val raw = session.uri.substringBefore('?')
            val decoded = try { java.net.URLDecoder.decode(raw, "UTF-8") } catch (_: Exception) { "/" }
            if (decoded.contains("..") || decoded.contains('\\') || decoded.startsWith("//")) {
                return newFixedLengthResponse(Response.Status.FORBIDDEN, MIME_PLAINTEXT, "Forbidden")
            }

            val segments = decoded.trim('/').split('/').filter { it.isNotBlank() }
            val first = segments.firstOrNull().orEmpty()
            val possibleSite = File(root, first)
            val siteDir = if (first.isNotBlank() && possibleSite.isDirectory) possibleSite else root
            val relativePath = if (siteDir == root) decoded else "/" + segments.drop(1).joinToString("/")
            val requested = if (relativePath == "/" || relativePath.isBlank()) {
                resolveDirectoryIndex(siteDir)
            } else {
                File(siteDir, relativePath.removePrefix("/"))
            }
            val file = if (requested.isDirectory) resolveDirectoryIndex(requested) else requested

            val canonicalRoot = root.canonicalFile.toPath()
            val canonicalSite = siteDir.canonicalFile.toPath()
            val canonicalFile = file.canonicalFile.toPath()
            if (!canonicalSite.startsWith(canonicalRoot) || !canonicalFile.startsWith(canonicalSite)) {
                return newFixedLengthResponse(Response.Status.FORBIDDEN, MIME_PLAINTEXT, "Forbidden")
            }

            if (file.extension.equals("php", ignoreCase = true)) {
                return servePhp(session, siteDir, relativePath)
            }
            if (!file.isFile) return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "404 - Not Found")

            val mime = URLConnection.guessContentTypeFromName(file.name) ?: "application/octet-stream"
            val response = newChunkedResponse(Response.Status.OK, mime, FileInputStream(file))
            response.addHeader("X-Content-Type-Options", "nosniff")
            response.addHeader("Cache-Control", "no-store")
            return response
        }

        private fun resolveDirectoryIndex(directory: File): File {
            // PHP sites commonly contain index.php rather than index.html.
            return listOf("index.php", "index.html", "index.htm")
                .asSequence()
                .map { File(directory, it) }
                .firstOrNull { it.isFile }
                ?: File(directory, "index.html")
        }

        private fun servePhp(session: IHTTPSession, siteDir: File, path: String): Response {
            val port = try {
                php.startSiteServer(siteDir)
            } catch (e: Exception) {
                return newFixedLengthResponse(
                    Response.Status.SERVICE_UNAVAILABLE,
                    "text/plain; charset=utf-8",
                    "PHP runtime unavailable: ${e.message ?: "install PHP 8.4 from the PocketHost dashboard"}"
                )
            }

            var connection: HttpURLConnection? = null
            return try {
                val query = session.queryParameterString?.takeIf { it.isNotBlank() }?.let { "?$it" } ?: ""
                val targetPath = if (path.isBlank()) "/" else path
                connection = (URL("http://127.0.0.1:$port$targetPath$query").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5000
                    readTimeout = 30000
                    requestMethod = session.method.name
                    instanceFollowRedirects = false
                    session.headers.forEach { (key, value) ->
                        if (!key.equals("host", true) && !key.equals("connection", true) &&
                            !key.equals("content-length", true)) {
                            setRequestProperty(key, value)
                        }
                    }
                }

                val requestBody = if (session.method == Method.POST || session.method == Method.PUT) {
                    val parsed = HashMap<String, String>()
                    session.parseBody(parsed)
                    parsed["postData"]?.toByteArray(Charsets.UTF_8) ?: ByteArray(0)
                } else ByteArray(0)

                if (requestBody.isNotEmpty()) {
                    connection.doOutput = true
                    connection.setFixedLengthStreamingMode(requestBody.size)
                    connection.outputStream.use { it.write(requestBody) }
                }

                val status = connection.responseCode
                val body = if (status >= 400) connection.errorStream else connection.inputStream
                val contentType = connection.contentType ?: "text/html; charset=utf-8"
                val responseStatus = Response.Status.lookup(status) ?: Response.Status.INTERNAL_ERROR
                val response = if (body != null) newChunkedResponse(responseStatus, contentType, body)
                    else newFixedLengthResponse(responseStatus, contentType, "")
                connection.headerFields.forEach { (key, values) ->
                    if (key != null && values != null && key.lowercase() !in
                        setOf("content-length", "transfer-encoding", "connection")) {
                        values.firstOrNull()?.let { response.addHeader(key, it) }
                    }
                }
                response.addHeader("X-Content-Type-Options", "nosniff")
                response
            } catch (e: Exception) {
                newFixedLengthResponse(
                    Response.Status.INTERNAL_ERROR,
                    "text/plain; charset=utf-8",
                    "PHP request failed: ${e.message ?: "unknown error"}"
                )
            } finally {
                // The response stream owns the connection until NanoHTTPD finishes reading it.
                // Disconnect is intentionally not called here.
            }
        }
    }

    companion object {
        @Volatile var isRunning: Boolean = false
            private set
        private const val CHANNEL_ID = "pockethost_server"
        private const val NOTIFICATION_ID = 5100
    }
}