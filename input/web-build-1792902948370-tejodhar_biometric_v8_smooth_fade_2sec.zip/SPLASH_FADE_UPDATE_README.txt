TEJODHAR BIOMETRIC V8 — 2 SECOND SPLASH FADE-IN

Updated:
- MainActivity.java: Android splash screen view now fades in over 2 seconds before revealing the existing app content.
- Keeps the existing LaunchActivity and biometric authentication code intact.
- Keeps the existing manifest, app configuration, and other project files intact.

Build:
1. Upload/extract this ZIP in your GitHub repository.
2. Commit the updated source.
3. Run the repository's existing Android build workflow from GitHub Actions.
4. Download the APK from the successful workflow artifact.

Important:
- This ZIP contains Android source; it is not a compiled APK.
- The build has not been run or verified in this environment.
