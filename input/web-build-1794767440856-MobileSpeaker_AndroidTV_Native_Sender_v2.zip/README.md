# Mobile Speaker – Android TV to Android Phone (v2.0)

This project contains **two native Android apps**:

1. `app` – install on the Android phone. It receives audio over the local Wi-Fi network and plays it through the phone speaker.
2. `tv` – install on the Android TV (Android 10/API 29 or newer; designed for Android 14). It requests Android's playback-capture permission and streams captured PCM audio to the phone.

The old browser sender has been removed from the recommended setup. The TV app uses Android `MediaProjection` consent plus `AudioPlaybackCapture` and a local WebSocket connection. Both devices must be connected to the same Wi-Fi network.

## Install and use

1. Build both APKs using GitHub Actions (steps below).
2. Install `app-debug.apk` on the Android phone.
3. Install `tv-debug.apk` on the Android TV. If the TV does not show it in the Play Store, use the TV's supported APK installation method / USB installer.
4. Connect the phone and TV to the same Wi-Fi network.
5. Open **Mobile Speaker** on the phone and tap **START WI-FI SPEAKER**. Keep it open. Note the phone IP address shown on screen.
6. Open **Mobile Speaker TV Sender** on the TV. Enter the phone IP address and press **ALLOW AUDIO & CONNECT**.
7. Approve the Android system audio-capture prompt. Audio that Android allows to be captured will play through the phone speaker.
8. To stop, press **STOP SENDING** on the TV; stop the receiver on the phone by closing the app.

## Important Android limitation

Android playback capture is controlled by the source app. An app can opt out of playback capture, and protected/DRM content may not be captured. Therefore this project **cannot guarantee all audio from every TV app**, including every YouTube or streaming-app playback scenario. The Android system consent prompt is required, and some TV firmware may disable playback capture. This is an Android platform restriction, not a network setting that this app can bypass.

The phone receiver uses local network port `8765`. Use only on a trusted private Wi-Fi network. This starter implementation does not provide network encryption or authentication. Do not expose port 8765 to the public internet.

## GitHub Actions build (no local computer required)

1. Upload the contents of this ZIP to a GitHub repository (keep the `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Mobile Speaker Apps** and tap **Run workflow** (or push to `main`).
4. When the run finishes, download both artifacts:
   - `MobileSpeaker-Phone-Receiver-APK`
   - `MobileSpeaker-AndroidTV-Sender-APK`
5. Install each APK on the matching device.

## Build configuration

- JDK 17; Java/Kotlin JVM targets aligned to 17.
- Android Gradle Plugin 8.7.3; Gradle 8.9.
- Phone app: min SDK 26 (Android 8.0), compile SDK 35, target SDK 35.
- TV sender: min SDK 29 (Android 10), compile SDK 35, target SDK 34 for Android 14 media-projection foreground-service compatibility.
- No Termux required. No prebuilt APK is included; GitHub Actions builds both APKs.

## Troubleshooting

- **TV cannot connect:** confirm both devices are on the same Wi-Fi (not guest Wi-Fi), restart the phone receiver, and re-enter the current phone IP. Keep port 8765 available on the local network.
- **Connected but silent:** start actual playback on the TV; check phone media volume; verify that the TV's system capture permission was approved. The source app may block capture.
- **TV says capture not available:** some TV manufacturers disable playback capture in their firmware. The app cannot override that OS restriction.
- **Phone IP changed:** restart the phone receiver and enter its newly displayed IP on the TV.
