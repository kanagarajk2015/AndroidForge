package com.tejodhar.mobilespeakertv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom
import java.security.MessageDigest
import java.util.Base64
import kotlin.concurrent.thread

class CaptureService : Service() {
    @Volatile private var running = false
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var socket: Socket? = null
    private val channelId = "mobile_speaker_capture"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_NOT_STICKY
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(77, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(77, buildNotification())
        }
        val ip = intent?.getStringExtra(EXTRA_PHONE_IP).orEmpty()
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                   else intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        if (ip.isBlank() || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        thread(name = "tv-audio-capture") { capture(ip, code, data) }
        return START_NOT_STICKY
    }

    private fun capture(ip: String, resultCode: Int, data: Intent) {
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            val p = projection ?: error("Android did not provide audio capture permission")
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopCapture() }
            }, android.os.Handler(mainLooper))

            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            val config = AudioPlaybackCaptureConfiguration.Builder(p)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            recorder = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes((min * 4).coerceAtLeast(16384))
                .setAudioPlaybackCaptureConfig(config)
                .build()
            if (recorder?.state != AudioRecord.STATE_INITIALIZED) error("TV audio recorder could not start")

            socket = Socket().apply { connect(InetSocketAddress(ip, PHONE_PORT), 8000); soTimeout = 0; tcpNoDelay = true }
            val output = BufferedOutputStream(socket!!.getOutputStream())
            val input = BufferedInputStream(socket!!.getInputStream())
            openWebSocket(output, input)
            recorder?.startRecording()
            val buffer = ByteArray(4096)
            while (running) {
                val count = recorder?.read(buffer, 0, buffer.size) ?: -1
                if (count < 0) error("TV audio capture read failed: $count")
                if (count > 0) sendBinary(output, buffer, count)
            }
        } catch (e: Exception) {
            Log.e(TAG, "TV audio stream stopped", e)
        } finally {
            stopCapture()
        }
    }

    private fun openWebSocket(out: BufferedOutputStream, input: BufferedInputStream) {
        val keyBytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val key = Base64.getEncoder().encodeToString(keyBytes)
        val request = "GET /stream HTTP/1.1\r\nHost: ${socket?.inetAddress?.hostAddress}:$PHONE_PORT\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: $key\r\nSec-WebSocket-Version: 13\r\n\r\n"
        out.write(request.toByteArray(Charsets.US_ASCII)); out.flush()
        val response = StringBuilder()
        var matched = 0
        while (response.length < 8192) {
            val ch = input.read()
            if (ch < 0) error("Phone closed the connection during handshake")
            response.append(ch.toChar())
            matched = when {
                matched == 0 && ch == 13 -> 1
                matched == 1 && ch == 10 -> 2
                matched == 2 && ch == 13 -> 3
                matched == 3 && ch == 10 -> 4
                ch == 13 -> 1
                else -> 0
            }
            if (matched == 4) break
        }
        if (!response.toString().startsWith("HTTP/1.1 101")) error("Phone receiver did not accept the stream: $response")
        val expected = Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1").digest((key + WS_GUID).toByteArray()))
        if (!response.contains(expected)) error("Invalid WebSocket handshake from phone")
    }

    private fun sendBinary(out: BufferedOutputStream, data: ByteArray, count: Int) {
        out.write(0x82)
        when {
            count < 126 -> out.write(0x80 or count)
            count <= 65535 -> { out.write(0x80 or 126); out.write((count ushr 8) and 255); out.write(count and 255) }
            else -> { out.write(0x80 or 127); for (i in 7 downTo 0) out.write((count.toLong() ushr (i * 8)).toInt() and 255) }
        }
        val mask = ByteArray(4).also { SecureRandom().nextBytes(it) }
        out.write(mask)
        val chunk = ByteArray(count)
        for (i in 0 until count) chunk[i] = (data[i].toInt() xor mask[i % 4].toInt()).toByte()
        out.write(chunk); out.flush()
    }

    @Synchronized private fun stopCapture() {
        if (!running && recorder == null && socket == null && projection == null) return
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { stopCapture(); super.onDestroy() }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "TV audio sharing", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return Notification.Builder(this, channelId)
            .setContentTitle("Mobile Speaker TV")
            .setContentText("Capturing permitted TV audio for your phone")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        const val EXTRA_PHONE_IP = "phone_ip"
        private const val PHONE_PORT = 8765
        private const val SAMPLE_RATE = 44100
        private const val WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
        private const val TAG = "MobileSpeakerTV"
    }
}
