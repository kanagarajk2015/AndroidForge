package com.tejodhar.mobilespeakertv

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class TvMainActivity : Activity() {
    private lateinit var phoneIp: EditText
    private lateinit var status: TextView
    private val projectionRequest = 4102
    private val audioPermissionRequest = 4103

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 28, 36, 28)
            setBackgroundColor(0xFF10213D.toInt())
        }
        root.addView(TextView(this).apply {
            text = "MOBILE SPEAKER TV"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }, match(LinearLayout.LayoutParams.MATCH_PARENT, -2))
        root.addView(TextView(this).apply {
            text = "Send supported TV audio to your Android phone over Wi-Fi"
            textSize = 17f
            setTextColor(0xFFE4ECFA.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 22)
        }, match(LinearLayout.LayoutParams.MATCH_PARENT, -2))
        phoneIp = EditText(this).apply {
            hint = "Phone IP address (example: 192.168.1.20)"
            singleLine = true
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFB8C7DD.toInt())
            setPadding(16, 12, 16, 12)
            setBackgroundColor(0xFF263B5B.toInt())
        }
        root.addView(phoneIp, match(LinearLayout.LayoutParams.MATCH_PARENT, -2))
        val start = Button(this).apply {
            text = "ALLOW AUDIO & CONNECT"
            textSize = 16f
            setOnClickListener { beginCapture() }
        }
        root.addView(start, match(LinearLayout.LayoutParams.MATCH_PARENT, -2).apply { topMargin = 18 })
        root.addView(Button(this).apply {
            text = "STOP SENDING"
            setOnClickListener { stopService(Intent(this@TvMainActivity, CaptureService::class.java)); status.text = "Stopped" }
        }, match(LinearLayout.LayoutParams.MATCH_PARENT, -2))
        status = TextView(this).apply {
            text = "1. Start Wi-Fi Speaker on your phone.\n2. Enter the phone IP shown there.\n3. Press Allow Audio and approve Android's capture prompt."
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(status, match(LinearLayout.LayoutParams.MATCH_PARENT, -2))
        setContentView(root)
    }

    private fun beginCapture() {
        val ip = phoneIp.text.toString().trim()
        if (ip.isBlank()) {
            Toast.makeText(this, "Enter the phone IP address", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        requestProjection(ip)
    }

    private fun requestProjection(ip: String) {
        getPreferences(MODE_PRIVATE).edit().putString("phone_ip", ip).apply()
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    @Deprecated("Uses the platform MediaProjection consent result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_RESULT_DATA, data)
                    putExtra(CaptureService.EXTRA_PHONE_IP, getPreferences(MODE_PRIVATE).getString("phone_ip", ""))
                }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
                status.text = "Connecting to phone… Keep this app running."
            } else status.text = "Audio capture permission was cancelled."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            requestProjection(phoneIp.text.toString().trim())
        } else if (requestCode == audioPermissionRequest) {
            status.text = "Microphone/audio permission is required by Android for playback capture."
        }
    }

    private fun match(width: Int, height: Int) = LinearLayout.LayoutParams(width, height)
}
