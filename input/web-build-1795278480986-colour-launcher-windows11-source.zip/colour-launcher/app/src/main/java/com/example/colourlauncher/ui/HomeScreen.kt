package com.example.colourlauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.example.colourlauncher.DOCK_CAPACITY
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.data.LauncherStyle
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

/** How far the user must swipe up on the dock to open the app drawer. */
private val SwipeUpDistance = 48.dp

private val TimeFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val DateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM")
private val OxygenTimeFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("HH : mm")

/** Grid items for home cells are keyed "cell:N", so a drag can tell which cell an item is. */
private const val CellKeyPrefix = "cell:"

private fun cellKey(index: Int): String = CellKeyPrefix + index

private fun cellIndexOf(key: Any?): Int? =
    (key as? String)?.takeIf { it.startsWith(CellKeyPrefix) }?.removePrefix(CellKeyPrefix)?.toIntOrNull()

/**
 * The home screen: clock, a grid of app cells, and the dock.
 *
 * [homePackages] holds one entry per cell, in reading order. A null entry is an empty cell.
 */
@Composable
fun HomeScreen(
    apps: List<LauncherApp>,
    homePackages: List<String?>,
    dockPackages: List<String>,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenControls: () -> Unit,
    arranging: Boolean = false,
    onDrop: (packageName: String, slot: Int) -> Unit = { _, _ -> },
    onDoneArranging: () -> Unit = {},
    runningPackages: Set<String> = emptySet(),
) {
    val settings = LocalLauncherSettings.current
    val columns = settings.columns
    // Pastel Glow sits on a pale background, so its home screen text is dark.
    val labelColor = if (settings.style == LauncherStyle.PastelGlow && settings.showArtwork) PastelInk else Color.White
    // Dragging up past the bottom of the grid (or on a grid that fits the screen) opens the drawer.
    val pullUp = rememberPullConnection(upward = true, threshold = 64.dp, onTrigger = onOpenDrawer)
    // Dragging down from the top of the home screen opens the quick controls.
    val pullDown = rememberPullConnection(upward = false, threshold = 64.dp, onTrigger = onOpenControls)
    val appsByPackage = remember(apps) { apps.associateBy { it.packageName } }
    val dockApps = dockPackages.mapNotNull { appsByPackage[it] }

    // Rows needed for every icon. The grid below also grows to fill the whole display.
    val appRows = (homePackages.size + columns - 1) / columns
    // An empty cell is as tall as an icon with its padding and, if shown, its label.
    val labelHeight = if (settings.showLabels) 38 else 16
    val cellHeight = (settings.iconSizeDp + labelHeight).dp

    // Arranging state. The dragged icon follows the finger and only moves into a cell when dropped.
    val gridState = rememberLazyGridState()
    val currentOnDrop by rememberUpdatedState(onDrop)
    val currentOpenSettings by rememberUpdatedState(onOpenSettings)
    var draggingPackage by remember { mutableStateOf<String?>(null) }
    var dragStart by remember { mutableStateOf(Offset.Zero) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    var hoverSlot by remember { mutableStateOf<Int?>(null) }

    // The cell under a point in grid coordinates, or null if no visible cell is there.
    fun cellAt(point: Offset): Int? {
        for (info in gridState.layoutInfo.visibleItemsInfo) {
            val index = cellIndexOf(info.key) ?: continue
            val left = info.offset.x
            val top = info.offset.y
            if (point.x >= left && point.x < left + info.size.width &&
                point.y >= top && point.y < top + info.size.height
            ) {
                return index
            }
        }
        return null
    }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
        // Enough rows to cover the whole display, so an icon can be dropped anywhere on it.
        // The header is estimated, and the Windows 11 style has none. While arranging, one spare
        // row lets an icon go below the last one when the icons already fill the screen.
        val headerHeight = if (settings.style == LauncherStyle.Windows11) 0.dp else 110.dp
        val screenRows = ((maxHeight - 16.dp - headerHeight) / cellHeight).toInt()
        val fillRows = maxOf(appRows, screenRows)
        val cellCount = (if (arranging && fillRows == appRows) fillRows + 1 else fillRows) * columns

        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            state = gridState,
            modifier = Modifier
                .fillMaxSize()
                // Pull gestures would compete with a drag, so they are off while arranging.
                .then(if (arranging) Modifier else Modifier.nestedScroll(pullUp).nestedScroll(pullDown)),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        ) {
            // The Windows 11 style shows the clock in its taskbar and the gear in the Start menu.
            // While arranging, a hint and a Done button replace the clock.
            if (arranging) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    ArrangeBar(onDone = onDoneArranging, ink = labelColor)
                }
            } else if (settings.style.themed) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    ThemedHeader(style = settings.style, onOpenSettings = onOpenSettings)
                }
            } else if (settings.style != LauncherStyle.Windows11) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    ClockHeader(
                        onOpenSettings = onOpenSettings,
                        oxygen = settings.style == LauncherStyle.OxygenOS,
                    )
                }
            }

            if (homePackages.none { it != null }) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        text = stringResource(R.string.home_empty_hint),
                        color = labelColor,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }

            items(count = cellCount, key = { cellKey(it) }) { index ->
                val app = homePackages.getOrNull(index)?.let { appsByPackage[it] }
                if (arranging) {
                    val isDragging = app != null && app.packageName == draggingPackage
                    val isTarget = draggingPackage != null && hoverSlot == index
                    Box(
                        modifier = Modifier
                            .height(cellHeight)
                            .fillMaxWidth()
                            .zIndex(if (isDragging) 1f else 0f)
                            .graphicsLayer {
                                if (isDragging) {
                                    translationX = dragOffset.x
                                    translationY = dragOffset.y
                                    scaleX = 1.1f
                                    scaleY = 1.1f
                                }
                            }
                            .background(
                                if (isTarget) Color.White.copy(alpha = 0.18f) else Color.Transparent,
                                RoundedCornerShape(20.dp),
                            )
                            .then(
                                if (app == null) {
                                    Modifier
                                } else {
                                    Modifier.pointerInput(index, app.packageName) {
                                        detectDragGestures(
                                            onDragStart = {
                                                draggingPackage = app.packageName
                                                dragOffset = Offset.Zero
                                                // Centre of the dragged cell, in grid coordinates.
                                                dragStart = gridState.layoutInfo.visibleItemsInfo
                                                    .firstOrNull { cellIndexOf(it.key) == index }
                                                    ?.let { info ->
                                                        Offset(
                                                            info.offset.x + info.size.width / 2f,
                                                            info.offset.y + info.size.height / 2f,
                                                        )
                                                    } ?: Offset.Zero
                                                hoverSlot = index
                                            },
                                            onDrag = { change, amount ->
                                                change.consume()
                                                dragOffset += amount
                                                hoverSlot = cellAt(dragStart + dragOffset)
                                            },
                                            onDragEnd = {
                                                val target = hoverSlot
                                                val packageName = draggingPackage
                                                if (packageName != null && target != null) {
                                                    currentOnDrop(packageName, target)
                                                }
                                                draggingPackage = null
                                                dragOffset = Offset.Zero
                                                hoverSlot = null
                                            },
                                            onDragCancel = {
                                                draggingPackage = null
                                                dragOffset = Offset.Zero
                                                hoverSlot = null
                                            },
                                        )
                                    }
                                },
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (app != null) AppIcon(app = app, onClick = {}, onLongClick = {}, labelColor = labelColor)
                    }
                } else if (app != null) {
                    AppIcon(
                        app = app,
                        onClick = { onLaunch(app.packageName) },
                        onLongClick = { onLongPress(app) },
                        labelColor = labelColor,
                    )
                } else {
                    // Long press on empty space opens the settings, where icon options live.
                    Spacer(
                        Modifier
                            .height(cellHeight)
                            .fillMaxWidth()
                            .pointerInput(Unit) { detectTapGestures(onLongPress = { currentOpenSettings() }) },
                    )
                }
            }
        }
        }

        if (settings.style == LauncherStyle.Windows11) {
            Taskbar(
                apps = dockApps,
                runningPackages = runningPackages,
                onLaunch = onLaunch,
                onLongPress = onLongPress,
                onStart = onOpenDrawer,
                onOpenControls = onOpenControls,
            )
        } else {
            DockBar(
                apps = dockApps,
                onLaunch = onLaunch,
                onLongPress = onLongPress,
                onOpenDrawer = onOpenDrawer,
            )
        }
    }
}

/** Shown above the grid while arranging icons. */
@Composable
private fun ArrangeBar(onDone: () -> Unit, ink: Color) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, top = 24.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = stringResource(R.string.arrange_hint),
            style = MaterialTheme.typography.titleMedium.copy(
                shadow = if (ink == PastelInk) null else LauncherTextShadow,
            ),
            color = ink,
            modifier = Modifier.weight(1f),
        )
        Button(onClick = onDone) { Text(stringResource(R.string.arrange_done)) }
    }
}

@Composable
private fun ClockHeader(onOpenSettings: () -> Unit, oxygen: Boolean = false) {
    val now by produceState(initialValue = LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(10_000L)
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 8.dp, top = 24.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            if (oxygen) {
                // OxygenOS 16 clock card: bold serif time on a white plate, label underneath.
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = Color.White,
                    shadowElevation = 6.dp,
                ) {
                    Text(
                        text = now.format(OxygenTimeFormat),
                        style = MaterialTheme.typography.displaySmall,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF111111),
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    )
                }
                Text(
                    text = now.format(DateFormat),
                    style = MaterialTheme.typography.labelLarge.copy(shadow = LauncherTextShadow),
                    color = Color.White,
                    modifier = Modifier.padding(start = 12.dp, top = 6.dp),
                )
            } else {
                Text(
                    text = now.format(TimeFormat),
                    style = MaterialTheme.typography.displayLarge.copy(shadow = LauncherTextShadow),
                    color = Color.White,
                    fontWeight = FontWeight.Light,
                )
                Text(
                    text = now.format(DateFormat),
                    style = MaterialTheme.typography.titleMedium.copy(shadow = LauncherTextShadow),
                    color = Color.White,
                )
            }
        }
        IconButton(onClick = onOpenSettings) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = stringResource(R.string.settings_open),
                tint = Color.White,
            )
        }
    }
}

/**
 * Up to [DOCK_CAPACITY] apps in a rounded panel. Swiping up on the dock, or tapping
 * the handle beneath it, opens the app drawer.
 */
@Composable
private fun DockBar(
    apps: List<LauncherApp>,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    onOpenDrawer: () -> Unit,
) {
    val style = LocalLauncherSettings.current.style
    val oxygen = style == LauncherStyle.OxygenOS
    val pastel = style == LauncherStyle.PastelGlow
    val ink = dockInk(style, LocalLauncherSettings.current.showArtwork)
    val iconSize = LocalLauncherSettings.current.iconSizeDp.dp
    val haptics = LocalHapticFeedback.current
    val swipeThreshold = with(LocalDensity.current) { SwipeUpDistance.toPx() }
    val currentOpenDrawer by rememberUpdatedState(onOpenDrawer)
    var dragTotal by remember { mutableFloatStateOf(0f) }
    val dockShape = RoundedCornerShape(28.dp)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .pointerInput(swipeThreshold) {
                detectVerticalDragGestures(
                    onDragStart = { dragTotal = 0f },
                    onDragEnd = {
                        if (dragTotal < -swipeThreshold) {
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            currentOpenDrawer()
                        }
                    },
                ) { _, dragAmount -> dragTotal += dragAmount }
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (oxygen || pastel) {
            // Page indicator, as on OxygenOS and Pastel Glow. Decorative: the launcher has a single home page.
            Row(
                modifier = Modifier.padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                repeat(4) { i ->
                    Box(
                        Modifier
                            .size(7.dp)
                            .background(ink.copy(alpha = if (i == 0) 1f else 0.4f), CircleShape),
                    )
                }
            }
        }

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                // Each style's dock panel. OxygenOS has no panel: its icons float on the wallpaper.
                .then(if (oxygen) Modifier else Modifier.themedDockPanel(style, dockShape)),
            shape = dockShape,
            color = Color.Transparent,
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = if (oxygen) 4.dp else 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                for (slot in 0 until DOCK_CAPACITY) {
                    val app = apps.getOrNull(slot)
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        if (app != null) {
                            AppIcon(
                                app = app,
                                showLabel = false,
                                dock = true,
                                onClick = { onLaunch(app.packageName) },
                                onLongClick = { onLongPress(app) },
                            )
                        } else {
                            // An empty slot is a faint outline. Tapping it opens the app drawer, where a long press adds an app.
                            val slotShape = RoundedCornerShape(18.dp)
                            Box(
                                modifier = Modifier
                                    .size(iconSize * 0.86f)
                                    .clip(slotShape)
                                    .border(1.dp, ink.copy(alpha = 0.28f), slotShape)
                                    .clickable(onClickLabel = stringResource(R.string.all_apps), onClick = onOpenDrawer),
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(4.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .clickable(onClickLabel = stringResource(R.string.all_apps), onClick = onOpenDrawer),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier
                    .size(width = if (oxygen) 130.dp else 40.dp, height = if (oxygen) 4.dp else 5.dp)
                    .clip(CircleShape)
                    .background(ink.copy(alpha = 0.85f)),
            )
        }
    }
}
