package com.pockethost.server

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var webRoot: File
    private var selectedSite by mutableStateOf("")
    private var sharedTreeUri by mutableStateOf<Uri?>(null)

    private val chooseSharedFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        uri?.let {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            runCatching { contentResolver.takePersistableUriPermission(it, flags) }
            sharedTreeUri = it
            getSharedPreferences("pockethost", MODE_PRIVATE).edit().putString("shared_tree_uri", it.toString()).apply()
            messageForStorage = "Shared folder selected"
        }
    }

    private var messageForStorage by mutableStateOf("")

    private val importFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { copyIntoSelectedSite(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webRoot = File(filesDir, "www").apply { mkdirs() }
        val index = File(webRoot, "index.html")
        if (!index.exists()) index.writeText(defaultHtml("PocketHost is running", "Your first website is online on this device."))
        selectedSite = webRoot.listFiles()?.firstOrNull { it.isDirectory }?.name ?: ""
        sharedTreeUri = getSharedPreferences("pockethost", MODE_PRIVATE)
            .getString("shared_tree_uri", null)?.let { runCatching { Uri.parse(it) }.getOrNull() }
        setContent { PocketHostApp() }
    }

    private fun copyIntoSelectedSite(uri: Uri) {
        if (selectedSite.isBlank()) return
        val name = queryDisplayName(uri).replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (name.isBlank() || name == "." || name == "..") return
        val destination = File(File(webRoot, selectedSite), name)
        contentResolver.openInputStream(uri)?.use { input ->
            destination.outputStream().use { output -> input.copyTo(output) }
        }
        refreshCounter++
    }

    private fun queryDisplayName(uri: Uri): String {
        var name = "upload_${System.currentTimeMillis()}"
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        return name
    }

    private var refreshCounter by mutableIntStateOf(0)

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun PocketHostApp() {
        var tab by remember { mutableStateOf("Dashboard") }
        var running by remember { mutableStateOf(HostingService.isRunning) }
        var showCreateSite by remember { mutableStateOf(false) }
        var newSiteName by remember { mutableStateOf("") }
        var showCreateFile by remember { mutableStateOf(false) }
        var newFileName by remember { mutableStateOf("index.html") }
        var editorFile by remember { mutableStateOf<File?>(null) }
        var editorText by remember { mutableStateOf("") }
        var previewSite by remember { mutableStateOf<String?>(null) }
        var message by remember { mutableStateOf("") }
        val phpManager = remember { PhpRuntimeManager(this@MainActivity) }
        var phpStatus by remember { mutableStateOf(phpManager.status) }
        var phpInstalled by remember { mutableStateOf(phpManager.isInstalled) }
        var phpInstalling by remember { mutableStateOf(false) }
        var storageBusy by remember { mutableStateOf(false) }

        val sharedFolderLabel = remember(sharedTreeUri) {
            sharedTreeUri?.let { DocumentFile.fromTreeUri(this@MainActivity, it)?.name } ?: "Not selected"
        }

        val sites = remember(refreshCounter) { webRoot.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name } ?: emptyList() }
        if (selectedSite.isBlank() && sites.isNotEmpty()) selectedSite = sites.first().name
        val siteDir = selectedSite.takeIf { it.isNotBlank() }?.let { File(webRoot, it) }

        MaterialTheme {
            Scaffold(
                topBar = {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp)) {
                        Text("PocketHost", style = MaterialTheme.typography.headlineMedium)
                        Text("Android hosting control panel • v5.3.1", style = MaterialTheme.typography.bodySmall)
                    }
                },
                bottomBar = {
                    NavigationBar {
                        listOf("Dashboard", "Websites", "Files").forEach { item ->
                            NavigationBarItem(
                                selected = tab == item,
                                onClick = { tab = item },
                                icon = { Text(when(item) { "Dashboard" -> "⌂"; "Websites" -> "▤"; else -> "▧" }) },
                                label = { Text(item) }
                            )
                        }
                    }
                }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                    when (tab) {
                        "Dashboard" -> {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text(if (running) "Server RUNNING" else "Server STOPPED", style = MaterialTheme.typography.titleLarge)
                                    Text("Local URL: http://127.0.0.1:8080")
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = {
                                            ContextCompat.startForegroundService(this@MainActivity,
                                                Intent(this@MainActivity, HostingService::class.java))
                                            running = true
                                        }, enabled = !running) { Text("Start") }
                                        OutlinedButton(onClick = {
                                            stopService(Intent(this@MainActivity, HostingService::class.java))
                                            running = false
                                        }, enabled = running) { Text("Stop") }
                                    }
                                }
                            }
                            Spacer(Modifier.height(16.dp))
                            Text("Hosting overview", style = MaterialTheme.typography.titleLarge)
                            StatRow("Websites", sites.size.toString())
                            StatRow("Web server", "Static HTTP • port 8080")
                            StatRow("Storage", "App-private + selected shared folder")
                            Text("Shared storage", style = MaterialTheme.typography.titleMedium)
                            Text("Selected folder: $sharedFolderLabel", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { chooseSharedFolder.launch(sharedTreeUri) }) {
                                    Text(if (sharedTreeUri == null) "Choose shared folder" else "Change folder")
                                }
                            }
                            if (messageForStorage.isNotBlank()) Text(messageForStorage, style = MaterialTheme.typography.bodySmall)
                            Text("PHP runtime", style = MaterialTheme.typography.titleMedium)
                            Text(phpStatus, style = MaterialTheme.typography.bodySmall)
                            Text(phpManager.diagnostic(), style = MaterialTheme.typography.bodySmall)
                            Button(
                                enabled = !phpInstalling && !phpInstalled,
                                onClick = {
                                    phpInstalling = true
                                    phpStatus = "Checking bundled PHP…"
                                    phpManager.install { _, result ->
                                        runOnUiThread {
                                            phpStatus = result
                                            phpInstalled = result.startsWith("PHP 8.4 ready")
                                            phpInstalling = false
                                        }
                                    }
                                }
                            ) { Text(if (phpInstalling) "Checking…" else if (phpInstalled) "PHP 8.4 Ready" else "Verify PHP 8.4") }
                            Text("MySQL / Python / Rust / Ruby: not installed",
                                style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(12.dp))
                            Text("PHP 8.4 is bundled in the APK (libphp.so) and executed directly from the app native library folder.",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        "Websites" -> {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Your websites", style = MaterialTheme.typography.titleLarge)
                                Button(onClick = { showCreateSite = true }) { Text("＋ Create") }
                            }
                            Spacer(Modifier.height(8.dp))
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(sites, key = { it.name }) { site ->
                                    Card(Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(site.name, style = MaterialTheme.typography.titleMedium)
                                            Text("http://127.0.0.1:8080/${site.name}/")
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                OutlinedButton(onClick = { selectedSite = site.name; tab = "Files" }) { Text("Manage files") }
                                                Button(onClick = { previewSite = site.name }) { Text("Preview") }
                                                TextButton(onClick = {
                                                    site.deleteRecursively()
                                                    if (selectedSite == site.name) selectedSite = sites.firstOrNull { it.name != site.name }?.name ?: ""
                                                    refreshCounter++
                                                }) { Text("Delete") }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else -> {
                            Text("File manager", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(8.dp))
                            if (sites.isNotEmpty()) {
                                var expanded by remember { mutableStateOf(false) }
                                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                                    OutlinedTextField(
                                        value = selectedSite, onValueChange = {}, readOnly = true,
                                        label = { Text("Website") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                                        modifier = Modifier.menuAnchor().fillMaxWidth()
                                    )
                                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                        sites.forEach { site ->
                                            DropdownMenuItem(text = { Text(site.name) }, onClick = {
                                                selectedSite = site.name; expanded = false
                                            })
                                        }
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { showCreateFile = true }) { Text("＋ New file") }
                                    OutlinedButton(onClick = { importFile.launch(arrayOf("*/*")) }) { Text("Upload file") }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { chooseSharedFolder.launch(sharedTreeUri) }) {
                                        Text(if (sharedTreeUri == null) "Choose folder" else "Change folder")
                                    }
                                    OutlinedButton(
                                        enabled = !storageBusy && sharedTreeUri != null && siteDir != null,
                                        onClick = {
                                            val uri = sharedTreeUri
                                            val target = siteDir
                                            if (uri != null && target != null) {
                                                storageBusy = true
                                                Thread {
                                                    val result = runCatching {
                                                        SharedStorageManager(this@MainActivity).importFolder(uri, target)
                                                    }
                                                    runOnUiThread {
                                                        storageBusy = false
                                                        refreshCounter++
                                                        messageForStorage = result.fold(
                                                            { "Imported ${it.files} files (${it.directories} folders)" },
                                                            { "Import failed: ${it.message}" }
                                                        )
                                                    }
                                                }.start()
                                            }
                                        }
                                    ) { Text(if (storageBusy) "Working…" else "Import folder") }
                                    OutlinedButton(
                                        enabled = !storageBusy && sharedTreeUri != null && siteDir != null,
                                        onClick = {
                                            val uri = sharedTreeUri
                                            val source = siteDir
                                            if (uri != null && source != null) {
                                                storageBusy = true
                                                Thread {
                                                    val result = runCatching {
                                                        SharedStorageManager(this@MainActivity).exportWebsite(source, uri)
                                                    }
                                                    runOnUiThread {
                                                        storageBusy = false
                                                        messageForStorage = result.fold(
                                                            { "Exported ${it.files} files (${it.directories} folders) to shared storage" },
                                                            { "Export failed: ${it.message}" }
                                                        )
                                                    }
                                                }.start()
                                            }
                                        }
                                    ) { Text("Export website") }
                                }
                                if (messageForStorage.isNotBlank()) Text(messageForStorage, style = MaterialTheme.typography.bodySmall)
                                Text("Path: ${siteDir?.absolutePath ?: ""}", style = MaterialTheme.typography.bodySmall)
                                val children = remember(refreshCounter, selectedSite) {
                                    siteDir?.listFiles()?.sortedBy { it.name } ?: emptyList()
                                }
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    items(children, key = { it.absolutePath }) { file ->
                                        ListItem(
                                            headlineContent = { Text(file.name) },
                                            supportingContent = { Text(if (file.isDirectory) "Folder" else "${file.length()} bytes") },
                                            trailingContent = {
                                                Row {
                                                    if (file.isFile && file.length() < 1_000_000 &&
                                                        file.extension.lowercase() in listOf("html","htm","css","js","txt","json","php","py","rb","rs")) {
                                                        TextButton(onClick = {
                                                            editorFile = file
                                                            editorText = file.readText()
                                                        }) { Text("Edit") }
                                                    }
                                                    TextButton(onClick = { file.deleteRecursively(); refreshCounter++ }) { Text("Delete") }
                                                }
                                            }
                                        )
                                        HorizontalDivider()
                                    }
                                }
                            } else {
                                Text("Create a website first to manage its files.")
                                Button(onClick = { tab = "Websites"; showCreateSite = true }) { Text("Create website") }
                            }
                        }
                    }
                }
            }
        }

        if (showCreateSite) AlertDialog(
            onDismissRequest = { showCreateSite = false },
            title = { Text("Create website") },
            text = { OutlinedTextField(newSiteName, { newSiteName = it }, label = { Text("Website name") }) },
            confirmButton = {
                TextButton(onClick = {
                    val safe = newSiteName.trim().replace(Regex("[^A-Za-z0-9_-]"), "")
                    if (safe.isNotBlank() && safe != "." && safe != ".." && !File(webRoot, safe).exists()) {
                        val dir = File(webRoot, safe)
                        dir.mkdirs()
                        File(dir, "index.html").writeText(defaultHtml(safe, "Your website is ready. Upload or edit files in PocketHost."))
                        selectedSite = safe
                        refreshCounter++
                        message = "Website created"
                    } else message = "Enter a unique name using letters, numbers, _ or -"
                    showCreateSite = false; newSiteName = ""
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showCreateSite = false }) { Text("Cancel") } }
        )

        if (showCreateFile) AlertDialog(
            onDismissRequest = { showCreateFile = false },
            title = { Text("Create file") },
            text = { OutlinedTextField(newFileName, { newFileName = it }, label = { Text("File name") }) },
            confirmButton = {
                TextButton(onClick = {
                    val safe = newFileName.trim()
                    if (siteDir != null && safe.isNotBlank() && !safe.contains("/") && !safe.contains("\\") && safe != "." && safe != "..") {
                        val f = File(siteDir, safe)
                        if (!f.exists()) f.writeText(if (safe.endsWith(".html")) defaultHtml(safe.substringBefore('.'), "Edit this page in the file manager.") else "")
                        refreshCounter++
                    }
                    showCreateFile = false
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showCreateFile = false }) { Text("Cancel") } }
        )

        editorFile?.let { file ->
            AlertDialog(
                onDismissRequest = { editorFile = null },
                title = { Text("Edit ${file.name}") },
                text = {
                    OutlinedTextField(editorText, { editorText = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp, max = 420.dp),
                        label = { Text("File content") })
                },
                confirmButton = {
                    TextButton(onClick = {
                        runCatching { file.writeText(editorText) }
                        editorFile = null; refreshCounter++
                    }) { Text("Save") }
                },
                dismissButton = { TextButton(onClick = { editorFile = null }) { Text("Cancel") } }
            )
        }

        previewSite?.let { name ->
            AlertDialog(
                onDismissRequest = { previewSite = null },
                title = { Text("Preview: $name") },
                text = {
                    AndroidView(
                        factory = { context -> WebView(context).apply {
                            webViewClient = WebViewClient()
                            settings.javaScriptEnabled = true
                            loadUrl("http://127.0.0.1:8080/$name/")
                        } },
                        modifier = Modifier.fillMaxWidth().height(480.dp)
                    )
                },
                confirmButton = { TextButton(onClick = { previewSite = null }) { Text("Close") }
                }
            )
        }
        if (message.isNotBlank()) {
            LaunchedEffect(message) { kotlinx.coroutines.delay(1800); message = "" }
        }
    }

    @Composable
    private fun StatRow(label: String, value: String) {
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(value, style = MaterialTheme.typography.bodyMedium)
        }
    }

    private fun defaultHtml(title: String, description: String) =
        """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>$title</title></head><body style="font-family:Arial,sans-serif;padding:32px"><h1>$title</h1><p>$description</p></body></html>"""
}