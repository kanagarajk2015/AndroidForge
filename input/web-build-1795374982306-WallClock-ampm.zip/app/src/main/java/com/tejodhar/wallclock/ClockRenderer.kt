package com.tejodhar.wallclock

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.graphics.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws the clock shape as a white mask, then fills the mask with
 * wallpaper / solid / gradient / rainbow (DST_IN), so the wallpaper shows inside the digits.
 */
object ClockRenderer {

    fun render(ctx: Context, s: ClockSettings, cal: Calendar, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        if (s.card) {
            val cp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000 }
            c.drawRoundRect(0f, 0f, w.toFloat(), h.toFloat(), h * 0.16f, h * 0.16f, cp)
        }

        val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val batt = if (s.style == ClockStyle.BATTERY) batteryLevel(ctx) else 0
        val plugged = s.style == ClockStyle.BATTERY && isPlugged(ctx)

        // 12-hour clocks get an AM/PM label in a strip on the right; the clock lays out in the rest.
        val amPm = if (!s.is24 && showsTime(s.style)) {
            if (cal.get(Calendar.HOUR_OF_DAY) < 12) "AM" else "PM"
        } else null
        val edge = h * 0.04f
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            textSize = h * 0.13f
        }
        val labelW = if (amPm != null) labelPaint.measureText("PM") + 2 * edge else 0f
        val contentW = w - labelW.toInt()

        val mc = Canvas(mask)
        drawClock(mc, s, cal, contentW, h, maskColor(s.style), batt, plugged = plugged)
        if (s.style == ClockStyle.GLASS) drawClock(mc, s, cal, contentW, h, Color.WHITE, batt, outline = h * 0.012f)
        if (amPm != null) {
            labelPaint.color = maskColor(s.style)
            labelPaint.textAlign = Paint.Align.RIGHT
            val fm = labelPaint.fontMetrics
            mc.drawText(amPm, w - edge, h / 2f - (fm.ascent + fm.descent) / 2f, labelPaint)
        }
        if (s.style == ClockStyle.HOLOGRAPHIC) scanlines(mc, w, h)

        when (s.style) {
            ClockStyle.NEON -> glow(c, mask, h, if (s.fill == FillMode.SOLID) s.solid else Color.WHITE)
            ClockStyle.THREE_D -> extrude(c, mask, h)
            ClockStyle.FLOATING -> hover(c, mask, h)
            else -> if (s.shadow) dropShadow(c, mask, h)
        }

        val fill = makeFill(ctx, s, w, h)
        val dstIn = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
        Canvas(fill).drawBitmap(mask, 0f, 0f, dstIn)
        c.drawBitmap(fill, 0f, 0f, null)
        mask.recycle()
        fill.recycle()
        return out
    }

    private fun batteryLevel(ctx: Context): Int {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l < 0 || sc <= 0) 0 else l * 100 / sc
    }

    /** True while any charger (AC, USB or wireless) is connected. */
    private fun isPlugged(ctx: Context): Boolean {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
    }

    /** Lightning bolt filling the box (x, y, w, h). */
    private fun boltPath(x: Float, y: Float, w: Float, h: Float): Path = Path().apply {
        moveTo(x + 0.70f * w, y)
        lineTo(x + 0.20f * w, y + 0.56f * h)
        lineTo(x + 0.48f * w, y + 0.56f * h)
        lineTo(x + 0.30f * w, y + h)
        lineTo(x + 0.80f * w, y + 0.44f * h)
        lineTo(x + 0.52f * w, y + 0.44f * h)
        close()
    }

    private fun makeFill(ctx: Context, s: ClockSettings, w: Int, h: Int): Bitmap {
        if (s.style == ClockStyle.LUXURY_GOLD || s.style == ClockStyle.HOLOGRAPHIC) return styledFill(s, w, h)
        if (s.fill == FillMode.WALLPAPER) {
            return WallpaperSource.load(ctx, s, w, h).copy(Bitmap.Config.ARGB_8888, true)
        }
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        when (s.fill) {
            FillMode.SOLID -> p.color = s.solid
            FillMode.GRADIENT -> {
                val g = Palettes.gradients[s.grad.coerceIn(0, Palettes.gradients.size - 1)]
                p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), g, null, Shader.TileMode.CLAMP)
            }
            else -> p.shader = LinearGradient(0f, 0f, w.toFloat(), 0f, Palettes.rainbow, null, Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        return b
    }

    // ---------- helpers ----------

    private fun bounds(p: Paint, t: String): Rect = Rect().also { p.getTextBounds(t, 0, t.length, it) }

    private fun fit(p: Paint, ref: String, maxW: Float, maxH: Float, k: Float): Float {
        p.textSize = 100f
        val b = bounds(p, ref)
        val sc = min(maxW / b.width(), maxH / b.height())
        return 100f * sc * k
    }

    private fun xFor(a: ClockAlign, w: Int, pad: Float, tw: Float): Float = when (a) {
        ClockAlign.LEFT -> pad
        ClockAlign.CENTER -> (w - tw) / 2f
        ClockAlign.RIGHT -> w - pad - tw
    }

    private fun circleCx(a: ClockAlign, w: Int, pad: Float, r: Float): Float = when (a) {
        ClockAlign.LEFT -> pad + r
        ClockAlign.CENTER -> w / 2f
        ClockAlign.RIGHT -> w - pad - r
    }

    private fun put(c: Canvas, p: Paint, t: String, ref: String, a: ClockAlign, w: Int, pad: Float, cy: Float) {
        val b = bounds(p, t)
        val r = bounds(p, ref)
        val x = xFor(a, w, pad, b.width().toFloat()) - b.left
        val base = cy - (r.top + r.bottom) / 2f
        c.drawText(t, x, base, p)
    }

    // ---------- style effects and fills ----------

    /** Styles that show a time, so an AM/PM label applies. */
    private fun showsTime(style: ClockStyle): Boolean = when (style) {
        ClockStyle.MONTH, ClockStyle.DAY, ClockStyle.BATTERY, ClockStyle.AMPM -> false
        else -> true
    }

    /** Mask colour: translucent for the see-through styles, opaque otherwise. */
    private fun maskColor(style: ClockStyle): Int = when (style) {
        ClockStyle.TRANSPARENT -> 0x66FFFFFF
        ClockStyle.GLASS -> 0x59FFFFFF
        else -> Color.WHITE
    }

    private fun dropShadow(c: Canvas, mask: Bitmap, h: Int) {
        val blur = Paint().apply {
            maskFilter = BlurMaskFilter(max(2f, h * 0.015f), BlurMaskFilter.Blur.NORMAL)
        }
        val off = IntArray(2)
        val alpha = mask.extractAlpha(blur, off)
        val sp = Paint().apply { color = 0xB3000000L.toInt() }
        c.drawBitmap(alpha, off[0].toFloat(), off[1] + h * 0.012f, sp)
        alpha.recycle()
    }

    /** Coloured halo behind the digits. */
    private fun glow(c: Canvas, mask: Bitmap, h: Int, tint: Int) {
        val blur = Paint().apply { maskFilter = BlurMaskFilter(h * 0.07f, BlurMaskFilter.Blur.NORMAL) }
        val off = IntArray(2)
        val g = mask.extractAlpha(blur, off)
        val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tint
            alpha = 200
        }
        c.drawBitmap(g, off[0].toFloat(), off[1].toFloat(), gp)
        g.recycle()
    }

    /** Stacked dark copies behind the digits, giving a solid 3D depth. */
    private fun extrude(c: Canvas, mask: Bitmap, h: Int) {
        val off = IntArray(2)
        val a = mask.extractAlpha(null, off)
        val sp = Paint().apply { color = 0xFF1A1A1A.toInt() }
        val step = h * 0.006f
        for (i in 6 downTo 1) {
            c.drawBitmap(a, off[0] + i * step, off[1] + i * step, sp)
        }
        a.recycle()
    }

    /** Soft shadow dropped well below the digits, as if they hover. */
    private fun hover(c: Canvas, mask: Bitmap, h: Int) {
        val blur = Paint().apply { maskFilter = BlurMaskFilter(h * 0.05f, BlurMaskFilter.Blur.NORMAL) }
        val off = IntArray(2)
        val a = mask.extractAlpha(blur, off)
        val sp = Paint().apply { color = 0x80000000L.toInt() }
        c.drawBitmap(a, off[0].toFloat(), off[1] + h * 0.08f, sp)
        a.recycle()
    }

    /** Erases thin horizontal lines from the mask for a scan-line look. */
    private fun scanlines(mc: Canvas, w: Int, h: Int) {
        val clear = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
        val step = max(3f, h / 60f)
        var y = step
        while (y < h) {
            mc.drawRect(0f, y, w.toFloat(), y + max(1f, step * 0.3f), clear)
            y += step
        }
    }

    private val goldStops = intArrayOf(
        0xFFFFF1B8.toInt(), 0xFFD4AF37.toInt(), 0xFF7A5B17.toInt(), 0xFFE9C46A.toInt(), 0xFFB8862B.toInt()
    )
    private val holoStops = intArrayOf(
        0xFF7FF7FF.toInt(), 0xFFFF7FD4.toInt(), 0xFFFFF59A.toInt(), 0xFF9AFFCF.toInt(),
        0xFFB59CFF.toInt(), 0xFF7FF7FF.toInt()
    )

    /** Fixed gold or holographic fill, used by the two material styles. */
    private fun styledFill(s: ClockSettings, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = if (s.style == ClockStyle.LUXURY_GOLD) {
            LinearGradient(0f, 0f, 0f, h.toFloat(), goldStops, null, Shader.TileMode.CLAMP)
        } else {
            LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), holoStops, null, Shader.TileMode.CLAMP)
        }
        Canvas(b).drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        return b
    }

    /** Tapered hand from the centre. ang is clockwise from 12 o'clock, in radians. */
    private fun hand(c: Canvas, p: Paint, cx: Float, cy: Float, ang: Double, len: Float, baseW: Float, tipW: Float) {
        val dx = sin(ang).toFloat()
        val dy = -cos(ang).toFloat()
        val nx = -dy
        val ny = dx
        val path = Path().apply {
            moveTo(cx + nx * baseW / 2f, cy + ny * baseW / 2f)
            lineTo(cx + dx * len + nx * tipW / 2f, cy + dy * len + ny * tipW / 2f)
            lineTo(cx + dx * len - nx * tipW / 2f, cy + dy * len - ny * tipW / 2f)
            lineTo(cx - nx * baseW / 2f, cy - ny * baseW / 2f)
            close()
        }
        p.style = Paint.Style.FILL
        c.drawPath(path, p)
    }

    /** 5x7 dot-matrix glyphs; each row holds 5 bits, leftmost column in bit 4. */
    private val dotFont: Map<Char, IntArray> = mapOf(
        '0' to intArrayOf(0x0E, 0x11, 0x13, 0x15, 0x19, 0x11, 0x0E),
        '1' to intArrayOf(0x04, 0x0C, 0x04, 0x04, 0x04, 0x04, 0x0E),
        '2' to intArrayOf(0x0E, 0x11, 0x01, 0x02, 0x04, 0x08, 0x1F),
        '3' to intArrayOf(0x1F, 0x02, 0x04, 0x02, 0x01, 0x11, 0x0E),
        '4' to intArrayOf(0x02, 0x06, 0x0A, 0x12, 0x1F, 0x02, 0x02),
        '5' to intArrayOf(0x1F, 0x10, 0x1E, 0x01, 0x01, 0x11, 0x0E),
        '6' to intArrayOf(0x06, 0x08, 0x10, 0x1E, 0x11, 0x11, 0x0E),
        '7' to intArrayOf(0x1F, 0x01, 0x02, 0x04, 0x08, 0x08, 0x08),
        '8' to intArrayOf(0x0E, 0x11, 0x11, 0x0E, 0x11, 0x11, 0x0E),
        '9' to intArrayOf(0x0E, 0x11, 0x11, 0x0F, 0x01, 0x02, 0x0C),
        ':' to intArrayOf(0x00, 0x04, 0x04, 0x00, 0x04, 0x04, 0x00)
    )

    /** Seven-segment masks for 0-9; bits 0..6 are segments a..g. */
    private val sevenSegMasks = intArrayOf(0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F)

    /** One seven-segment digit. Unlit segments are drawn faint, like an LED display. */
    private fun sevenSeg(c: Canvas, p: Paint, x: Float, y: Float, dw: Float, dh: Float, t: Float, mask: Int) {
        val mid = y + dh / 2f
        val hw = t / 2f
        val segs = arrayOf(
            floatArrayOf(x + t, y, x + dw - t, y + t),
            floatArrayOf(x + dw - t, y + t, x + dw, mid - hw),
            floatArrayOf(x + dw - t, mid + hw, x + dw, y + dh - t),
            floatArrayOf(x + t, y + dh - t, x + dw - t, y + dh),
            floatArrayOf(x, mid + hw, x + t, y + dh - t),
            floatArrayOf(x, y + t, x + t, mid - hw),
            floatArrayOf(x + t, mid - hw, x + dw - t, mid + hw)
        )
        p.style = Paint.Style.FILL
        for (i in 0 until 7) {
            val lit = ((mask shr i) and 1) == 1
            p.alpha = if (lit) 255 else 40
            val seg = segs[i]
            c.drawRoundRect(seg[0], seg[1], seg[2], seg[3], t * 0.3f, t * 0.3f, p)
        }
    }

    // ---------- clock layouts ----------

    private fun drawClock(
        c: Canvas, s: ClockSettings, cal: Calendar, w: Int, h: Int, color: Int, batt: Int,
        outline: Float = 0f, plugged: Boolean = false
    ) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            typeface = Palettes.typeface(s.font)
        }
        if (outline > 0f) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = outline
        }
        val pad = w * 0.05f
        val maxW = w - 2 * pad
        val maxH = h - 2 * pad
        val cy = h / 2f
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val h12 = if (hour % 12 == 0) 12 else hour % 12
        val hh = if (s.is24) hour.toString().padStart(2, '0') else h12.toString()
        val mm = cal.get(Calendar.MINUTE).toString().padStart(2, '0')

        when (s.style) {
            ClockStyle.DIGITAL, ClockStyle.GLASS, ClockStyle.TRANSPARENT, ClockStyle.NEON, ClockStyle.THREE_D,
            ClockStyle.LUXURY_GOLD, ClockStyle.FLOATING, ClockStyle.HOLOGRAPHIC -> {
                p.textSize = fit(p, "00:00", maxW, maxH, s.scale)
                put(c, p, "$hh:$mm", "00:00", s.align, w, pad, cy)
            }

            ClockStyle.STACKED -> {
                p.textSize = fit(p, "00", maxW, maxH * 0.46f, s.scale)
                val bh = bounds(p, "00").height()
                val off = bh / 2f + maxH * 0.03f
                put(c, p, hh.padStart(2, '0'), "00", s.align, w, pad, cy - off)
                put(c, p, mm, "00", s.align, w, pad, cy + off)
            }

            ClockStyle.BIG_HOUR -> {
                val gapF = 0.08f
                var hs = fit(p, "00", maxW * 0.62f, maxH, s.scale)
                fun totalW(size: Float): Float {
                    p.textSize = size
                    val a = bounds(p, hh).width()
                    p.textSize = size * 0.42f
                    val b = bounds(p, mm).width()
                    return a + b + size * gapF
                }
                var tw = totalW(hs)
                if (tw > maxW) {
                    hs *= maxW / tw
                    tw = totalW(hs)
                }
                p.textSize = hs
                val bh = bounds(p, hh)
                val ref = bounds(p, "00")
                val x0 = xFor(s.align, w, pad, tw)
                val base = cy - (ref.top + ref.bottom) / 2f
                c.drawText(hh, x0 - bh.left, base, p)
                p.textSize = hs * 0.42f
                val bm = bounds(p, mm)
                c.drawText(mm, x0 + bh.width() + hs * gapF - bm.left, base, p)
            }

            ClockStyle.DATE -> {
                p.textSize = fit(p, "00:00", maxW, maxH * 0.62f, s.scale)
                val bt = bounds(p, "00:00").height()
                val dp = Paint(p).apply {
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    letterSpacing = 0.12f
                }
                val dateRef = "WED, 28 MAY"
                val dateText = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(cal.time).uppercase()
                dp.textSize = min(p.textSize * 0.34f, fit(dp, dateRef, maxW, maxH * 0.2f, s.scale))
                val bd = bounds(dp, dateRef).height()
                val gap = maxH * 0.06f
                val top = cy - (bt + gap + bd) / 2f
                put(c, p, "$hh:$mm", "00:00", s.align, w, pad, top + bt / 2f)
                put(c, dp, dateText, dateRef, s.align, w, pad, top + bt + gap + bd / 2f)
            }

            ClockStyle.DAY -> {
                p.textSize = fit(p, "00", maxW, maxH * 0.62f, s.scale)
                val bt = bounds(p, "00").height()
                val dp = Paint(p).apply {
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    letterSpacing = 0.12f
                }
                val ref = "WED \u00B7 MAY"
                val txt = SimpleDateFormat("EEE '\u00B7' MMM", Locale.getDefault()).format(cal.time).uppercase()
                dp.textSize = min(p.textSize * 0.34f, fit(dp, ref, maxW, maxH * 0.2f, s.scale))
                val bd = bounds(dp, ref).height()
                val gap = maxH * 0.06f
                val top = cy - (bt + gap + bd) / 2f
                put(c, p, cal.get(Calendar.DAY_OF_MONTH).toString(), "00", s.align, w, pad, top + bt / 2f)
                put(c, dp, txt, ref, s.align, w, pad, top + bt + gap + bd / 2f)
            }

            ClockStyle.BATTERY -> {
                p.textSize = fit(p, "100%", maxW, maxH * 0.66f, s.scale)
                val bt = bounds(p, "100%").height()
                val txt = "$batt%"
                val tw = bounds(p, txt).width().toFloat()
                val barH = maxH * 0.12f
                val gap = maxH * 0.07f
                val top = cy - (bt + gap + barH) / 2f
                // While a charger is connected, a bolt sits in front of the percentage. Layout is
                // unchanged when unplugged: the bolt width is zero and the bar spans the text.
                val boltW = if (plugged) bt * 0.6f else 0f
                val boltGap = if (plugged) bt * 0.15f else 0f
                val totalW = boltW + boltGap + tw
                val x0 = xFor(s.align, w, pad, totalW)
                if (plugged) {
                    p.style = Paint.Style.FILL
                    c.drawPath(boltPath(x0, top, boltW, bt), p)
                }
                put(c, p, txt, "100%", ClockAlign.LEFT, w, x0 + boltW + boltGap, top + bt / 2f)
                val by = top + bt + gap
                val bp = Paint(p).apply { style = Paint.Style.FILL; alpha = 90 }
                c.drawRoundRect(x0, by, x0 + totalW, by + barH, barH / 2f, barH / 2f, bp)
                bp.alpha = 255
                c.drawRoundRect(x0, by, x0 + max(barH, totalW * batt / 100f), by + barH, barH / 2f, barH / 2f, bp)
            }

            ClockStyle.MONTH -> {
                val gridW = maxW * s.scale
                val x0 = xFor(s.align, w, pad, gridW)
                val titleH = maxH * 0.13f
                val rowH = (maxH - titleH) / 7f
                val cellW = gridW / 7f
                val top = pad
                p.textAlign = Paint.Align.CENTER
                fun baseAt(cyy: Float): Float {
                    val fm = p.fontMetrics
                    return cyy - (fm.ascent + fm.descent) / 2f
                }
                val title = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time).uppercase()
                p.textSize = fit(p, "SEPTEMBER 2026", gridW, titleH * 0.7f, 1f)
                c.drawText(title, x0 + gridW / 2f, baseAt(top + titleH / 2f), p)

                val firstDow = cal.firstDayOfWeek
                val letters = "SMTWTFS"
                p.textSize = min(rowH * 0.5f, cellW * 0.5f)
                p.alpha = 130
                for (i in 0 until 7) {
                    c.drawText(
                        letters[(firstDow - 1 + i) % 7].toString(),
                        x0 + cellW * (i + 0.5f), baseAt(top + titleH + rowH * 0.5f), p
                    )
                }

                val first = cal.clone() as Calendar
                first.set(Calendar.DAY_OF_MONTH, 1)
                val off = (first.get(Calendar.DAY_OF_WEEK) - firstDow + 7) % 7
                val dim = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
                val today = cal.get(Calendar.DAY_OF_MONTH)
                p.textSize = min(rowH * 0.58f, cellW * 0.6f)
                for (d in 1..dim) {
                    val idx = off + d - 1
                    val cx = x0 + cellW * ((idx % 7) + 0.5f)
                    val cyy = top + titleH + rowH * ((idx / 7) + 1.5f)
                    if (d == today) {
                        p.alpha = 255
                        p.style = Paint.Style.STROKE
                        p.strokeWidth = rowH * 0.06f
                        c.drawCircle(cx, cyy, min(rowH, cellW) * 0.46f, p)
                        p.style = Paint.Style.FILL
                    } else {
                        p.alpha = 170
                    }
                    c.drawText(d.toString(), cx, baseAt(cyy), p)
                }
            }

            ClockStyle.WORDS -> {
                val names = arrayOf("TWELVE", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "ELEVEN")
                var r5 = ((cal.get(Calendar.MINUTE) + 2) / 5) * 5
                var hr = hour
                if (r5 == 60) { r5 = 0; hr += 1 }
                if (r5 > 30) hr += 1
                val hw = names[hr % 12]
                val mins = when (r5) {
                    5 -> "FIVE PAST"
                    10 -> "TEN PAST"
                    15 -> "QUARTER PAST"
                    20 -> "TWENTY PAST"
                    25 -> "TWENTY FIVE PAST"
                    30 -> "HALF PAST"
                    35 -> "TWENTY FIVE TO"
                    40 -> "TWENTY TO"
                    45 -> "QUARTER TO"
                    50 -> "TEN TO"
                    55 -> "FIVE TO"
                    else -> ""
                }
                val l1 = if (mins.isEmpty()) hw else mins
                val l2 = if (mins.isEmpty()) "O'CLOCK" else hw
                p.letterSpacing = 0.04f
                p.textSize = fit(p, "TWENTY FIVE PAST", maxW, maxH * 0.46f, s.scale)
                val bh = bounds(p, "TWENTY").height()
                val off = bh / 2f + maxH * 0.03f
                put(c, p, l1, "TWENTY", s.align, w, pad, cy - off)
                put(c, p, l2, "TWENTY", s.align, w, pad, cy + off)
            }

            ClockStyle.BINARY -> {
                val hv = if (s.is24) hour else h12
                val minute = cal.get(Calendar.MINUTE)
                val digits = intArrayOf(hv / 10, hv % 10, minute / 10, minute % 10)
                val cell = min(maxH / 4f, maxW / 4.6f) * s.scale
                val x0 = xFor(s.align, w, pad, cell * 4.6f)
                p.style = Paint.Style.FILL
                for (i in 0 until 4) {
                    val colX = x0 + cell * (i + 0.5f) + (if (i >= 2) cell * 0.6f else 0f)
                    for (row in 0 until 4) {
                        val bit = (digits[i] shr (3 - row)) and 1
                        p.alpha = if (bit == 1) 255 else 70
                        c.drawCircle(colX, cy + (row - 1.5f) * cell, cell * 0.38f, p)
                    }
                }
            }

            ClockStyle.SPLIT -> {
                val hh2 = hh.padStart(2, '0')
                var size = fit(p, "00", maxW * 0.46f, maxH, s.scale)
                fun tw(sz: Float): Float {
                    p.textSize = sz
                    return bounds(p, hh2).width() + bounds(p, mm).width() + sz * 0.4f
                }
                var total = tw(size)
                if (total > maxW) {
                    size *= maxW / total
                    total = tw(size)
                }
                p.textSize = size
                val bH = bounds(p, hh2)
                val bM = bounds(p, mm)
                val ref = bounds(p, "00")
                val x0 = xFor(s.align, w, pad, total)
                val base = cy - (ref.top + ref.bottom) / 2f
                c.drawText(hh2, x0 - bH.left, base, p)
                val sx = x0 + bH.width() + size * 0.2f
                c.drawCircle(sx, cy - size * 0.17f, size * 0.045f, p)
                c.drawCircle(sx, cy + size * 0.17f, size * 0.045f, p)
                c.drawText(mm, x0 + bH.width() + size * 0.4f - bM.left, base, p)
            }

            ClockStyle.ANALOG_NUM -> {
                val r = min(maxW, maxH) / 2f * s.scale
                val cx = circleCx(s.align, w, pad, r)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = r * 0.06f
                c.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
                p.style = Paint.Style.FILL
                p.textAlign = Paint.Align.CENTER
                p.textSize = r * 0.24f
                val fm = p.fontMetrics
                for (n in 1..12) {
                    val a = n * 30.0 * PI / 180.0
                    c.drawText(
                        n.toString(),
                        cx + (r * 0.76f * sin(a)).toFloat(),
                        cy - (r * 0.76f * cos(a)).toFloat() - (fm.ascent + fm.descent) / 2f, p
                    )
                }
                val minute = cal.get(Calendar.MINUTE)
                val ha = ((hour % 12) + minute / 60f) * 30.0 * PI / 180.0
                val ma = minute * 6.0 * PI / 180.0
                p.style = Paint.Style.STROKE
                p.strokeWidth = r * 0.09f
                c.drawLine(cx, cy, cx + (r * 0.40f * sin(ha)).toFloat(), cy - (r * 0.40f * cos(ha)).toFloat(), p)
                p.strokeWidth = r * 0.06f
                c.drawLine(cx, cy, cx + (r * 0.58f * sin(ma)).toFloat(), cy - (r * 0.58f * cos(ma)).toFloat(), p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.06f, p)
            }

            ClockStyle.RING -> {
                val r = min(maxW, maxH) / 2f * s.scale
                val cx = circleCx(s.align, w, pad, r)
                val sw = r * 0.12f
                val rr = r - sw / 2f
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = sw
                p.alpha = 70
                c.drawCircle(cx, cy, rr, p)
                p.alpha = 255
                val minute = cal.get(Calendar.MINUTE)
                c.drawArc(RectF(cx - rr, cy - rr, cx + rr, cy + rr), -90f, max(1f, minute * 6f), false, p)
                p.style = Paint.Style.FILL
                val inner = (r - sw * 1.5f) * 2f
                p.textSize = fit(p, "00:00", inner * 0.8f, inner * 0.4f, 1f)
                p.textAlign = Paint.Align.CENTER
                val ref = bounds(p, "00:00")
                c.drawText("$hh:$mm", cx, cy - (ref.top + ref.bottom) / 2f, p)
            }

            ClockStyle.AMPM -> {
                val tx = "$h12:$mm"
                val ap = if (hour < 12) "AM" else "PM"
                val gapF = 0.08f
                var hs = fit(p, "00:00", maxW * 0.8f, maxH, s.scale)
                fun tw(sz: Float): Float {
                    p.textSize = sz
                    val a = bounds(p, tx).width()
                    p.textSize = sz * 0.3f
                    return a + bounds(p, ap).width() + sz * gapF
                }
                var total = tw(hs)
                if (total > maxW) {
                    hs *= maxW / total
                    total = tw(hs)
                }
                p.textSize = hs
                val bt = bounds(p, tx)
                val ref = bounds(p, "00:00")
                val x0 = xFor(s.align, w, pad, total)
                val base = cy - (ref.top + ref.bottom) / 2f
                c.drawText(tx, x0 - bt.left, base, p)
                p.textSize = hs * 0.3f
                val ba = bounds(p, ap)
                c.drawText(ap, x0 + bt.width() + hs * gapF - ba.left, base, p)
            }

            ClockStyle.ANALOG -> {
                val r = min(maxW, maxH) / 2f * s.scale
                val cx = when (s.align) {
                    ClockAlign.LEFT -> pad + r
                    ClockAlign.CENTER -> w / 2f
                    ClockAlign.RIGHT -> w - pad - r
                }
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = r * 0.07f
                c.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
                for (i in 0 until 12) {
                    val a = i * 30.0 * PI / 180.0
                    val major = i % 3 == 0
                    val inner = r * (if (major) 0.74f else 0.84f)
                    val outer = r * 0.92f
                    p.strokeWidth = r * (if (major) 0.07f else 0.045f)
                    c.drawLine(
                        cx + (inner * sin(a)).toFloat(), cy - (inner * cos(a)).toFloat(),
                        cx + (outer * sin(a)).toFloat(), cy - (outer * cos(a)).toFloat(), p
                    )
                }
                val minute = cal.get(Calendar.MINUTE)
                val ha = ((hour % 12) + minute / 60f) * 30.0 * PI / 180.0
                val ma = minute * 6.0 * PI / 180.0
                p.strokeWidth = r * 0.1f
                c.drawLine(cx, cy, cx + (r * 0.5f * sin(ha)).toFloat(), cy - (r * 0.5f * cos(ha)).toFloat(), p)
                p.strokeWidth = r * 0.07f
                c.drawLine(cx, cy, cx + (r * 0.76f * sin(ma)).toFloat(), cy - (r * 0.76f * cos(ma)).toFloat(), p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.07f, p)
            }

            ClockStyle.MINIMAL -> {
                p.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
                p.letterSpacing = 0.1f
                p.textSize = fit(p, "00:00", maxW, maxH * 0.8f, s.scale)
                put(c, p, "$hh:$mm", "00:00", s.align, w, pad, cy)
            }

            ClockStyle.MATRIX -> {
                val hd = hh.padStart(2, '0')
                val glyphs = charArrayOf(hd[0], hd[1], ':', mm[0], mm[1])
                val cell = min(maxH / 7f, maxW / 29f) * s.scale
                val x0 = xFor(s.align, w, pad, cell * 29f)
                val y0 = cy - 3.5f * cell
                p.style = Paint.Style.FILL
                for (gi in glyphs.indices) {
                    val rows = dotFont[glyphs[gi]] ?: continue
                    for (row in 0 until 7) {
                        for (col in 0 until 5) {
                            val lit = ((rows[row] shr (4 - col)) and 1) == 1
                            p.alpha = if (lit) 255 else 45
                            c.drawCircle(
                                x0 + (gi * 6 + col + 0.5f) * cell, y0 + (row + 0.5f) * cell, cell * 0.38f, p
                            )
                        }
                    }
                }
            }

            ClockStyle.RETRO -> {
                val hd = hh.padStart(2, '0')
                val dh = min(maxH * 0.9f, maxW / 2.92f) * s.scale
                val dw = dh * 0.55f
                val gap = dh * 0.2f
                val colonW = dh * 0.12f
                val total = 4 * dw + 3 * gap + colonW
                val x0 = xFor(s.align, w, pad, total)
                val y0 = cy - dh / 2f
                val t = dh * 0.12f
                val xs = floatArrayOf(
                    x0, x0 + dw + gap, x0 + 2 * dw + 2 * gap + colonW, x0 + 3 * dw + 3 * gap + colonW
                )
                val digits = charArrayOf(hd[0], hd[1], mm[0], mm[1])
                for (i in 0 until 4) {
                    sevenSeg(c, p, xs[i], y0, dw, dh, t, sevenSegMasks[digits[i] - '0'])
                }
                val colX = x0 + 2 * dw + 1.5f * gap + colonW / 2f
                p.style = Paint.Style.FILL
                p.alpha = 255
                c.drawCircle(colX, y0 + dh * 0.33f, t * 0.5f, p)
                c.drawCircle(colX, y0 + dh * 0.67f, t * 0.5f, p)
            }

            ClockStyle.ROMAN -> {
                val r = min(maxW, maxH) / 2f * s.scale
                val cx = circleCx(s.align, w, pad, r)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = r * 0.04f
                c.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
                p.strokeWidth = r * 0.012f
                c.drawCircle(cx, cy, r * 0.9f, p)
                p.style = Paint.Style.FILL
                p.textAlign = Paint.Align.CENTER
                p.textSize = r * 0.16f
                val fm = p.fontMetrics
                val numerals = arrayOf("XII", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI")
                for (n in 0 until 12) {
                    val a = n * 30.0 * PI / 180.0
                    c.drawText(
                        numerals[n],
                        cx + (r * 0.74f * sin(a)).toFloat(),
                        cy - (r * 0.74f * cos(a)).toFloat() - (fm.ascent + fm.descent) / 2f, p
                    )
                }
                val minute = cal.get(Calendar.MINUTE)
                val ha = ((hour % 12) + minute / 60f) * 30.0 * PI / 180.0
                val ma = minute * 6.0 * PI / 180.0
                hand(c, p, cx, cy, ha, r * 0.5f, r * 0.1f, r * 0.05f)
                hand(c, p, cx, cy, ma, r * 0.76f, r * 0.06f, r * 0.03f)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.05f, p)
            }

            ClockStyle.CIRCULAR -> {
                val r = min(maxW, maxH) / 2f * s.scale
                val cx = circleCx(s.align, w, pad, r)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                for (i in 0 until 60) {
                    val a = i * 6.0 * PI / 180.0
                    val major = i % 5 == 0
                    p.strokeWidth = r * (if (major) 0.03f else 0.012f)
                    val inner = r * (if (major) 0.8f else 0.88f)
                    val outer = r * 0.97f
                    c.drawLine(
                        cx + (inner * sin(a)).toFloat(), cy - (inner * cos(a)).toFloat(),
                        cx + (outer * sin(a)).toFloat(), cy - (outer * cos(a)).toFloat(), p
                    )
                }
                p.style = Paint.Style.FILL
                p.textAlign = Paint.Align.CENTER
                p.textSize = fit(p, "00", r * 1.1f, r * 0.55f, 1f)
                val fm = p.fontMetrics
                val off = r * 0.26f
                c.drawText(hh.padStart(2, '0'), cx, cy - off - (fm.ascent + fm.descent) / 2f, p)
                c.drawText(mm, cx, cy + off - (fm.ascent + fm.descent) / 2f, p)
            }

            ClockStyle.CHRONO -> {
                val r = min(maxW, maxH) / 2f * s.scale
                val cx = circleCx(s.align, w, pad, r)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.BUTT
                p.strokeWidth = r * 0.1f
                c.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
                for (i in 0 until 60) {
                    val a = i * 6.0 * PI / 180.0
                    val major = i % 5 == 0
                    p.strokeWidth = r * (if (major) 0.05f else 0.02f)
                    val inner = r * (if (major) 0.76f else 0.82f)
                    val outer = r * 0.88f
                    c.drawLine(
                        cx + (inner * sin(a)).toFloat(), cy - (inner * cos(a)).toFloat(),
                        cx + (outer * sin(a)).toFloat(), cy - (outer * cos(a)).toFloat(), p
                    )
                }
                // Three sub-dials at 3, 6 and 9 o'clock.
                for (deg in doubleArrayOf(90.0, 180.0, 270.0)) {
                    val a = deg * PI / 180.0
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = r * 0.02f
                    c.drawCircle(cx + (r * 0.45f * sin(a)).toFloat(), cy - (r * 0.45f * cos(a)).toFloat(), r * 0.2f, p)
                }
                val minute = cal.get(Calendar.MINUTE)
                val ha = ((hour % 12) + minute / 60f) * 30.0 * PI / 180.0
                val ma = minute * 6.0 * PI / 180.0
                hand(c, p, cx, cy, ha, r * 0.5f, r * 0.09f, r * 0.05f)
                hand(c, p, cx, cy, ma, r * 0.8f, r * 0.06f, r * 0.03f)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.05f, p)
            }

            ClockStyle.ROLEX -> {
                val r = min(maxW, maxH) / 2f * s.scale
                val cx = circleCx(s.align, w, pad, r)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.BUTT
                p.strokeWidth = r * 0.16f
                c.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
                for (i in 0 until 12) {
                    val a = i * 30.0 * PI / 180.0
                    val sn = sin(a).toFloat()
                    val cs = cos(a).toFloat()
                    if (i % 3 == 0) {
                        p.style = Paint.Style.STROKE
                        p.strokeWidth = r * 0.07f
                        c.drawLine(cx + sn * r * 0.68f, cy - cs * r * 0.68f, cx + sn * r * 0.84f, cy - cs * r * 0.84f, p)
                    } else {
                        p.style = Paint.Style.FILL
                        c.drawCircle(cx + sn * r * 0.76f, cy - cs * r * 0.76f, r * 0.028f, p)
                    }
                }
                val minute = cal.get(Calendar.MINUTE)
                val ha = ((hour % 12) + minute / 60f) * 30.0 * PI / 180.0
                val ma = minute * 6.0 * PI / 180.0
                hand(c, p, cx, cy, ha, r * 0.5f, r * 0.13f, r * 0.05f)
                hand(c, p, cx, cy, ma, r * 0.8f, r * 0.09f, r * 0.035f)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.05f, p)
            }

            ClockStyle.WORLD -> {
                val utc = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = cal.timeInMillis }
                val uh = utc.get(Calendar.HOUR_OF_DAY)
                val uhh = if (s.is24) uh.toString().padStart(2, '0') else (if (uh % 12 == 0) 12 else uh % 12).toString()
                val umm = utc.get(Calendar.MINUTE).toString().padStart(2, '0')
                p.textSize = fit(p, "00:00", maxW, maxH * 0.62f, s.scale)
                val bt = bounds(p, "00:00").height()
                val small = Paint(p).apply {
                    textSize = p.textSize * 0.3f
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    letterSpacing = 0.12f
                }
                val bs = bounds(small, "UTC 00:00").height()
                val gap = maxH * 0.06f
                val top = cy - (bt + gap + bs) / 2f
                put(c, p, "$hh:$mm", "00:00", s.align, w, pad, top + bt / 2f)
                put(c, small, "UTC $uhh:$umm", "UTC 00:00", s.align, w, pad, top + bt + gap + bs / 2f)
            }

            ClockStyle.DUAL -> {
                val r = min(maxW * 0.34f, maxH / 2f) * s.scale
                val ax = pad + r
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = r * 0.06f
                c.drawCircle(ax, cy, r - p.strokeWidth / 2f, p)
                for (i in 0 until 12) {
                    val a = i * 30.0 * PI / 180.0
                    val major = i % 3 == 0
                    p.strokeWidth = r * (if (major) 0.07f else 0.04f)
                    val inner = r * (if (major) 0.7f else 0.82f)
                    val outer = r * 0.9f
                    c.drawLine(
                        ax + (inner * sin(a)).toFloat(), cy - (inner * cos(a)).toFloat(),
                        ax + (outer * sin(a)).toFloat(), cy - (outer * cos(a)).toFloat(), p
                    )
                }
                val minute = cal.get(Calendar.MINUTE)
                val ha = ((hour % 12) + minute / 60f) * 30.0 * PI / 180.0
                val ma = minute * 6.0 * PI / 180.0
                hand(c, p, ax, cy, ha, r * 0.5f, r * 0.12f, r * 0.06f)
                hand(c, p, ax, cy, ma, r * 0.78f, r * 0.08f, r * 0.03f)
                p.style = Paint.Style.FILL
                c.drawCircle(ax, cy, r * 0.06f, p)
                val tx = ax + r + pad
                p.textSize = fit(p, "00:00", w - pad - tx, maxH * 0.6f, s.scale)
                put(c, p, "$hh:$mm", "00:00", ClockAlign.LEFT, w, tx, cy)
            }
        }
    }
}
