@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.tejodhar.wallclock

import android.Manifest
import android.app.AlarmManager
import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

class MainActivity : ComponentActivity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var latest: ClockSettings? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetId = intent?.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            // Back key still adds the widget with the default look.
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
            ClockWidgetProvider.updateOne(this, widgetId)
        }
        val start = Prefs.load(this, widgetId)
        val id = widgetId
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    Editor(
                        start = start,
                        widgetId = id,
                        onChange = { latest = it },
                        onSave = { persist(it) },
                        onDone = { finish() }
                    )
                }
            }
        }
    }

    private fun persist(s: ClockSettings) {
        Prefs.save(this, widgetId, s)
        ClockWidgetProvider.refresh(this, widgetId)
    }

    override fun onPause() {
        super.onPause()
        latest?.let { persist(it) }
    }
}

@Composable
private fun Editor(
    start: ClockSettings,
    widgetId: Int,
    onChange: (ClockSettings) -> Unit,
    onSave: (ClockSettings) -> Unit,
    onDone: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var s by remember { mutableStateOf(start) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var darkBg by remember { mutableStateOf(true) }

    SideEffect { onChange(s) }
    LaunchedEffect(Unit) { while (true) { delay(15_000); now = System.currentTimeMillis() } }
    LaunchedEffect(s) { delay(500); onSave(s) }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { }
            s = s.copy(uri = uri.toString(), wall = WallSource.GALLERY, fill = FillMode.WALLPAPER)
        }
    }
    val askStorage = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        WallpaperSource.invalidate()
        now = System.currentTimeMillis()
    }

    val preview by produceState<ImageBitmap?>(null, s, now) {
        value = withContext(Dispatchers.Default) {
            val cal = Calendar.getInstance().apply { timeInMillis = now }
            ClockRenderer.render(ctx, s, cal, 720, 330).asImageBitmap()
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) "Wall Clock" else "Widget settings",
            style = MaterialTheme.typography.headlineSmall
        )

        Box(
            Modifier.fillMaxWidth().aspectRatio(720f / 330f).clip(RoundedCornerShape(20.dp))
                .background(
                    if (darkBg) Brush.linearGradient(listOf(Color(0xFF1B1B2F), Color(0xFF3A3A5C)))
                    else Brush.linearGradient(listOf(Color(0xFFF2F2F7), Color(0xFFD6D6E0)))
                )
                .clickable { darkBg = !darkBg },
            contentAlignment = Alignment.Center
        ) {
            preview?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
        }
        Text("Tap the preview to switch background", style = MaterialTheme.typography.labelSmall)

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val mgr = AppWidgetManager.getInstance(ctx)
                if (Build.VERSION.SDK_INT >= 26 && mgr.isRequestPinAppWidgetSupported) {
                    mgr.requestPinAppWidget(ComponentName(ctx, ClockWidgetProvider::class.java), null, null)
                } else {
                    Toast.makeText(ctx, "Long-press home screen > Widgets > Wall Clock", Toast.LENGTH_LONG).show()
                }
            }
        ) { Text("Add widget to home screen") }

        Section("Clock type") {
            ChipRow(ClockStyle.entries, s.style, { it.label }) { s = s.copy(style = it) }
        }
        Section("Position") {
            ChipRow(ClockAlign.entries, s.align, { it.label }) { s = s.copy(align = it) }
        }
        Section("Colour type") {
            ChipRow(FillMode.entries, s.fill, { it.label }) { s = s.copy(fill = it) }
        }

        when (s.fill) {
            FillMode.SOLID -> Section("Colour") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Palettes.solids.forEach { col ->
                        Swatch(SolidColor(Color(col)), s.solid == col) { s = s.copy(solid = col) }
                    }
                }
            }
            FillMode.GRADIENT -> Section("Gradient") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Palettes.gradients.forEachIndexed { i, g ->
                        Swatch(Brush.linearGradient(g.map { Color(it) }), s.grad == i) { s = s.copy(grad = i) }
                    }
                }
            }
            FillMode.WALLPAPER -> Section("Wallpaper inside the clock") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    WallSource.entries.filter { it != WallSource.GALLERY && it != WallSource.SYSTEM }.forEach { ws ->
                        val cols = Palettes.wall.getValue(ws).map { Color(it) }
                        Swatch(Brush.linearGradient(cols), s.wall == ws) { s = s.copy(wall = ws) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pickImage.launch(arrayOf("image/*")) }) {
                        Text(if (s.wall == WallSource.GALLERY) "Gallery ✓" else "Gallery photo")
                    }
                    OutlinedButton(onClick = {
                        s = s.copy(wall = WallSource.SYSTEM, fill = FillMode.WALLPAPER)
                        if (Build.VERSION.SDK_INT <= 32 &&
                            ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                        ) askStorage.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                    }) { Text(if (s.wall == WallSource.SYSTEM) "Current ✓" else "Current wallpaper") }
                }
                Text(
                    "Current wallpaper can be blocked on Android 13+; use Gallery photo then.",
                    style = MaterialTheme.typography.labelSmall
                )
            }
            FillMode.RAINBOW -> Text("Rainbow colours across the clock.", style = MaterialTheme.typography.bodySmall)
        }

        Section("Font") {
            ChipRow(Palettes.fontNames.indices.toList(), s.font, { Palettes.fontNames[it] }) { s = s.copy(font = it) }
        }
        Section("Size") {
            Slider(value = s.scale, onValueChange = { s = s.copy(scale = it) }, valueRange = 0.5f..1f)
        }

        SwitchRow("24-hour time", s.is24) { s = s.copy(is24 = it) }
        SwitchRow("Soft shadow", s.shadow) { s = s.copy(shadow = it) }
        SwitchRow("Dark card behind clock", s.card) { s = s.copy(card = it) }

        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch(Dispatchers.IO) {
                    val ok = try {
                        val dm = ctx.resources.displayMetrics
                        val b = WallpaperSource.load(ctx, s, dm.widthPixels, dm.heightPixels)
                        WallpaperManager.getInstance(ctx).setBitmap(b)
                        true
                    } catch (e: Exception) { false }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(ctx, if (ok) "Wallpaper set" else "Could not set wallpaper", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        ) { Text("Set this wallpaper on phone") }

        if (Build.VERSION.SDK_INT >= 31 && !ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
                    )
                }
            ) { Text("Allow exact minute updates") }
        }

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                onSave(s)
                Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
                if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) onDone()
            }
        ) { Text(if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) "Done" else "Apply to widgets") }

        Text(
            "Add the widget: long-press the home screen → Widgets → Wall Clock.",
            style = MaterialTheme.typography.labelSmall
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        content()
    }
}

@Composable
private fun <T> ChipRow(items: List<T>, selected: T, label: (T) -> String, onPick: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { item ->
            FilterChip(selected = item == selected, onClick = { onPick(item) }, label = { Text(label(item)) })
        }
    }
}

@Composable
private fun Swatch(brush: Brush, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(brush)
            .border(
                if (selected) 3.dp else 1.dp,
                if (selected) MaterialTheme.colorScheme.primary else Color.Gray,
                CircleShape
            )
            .clickable(onClick = onClick)
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
