package com.tejodhar.wallclock

import android.app.WallpaperManager
import android.content.Context
import android.graphics.*
import android.net.Uri
import kotlin.math.max
import kotlin.random.Random

object WallpaperSource {
    private var key = ""
    private var cached: Bitmap? = null

    @Synchronized
    fun invalidate() { key = ""; cached = null }

    /** Returns a bitmap of exactly w x h. Do not modify it (it is cached). */
    @Synchronized
    fun load(ctx: Context, s: ClockSettings, w: Int, h: Int): Bitmap {
        val k = "${s.wall}|${s.uri}|$w|$h"
        val c = cached
        if (c != null && k == key) return c
        val b: Bitmap = try {
            when (s.wall) {
                WallSource.GALLERY -> fromUri(ctx, s.uri, w, h)
                WallSource.SYSTEM -> fromSystem(ctx, w, h)
                else -> procedural(s.wall, w, h)
            }
        } catch (e: Throwable) {
            procedural(WallSource.SUNSET, w, h)
        }
        key = k
        cached = b
        return b
    }

    private fun cropTo(src: Bitmap, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val sw = src.width.toFloat()
        val sh = src.height.toFloat()
        val dstAspect = w.toFloat() / h
        val r = if (sw / sh > dstAspect) {
            val cw = sh * dstAspect
            Rect(((sw - cw) / 2f).toInt(), 0, ((sw + cw) / 2f).toInt(), sh.toInt())
        } else {
            val ch = sw / dstAspect
            Rect(0, ((sh - ch) / 2f).toInt(), sw.toInt(), ((sh + ch) / 2f).toInt())
        }
        Canvas(out).drawBitmap(src, r, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun fromUri(ctx: Context, uriStr: String, w: Int, h: Int): Bitmap {
        val uri = Uri.parse(uriStr)
        val cr = ctx.contentResolver
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var ss = 1
        while (o.outWidth / (ss * 2) >= w && o.outHeight / (ss * 2) >= h) ss *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = ss }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: throw IllegalStateException("decode failed")
        return cropTo(bmp, w, h)
    }

    private fun fromSystem(ctx: Context, w: Int, h: Int): Bitmap {
        val d = WallpaperManager.getInstance(ctx).drawable ?: throw IllegalStateException("none")
        val iw = d.intrinsicWidth.coerceIn(1, 1600)
        val ih = d.intrinsicHeight.coerceIn(1, 1600)
        val src = Bitmap.createBitmap(iw, ih, Bitmap.Config.ARGB_8888)
        val cv = Canvas(src)
        d.setBounds(0, 0, iw, ih)
        d.draw(cv)
        return cropTo(src, w, h)
    }

    fun procedural(src: WallSource, w: Int, h: Int): Bitmap {
        val cols = Palettes.wall[src] ?: Palettes.wall.getValue(WallSource.SUNSET)
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), cols, null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        val rnd = Random(src.ordinal * 7919L + 13)
        repeat(5) {
            val cx = rnd.nextFloat() * w
            val cy = rnd.nextFloat() * h
            val rad = (0.35f + rnd.nextFloat() * 0.5f) * max(w, h)
            val col = cols[rnd.nextInt(cols.size)]
            val clear = col and 0x00FFFFFF
            val strong = clear or (0xAA shl 24)
            p.shader = RadialGradient(cx, cy, rad, intArrayOf(strong, clear), null, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, rad, p)
        }
        return b
    }
}
