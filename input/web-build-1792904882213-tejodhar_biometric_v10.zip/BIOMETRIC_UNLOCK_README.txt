Tejodhar biometric unlock
- Single biometric unlock: on the portal login page (linked to the user's username/password account).
- No second lock when the app opens.
- Native bridge: app/src/main/java/co/median/android/BiometricBridge.java (window.TejodharBio).
- Server side: website/index.php (bio_native_register / bio_native_login).
- Source change only; build with AndroidForge.
