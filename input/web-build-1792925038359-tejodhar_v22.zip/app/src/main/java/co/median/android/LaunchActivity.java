package co.median.android;

/**
 * Launcher activity. The app-open biometric lock was removed on purpose:
 * biometric unlock is now done ONCE, on the portal login page, and is linked
 * to the user's account (see BiometricBridge + the portal's index.php).
 */
public class LaunchActivity extends MainActivity {
}
