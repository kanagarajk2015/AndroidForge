package co.median.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * JavaScript bridge (window.TejodharBio) so the Tejodhar portal can use the phone's
 * native fingerprint / face prompt inside the app (WebView has no WebAuthn passkeys).
 *
 * The server issues a random login token when the user enables biometric login.
 * The token is stored here, encrypted with an Android Keystore key, and is only
 * released after the user passes the fingerprint / face / screen-lock prompt.
 * Only pages on tejodhar.in may use this bridge.
 */
public class BiometricBridge {
    private static final String KEY_ALIAS = "tejodhar_bio_key";
    private static final String PREFS = "tejodhar_bio";
    private static final String PREF_TOKEN = "tok";
    private static final String PREF_IV = "iv";
    private static final String ALLOWED_HOST = "tejodhar.in";
    private static final int AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK
            | BiometricManager.Authenticators.DEVICE_CREDENTIAL;
    private static final Pattern CALLBACK = Pattern.compile("^[A-Za-z_$][A-Za-z0-9_$.]*$");

    private final MainActivity activity;
    private boolean promptShowing = false;

    public BiometricBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public boolean isAvailable() {
        return BiometricManager.from(activity).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS;
    }

    @JavascriptInterface
    public boolean hasToken() {
        return prefs().contains(PREF_TOKEN);
    }

    @JavascriptInterface
    public void clear() {
        prefs().edit().remove(PREF_TOKEN).remove(PREF_IV).apply();
    }

    /** Ask for fingerprint/face, then store the server-issued token securely. */
    @JavascriptInterface
    public void register(final String token, final String callback) {
        if (!validCallback(callback)) return;
        activity.runOnUiThread(() -> {
            if (!allowedPage()) { reply(callback, false, null, "blocked"); return; }
            if (token == null || token.length() < 20) { reply(callback, false, null, "bad_token"); return; }
            prompt("Enable biometric login", "Confirm to enable on this phone", callback, () -> {
                try {
                    store(token);
                    reply(callback, true, null, null);
                } catch (Exception e) {
                    reply(callback, false, null, "store_failed");
                }
            });
        });
    }

    /** Ask for fingerprint/face, then hand the saved token to the page. */
    @JavascriptInterface
    public void unlock(final String callback) {
        if (!validCallback(callback)) return;
        activity.runOnUiThread(() -> {
            if (!allowedPage()) { reply(callback, false, null, "blocked"); return; }
            if (!hasToken()) { reply(callback, false, null, "not_registered"); return; }
            prompt("Unlock Tejodhar Construction", "Verify your identity to log in", callback, () -> {
                try {
                    reply(callback, true, load(), null);
                } catch (Exception e) {
                    clear();
                    reply(callback, false, null, "not_registered");
                }
            });
        });
    }

    // ---------------------------------------------------------------- internals

    private void prompt(String title, String subtitle, final String callback, final Runnable onSuccess) {
        if (promptShowing) { reply(callback, false, null, "busy"); return; }
        if (!isAvailable()) { reply(callback, false, null, "unavailable"); return; }
        promptShowing = true;
        BiometricPrompt p = new BiometricPrompt(activity, ContextCompat.getMainExecutor(activity),
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                        promptShowing = false;
                        onSuccess.run();
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                        promptShowing = false;
                        String why;
                        switch (errorCode) {
                            case BiometricPrompt.ERROR_USER_CANCELED:
                            case BiometricPrompt.ERROR_NEGATIVE_BUTTON:
                            case BiometricPrompt.ERROR_CANCELED:
                                why = "cancelled"; break;
                            case BiometricPrompt.ERROR_LOCKOUT:
                            case BiometricPrompt.ERROR_LOCKOUT_PERMANENT:
                                why = "locked"; break;
                            case BiometricPrompt.ERROR_NO_BIOMETRICS:
                            case BiometricPrompt.ERROR_NO_DEVICE_CREDENTIAL:
                            case BiometricPrompt.ERROR_HW_NOT_PRESENT:
                            case BiometricPrompt.ERROR_HW_UNAVAILABLE:
                                why = "unavailable"; break;
                            default:
                                why = "failed";
                        }
                        reply(callback, false, null, why);
                    }
                });
        try {
            p.authenticate(new BiometricPrompt.PromptInfo.Builder()
                    .setTitle(title)
                    .setSubtitle(subtitle)
                    .setAllowedAuthenticators(AUTH)
                    .build());
        } catch (Exception e) {
            // never leave the bridge stuck in "busy" if the prompt could not be shown
            promptShowing = false;
            reply(callback, false, null, "failed");
        }
    }

    private boolean allowedPage() {
        try {
            String url = activity.getWebView().getUrl();
            if (url == null) return false;
            URI u = new URI(url);
            String host = u.getHost();
            return "https".equalsIgnoreCase(u.getScheme()) && host != null
                    && (host.equalsIgnoreCase(ALLOWED_HOST) || host.toLowerCase().endsWith("." + ALLOWED_HOST));
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean validCallback(String cb) {
        return cb != null && CALLBACK.matcher(cb).matches();
    }

    private void reply(String callback, boolean ok, String token, String error) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", ok);
            if (token != null) o.put("token", token);
            if (error != null) o.put("error", error);
            activity.runJavascript(callback + "(" + o.toString() + ");");
        } catch (Exception ignored) {
        }
    }

    private SharedPreferences prefs() {
        return activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            return (SecretKey) ks.getKey(KEY_ALIAS, null);
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
        return kg.generateKey();
    }

    private void store(String token) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key());
        byte[] enc = c.doFinal(token.getBytes(StandardCharsets.UTF_8));
        prefs().edit()
                .putString(PREF_TOKEN, Base64.encodeToString(enc, Base64.NO_WRAP))
                .putString(PREF_IV, Base64.encodeToString(c.getIV(), Base64.NO_WRAP))
                .apply();
    }

    private String load() throws Exception {
        byte[] enc = Base64.decode(prefs().getString(PREF_TOKEN, ""), Base64.NO_WRAP);
        byte[] iv = Base64.decode(prefs().getString(PREF_IV, ""), Base64.NO_WRAP);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
        return new String(c.doFinal(enc), StandardCharsets.UTF_8);
    }
}
