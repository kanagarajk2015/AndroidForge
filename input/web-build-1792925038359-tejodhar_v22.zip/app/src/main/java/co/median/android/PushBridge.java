package co.median.android;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.JavascriptInterface;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.messaging.FirebaseMessaging;

/**
 * JavaScript bridge (window.TejodharPush) used by the Tejodhar portal page:
 *  - getToken()      : this phone's Firebase Cloud Messaging token ("" until Firebase has issued it)
 *  - requestPermission(): asks for the Android 13+ notification permission (once per call, harmless if already granted)
 *  - takeLaunch()    : the screen a tapped notification wants opened ("chat", "approvals", "myleave", "myreq"), then cleared
 */
public class PushBridge {
    public static final String PREFS = "tejodhar_push";
    public static final String PREF_TOKEN = "token";
    public static final String PREF_OPEN = "open";
    public static final String CH_ALERTS = "tejodhar_alerts";
    public static final String CH_CHAT = "tejodhar_chat";

    /** True while the app's screen is visible (set from MainActivity.onResume / onPause). */
    public static volatile boolean foreground = false;

    private final MainActivity activity;

    public PushBridge(MainActivity activity) {
        this.activity = activity;
        ensureChannels(activity);
        fetchToken(activity);
    }

    @JavascriptInterface
    public String getToken() {
        String t = prefs(activity).getString(PREF_TOKEN, "");
        if (t == null || t.isEmpty()) fetchToken(activity);
        return t == null ? "" : t;
    }

    @JavascriptInterface
    public void requestPermission() {
        if (Build.VERSION.SDK_INT < 33) return;
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return;
        activity.runOnUiThread(() -> {
            try {
                ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7311);
            } catch (Exception ignored) {
            }
        });
    }

    @JavascriptInterface
    public String takeLaunch() {
        SharedPreferences p = prefs(activity);
        String v = p.getString(PREF_OPEN, "");
        if (v != null && !v.isEmpty()) p.edit().remove(PREF_OPEN).apply();
        return v == null ? "" : v;
    }

    // ---------------------------------------------------------------- helpers

    public static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void fetchToken(final Context c) {
        try {
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult() != null) {
                    prefs(c).edit().putString(PREF_TOKEN, task.getResult()).apply();
                }
            });
        } catch (Throwable ignored) {
            // Firebase not configured (google-services.json missing): push stays off, app keeps working.
        }
    }

    public static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel alerts = new NotificationChannel(CH_ALERTS, "Leave & attendance", NotificationManager.IMPORTANCE_HIGH);
        alerts.setDescription("Leave requests, missed attendance requests, approvals and rejections");
        NotificationChannel chat = new NotificationChannel(CH_CHAT, "Team chat", NotificationManager.IMPORTANCE_DEFAULT);
        chat.setDescription("New team chat messages");
        nm.createNotificationChannel(alerts);
        nm.createNotificationChannel(chat);
    }
}
