package co.median.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/**
 * Invisible trampoline: remembers which screen the tapped notification wants, then brings the app to the front.
 * The portal page picks the request up through TejodharPush.takeLaunch().
 */
public class PushTapActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String tab = getIntent() == null ? null : getIntent().getStringExtra("tab");
        if (tab != null && !tab.isEmpty()) {
            PushBridge.prefs(this).edit().putString(PushBridge.PREF_OPEN, tab).apply();
        }
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(launch);
        }
        finish();
    }
}
