package co.median.android;

import android.Manifest;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/** Receives the server's data-only push messages and shows them as notifications. */
public class TejodharMessagingService extends FirebaseMessagingService {

    @Override
    public void onNewToken(@NonNull String token) {
        // The page re-reads the token every few seconds and registers it with the server.
        PushBridge.prefs(this).edit().putString(PushBridge.PREF_TOKEN, token).apply();
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {
        Map<String, String> d = message.getData();
        if (d == null || d.isEmpty()) return;
        String type = d.get("type") == null ? "" : d.get("type");
        String title = d.get("title") == null ? "Tejodhar" : d.get("title");
        String body = d.get("body") == null ? "" : d.get("body");
        String tab = d.get("tab") == null ? "" : d.get("tab");
        if ("test".equals(type)) tab = "";

        boolean chat = "chat".equals(type);
        // Chat is already live on screen while the app is open; everything else is still worth a banner.
        if (chat && PushBridge.foreground) return;

        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        PushBridge.ensureChannels(this);

        Intent tap = new Intent(this, PushTapActivity.class);
        tap.putExtra("tab", tab);
        tap.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int id = (int) (System.currentTimeMillis() & 0x7fffffff);
        PendingIntent pi = PendingIntent.getActivity(this, id, tap,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, chat ? PushBridge.CH_CHAT : PushBridge.CH_ALERTS)
                .setSmallIcon(R.drawable.ic_stat_onesignal_default)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setCategory(chat ? NotificationCompat.CATEGORY_MESSAGE : NotificationCompat.CATEGORY_EVENT)
                .setPriority(chat ? NotificationCompat.PRIORITY_DEFAULT : NotificationCompat.PRIORITY_HIGH);
        if (chat) b.setGroup("tejodhar_chat_group");

        try {
            NotificationManagerCompat.from(this).notify(id, b.build());
        } catch (SecurityException ignored) {
        }
    }
}
