<?php
/* Fix: "Forgot In Time" approvals were landing as Half Day even when the
   approved time was clearly a full day's work (e.g. approve 09:00 In,
   existing 18:00 Out — should be ~9 hrs, was coming out as ~3.5 hrs).
   Root cause: PHP had no explicit timezone set, so it was falling back to
   the server's default (commonly UTC). When an admin approved a forgotten
   punch, `new DateTime($date.' '.$punchTime.':00')` interpreted that
   09:00 as 09:00 UTC — not 09:00 IST — which is 5.5 hours later than the
   employee actually clocked in. That pushed the approved IN timestamp
   much closer to the real OUT timestamp, so the calculated worked hours
   dropped to well under 4 and got recorded as Half Day. Meanwhile normal
   punches (via record_punch) were unaffected because the browser already
   sends a correct absolute timestamp (Date.now()) — only the server-side
   reconstruction of an *approved* time was off. Pinning the timezone here
   makes every date/time calculation in this file (this approval included)
   consistent with the actual local punch times. Change "Asia/Kolkata" if
   your staff punch in from a different timezone. */
date_default_timezone_set('Asia/Kolkata');
/*
 * Cash Book bill storage:
 * New Cash Book bill uploads are sent to Cloudinary instead of being saved
 * inside the InfinityFree /bills folder. Existing bill files are untouched.
 * Cloudinary settings are defined just below.
 */
/* ---- Cloudinary settings (Cash Book bills). Keep this file private; rotate the secret in Cloudinary if it was ever shared. ---- */
define('CLOUDINARY_CLOUD_NAME', 'wpizqa3u');
define('CLOUDINARY_API_KEY', '317316113518863');
define('CLOUDINARY_API_SECRET', 'uvWakCJKsGRsrpLYoEEzwjpdzPs');

function uploadCashBillToCloudinary(string $binary, string $mime, string $originalName, string $date): array {
    if (!defined('CLOUDINARY_CLOUD_NAME') || !defined('CLOUDINARY_API_KEY') || !defined('CLOUDINARY_API_SECRET')
        || CLOUDINARY_CLOUD_NAME === '' || CLOUDINARY_CLOUD_NAME === 'YOUR_CLOUD_NAME'
        || CLOUDINARY_API_KEY === '' || CLOUDINARY_API_SECRET === '') {
        return ['ok'=>false,'message'=>'Cloudinary is not configured. Check the Cloudinary settings at the top of index.php.'];
    }
    if (!function_exists('curl_init')) {
        return ['ok'=>false,'message'=>'PHP cURL is not enabled on this hosting account.'];
    }
    $safeBase = preg_replace('/[^A-Za-z0-9_-]+/', '_', pathinfo($originalName ?: 'bill', PATHINFO_FILENAME));
    $safeBase = trim((string)$safeBase, '_-');
    if ($safeBase === '') $safeBase = 'bill';
    $publicId = 'cashbook_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4));
    $timestamp = time();
    $signParams = [
        'folder' => 'cashbook_bills',
        'public_id' => $publicId,
        'timestamp' => $timestamp,
    ];
    ksort($signParams);
    $toSign = http_build_query($signParams, '', '&', PHP_QUERY_RFC3986);
    $signature = sha1($toSign . CLOUDINARY_API_SECRET);

    $tmp = tempnam(sys_get_temp_dir(), 'cb_');
    if ($tmp === false || file_put_contents($tmp, $binary) === false) {
        return ['ok'=>false,'message'=>'Unable to create temporary upload file.'];
    }
    $endpoint = 'https://api.cloudinary.com/v1_1/' . rawurlencode(CLOUDINARY_CLOUD_NAME) . '/auto/upload';
    $post = [
        'file' => new CURLFile($tmp, $mime ?: 'application/octet-stream', $originalName ?: ($safeBase . '.bin')),
        'api_key' => CLOUDINARY_API_KEY,
        'timestamp' => $timestamp,
        'signature' => $signature,
        'folder' => 'cashbook_bills',
        'public_id' => $publicId,
    ];
    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $post,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT => 90,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $response = curl_exec($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    @unlink($tmp);
    if ($response === false || $curlError !== '') {
        return ['ok'=>false,'message'=>'Cloudinary connection failed: '.$curlError];
    }
    $data = json_decode($response, true);
    if ($httpCode < 200 || $httpCode >= 300 || !is_array($data) || empty($data['secure_url'])) {
        $detail = is_array($data) && !empty($data['error']['message']) ? $data['error']['message'] : 'HTTP '.$httpCode;
        return ['ok'=>false,'message'=>'Cloudinary upload failed: '.$detail];
    }
    return [
        'ok'=>true,
        'url'=>(string)$data['secure_url'],
        'type'=>$mime,
        'name'=>$originalName,
    ];
}

/* Generic Cloudinary uploader used for ALL non-bill images (employee photos, company logo/seal).
 * Same credentials/signature scheme as the bill uploader, but with a configurable folder. */
function uploadToCloudinaryFolder(string $binary, string $mime, string $folder, string $prefix): array {
    if (!defined('CLOUDINARY_CLOUD_NAME') || CLOUDINARY_CLOUD_NAME === '' || CLOUDINARY_API_KEY === '' || CLOUDINARY_API_SECRET === '') {
        return ['ok'=>false,'message'=>'Cloudinary is not configured. Check the Cloudinary settings at the top of index.php.'];
    }
    if (!function_exists('curl_init')) return ['ok'=>false,'message'=>'PHP cURL is not enabled on this hosting account.'];
    $prefix = trim((string)preg_replace('/[^A-Za-z0-9_-]+/', '_', $prefix), '_-') ?: 'img';
    $publicId = $prefix . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4));
    $timestamp = time();
    $signParams = ['folder'=>$folder,'public_id'=>$publicId,'timestamp'=>$timestamp];
    ksort($signParams);
    $signature = sha1(http_build_query($signParams, '', '&', PHP_QUERY_RFC3986) . CLOUDINARY_API_SECRET);
    $tmp = tempnam(sys_get_temp_dir(), 'ci_');
    if ($tmp === false || file_put_contents($tmp, $binary) === false) return ['ok'=>false,'message'=>'Unable to create temporary upload file.'];
    $ch = curl_init('https://api.cloudinary.com/v1_1/' . rawurlencode(CLOUDINARY_CLOUD_NAME) . '/image/upload');
    curl_setopt_array($ch, [
        CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>['file'=>new CURLFile($tmp, $mime ?: 'image/jpeg', $publicId), 'api_key'=>CLOUDINARY_API_KEY,
            'timestamp'=>$timestamp, 'signature'=>$signature, 'folder'=>$folder, 'public_id'=>$publicId],
        CURLOPT_RETURNTRANSFER=>true, CURLOPT_CONNECTTIMEOUT=>15, CURLOPT_TIMEOUT=>90,
        CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2,
    ]);
    $response = curl_exec($ch); $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $curlError = curl_error($ch);
    curl_close($ch); @unlink($tmp);
    if ($response === false || $curlError !== '') return ['ok'=>false,'message'=>'Cloudinary connection failed: '.$curlError];
    $data = json_decode($response, true);
    if ($httpCode < 200 || $httpCode >= 300 || !is_array($data) || empty($data['secure_url'])) {
        $detail = is_array($data) && !empty($data['error']['message']) ? $data['error']['message'] : 'HTTP '.$httpCode;
        return ['ok'=>false,'message'=>'Cloudinary upload failed: '.$detail];
    }
    return ['ok'=>true,'url'=>(string)$data['secure_url']];
}

/* Fixed-name Cloudinary uploader for app icons (public_id = app_icons/<name>, overwrites). URL is predictable:
 * https://res.cloudinary.com/<cloud>/image/upload/app_icons/<name>.png */
function uploadIconToCloudinary(string $binary, string $mime, string $name): array {
    if (!defined('CLOUDINARY_CLOUD_NAME') || CLOUDINARY_CLOUD_NAME === '' || CLOUDINARY_API_KEY === '' || CLOUDINARY_API_SECRET === '') return ['ok'=>false,'message'=>'Cloudinary is not configured.'];
    if (!function_exists('curl_init')) return ['ok'=>false,'message'=>'PHP cURL is not enabled on this hosting account.'];
    $publicId = 'app_icons/' . preg_replace('/[^A-Za-z0-9_-]+/', '_', $name);
    $timestamp = time();
    $sign = ['invalidate'=>'true','overwrite'=>'true','public_id'=>$publicId,'timestamp'=>$timestamp];
    ksort($sign);
    $signature = sha1(http_build_query($sign, '', '&', PHP_QUERY_RFC3986) . CLOUDINARY_API_SECRET);
    $tmp = tempnam(sys_get_temp_dir(), 'ic_');
    if ($tmp === false || file_put_contents($tmp, $binary) === false) return ['ok'=>false,'message'=>'Unable to create temporary upload file.'];
    $ch = curl_init('https://api.cloudinary.com/v1_1/' . rawurlencode(CLOUDINARY_CLOUD_NAME) . '/image/upload');
    curl_setopt_array($ch, [
        CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>['file'=>new CURLFile($tmp, $mime ?: 'image/png', basename($publicId)),'api_key'=>CLOUDINARY_API_KEY,
            'timestamp'=>$timestamp,'signature'=>$signature,'public_id'=>$publicId,'overwrite'=>'true','invalidate'=>'true'],
        CURLOPT_RETURNTRANSFER=>true, CURLOPT_CONNECTTIMEOUT=>15, CURLOPT_TIMEOUT=>60,
        CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2,
    ]);
    $response = curl_exec($ch); $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $curlError = curl_error($ch);
    curl_close($ch); @unlink($tmp);
    if ($response === false || $curlError !== '') return ['ok'=>false,'message'=>'Cloudinary connection failed: '.$curlError];
    $data = json_decode($response, true);
    if ($httpCode < 200 || $httpCode >= 300 || !is_array($data) || empty($data['secure_url'])) {
        return ['ok'=>false,'message'=>'Cloudinary upload failed: '.(is_array($data)&&!empty($data['error']['message'])?$data['error']['message']:'HTTP '.$httpCode)];
    }
    return ['ok'=>true,'url'=>(string)$data['secure_url']];
}

/* Turns a data:image/...;base64 string into a Cloudinary URL. Returns the input unchanged if it is
 * already a URL/empty. On failure returns ['ok'=>false,...] so the caller can decide. */
function dataUriToCloud(string $dataUri, string $folder, string $prefix): array {
    if (!preg_match('#^data:image/(jpeg|jpg|png|webp|gif);base64,(.+)$#s', $dataUri, $m)) return ['ok'=>true,'url'=>$dataUri];
    $bin = base64_decode($m[2], true);
    if ($bin === false || $bin === '') return ['ok'=>false,'message'=>'Could not read the uploaded image.'];
    if (strlen($bin) > 10*1024*1024) return ['ok'=>false,'message'=>'Image is too large (max 10 MB).'];
    return uploadToCloudinaryFolder($bin, 'image/'.$m[1], $folder, $prefix);
}

/* Deletes a Cash Book bill file when its entry is deleted.
 * - Cloudinary URL  -> signed "destroy" call (public_id + resource type are read from the URL itself,
 *   so it also works for bills saved before this fix).
 * - Local "bills/..." path -> unlink the file inside /bills only.
 * Returns ['ok'=>bool,'message'=>string]. A bill that is already gone counts as success. */
function deleteCashBillFile(string $url): array {
    $url = trim($url);
    if ($url === '') return ['ok'=>true,'message'=>'No bill file.'];
    if (!preg_match('#^https?://#i', $url)) {
        $billsDir = realpath(__DIR__ . '/bills');
        $file = realpath(__DIR__ . '/' . ltrim($url, '/'));
        if ($billsDir && $file && strpos($file, $billsDir . DIRECTORY_SEPARATOR) === 0 && is_file($file)) {
            return @unlink($file) ? ['ok'=>true,'message'=>'Local bill deleted.'] : ['ok'=>false,'message'=>'Could not delete local bill file.'];
        }
        return ['ok'=>true,'message'=>'Local bill already gone.'];
    }
    if (!preg_match('#^https?://res\.cloudinary\.com/([^/]+)/(image|video|raw)/upload/(?:[^/]+/)*?(?:v\d+/)?(cashbook_bills/[^?\#]+)#i', $url, $m)) {
        return ['ok'=>false,'message'=>'Bill URL is not a Cash Book Cloudinary file; left untouched.'];
    }
    $resType = strtolower($m[2]);
    $publicId = rawurldecode($m[3]);
    if ($resType !== 'raw') $publicId = preg_replace('/\.[A-Za-z0-9]{2,5}$/', '', $publicId); // images/PDFs: id has no extension
    if (!defined('CLOUDINARY_CLOUD_NAME') || !defined('CLOUDINARY_API_KEY') || !defined('CLOUDINARY_API_SECRET')) {
        return ['ok'=>false,'message'=>'Cloudinary is not configured.'];
    }
    if (!function_exists('curl_init')) return ['ok'=>false,'message'=>'PHP cURL is not enabled.'];
    $timestamp = time();
    $sign = ['invalidate'=>'true','public_id'=>$publicId,'timestamp'=>$timestamp];
    ksort($sign);
    $signature = sha1(urldecode(http_build_query($sign, '', '&')) . CLOUDINARY_API_SECRET);
    $ch = curl_init('https://api.cloudinary.com/v1_1/' . rawurlencode(CLOUDINARY_CLOUD_NAME) . '/' . $resType . '/destroy');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => ['public_id'=>$publicId,'invalidate'=>'true','timestamp'=>$timestamp,'api_key'=>CLOUDINARY_API_KEY,'signature'=>$signature],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $resp = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
    if ($resp === false || $err !== '') return ['ok'=>false,'message'=>'Cloudinary connection failed: '.$err];
    $d = json_decode($resp, true);
    $result = is_array($d) ? ($d['result'] ?? '') : '';
    if ($code >= 200 && $code < 300 && ($result === 'ok' || $result === 'not found')) return ['ok'=>true,'message'=>'Cloud bill deleted.'];
    $detail = is_array($d) && !empty($d['error']['message']) ? $d['error']['message'] : ('HTTP '.$code.' '.$result);
    return ['ok'=>false,'message'=>'Cloudinary delete failed: '.$detail];
}

/* Validates, (if needed) shrinks and uploads a bill sent as a data: URL. Shared by add + replace. */
function prepareAndUploadCashBill(string $billData,string $billName,string $date): array {
        if(strlen($billData)>8*1024*1024){return ['ok'=>false,'message'=>'Bill file is too large. Maximum allowed size is 6 MB.'];}
        if(!preg_match('#^data:(image/(?:jpeg|jpg|png|webp)|application/pdf);base64,(.+)$#s',$billData,$bm)){
            return ['ok'=>false,'message'=>'Invalid bill file. Upload JPG, PNG, WEBP or PDF only.'];
        }
        $bin=base64_decode($bm[2],true);
        if($bin===false||$bin===''){return ['ok'=>false,'message'=>'Could not read the uploaded bill.'];}
        if(strlen($bin)>6*1024*1024){return ['ok'=>false,'message'=>'Bill file is too large. Maximum allowed size is 6 MB.'];}
        $mime=strtolower($bm[1]);
        /* Safety net only (the browser already compresses to ~60 KB): if an oversized photo still arrives, shrink it. */
        if($mime!=='application/pdf' && strlen($bin)>120000 && function_exists('imagecreatefromstring') && function_exists('imagejpeg')){
            $gi=@imagecreatefromstring($bin);
            if($gi){
                $gw=imagesx($gi);$gh=imagesy($gi);$best=null;
                foreach([1400,1200,1000] as $md){
                    $gs=min(1,$md/max($gw,$gh));
                    $nw=max(1,(int)round($gw*$gs));$nh=max(1,(int)round($gh*$gs));
                    $canvas=imagecreatetruecolor($nw,$nh);
                    imagefill($canvas,0,0,imagecolorallocate($canvas,255,255,255));
                    imagecopyresampled($canvas,$gi,0,0,0,0,$nw,$nh,$gw,$gh);
                    if(function_exists('imagefilter')){@imagefilter($canvas,IMG_FILTER_GRAYSCALE);@imagefilter($canvas,IMG_FILTER_CONTRAST,-12);}
                    $done=false;
                    foreach([75,65,55,48] as $qq){
                        ob_start();imagejpeg($canvas,null,$qq);$out=ob_get_clean();
                        if(is_string($out)&&$out!==''&&($best===null||strlen($out)<strlen($best)))$best=$out;
                        if(is_string($out)&&strlen($out)<=60000){$done=true;break;}
                    }
                    imagedestroy($canvas);
                    if($done)break;
                }
                imagedestroy($gi);
                if(is_string($best)&&$best!==''&&strlen($best)<strlen($bin)){$bin=$best;$mime='image/jpeg';}
            }
        }
        $billOriginalName=$billName!==''?$billName:('Cash Bill - '.$date);
        // New Cash Book bills are stored in Cloudinary. Existing bills already
        // stored under /bills remain valid and are not migrated or deleted here.
        $cloudResult=uploadCashBillToCloudinary($bin,$mime,$billOriginalName,$date);
        if(!$cloudResult['ok']){
            return ['ok'=>false,'message'=>$cloudResult['message']];
        }
        return ['ok'=>true,'url'=>$cloudResult['url'],'type'=>$mime,'name'=>$billOriginalName];
}

/* Lists every file currently in the Cloudinary "cashbook_bills" folder (Admin API, paged).
 * Returns an array of public_ids, or null if Cloudinary could not be reached (callers must then change nothing). */
function listCloudBillIds(): ?array {
    if (!defined('CLOUDINARY_CLOUD_NAME') || !defined('CLOUDINARY_API_KEY') || !defined('CLOUDINARY_API_SECRET') || !function_exists('curl_init')) return null;
    $ids = []; $cursor = ''; $pages = 0;
    do {
        $url = 'https://api.cloudinary.com/v1_1/' . rawurlencode(CLOUDINARY_CLOUD_NAME) . '/resources/image/upload?prefix=' . rawurlencode('cashbook_bills/') . '&max_results=500' . ($cursor !== '' ? '&next_cursor=' . rawurlencode($cursor) : '');
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_CONNECTTIMEOUT=>10, CURLOPT_TIMEOUT=>30,
            CURLOPT_USERPWD=>CLOUDINARY_API_KEY . ':' . CLOUDINARY_API_SECRET, CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2]);
        $resp = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        $d = json_decode((string)$resp, true);
        if ($resp === false || $code !== 200 || !is_array($d) || !isset($d['resources'])) return null;
        foreach ($d['resources'] as $r) { if (!empty($r['public_id'])) $ids[(string)$r['public_id']] = true; }
        $cursor = (string)($d['next_cursor'] ?? '');
    } while ($cursor !== '' && ++$pages < 20);
    return array_keys($ids);
}
function cloudBillPublicId(string $url): ?string {
    if (!preg_match('#^https?://res\.cloudinary\.com/[^/]+/image/upload/(?:[^/]+/)*?(?:v\d+/)?(cashbook_bills/[^?\#]+)#i', $url, $m)) return null;
    return preg_replace('/\.[A-Za-z0-9]{2,5}$/', '', rawurldecode($m[1]));
}

/* Security/compatibility baseline: use safer session cookies when supported and
   send modern browser security headers without changing the existing UX. */
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.gc_maxlifetime', '86400'); /* keep PHP session files for 24 h to prevent short host defaults */
session_set_cookie_params([
    'lifetime' => 86400,
    'path' => '/',
    'secure' => $https,
    'httponly' => true,
    'samesite' => 'Lax'
]);
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: SAMEORIGIN');
header('Permissions-Policy: camera=(self), microphone=(), geolocation=()');
/* Do not cache authenticated/application responses. */
header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
/* Compress output (HTML/CSS/JS/JSON) if the browser supports it and the
   server has zlib available — cuts the ~200KB page down substantially
   on the wire without changing anything else. */
if (!ob_start('ob_gzhandler')) { ob_start(); }
session_start();
/* Action (AJAX) requests must ALWAYS answer with JSON: never leak PHP warnings into the reply, and turn a fatal
   error into a JSON message instead of a blank/HTML page (which the app showed as "Invalid server response"). */
if(($_SERVER['REQUEST_METHOD']??'')==='POST' && isset($_GET['action'])){
    @ini_set('display_errors','0');
    register_shutdown_function(function(){
        $e=error_get_last();
        if($e && in_array($e['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR],true)){
            error_log('Fatal in action request: '.$e['message'].' @ '.$e['file'].':'.$e['line']);
            while(ob_get_level())@ob_end_clean();
            if(!headers_sent()){http_response_code(500);header('Content-Type: application/json; charset=utf-8');}
            echo json_encode(['status'=>'error','message'=>'Server error. Please try again in a moment.']);
        }
    });
}
/* ---- DEMO ADMIN ACCOUNT (for testing / showing to buyers) ----
   Logs in as an Admin but works ONLY on a separate store ("demo") filled with sample data.
   The real company data is never read or changed. Set DEMO_ENABLED to false to switch it off. */
if(!defined('DEMO_ENABLED'))define('DEMO_ENABLED',false);
if(!defined('DEMO_USER'))define('DEMO_USER','demo');
if(!defined('DEMO_PASS'))define('DEMO_PASS','demo123');
function isDemo(){return !empty($_SESSION['demo']);}
function dbStore(){return isDemo()?'demo':'database';}
function demoDatabase(){
    $d=defaultDatabase();
    $d['company']['name']='Demo Construction Pvt Ltd';
    $d['company']['addr']='123 Sample Road, Bangalore 560001';
    $d['admin']=['user'=>DEMO_USER,'pass'=>''];
    $d['admin_users']=[];
    $d['security']=[];
    $d['employees']=[[
        'id'=>'DM001','name'=>'Demo Engineer','des'=>'Site Engineer','project'=>'Demo Tower','doj'=>'01-01-2025','bank'=>'Demo Bank',
        'acc'=>'000000000000','ctc'=>40000,'pf_no'=>'','esi_no'=>'','pan'=>'AAAAA0000A','uan'=>'000000000000','grade'=>'G1',
        'basic_rate'=>20000,'hra_rate'=>10000,'lta_rate'=>1000,'special_rate'=>8000,'mobile_rate'=>1000,'pf_ded'=>1800,
        'pt_ded'=>200,'emp_pf_ded'=>1800,'user'=>'demo.emp','pass'=>'demo123'
    ]];
    $t=date('Y-m-d');$now=date('Y-m-d H:i:s');
    $mk=function($sheet,$desc,$n,$l,$b,$dp,$u,$ded)use($t,$now){
        $v=array_filter([$n,$l,$b,$dp],function($x){return $x!==null;});$q=1.0;foreach($v as $x)$q*=$x;$q=round($q,3);if($ded)$q=-$q;
        return ['id'=>uniqid('ms_',true),'date'=>$t,'project'=>'Demo Tower','sheet'=>$sheet,'description'=>$desc,'nos'=>$n,'length'=>$l,'breadth'=>$b,'depth'=>$dp,
            'unit'=>$u,'qty'=>$q,'deduct'=>$ded,'remarks'=>'','employee_id'=>'DM001','employee_name'=>'Demo Engineer','created'=>$now];
    };
    $d['measurements']=[
        $mk('RCC Footing - Block A','F1 footing',4,1.5,1.5,0.45,'Cum',false),
        $mk('RCC Footing - Block A','F2 footing',6,1.2,1.2,0.4,'Cum',false),
        $mk('RCC Footing - Block A','Less: pedestal opening',2,0.3,0.3,0.45,'Cum',true),
        $mk('Brick Masonry - Ground Floor','External wall',1,12.5,0.23,3.0,'Cum',false),
    ];
    return $d;
}
/* SINGLE FILE HR PORTAL
   PHP + HTML + CSS + JS + ONLINE JSON STORAGE
*/
$db_file = __DIR__ . '/data.json';   /* legacy source only: used once to import old JSON data into MySQL */
define('DATA_FLAGS',JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
/* ===================== MySQL storage =====================
   Connection settings live in db_config.php (blocked from download in .htaccess).
   One table, app_store(store,k,v): every top-level key of the app data is one row, so a save only
   rewrites the rows that actually changed.  Stores: database, biometrics, sw_sessions, login_attempts.
   On first use each store is imported automatically from the old data.json / *.json files. */
function dataLegacyFiles(){return ['database'=>'database.json','biometrics'=>'biometrics.json','sw_sessions'=>'sw_sessions.json','login_attempts'=>'login_attempts.json'];}
function dataLegacySection($store){
    $f=__DIR__.'/data.json';
    if(is_file($f)){$all=json_decode((string)@file_get_contents($f),true);if(is_array($all)&&isset($all[$store])&&is_array($all[$store]))return $all[$store];}
    $l=dataLegacyFiles();
    if(isset($l[$store])&&is_file(__DIR__.'/'.$l[$store])){$v=json_decode((string)@file_get_contents(__DIR__.'/'.$l[$store]),true);if(is_array($v))return $v;}
    return [];
}
function dataPdo(){
    static $pdo=null,$tried=false;
    if($tried)return $pdo; $tried=true;
    try{
        $f=__DIR__.'/db_config.php'; $c=is_file($f)?require $f:[]; if(!is_array($c))$c=[];
        $dsn=$c['dsn']??('mysql:host='.($c['host']??'localhost').';'.(!empty($c['port'])?'port='.(int)$c['port'].';':'').'dbname='.($c['name']??'').';charset=utf8mb4');
        $pdo=new PDO($dsn,$c['user']??null,$c['pass']??null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_NUM,PDO::ATTR_TIMEOUT=>8]);
        $my=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql';
        if($my)$pdo->exec("SET NAMES utf8mb4");
        try{$pdo->query('SELECT 1 FROM app_store LIMIT 1')->fetchAll();}
        catch(Throwable $e){
            $pdo->exec($my
              ?"CREATE TABLE IF NOT EXISTS app_store (store VARCHAR(32) CHARACTER SET ascii NOT NULL, k VARCHAR(255) CHARACTER SET ascii NOT NULL, v LONGTEXT NOT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY (store,k)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
              :"CREATE TABLE IF NOT EXISTS app_store (store TEXT NOT NULL, k TEXT NOT NULL, v TEXT NOT NULL, updated_at TEXT, PRIMARY KEY (store,k))");
            foreach(array_keys(dataLegacyFiles()) as $st)$pdo->prepare(($my?'INSERT IGNORE':'INSERT OR IGNORE').' INTO app_store (store,k,v) VALUES (?,?,?)')->execute(['_lock',$st,'']);
        }
        try{ledgerEnsure($pdo);}catch(Throwable $e){error_log('Ledger setup failed: '.$e->getMessage());}
    }catch(Throwable $e){error_log('MySQL connect/setup failed: '.$e->getMessage());$pdo=null;}
    return $pdo;
}
function dataCanon($v){
    if(is_array($v)){
        $list=($v===[]||array_keys($v)===range(0,count($v)-1));
        if(!$list)ksort($v,SORT_STRING);
        return array_map('dataCanon',$v);
    }
    return $v;
}
function dataSame($a,$b){return json_encode(dataCanon($a),DATA_FLAGS)===json_encode(dataCanon($b),DATA_FLAGS);}
function dataMeta($pdo,$name){$pdo->prepare('REPLACE INTO app_store (store,k,v) VALUES (?,?,?)')->execute(['_meta',$name,'1']);}
/* returns [array rows(decoded), array rawJsonByKey, bool migrated] */
function dataReadStore($pdo,$store){
    $st=$pdo->prepare("SELECT store,k,v FROM app_store WHERE store IN (?, '_meta')"); $st->execute([$store]);
    $arr=[];$raw=[];$mig=false;
    foreach($st->fetchAll() as $r){
        if($r[0]==='_meta'){if($r[1]==='migrated:'.$store)$mig=true;continue;}
        $raw[$r[1]]=$r[2]; $arr[$r[1]]=json_decode($r[2],true);
    }
    return [$arr,$raw,$mig];
}
/* ===================== Blockchain-style hash-chain ledger (tamper-evident storage) =====================
   Every change to a tracked store (database, biometrics) is recorded as a block in app_ledger,
   inside the same MySQL transaction as the data write. Each block holds the SHA-256 of the saved
   value (not the value itself, so it stays small) and the hash of the previous block, so editing,
   deleting or re-ordering anything later breaks the chain. "Verify" re-checks the whole chain and
   compares it with what is actually in app_store right now. */
if(!defined('LEDGER_STORES'))define('LEDGER_STORES',['database','biometrics']);
function ledgerTracked($store){return in_array($store,LEDGER_STORES,true);}
function ledgerEnsure($pdo){
    static $done=false; if($done)return; $done=true;
    $my=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql';
    try{$pdo->query('SELECT 1 FROM app_ledger LIMIT 1')->fetchAll();}
    catch(Throwable $e){
        $pdo->exec($my
          ?"CREATE TABLE IF NOT EXISTS app_ledger (height BIGINT UNSIGNED NOT NULL PRIMARY KEY, ts BIGINT NOT NULL, store VARCHAR(32) CHARACTER SET ascii NOT NULL, k VARCHAR(255) CHARACTER SET ascii NOT NULL, op VARCHAR(8) CHARACTER SET ascii NOT NULL, data_hash CHAR(64) CHARACTER SET ascii NOT NULL, prev_data_hash CHAR(64) CHARACTER SET ascii NOT NULL, prev_hash CHAR(64) CHARACTER SET ascii NOT NULL, block_hash CHAR(64) CHARACTER SET ascii NOT NULL, KEY ix_key (store,k,height)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
          :"CREATE TABLE IF NOT EXISTS app_ledger (height INTEGER PRIMARY KEY, ts INTEGER NOT NULL, store TEXT NOT NULL, k TEXT NOT NULL, op TEXT NOT NULL, data_hash TEXT NOT NULL, prev_data_hash TEXT NOT NULL, prev_hash TEXT NOT NULL, block_hash TEXT NOT NULL)");
    }
    $pdo->prepare(($my?'INSERT IGNORE':'INSERT OR IGNORE').' INTO app_store (store,k,v) VALUES (?,?,?)')->execute(['_lock','_ledger','']);
}
function ledgerBlockHash($h,$ts,$store,$k,$op,$dh,$pdh,$prev){return hash('sha256',implode('|',[$h,$ts,$store,$k,$op,$dh,$pdh,$prev]));}
/* Append blocks for the keys this save touched. Call inside the open transaction, after the data writes.
   $oldRaw = raw JSON per key before the save, $newRaw = raw JSON per key after the save. */
function ledgerAppend($pdo,$store,array $oldRaw,array $newRaw){
    if(!ledgerTracked($store))return;
    $my=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql'; $zero=str_repeat('0',64);
    if($my){$q=$pdo->prepare("SELECT v FROM app_store WHERE store='_lock' AND k=? FOR UPDATE");$q->execute(['_ledger']);$q->fetchAll();}
    $changes=[]; $queued=[];
    foreach($newRaw as $k=>$j){$k=(string)$k;if(!array_key_exists($k,$oldRaw)||$oldRaw[$k]!==$j){$changes[]=[$k,'set',hash('sha256',$j),array_key_exists($k,$oldRaw)?hash('sha256',$oldRaw[$k]):$zero];$queued[$k]=1;}}
    foreach($oldRaw as $k=>$j){$k=(string)$k;if(!array_key_exists($k,$newRaw)){$changes[]=[$k,'del',$zero,hash('sha256',$j)];$queued[$k]=1;}}
    /* Keys that exist but were never sealed (data from before the ledger existed) are sealed once, as they are now. */
    $sealed=[];$q=$pdo->prepare('SELECT DISTINCT k FROM app_ledger WHERE store=?');$q->execute([$store]);foreach($q->fetchAll() as $r)$sealed[$r[0]]=1;
    foreach($newRaw as $k=>$j){$k=(string)$k;if(!isset($sealed[$k])&&!isset($queued[$k])){$h=hash('sha256',$j);$changes[]=[$k,'set',$h,$h];}}
    if(!$changes)return;
    $last=$pdo->query('SELECT height,block_hash FROM app_ledger ORDER BY height DESC LIMIT 1')->fetchAll();
    $h=$last?(int)$last[0][0]:0; $prev=$last?$last[0][1]:$zero;
    $ins=$pdo->prepare('INSERT INTO app_ledger (height,ts,store,k,op,data_hash,prev_data_hash,prev_hash,block_hash) VALUES (?,?,?,?,?,?,?,?,?)');
    $ts=time();
    foreach($changes as $c){
        $h++; $bh=ledgerBlockHash($h,$ts,$store,$c[0],$c[1],$c[2],$c[3],$prev);
        $ins->execute([$h,$ts,$store,$c[0],$c[1],$c[2],$c[3],$prev,$bh]); $prev=$bh;
    }
}
/* Document registry + external anchors (OpenTimestamps). Tables are created on first admin use. */
function ledgerEnsureExtra($pdo){
    static $d=false; if($d)return; $d=true;
    $my=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql';
    $mk=function($t,$mysql,$lite)use($pdo,$my){try{$pdo->query("SELECT 1 FROM $t LIMIT 1")->fetchAll();}catch(Throwable $e){$pdo->exec($my?$mysql:$lite);}};
    $mk('app_docs',
      "CREATE TABLE IF NOT EXISTS app_docs (path_hash CHAR(40) CHARACTER SET ascii NOT NULL, sha256 CHAR(64) CHARACTER SET ascii NOT NULL, path TEXT NOT NULL, size BIGINT NOT NULL, ts BIGINT NOT NULL, PRIMARY KEY (path_hash,sha256)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
      "CREATE TABLE IF NOT EXISTS app_docs (path_hash TEXT NOT NULL, sha256 TEXT NOT NULL, path TEXT NOT NULL, size INTEGER NOT NULL, ts INTEGER NOT NULL, PRIMARY KEY (path_hash,sha256))");
    $mk('app_anchors',
      "CREATE TABLE IF NOT EXISTS app_anchors (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, ts BIGINT NOT NULL, height BIGINT NOT NULL, head_hash CHAR(64) CHARACTER SET ascii NOT NULL, docs INT NOT NULL, docs_root CHAR(64) CHARACTER SET ascii NOT NULL, anchor_text TEXT NOT NULL, proofs LONGTEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
      "CREATE TABLE IF NOT EXISTS app_anchors (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, height INTEGER NOT NULL, head_hash TEXT NOT NULL, docs INTEGER NOT NULL, docs_root TEXT NOT NULL, anchor_text TEXT NOT NULL, proofs TEXT NOT NULL)");
}
function ledgerDocWalk($v,$path,&$out){
    if(is_string($v)){
        if(strlen($v)>2000&&strncmp($v,'data:',5)===0){
            $p=strpos($v,';base64,');
            if($p!==false&&$p<100){$bin=base64_decode(substr($v,$p+8),true);if($bin!==false)$out[$path]=[hash('sha256',$bin),strlen($bin)];}
        }
    }elseif(is_array($v)){
        foreach($v as $k=>$x){
            $seg=(is_array($x)&&isset($x['id'])&&is_scalar($x['id']))?'#'.$x['id']:$k;
            ledgerDocWalk($x,$path.'/'.$seg,$out);
        }
    }
}
/* Hash every embedded document (photos, bills, ID images stored as data: URLs). New or changed hashes are recorded with a timestamp. */
function ledgerDocScan($pdo,$record){
    ledgerEnsureExtra($pdo);
    $docs=[];
    $st=$pdo->prepare('SELECT k,v FROM app_store WHERE store=?');$st->execute(['database']);
    while($r=$st->fetch()){$d=json_decode($r[1],true);if(is_array($d))ledgerDocWalk($d,'database/'.$r[0],$docs);unset($d);}
    $known=[];foreach($pdo->query('SELECT path_hash,sha256 FROM app_docs')->fetchAll() as $r)$known[$r[0]][$r[1]]=1;
    $my=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql';
    $ins=$pdo->prepare(($my?'INSERT IGNORE':'INSERT OR IGNORE').' INTO app_docs (path_hash,sha256,path,size,ts) VALUES (?,?,?,?,?)');
    $new=0;$changed=0;$now=time();
    ksort($docs,SORT_STRING);$lines=[];
    foreach($docs as $path=>$info){
        $ph=sha1($path);$lines[]=$path.'|'.$info[0];
        if(isset($known[$ph][$info[0]]))continue;
        if(isset($known[$ph]))$changed++;else $new++;
        if($record)$ins->execute([$ph,$info[0],$path,$info[1],$now]);
    }
    return ['count'=>count($docs),'new'=>$new,'changed'=>$changed,'root'=>hash('sha256',implode("\n",$lines))];
}
function ledgerHead($pdo){$r=$pdo->query('SELECT height,block_hash FROM app_ledger ORDER BY height DESC LIMIT 1')->fetchAll();return $r?[(int)$r[0][0],$r[0][1]]:null;}
function ledgerOtsMagic(){return hex2bin('004f70656e54696d657374616d7073000050726f6f6600bf89e2e884e89294');}
/* Full audit. Returns a plain array that is safe to send to the browser. */
function ledgerVerify(){
    $pdo=dataPdo(); if(!$pdo)return ['ok'=>false,'message'=>'MySQL is not available.'];
    ledgerEnsure($pdo);
    $issues=[]; $prev=str_repeat('0',64); $exp=1; $latest=[]; $cont=[]; $n=0; $headTs=0;
    foreach($pdo->query('SELECT height,ts,store,k,op,data_hash,prev_data_hash,prev_hash,block_hash FROM app_ledger ORDER BY height ASC')->fetchAll() as $r){
        list($h,$ts,$st,$k,$op,$dh,$pdh,$ph,$bh)=$r; $h=(int)$h; $n++; $headTs=(int)$ts;
        if($h!==$exp)$issues[]="Block #$exp is missing (found #$h next) - a block was deleted.";
        $exp=$h+1;
        if($ph!==$prev)$issues[]="Block #$h does not link to the block before it.";
        if(ledgerBlockHash($h,$ts,$st,$k,$op,$dh,$pdh,$ph)!==$bh)$issues[]="Block #$h was edited (its hash does not match its content).";
        $id=$st.'/'.$k;
        if(isset($cont[$id])&&$cont[$id]!==$pdh)$issues[]="Block #$h: '$id' was changed directly in the database between two app saves.";
        $cont[$id]=$dh; $latest[$id]=($op==='del')?null:$dh;
        $prev=$bh;
    }
    $anchors=0;$ds=null;
    try{
        ledgerEnsureExtra($pdo);
        foreach($pdo->query('SELECT id,height,head_hash FROM app_anchors ORDER BY id')->fetchAll() as $a){
            $q=$pdo->prepare('SELECT block_hash FROM app_ledger WHERE height=?');$q->execute([(int)$a[1]]);$b=$q->fetchAll();$anchors++;
            if(!$b)$issues[]="Anchor #{$a[0]} refers to block #{$a[1]}, which no longer exists.";
            elseif($b[0][0]!==$a[2])$issues[]="Anchor #{$a[0]} does not match block #{$a[1]} - the chain was rewritten after it was anchored.";
        }
        $ds=ledgerDocScan($pdo,true);
    }catch(Throwable $e){error_log('Ledger doc/anchor check failed: '.$e->getMessage());}
    $untracked=0;
    foreach(LEDGER_STORES as $st){
        $q=$pdo->prepare('SELECT k,v FROM app_store WHERE store=?');$q->execute([$st]);$seen=[];
        foreach($q->fetchAll() as $r){
            $id=$st.'/'.$r[0];$seen[$id]=1;
            if(!array_key_exists($id,$latest))$untracked++;
            elseif($latest[$id]===null)$issues[]="'$id' exists in the database but the ledger says it was deleted.";
            elseif($latest[$id]!==hash('sha256',$r[1]))$issues[]="'$id' in the database does not match its last ledger entry (changed outside the app).";
        }
        foreach($latest as $id=>$dh){if(strpos($id,$st.'/')===0&&$dh!==null&&!isset($seen[$id]))$issues[]="'$id' is in the ledger but missing from the database.";}
    }
    return ['ok'=>!$issues,'blocks'=>$n,'head'=>$prev,'head_time'=>$headTs?date('Y-m-d H:i:s',$headTs):'','untracked'=>$untracked,'anchors'=>$anchors,'docs'=>$ds?$ds['count']:0,'docs_new'=>$ds?$ds['new']:0,'docs_changed'=>$ds?$ds['changed']:0,'issues'=>array_slice($issues,0,25),'issue_count'=>count($issues)];
}
/* Locked read-modify-write of one store. $fn(array &$rows). Returns $fn's result, or null if MySQL is unavailable / the write failed. */
$GLOBALS['dataLastError']='';
function dataStoreTx($store,$fn){
    $pdo=dataPdo(); if(!$pdo)return null;
    $my=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql';
    try{
        $pdo->beginTransaction();
        if($my){$q=$pdo->prepare("SELECT v FROM app_store WHERE store='_lock' AND k=? FOR UPDATE");$q->execute([$store]);$q->fetchAll();}
        list($arr,$raw,$mig)=dataReadStore($pdo,$store);
        if(!$mig){
            /* First use of this store: import the old JSON, read it back from MySQL and compare. Only a matching copy is marked "verified". */
            if(!count($arr))$arr=dataLegacySection($store);
            $imp=$pdo->prepare('REPLACE INTO app_store (store,k,v) VALUES (?,?,?)');
            foreach($arr as $k=>$v){$j=json_encode($v,DATA_FLAGS);if($j===false)throw new Exception('JSON encode failed for '.$store.'.'.$k);$imp->execute([$store,(string)$k,$j]);}
            list($chk,$raw)=dataReadStore($pdo,$store);
            dataMeta($pdo,'migrated:'.$store);
            if(dataSame($chk,$arr))dataMeta($pdo,'verified:'.$store);
        }
        $res=$fn($arr);
        $ins=$pdo->prepare('REPLACE INTO app_store (store,k,v) VALUES (?,?,?)');
        $newRaw=[];
        foreach($arr as $k=>$v){
            $k=(string)$k; $j=json_encode($v,DATA_FLAGS); if($j===false)throw new Exception('JSON encode failed for '.$store.'.'.$k);
            $newRaw[$k]=$j;
            if(!isset($raw[$k])||$raw[$k]!==$j)$ins->execute([$store,$k,$j]);
        }
        $del=$pdo->prepare('DELETE FROM app_store WHERE store=? AND k=?');
        foreach($raw as $k=>$_){if(!array_key_exists($k,$arr)&&!array_key_exists((int)$k,$arr))$del->execute([$store,$k]);}
        /* Fail closed: tracked data and its audit blocks must commit atomically.
           If app_ledger cannot be written, roll back the business-data update too. */
        ledgerAppend($pdo,$store,$raw,$newRaw);
        $pdo->commit();
        return $res;
    }catch(Throwable $e){
        if($pdo->inTransaction())$pdo->rollBack();
        error_log('dataStoreTx('.$store.') failed: '.$e->getMessage());
        $GLOBALS['dataLastError']=$e->getMessage();
        return null;
    }
}
function dataSectionTx($store,$fn){return dataStoreTx($store,$fn);}
/* Replace a whole store (used for the main database and biometric keys). */
function dataStoreSet($store,$data){return dataStoreTx($store,function(&$a) use($data){$a=is_array($data)?$data:[];return true;});}
/* Read a store. null = MySQL unavailable or store empty. */
/* Deletes the old JSON files, but only those whose content is confirmed to be in MySQL. Returns the list of deleted files. */
function dataCleanupLegacy(){
    $files=[]; foreach(dataLegacyFiles() as $st=>$f)if(is_file(__DIR__.'/'.$f))$files[$st]=$f;
    $hasData=is_file(__DIR__.'/data.json');
    if(!$files&&!$hasData)return [];
    $pdo=dataPdo(); if(!$pdo)return [];
    $deleted=[];
    try{
        $meta=[]; foreach($pdo->query("SELECT k FROM app_store WHERE store='_meta'")->fetchAll() as $r)$meta[$r[0]]=true;
        /* import every store that still has an old JSON source and has not been migrated yet */
        $redo=false;
        foreach(array_keys(dataLegacyFiles()) as $st){if(empty($meta['migrated:'.$st])&&($hasData||isset($files[$st]))){dataStoreTx($st,function(&$a){return true;});$redo=true;}}
        if($redo){$meta=[];foreach($pdo->query("SELECT k FROM app_store WHERE store='_meta'")->fetchAll() as $r)$meta[$r[0]]=true;}
        $ver=[];
        foreach(array_keys(dataLegacyFiles()) as $st){
            if(!empty($meta['verified:'.$st])){$ver[$st]=true;continue;}
            if(empty($meta['migrated:'.$st]))continue;
            if(in_array($st,['sw_sessions','login_attempts'],true)){$ver[$st]=true;continue;}   /* temporary data, nothing to keep */
            $legacy=dataLegacySection($st); list($cur)=dataReadStore($pdo,$st);
            if(dataSame($cur,$legacy)){$ver[$st]=true;dataMeta($pdo,'verified:'.$st);}
        }
        foreach($files as $st=>$f)if(!empty($ver[$st])&&@unlink(__DIR__.'/'.$f))$deleted[]=$f;
        if($hasData&&count($ver)===count(dataLegacyFiles())){foreach(['data.json','data.json.lock','data.json.tmp'] as $f)if(is_file(__DIR__.'/'.$f)&&@unlink(__DIR__.'/'.$f))$deleted[]=$f;}
    }catch(Throwable $e){error_log('dataCleanupLegacy failed: '.$e->getMessage());}
    return $deleted;
}
/* Import uploaded old JSON text(s) into MySQL, verify by reading back, then delete the old files on the server. Returns [report[], deleted[]]. */
function dataImportUploadedJson($pdo,$files){
        $report=[];
        foreach($files as $name=>$text){
            $name=basename((string)$name);
            $text=(string)$text;
            if(substr($text,0,3)==="\xEF\xBB\xBF")$text=substr($text,3);          /* UTF-8 BOM from Windows editors */
            $data=json_decode($text,true);
            if(!is_array($data)){$report[]=$name.': not valid JSON ('.json_last_error_msg().') - skipped';continue;}
            /* Detect by CONTENT, so "database (1).json", "database_backup.json", etc. also work. */
            $lname=strtolower($name);
            if(array_key_exists('database',$data)&&is_array($data['database']))$sections=$data;                       /* old data.json */
            elseif(array_key_exists('company',$data)&&array_key_exists('employees',$data))$sections=['database'=>$data];  /* database.json */
            elseif(strpos($lname,'biometric')!==false)$sections=['biometrics'=>$data];                               /* biometrics.json */
            else{
                $isBio=count($data)>0;foreach($data as $v){if(!is_array($v)||!isset($v['pem'])){$isBio=false;break;}}
                if($isBio)$sections=['biometrics'=>$data];
                else{$report[]=$name.': not recognised - it must be the old database.json (with "company" and "employees"), biometrics.json or data.json - skipped';continue;}
            }
            foreach($sections as $st=>$arr){
                if(!in_array($st,['database','biometrics'],true)||!is_array($arr))continue;
                if($st==='database'&&(!array_key_exists('company',$arr)||!array_key_exists('employees',$arr))){$report[]=$name.': does not look like the app database - skipped';continue;}
                if(dataStoreSet($st,$arr)===null){$report[]=$name.': MySQL write failed - '.($GLOBALS['dataLastError']?:'unknown error').' (nothing was changed)';continue;}
                list($chk)=dataReadStore($pdo,$st);
                if(dataSame($chk,$arr)){dataMeta($pdo,'migrated:'.$st);dataMeta($pdo,'verified:'.$st);$report[]=$name.' ('.$st.'): imported and verified, '.count($arr).' rows';}
                else $report[]=$name.' ('.$st.'): imported but verification FAILED - old file kept';
            }
        }
        $deleted=dataCleanupLegacy();
        return [$report,$deleted];
}
/* True while the database is still the untouched factory default (nothing imported, no employees added, default admin login). */
function dataIsPristine($pdo){
    try{
        list($cur)=dataReadStore($pdo,'database'); if(!count($cur))return true;
        $d=defaultDatabase();
        $au=$cur['admin_users']??[]; if(count($au)!==1||($au[0]['user']??'')!=='admin')return false;
        $pw=(string)($au[0]['pass']??''); if(!($pw==='admin123'||password_verify('admin123',$pw)))return false;
        $ids=function($a){$o=[];foreach((array)$a as $e)$o[]=(string)($e['id']??'');sort($o);return $o;};
        if($ids($cur['employees']??[])!==$ids($d['employees']??[]))return false;
        foreach(['contractors','punches','payslips','requests'] as $k){ if(!empty($cur[$k]))return false; }
        return true;
    }catch(Throwable $e){return false;}
}
function dataGet($store){
    $pdo=dataPdo(); if(!$pdo)return null;
    try{
        list($arr,$raw,$mig)=dataReadStore($pdo,$store);
        if(!$mig){dataStoreTx($store,function(&$a){return true;});list($arr)=dataReadStore($pdo,$store);}
        return count($arr)?$arr:null;
    }catch(Throwable $e){error_log('dataGet('.$store.') failed: '.$e->getMessage());return null;}
}

/* ===================== Files in MySQL (assets/ and app/) =====================
   Table app_files(path,mime,size,sha1,data LONGBLOB).  Every file under /assets and /app can be copied
   into MySQL with the admin tool  index.php?tool=files_mysql  (preview)  /  &run=1 (upload + verify)  /  &restore=1 (write back any file missing on disk).
   /assets files are ALSO served from MySQL whenever the real file is missing on the web server (see the rewrite rule in .htaccess),
   and new logo/seal uploads are saved to MySQL as well.  /app (Android source) is stored for backup only and is never served publicly. */
function filesPdo(){
    static $ready=false; $pdo=dataPdo(); if(!$pdo)return null;
    if(!$ready){
        try{
            $pdo->exec("CREATE TABLE IF NOT EXISTS app_files (path VARCHAR(255) CHARACTER SET ascii NOT NULL, mime VARCHAR(100) CHARACTER SET ascii NOT NULL, size INT UNSIGNED NOT NULL, sha1 CHAR(40) CHARACTER SET ascii NOT NULL, data LONGBLOB NOT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY (path)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $ready=true;
        }catch(Throwable $e){error_log('app_files setup failed: '.$e->getMessage());return null;}
    }
    return $pdo;
}
function filesMime($path){
    static $m=['png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','gif'=>'image/gif','webp'=>'image/webp','svg'=>'image/svg+xml','ico'=>'image/x-icon','css'=>'text/css','js'=>'application/javascript','json'=>'application/json','xml'=>'application/xml','kt'=>'text/plain','java'=>'text/plain','txt'=>'text/plain','md'=>'text/plain','gradle'=>'text/plain','pro'=>'text/plain','properties'=>'text/plain'];
    return $m[strtolower(pathinfo($path,PATHINFO_EXTENSION))]??'application/octet-stream';
}
function filesPathOk($p){
    return is_string($p)&&strlen($p)<=255&&preg_match('#^(assets|app)/[A-Za-z0-9_.\-/]+$#',$p)&&strpos($p,'..')===false&&strpos($p,'//')===false;
}
function filesPut($path,$bin){
    if(!filesPathOk($path)||!is_string($bin))return false;
    $pdo=filesPdo(); if(!$pdo)return false;
    try{
        $st=$pdo->prepare('REPLACE INTO app_files (path,mime,size,sha1,data) VALUES (?,?,?,?,?)');
        $st->bindValue(1,$path);$st->bindValue(2,filesMime($path));$st->bindValue(3,strlen($bin),PDO::PARAM_INT);$st->bindValue(4,sha1($bin));$st->bindValue(5,$bin,PDO::PARAM_LOB);
        $st->execute();
        $q=$pdo->prepare('SELECT sha1 FROM app_files WHERE path=?');$q->execute([$path]);$r=$q->fetch();
        return $r&&$r[0]===sha1($bin);
    }catch(Throwable $e){error_log('filesPut('.$path.') failed: '.$e->getMessage());return false;}
}
/* returns [mime,bytes,sha1] or null */
function filesGet($path){
    if(!filesPathOk($path))return null;
    $pdo=filesPdo(); if(!$pdo)return null;
    try{
        $q=$pdo->prepare('SELECT mime,data,sha1 FROM app_files WHERE path=?');$q->execute([$path]);$r=$q->fetch();
        if(!$r)return null;
        $d=is_resource($r[1])?stream_get_contents($r[1]):$r[1];
        return [$r[0],(string)$d,$r[2]];
    }catch(Throwable $e){error_log('filesGet('.$path.') failed: '.$e->getMessage());return null;}
}
/* All files under /assets and /app on disk: [relative path => absolute path] */
function filesOnDisk(){
    $out=[];
    foreach(['assets','app'] as $root){
        $base=__DIR__.'/'.$root; if(!is_dir($base))continue;
        $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base,FilesystemIterator::SKIP_DOTS));
        foreach($it as $f){
            if(!$f->isFile()||$f->isLink())continue;
            $rel=$root.'/'.str_replace(DIRECTORY_SEPARATOR,'/',substr($f->getPathname(),strlen($base)+1));
            if(filesPathOk($rel))$out[$rel]=$f->getPathname();
        }
    }
    ksort($out);return $out;
}
/* Public: serve a missing /assets file from MySQL.  Never serves app/ or dot-files. */
if($_SERVER['REQUEST_METHOD']==='GET'&&isset($_GET['asset'])){
    $ap=(string)$_GET['asset'];
    if(strpos($ap,'assets/')!==0||!filesPathOk($ap)||$ap[strrpos('/'.$ap,'/')-1]==='.'){http_response_code(404);exit;}
    $row=filesGet($ap);
    if(!$row){http_response_code(404);exit;}
    $etag='"'.$row[2].'"';
    header('Content-Type: '.$row[0]);header('X-Content-Type-Options: nosniff');
    header('Cache-Control: public, max-age=31536000, immutable');header('ETag: '.$etag);
    if(($_SERVER['HTTP_IF_NONE_MATCH']??'')===$etag){http_response_code(304);exit;}
    header('Content-Length: '.strlen($row[1]));echo $row[1];exit;
}

/* Server-response fix: the company logo/seal were being stored as base64 text
   directly inside database.json, then embedded THREE times in every single
   page response (two <img src="data:..."> tags plus once more inside the
   `let db = {...}` JSON dump used by the JS app). A ~100KB logo therefore
   added ~300KB of duplicated text to every request/response, on every page
   view, with zero caching. This does not change any feature — the same logo
   and seal still display exactly the same way — it just decodes that base64
   once to a real file under /assets and stores a short reusable URL instead,
   so the browser downloads the image once and caches it instead of
   re-receiving it as inline text on every load. */
$assetsDir = __DIR__ . '/assets';
function offloadBase64Asset($dataUri, $assetsDir, $baseName) {
    if (!is_string($dataUri) || strpos($dataUri, 'data:') !== 0) return $dataUri; // already a URL/path or empty — nothing to do
    if (!preg_match('#^data:image/([a-zA-Z0-9.+-]+);base64,(.+)$#', $dataUri, $m)) return $dataUri;
    $ext = strtolower($m[1]); if ($ext === 'jpeg') $ext = 'jpg';
    $ext = preg_replace('/[^a-z0-9]/', '', $ext); if ($ext === '') $ext = 'png';
    $bin = base64_decode($m[2]);
    if ($bin === false || $bin === '') return $dataUri;
    /* Cloud first (Cloudinary). Only if that fails do we fall back to the local /assets folder. */
    $cloud = uploadToCloudinaryFolder($bin, 'image/'.$m[1], 'company_assets', $baseName);
    if (!empty($cloud['ok'])) return $cloud['url'];
    $hash = substr(md5($bin), 0, 12);
    $fname = $baseName . '_' . $hash . '.' . $ext;
    $inMysql = filesPut('assets/' . $fname, $bin);   // always keep a copy in MySQL (served by ?asset= if the file is missing on disk)
    if (!is_dir($assetsDir)) @mkdir($assetsDir, 0755, true);
    $path = $assetsDir . '/' . $fname;
    $onDisk = is_dir($assetsDir) && (file_exists($path) || @file_put_contents($path, $bin) !== false);
    if (!$onDisk && !$inMysql) return $dataUri; // neither disk nor MySQL worked — fall back to inline base64, unchanged behavior
    return 'assets/' . $fname;
}

function defaultDatabase() {
    return [
        'company' => [
            'name' => 'L&W Construction Private Limited',

            'addr' => 'Pride Hulkul, 8th Floor, No.116, Lalbagh Road, Bangalore 5600027',
            'logo' => '', 'seal' => '', 'size' => 80, 'login_size' => 160, 'name_offset' => 0
        ],
        'admin' => ['user' => 'admin', 'pass' => 'admin123'],
        'admin_users' => [['user'=>'admin','pass'=>'admin123']],
        'security' => [
            ['site'=>'Site 1','user'=>'security1','pass'=>'security123'],
            ['site'=>'Site 2','user'=>'security2','pass'=>'security123'],
        ],
        'employees' => [[
            'id'=>'LW5315','name'=>'Kanagaraj','des'=>'Senior Engineer - Structural',
            'project'=>'Provenance Land','doj'=>'02-01-2024','bank'=>'SBI',
            'acc'=>'33119573043','ctc'=>56600,'pf_no'=>'','esi_no'=>'',
            'pan'=>'GVGPK3770Q','uan'=>'101156971239','grade'=>'LW18',
            'basic_rate'=>28300,'hra_rate'=>16650,'lta_rate'=>1494,
            'special_rate'=>10156,'mobile_rate'=>800,'pf_ded'=>1800,
            'pt_ded'=>200,'emp_pf_ded'=>1800,'user'=>'kanagaraj','pass'=>'pass123'
        ]],
        'attendance'=>[],'requests'=>[],'request_history'=>[],
        'leave_requests'=>[],'leave_history'=>[],
        'contractors'=>[],'contractor_attendance'=>[],'contractor_payments'=>[],
        'salary_advances'=>[],
        'cashbook'=>[],
        'measurements'=>[],
        'owner_payments'=>[],
        'punches'=>[],
        'face_ai'=>['enabled'=>false,'guard_identify'=>true,'require_emp'=>true,'require_guard'=>true,'liveness'=>true,'allow_unenrolled'=>true,'snapshots'=>false,'threshold'=>0.5],
        'holidays'=>[],
        'locked_payroll'=>[],
        'salary_paid'=>[],
        'shifts'=>['shift1'=>['name'=>'Shift 1','start'=>'08:00','end'=>'18:00'],'shift2'=>['name'=>'Shift 2','start'=>'09:00','end'=>'19:00']]
    ];
}

/* ---- Argon2id password hashing (falls back to bcrypt only if this PHP build lacks Argon2) ---- */
function pwAlgo(){return defined('PASSWORD_ARGON2ID')?PASSWORD_ARGON2ID:PASSWORD_DEFAULT;}
function pwOptions(){return defined('PASSWORD_ARGON2ID')?['memory_cost'=>19456,'time_cost'=>2,'threads'=>1]:[];}
function pwIsHashed($s){return is_string($s)&&preg_match('/^\$(argon2id|2y)\$/',$s)===1;}
function pwHash($plain){return password_hash((string)$plain,pwAlgo(),pwOptions());}
function pwVerify($stored,$plain){$stored=(string)$stored;return pwIsHashed($stored)&&password_verify((string)$plain,$stored);}
/* Never send password hashes to the browser: blank them and only tell the UI whether one is set. */
function pwPublicDb($d){
    if(!is_array($d))return $d;
    $strip=function($r){if(is_array($r)&&array_key_exists('pass',$r)){$r['has_pass']=((string)$r['pass']!=='');$r['pass']='';}return $r;};
    if(isset($d['admin']))$d['admin']=$strip($d['admin']);
    $d['face_ai']=faceCfg($d);
    foreach(['admin_users','security','employees','contractors'] as $k){
        if(isset($d[$k])&&is_array($d[$k])){foreach($d[$k] as $i=>$r){$d[$k][$i]=$strip($r);}}
    }
    return $d;
}

/* Contractor Bill / Labour Payment records are private: Admin sees all, an Employee only the contractors assigned to /
   created by them, a Contractor only their own, everyone else (incl. the not-logged-in login page) none. */
function cpScopeDb($d){
    if(!is_array($d))return $d;
    $role=$_SESSION['role']??'';
    $all=is_array($d['contractor_payments']??null)?$d['contractor_payments']:[];
    if($role==='admin')return $d;
    $allowed=[];
    if($role==='contractor'){$allowed[(string)($_SESSION['contractor_id']??'')]=true;}
    elseif($role==='emp'){
        $eid=(string)($_SESSION['employee_id']??'');$usr=(string)($_SESSION['user']??'');
        foreach(($d['contractors']??[]) as $c){
            $ids=array_map('strval',is_array($c['assigned_employee_ids']??null)?$c['assigned_employee_ids']:[]);
            if(in_array($eid,$ids,true)||(string)($c['created_by']??'')===$usr)$allowed[(string)($c['id']??'')]=true;
        }
    }
    $d['contractor_payments']=array_values(array_filter($all,function($r)use($allowed){return isset($allowed[(string)($r['contractor_id']??'')]);}));
    /* Measurement sheets: Admin sees all; an employee sees only their own entries; other roles none. */
    $d['measurements']=array_values(array_filter(is_array($d['measurements']??null)?$d['measurements']:[],function($r)use($role){return $role==='emp'&&(string)($r['employee_id']??'')===(string)($_SESSION['employee_id']??'');}));
    return $d;
}

function saveDatabase($data) {
    $json=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    if($json===false)return ['success'=>false,'error'=>json_last_error_msg()];
    $r=dataStoreSet(dbStore(),$data);
    if($r===null)return ['success'=>false,'error'=>'Cannot save to MySQL. Check db_config.php and the database connection.'];
    return ['success'=>true];
}

function saveOrFail($db) {
    $result=saveDatabase($db);
    if(!$result['success']){
        $GLOBALS['pushQueue']=[]; /* nothing was saved, so do not announce it */
        http_response_code(500);
        echo json_encode(['status'=>'error','message'=>'Database save failed.','details'=>$result['error']]);
        exit;
    }
}

if(dataGet(dbStore())===null){
    $result=saveDatabase(isDemo()?demoDatabase():defaultDatabase());
    if(!$result['success']) die('<h2>Database Setup Error</h2><p>'.htmlspecialchars($result['error']).'</p><p>Make sure this folder is writable by PHP.</p>');
}

$dbSection=dataGet(dbStore());
$json=$dbSection===null?false:json_encode($dbSection,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
if($json===false) die('<h2>Database Read Error</h2><p>Cannot connect to MySQL. Fill in db_config.php (host, database name, user, password).</p>');

if(trim($json)===''){
    $db=defaultDatabase(); $result=saveDatabase($db);
    if(!$result['success']) die('<h2>Database Repair Error</h2><p>'.htmlspecialchars($result['error']).'</p>');
}else{
    $db=json_decode($json,true);
    if(!is_array($db)){
        $backup=__DIR__.'/database_corrupt_'.date('Ymd_His').'.json';
        @file_put_contents($backup,(string)json_encode($dbSection));
        $db=defaultDatabase(); $result=saveDatabase($db);
        if(!$result['success']) die('<h2>Database JSON Error</h2><p>'.htmlspecialchars(json_last_error_msg()).'</p><p>'.htmlspecialchars($result['error']).'</p>');
    }
}
dataCleanupLegacy();
$defaults=defaultDatabase(); $changed=false;
/* An old database without admin_users must inherit ITS admin login, never the factory admin/admin123. */
if(!isset($db['admin_users'])&&isset($db['admin']['user'])){$db['admin_users']=[['user'=>$db['admin']['user'],'pass'=>$db['admin']['pass']??'']];$changed=true;}
foreach($defaults as $key=>$value){if(!isset($db[$key])){$db[$key]=$value;$changed=true;}}
if(!isset($db['company']['name_offset'])){$db['company']['name_offset']=0;$changed=true;}
if(isset($db['security']['user'])){
    $oldUser=$db['security']['user'];$oldPass=$db['security']['pass'];
    $db['security']=[
        ['site'=>'Site 1','user'=>$oldUser,'pass'=>$oldPass],
        ['site'=>'Site 2','user'=>'security2','pass'=>'security123'],
    ];
    $changed=true;
}
if(isset($db['security']) && is_array($db['security']) && count($db['security'])>2){
    $db['security']=array_slice($db['security'],0,2);
    $changed=true;
}
// Contractor access-control migration
$contractorChanged=false;
foreach($db['contractors'] as $ci=>$c){
    if(!isset($db['contractors'][$ci]['created_by'])){$db['contractors'][$ci]['created_by']='Admin';$contractorChanged=true;}
    if(!isset($db['contractors'][$ci]['assigned_employee_ids']) || !is_array($db['contractors'][$ci]['assigned_employee_ids'])){
        $db['contractors'][$ci]['assigned_employee_ids']=[];$contractorChanged=true;
    }
}
if($contractorChanged)saveDatabase($db);
$employeeChanged=false;
foreach($db['employees'] as $ei=>$e){
    if(!isset($db['employees'][$ei]['contractor_ids']) || !is_array($db['employees'][$ei]['contractor_ids'])){
        $legacy=trim((string)($e['contractor_id']??''));
        $db['employees'][$ei]['contractor_ids']=$legacy!==''?[$legacy]:[];
        $employeeChanged=true;
    }
    // Keep the old field for backward compatibility, but it is no longer a single-assignment control.
    if(!isset($db['employees'][$ei]['contractor_id'])){$db['employees'][$ei]['contractor_id']='';$employeeChanged=true;}
}
if($employeeChanged)saveDatabase($db);

// Normalize many-to-many employee <-> contractor assignments in both directions.
// Older records may have the relationship stored only on the employee record.
$assignmentChanged=false;
// Contractor access is authoritative from the Admin assignment. Reconcile both
// sides so an employee portal can never keep a stale contractor after Admin removes it.
$contractorByEmployee=[];
foreach(($db['contractors']??[]) as $ci=>$c){
    if(!isset($db['contractors'][$ci]['assigned_employee_ids']) || !is_array($db['contractors'][$ci]['assigned_employee_ids'])) $db['contractors'][$ci]['assigned_employee_ids']=[];
    $ids=array_values(array_unique(array_filter(array_map('strval',$db['contractors'][$ci]['assigned_employee_ids']),fn($v)=>$v!=='')));
    $db['contractors'][$ci]['assigned_employee_ids']=$ids;
    foreach($ids as $eid){$contractorByEmployee[$eid][]=(string)($c['id']??'');}
}
foreach(($db['employees']??[]) as $ei=>$e){
    $eid=(string)($e['id']??'');
    $canonical=array_values(array_unique($contractorByEmployee[$eid]??[]));
    $current=is_array($e['contractor_ids']??null)?array_values(array_unique(array_map('strval',$e['contractor_ids']))):[];
    if($canonical!==$current || (string)($e['contractor_id']??'')!==($canonical[0]??'')){
        $db['employees'][$ei]['contractor_ids']=$canonical;
        $db['employees'][$ei]['contractor_id']=$canonical[0]??'';
        $assignmentChanged=true;
    }
}
if($assignmentChanged)saveDatabase($db);

/* Company logo: one fixed hosted image, used on every screen (login, menu bar, payslip, ID card, reports). */
define('COMPANY_LOGO_URL','https://res.cloudinary.com/wpizqa3u/image/upload/v1791246585/file_000000008458820887ff6b6738cd6e8a.png');
/* Optimised copy of the logo for on-screen use: Cloudinary serves WebP/AVIF at a phone-sized width instead of the full PNG. */
define('COMPANY_LOGO_FAST',str_replace('/image/upload/','/image/upload/f_auto,q_auto,w_420,dpr_auto/',COMPANY_LOGO_URL));
define('COMPANY_SEAL_URL','https://res.cloudinary.com/wpizqa3u/image/upload/v1791247031/seal_cc05c9eb89b8.jpg');
if(($db['company']['logo']??'')!==COMPANY_LOGO_URL||($db['company']['seal']??'')!==COMPANY_SEAL_URL){$db['company']['logo']=COMPANY_LOGO_URL;$db['company']['seal']=COMPANY_SEAL_URL;saveDatabase($db);}

// One-time migration: replace every plaintext password with an Argon2id hash. Idempotent.
$pwChanged=false;
$pwHashIfPlain=function(&$rec) use (&$pwChanged){
    if(is_array($rec)&&isset($rec['pass'])&&is_string($rec['pass'])&&$rec['pass']!==''&&!pwIsHashed($rec['pass'])){
        $rec['pass']=pwHash($rec['pass']);$pwChanged=true;
    }
};
if(isset($db['admin']))$pwHashIfPlain($db['admin']);
foreach(['admin_users','security','employees','contractors'] as $pwK){
    if(isset($db[$pwK])&&is_array($db[$pwK])){foreach(array_keys($db[$pwK]) as $pwI){$pwHashIfPlain($db[$pwK][$pwI]);}}
}
if($pwChanged)saveDatabase($db);

// One-time offload of any existing inline base64 logo/seal (see offloadBase64Asset above).
// Idempotent: once converted to a short "assets/..." URL, this no-ops on every later request.
$assetsChanged=false;
if(!empty($db['company']['logo']) && strpos($db['company']['logo'],'data:')===0){
    $db['company']['logo']=offloadBase64Asset($db['company']['logo'],$assetsDir,'logo');
    $assetsChanged=true;
}
if(!empty($db['company']['seal']) && strpos($db['company']['seal'],'data:')===0){
    $db['company']['seal']=offloadBase64Asset($db['company']['seal'],$assetsDir,'seal');
    $assetsChanged=true;
}
if($assetsChanged)saveDatabase($db);

function contractorAssignedToEmployee($contractorId,$employeeId){
    global $db;
    foreach(($db['contractors']??[]) as $c){
        if(($c['id']??'')===$contractorId){
            return in_array($employeeId,($c['assigned_employee_ids']??[]),true);
        }
    }
    return false;
}
// Attendance/punch keys are formatted as "{employeeId}-{month}-{year}". Employee IDs can
// themselves contain dashes (e.g. "TD-02"), so pull the ID off the END of the key
// (dropping the numeric year and month) instead of splitting on the first dash.
function employeeIdFromAttendanceKey($key){
    $parts=explode('-',$key);
    if(count($parts)>=3){
        array_pop($parts); // year
        array_pop($parts); // month
        return implode('-',$parts);
    }
    return $key;
}
// Contractor attendance keys are formatted as "{contractorId}-{month}-{year}". Contractor
// IDs can themselves contain dashes (e.g. "SAN-CH"), so pull the ID off the END of the key
// (dropping the numeric year and month) instead of splitting on the first dash.
function contractorIdFromAttendanceKey($key){
    return employeeIdFromAttendanceKey($key);
}
/* ---- Single active login per account + 4-minute idle timeout (server-enforced) ----
   Registry file (next to database.json) maps a hashed account key to ONE active
   session (hashed PHP session id + browser-tab id + last activity). A second
   login for the same account - other browser, other device, OR another tab of the
   same browser - replaces the older login (newest login wins). A session idle for
   4 minutes expires and frees the account. Only hashes are stored. */
define('SW_IDLE_LIMIT',86400); /* 24 h inactivity window; avoids the previous 4-minute auto-logout */
define('SW_IDLE_GRACE',15);
function swHash($v){return hash('sha256','sw|'.$v);}
function swKey($session){return swHash(($session['role']??'').'|'.strtolower((string)($session['user']??'')));}
function swWithLock($fn){ // returns null if data.json cannot be opened
    return dataSectionTx('sw_sessions',function(&$reg) use($fn){
        $now=time();
        foreach($reg as $k=>$v){if(!is_array($v)||($now-(int)($v['t']??0))>SW_IDLE_LIMIT+SW_IDLE_GRACE)unset($reg[$k]);}
        return $fn($reg);
    });
}
/* Called at login. The NEW login always wins: it replaces any older login of the same account
   (other browser, other device, other tab), which is then logged out on its next request/check.
   true = registered; null = registry unavailable.
   Regenerates the session id inside the lock so register is atomic. */
function swTabHeader(){return substr(preg_replace('/[^A-Za-z0-9_-]/','',(string)($_SERVER['HTTP_X_TAB']??'')),0,64);}
function swClaim($session,$tab){
    $key=swKey($session); $tab=substr(preg_replace('/[^A-Za-z0-9_-]/','',(string)$tab),0,64);
    return swWithLock(function(&$reg) use($key,$tab){
        session_regenerate_id(true);
        $reg[$key]=['sid'=>swHash(session_id()),'tab'=>$tab,'t'=>time()];
        return true;
    });
}
function swTouch($refresh=true){ // 'ok' | 'gone' (expired / other browser took over) | 'replaced' (another tab of THIS browser took over)
    if(empty($_SESSION['role'])||!empty($_SESSION['demo']))return 'ok';
    $key=swKey($_SESSION); $sid=swHash(session_id()); $tab=swTabHeader();
    $r=swWithLock(function(&$reg) use($key,$sid,$tab,$refresh){
        if(!isset($reg[$key])||($reg[$key]['sid']??'')!==$sid)return 'gone';
        if(($reg[$key]['tab']??'')!==$tab)return 'replaced';
        if($refresh)$reg[$key]['t']=time();
        return 'ok';
    });
    return $r===null ? 'ok' : $r;
}
function swRelease($force=false){ // frees this login's slot; returns true when this tab/session owned it (or nothing was registered)
    if(empty($_SESSION['role'])||!empty($_SESSION['demo']))return true;
    $key=swKey($_SESSION); $sid=swHash(session_id()); $tab=swTabHeader();
    $r=swWithLock(function(&$reg) use($key,$sid,$tab,$force){
        if(!isset($reg[$key]))return true;
        if(($reg[$key]['sid']??'')===$sid&&($force||($reg[$key]['tab']??'')===$tab)){unset($reg[$key]);return true;}
        return (($reg[$key]['sid']??'')!==$sid); // other browser owns it: ours is stale, safe to drop; same browser other tab owns it: keep session
    });
    return $r===null ? true : $r;
}
/* ---- Brute-force protection (file based, blocked from download in .htaccess) ---- */
function rlWith($fn){
    return dataSectionTx('login_attempts',function(&$d) use($fn){
        $now=time();
        foreach($d as $k=>$v){ if(($v['until']??0)<$now && ($v['first']??0)<$now-900) unset($d[$k]); }
        return $fn($d,$now);
    });
}
function rlKeys($scope,$username,$globalUser=false){
    $ip=(string)($_SERVER['REMOTE_ADDR']??'?'); $u=strtolower(trim((string)$username));
    $k=[[$scope.':ip:'.sha1($ip),25],[$scope.':ui:'.sha1($u.'|'.$ip),5]];
    if($globalUser)$k[]=[$scope.':u:'.sha1($u),10];
    return $k;
}
/* seconds left if blocked, else 0 */
function rlBlocked($scope,$username,$globalUser=false){
    $keys=rlKeys($scope,$username,$globalUser);
    return (int)rlWith(function(&$d,$now) use($keys){
        $wait=0; foreach($keys as $kk){ $e=$d[$kk[0]]??null; if($e && ($e['until']??0)>$now)$wait=max($wait,$e['until']-$now); } return $wait;
    });
}
function rlFail($scope,$username,$globalUser=false){
    $keys=rlKeys($scope,$username,$globalUser);
    rlWith(function(&$d,$now) use($keys){
        foreach($keys as $kk){
            $e=$d[$kk[0]]??['n'=>0,'first'=>$now,'until'=>0];
            if(($e['first']??0)<$now-900){$e=['n'=>0,'first'=>$now,'until'=>0];}
            $e['n']++; if($e['n']>=$kk[1])$e['until']=$now+900;
            $d[$kk[0]]=$e;
        }
    });
}
function rlClear($scope,$username){
    $k=rlKeys($scope,$username)[1][0];
    rlWith(function(&$d,$now) use($k){ unset($d[$k]); });
}
function rlDeny($wait){
    http_response_code(429);
    echo json_encode(['status'=>'error','locked'=>true,'message'=>'Too many failed attempts. Please try again in '.max(1,(int)ceil($wait/60)).' minute(s).']);
    exit;
}
function sessionGoneReply(){
    http_response_code(401);
    echo json_encode(['status'=>'error','session_expired'=>true,'message'=>'You were logged out: session expired, or this account logged in again somewhere else. Please log in again.']);
    exit;
}
/* SUPER ADMIN: these admin usernames (case-insensitive) are Super Admins. They keep every normal Admin
   permission and can additionally manage OTHER admin accounts (create / change their login and password). */
const SUPER_ADMIN_USERS=['dharmaraj'];
function isSuperAdminUser($user){return in_array(strtolower(trim((string)$user)),SUPER_ADMIN_USERS,true);}
function requireSuperAdmin(){
    requireRole('admin');
    if(empty($_SESSION['super'])){
        http_response_code(403);
        echo json_encode(['status'=>'error','message'=>'Only a Super Admin can do this.']);
        exit;
    }
}
function requireRole($roles){
    $role=$_SESSION['role']??'';
    if($role==='')sessionGoneReply();
    if(!in_array($role,(array)$roles,true)){
        http_response_code(403);
        echo json_encode(['status'=>'error','message'=>'Access denied.']);
        exit;
    }
}
/* Shared employee login-access rule for BOTH hard termination and a completed
   notice period. Whichever anchor date applies (termination_date, or
   notice_period_end once it has passed), the account stays fully live until
   that date, then lives on for exactly 15 more days in a restricted state
   (Payslip & Calendar only — enforced above by the 'restricted' session flag),
   then login is blocked entirely. */
function employeeAccessState($e){
    $anchor=null; $reason='';
    if(!empty($e['terminated']) && !empty($e['termination_date'])){
        $anchor=$e['termination_date']; $reason='terminated';
    } elseif(!empty($e['notice_period_end'])){
        $anchor=$e['notice_period_end']; $reason='notice_period';
    }
    if(!$anchor){return ['blocked'=>false,'restricted'=>false,'anchor_date'=>null,'reason'=>''];}
    try{ $anchorDt=new DateTime($anchor); }catch(Exception $ex){ return ['blocked'=>false,'restricted'=>false,'anchor_date'=>null,'reason'=>'']; }
    $today=new DateTime('today');
    if($today <= $anchorDt){
        // Notice period still running (or termination date is today) — full normal access.
        return ['blocked'=>false,'restricted'=>false,'anchor_date'=>$anchor,'reason'=>$reason];
    }
    $closes=(clone $anchorDt)->modify('+15 days');
    if($today > $closes){
        return ['blocked'=>true,'restricted'=>false,'anchor_date'=>$anchor,'reason'=>$reason];
    }
    return ['blocked'=>false,'restricted'=>true,'anchor_date'=>$anchor,'reason'=>$reason];
}

/* LOST-UPDATE FIX: $db is read once at the top of the request, and every action writes the WHOLE
   file back. Two requests overlapping (e.g. a Cash Book bill uploading to Cloudinary while the admin
   saves a Salary Advance) made the slower one overwrite the other with its stale copy, so the
   advance "saved" and then vanished. Before any write we now take an exclusive lock and re-read
   database.json, so every change is applied on top of the latest data. The lock is held until the
   request ends (PHP releases it on exit). */
$dbLockHandle=null;
function dbLockedReload(){
    global $db,$db_file,$dbLockHandle;
    if($dbLockHandle)return;
    $dbLockHandle=@fopen(__FILE__,'r');
    if($dbLockHandle)@flock($dbLockHandle,LOCK_EX);
    $fresh=dataGet(dbStore());
    if(is_array($fresh)){
        if(!isset($fresh['admin_users'])&&isset($fresh['admin']['user']))$fresh['admin_users']=[['user'=>$fresh['admin']['user'],'pass'=>$fresh['admin']['pass']??'']];
        foreach(defaultDatabase() as $k=>$v){if(!isset($fresh[$k]))$fresh[$k]=$v;}
        $db=$fresh;
    }
}

/* ===================== Face recognition security =====================
   Admin on/off switch: $db['face_ai']['enabled'] (Face Security tab).  Face templates (128-number descriptors made in the
   browser by face-api.js - never photos) and the scan log live in their own MySQL store 'face_data', so they are never sent
   to employee browsers.  Matching is done HERE on the server; a successful match gives a one-time, 2-minute token in the
   PHP session that record_punch requires while the feature is on. */
function faceCfg($d){
    $c=is_array($d['face_ai']??null)?$d['face_ai']:[];
    $b=function($k,$def) use($c){return array_key_exists($k,$c)?!empty($c[$k]):$def;};
    return ['enabled'=>$b('enabled',false),'require_emp'=>$b('require_emp',true),'require_guard'=>$b('require_guard',true),
            'liveness'=>$b('liveness',true),'guard_identify'=>$b('guard_identify',true),'allow_unenrolled'=>$b('allow_unenrolled',true),'snapshots'=>$b('snapshots',false),
            'threshold'=>round(max(0.35,min(0.65,(float)($c['threshold']??0.5))),2)];
}
function faceDescOk($d){
    if(!is_array($d)||count($d)!==128)return false;
    foreach($d as $x){if((!is_int($x)&&!is_float($x))||!is_finite((float)$x)||abs((float)$x)>5)return false;}
    return true;
}
function faceDist($a,$b){$s=0.0;for($i=0;$i<128;$i++){$t=(float)$a[$i]-(float)$b[$i];$s+=$t*$t;}return sqrt($s);}
function faceBest($descs,$probe){$best=9.0;foreach($descs as $t){if(faceDescOk($t))$best=min($best,faceDist($t,$probe));}return $best;}
function faceTemplates(){$s=dataGet('face_data');return (is_array($s)&&is_array($s['templates']??null))?$s['templates']:[];}
/* Is a face check needed for the logged-in role right now? */
function faceRequired($db){
    if(isDemo())return false;
    $c=faceCfg($db);if(!$c['enabled'])return false;
    $role=$_SESSION['role']??'';
    if($role==='admin')return false;
    return $role==='emp'?$c['require_emp']:$c['require_guard'];
}
/* Append one entry to the scan log (newest last, max 500; older entries and their snapshots are dropped). */
function faceLogAdd($entry,$snap=''){
    return dataStoreTx('face_data',function(&$a) use($entry,$snap){
        $log=is_array($a['log']??null)?$a['log']:[];
        $id=bin2hex(random_bytes(6));$entry['id']=$id;$entry['ts']=time();
        if($snap!==''){$a['snap_'.$id]=$snap;$entry['snap']=1;}
        $log[]=$entry;
        while(count($log)>500){$old=array_shift($log);if(!empty($old['id']))unset($a['snap_'.$old['id']]);}
        $a['log']=$log;return $id;
    });
}
/* null = punch allowed, otherwise the error text. Consumes the one-time token. */
function faceGate($db,$empId){
    if(!faceRequired($db))return null;
    $c=faceCfg($db);$t=faceTemplates();
    if(empty($t[$empId]['descriptors'])){return $c['allow_unenrolled']?null:'Your face is not enrolled yet. Please ask Admin to enrol your face before punching.';}
    $ok=(int)($_SESSION['face_ok'][$empId]??0);
    if($ok>time()){unset($_SESSION['face_ok'][$empId]);return null;}
    return 'Face verification required. Please verify your face and try again.';
}

/* Admin tool: copy /assets and /app into MySQL.  Log in as Admin, then open
   index.php?tool=files_mysql            (preview: compares disk with MySQL)
   index.php?tool=files_mysql&run=1      (upload new/changed files, verify each by reading it back)
   index.php?tool=files_mysql&restore=1  (write files that exist in MySQL but are missing on disk back to the server)
   Safe to repeat: unchanged files are skipped. */
if($_SERVER['REQUEST_METHOD']==='GET' && isset($_GET['tool']) && isDemo()){http_response_code(403);die('Not available in the demo account.');}
/* Admin tool: log in as Admin on the phone/PC, then open  index.php?tool=push_test  to send a test notification to your own registered phones
   and see exactly what is missing if nothing arrives. */
if($_SERVER['REQUEST_METHOD']==='GET' && ($_GET['tool']??'')==='push_test'){
    header('Content-Type: text/plain; charset=utf-8');
    if(($_SESSION['role']??'')!=='admin'){http_response_code(403);exit("Admin login required. Log in first, then reopen this link.\n");}
    $cfg=pushCfg();
    echo "1. fcm_service_account.json: ".($cfg?"found (project ".$cfg['project_id'].")":"NOT FOUND or invalid - upload it next to index.php")."\n";
    echo "2. PHP cURL: ".(function_exists('curl_init')?'yes':'NO')." | openssl: ".(function_exists('openssl_sign')?'yes':'NO')."\n";
    $pp=pushPdo(); if(!$pp)exit("3. MySQL: not connected.\n");
    $n=(int)$pp->query('SELECT COUNT(*) FROM app_push')->fetchColumn(); $na=$pp->prepare('SELECT COUNT(*) FROM app_push WHERE role=? AND usr=?'); $na->execute(['admin',(string)($_SESSION['user']??'')]);
    echo "3. Registered phones: $n total, ".(int)$na->fetchColumn()." for your admin login\n";
    if(!$cfg)exit;
    $err=null; $at=pushAccessToken($cfg,$err); echo "4. Google access token: ".($at?'OK':'FAILED - '.$err)."\n"; if(!$at)exit;
    $q=$pp->prepare('SELECT token FROM app_push WHERE role=? AND usr=?'); $q->execute(['admin',(string)($_SESSION['user']??'')]);
    $jobs=[]; foreach($q->fetchAll() as $r)$jobs[]=[(string)$r[0],'Tejodhar test','Push notifications are working.',['type'=>'test','tab'=>'']];
    if(!$jobs)exit("5. No phone is registered for this admin login yet. Open the Android app, log in as this admin, allow notifications, wait 10 seconds, then retry.\n");
    $log=[]; $dead=pushSendMany($cfg,$at,$jobs,$log); echo "5. Sent to ".count($jobs)." phone(s): ".implode(' | ',$log)."\n";
    if($dead){$d=$pp->prepare('DELETE FROM app_push WHERE token=?');foreach($dead as $t)$d->execute([$t]);echo "   Removed ".count($dead)." dead token(s) - reopen the app to register again.\n";}
    exit;
}
if($_SERVER['REQUEST_METHOD']==='GET' && ($_GET['tool']??'')==='files_mysql'){
    header('Content-Type: text/plain; charset=utf-8');
    if(($_SESSION['role']??'')!=='admin'){http_response_code(403);exit("Admin login required. Log in first, then reopen this link.\n");}
    $pdo=filesPdo(); if(!$pdo)exit("MySQL is not connected. Check db_config.php.\n");
    $run=isset($_GET['run']);$restore=isset($_GET['restore']);
    $inDb=[]; foreach($pdo->query('SELECT path,sha1,size FROM app_files')->fetchAll() as $r)$inDb[$r[0]]=[$r[1],(int)$r[2]];
    $disk=filesOnDisk();$new=0;$same=0;$upd=0;$bad=0;$rest=0;
    foreach($disk as $rel=>$abs){
        $bin=@file_get_contents($abs);
        if($bin===false){echo "UNREADABLE  $rel\n";$bad++;continue;}
        if(strlen($bin)>12*1024*1024){echo "TOO BIG (>12MB)  $rel\n";$bad++;continue;}
        $h=sha1($bin);
        if(isset($inDb[$rel])&&$inDb[$rel][0]===$h){$same++;continue;}
        $isNew=!isset($inDb[$rel]);
        if(!$run){echo ($isNew?"WOULD ADD     ":"WOULD UPDATE  ").$rel."  (".strlen($bin)." B)\n";$isNew?$new++:$upd++;continue;}
        if(filesPut($rel,$bin)){echo ($isNew?"ADDED   ":"UPDATED ").$rel."\n";$isNew?$new++:$upd++;}
        else{echo "FAILED  $rel  (file larger than MySQL max_allowed_packet?)\n";$bad++;}
    }
    if($restore){
        foreach($inDb as $rel=>$_){
            if(isset($disk[$rel]))continue;
            $row=filesGet($rel); if(!$row){echo "FAILED RESTORE  $rel\n";$bad++;continue;}
            $abs=__DIR__.'/'.$rel;$dir=dirname($abs);
            if(!is_dir($dir))@mkdir($dir,0755,true);
            if(@file_put_contents($abs,$row[1])!==false){echo "RESTORED  $rel\n";$rest++;}else{echo "FAILED RESTORE  $rel  (folder not writable)\n";$bad++;}
        }
    }
    $extra=0;foreach($inDb as $rel=>$_)if(!isset($disk[$rel]))$extra++;
    echo "\nOn disk: ".count($disk)." | already in MySQL and identical: $same | ".($run?"added":"to add").": $new | ".($run?"updated":"to update").": $upd | in MySQL only: $extra | restored: $rest | problems: $bad\n";
    if(!$run&&!$restore)echo "Preview only. Add &run=1 to upload, or &restore=1 to write MySQL-only files back to the server.\n";
    exit;
}

/* One-time admin tool (replaces the separate migrate file): moves OLD local /bills files to Cloudinary.
   Log in as Admin, then open  index.php?tool=migrate_bills  (preview)  /  &run=1 (move)  /  &run=1&delete=1 (also remove local copies).
   Safe to repeat: entries already on Cloudinary are skipped. */
if($_SERVER['REQUEST_METHOD']==='GET' && ($_GET['tool']??'')==='migrate_bills'){
    header('Content-Type: text/plain; charset=utf-8');
    if(($_SESSION['role']??'')!=='admin'){http_response_code(403);exit("Admin login required. Log in first, then reopen this link.\n");}
    $run=isset($_GET['run']);$delLocal=isset($_GET['delete']);
    dbLockedReload();
    $todo=0;$done=0;$bad=0;$remove=[];
    foreach(($db['cashbook']??[]) as $i=>$c){
        $u=(string)($c['bill_url']??'');
        if($u===''||preg_match('#^https?://#i',$u))continue;
        $todo++;
        $billsDir=realpath(__DIR__.'/bills');$file=realpath(__DIR__.'/'.ltrim($u,'/'));
        if(!$billsDir||!$file||strpos($file,$billsDir.DIRECTORY_SEPARATOR)!==0||!is_file($file)){echo "MISSING  $u\n";$bad++;continue;}
        if(!$run){echo "WOULD MOVE  $u\n";continue;}
        $mime=(string)($c['bill_type']??'')?:(function_exists('mime_content_type')?mime_content_type($file):'image/jpeg');
        $r=uploadCashBillToCloudinary((string)file_get_contents($file),$mime,(string)($c['bill_name']??basename($file)),(string)($c['date']??''));
        if(!$r['ok']){echo "FAILED   $u : {$r['message']}\n";$bad++;continue;}
        $db['cashbook'][$i]['bill_url']=$r['url'];$remove[]=$file;$done++;echo "MOVED    $u\n";
    }
    if($run&&$done){saveOrFail($db);if($delLocal)foreach($remove as $f)@unlink($f);}
    echo "\nLocal bills: $todo | moved: $done | problems: $bad\n";
    if(!$run)echo "Preview only. Add &run=1 to move them (and &delete=1 to remove local copies).\n";
    exit;
}

/* One-time migration: recursively store /assets files in MySQL.
   Preview: index.php?tool=assets_mysql
   Store and verify only: index.php?tool=assets_mysql&run=1
   Delete local copies only after reviewing the successful migration:
   index.php?tool=assets_mysql&run=1&delete=1
   Local files are removed only when EVERY discovered file was stored and read-back verified. */
if($_SERVER['REQUEST_METHOD']==='GET' && ($_GET['tool']??'')==='assets_mysql'){
    header('Content-Type: text/plain; charset=utf-8');
    if(($_SESSION['role']??'')!=='admin'){http_response_code(403);exit("Admin login required. Log in first, then reopen this link.\n");}
    $run=isset($_GET['run']); $del=isset($_GET['delete']); $files=[];
    $base=__DIR__.'/assets';
    if(is_dir($base)){
        try {
            $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base,FilesystemIterator::SKIP_DOTS));
            foreach($it as $f){
                if(!$f->isFile()||$f->isLink())continue;
                $rel='assets/'.str_replace(DIRECTORY_SEPARATOR,'/',substr($f->getPathname(),strlen($base)+1));
                if(filesPathOk($rel))$files[$rel]=$f->getPathname();
            }
        } catch(Throwable $e) { echo "SCAN ERROR: ".$e->getMessage()."\n"; }
    }
    ksort($files); $ok=0;$bad=0;$removed=0;
    if(!$files)echo "No local asset files found under: ".$base."\n";
    foreach($files as $rel=>$abs){
        if(!$run){echo "WOULD STORE  $rel\n";continue;}
        $bin=@file_get_contents($abs);
        if($bin===false||!filesPut($rel,$bin)){$bad++;echo "FAILED      $rel : MySQL write failed; local copy kept\n";continue;}
        $check=filesGet($rel);
        if(!$check||sha1($bin)!==$check[2]||sha1($bin)!==sha1($check[1])||strlen($bin)!==strlen($check[1])){
            $bad++;echo "FAILED      $rel : read-back verification failed; local copy kept\n";continue;
        }
        $ok++;echo "STORED      $rel (".strlen($bin)." bytes; SHA-1 verified)\n";
    }
    $allVerified=($run && count($files)>0 && $bad===0 && $ok===count($files));
    if($del && !$allVerified){
        echo "\nSAFETY: local files were NOT deleted because not every discovered file was verified.\n";
    } elseif($del && $allVerified){
        foreach($files as $rel=>$abs){if(is_file($abs)&&@unlink($abs))$removed++;else { $bad++; echo "WARNING: could not remove local file $rel\n"; }}
        $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
        foreach($it as $f){if($f->isDir()&&!$f->isLink())@rmdir($f->getPathname());}
        @rmdir($base);
    }
    echo "\nAssets found: ".count($files)." | stored and verified: $ok | problems: $bad | local files removed: $removed\n";
    if(!$run)echo "Preview only. Next run with &run=1 to store and verify; review results before using &run=1&delete=1.\n";
    elseif(!$del)echo "Store/verification pass complete. Local files were kept. Check all results before deleting local copies.\n";
    elseif($allVerified)echo "All discovered files verified before local cleanup. Check your website icons and images now.\n";
    exit;
}

/* One-time admin tool: uploads the app icons (assets/icons/*.png, assets/paid_stamp.png) to Cloudinary folder app_icons.
   Log in as Admin, then open  index.php?tool=migrate_icons  (preview)  /  &run=1 (upload).  Safe to repeat (overwrites). */
if($_SERVER['REQUEST_METHOD']==='GET' && ($_GET['tool']??'')==='migrate_icons'){
    header('Content-Type: text/plain; charset=utf-8');
    if(($_SESSION['role']??'')!=='admin'){http_response_code(403);exit("Admin login required. Log in first, then reopen this link.\n");}
    $run=isset($_GET['run']); $files=array_merge(glob(__DIR__.'/assets/icons/*.png')?:[], glob(__DIR__.'/assets/paid_stamp.png')?:[]);
    $ok=0;$bad=0;
    if(!$files)echo "No icon files found in assets/icons on the server.\n";
    foreach($files as $f){
        $n=pathinfo($f,PATHINFO_FILENAME);
        if(!$run){echo "WOULD UPLOAD  $n\n";continue;}
        $r=uploadIconToCloudinary((string)file_get_contents($f),'image/png',$n);
        if($r['ok']){$ok++;echo "UPLOADED  $n  ->  {$r['url']}\n";}else{$bad++;echo "FAILED    $n : {$r['message']}\n";}
    }
    echo "\nFiles: ".count($files)." | uploaded: $ok | problems: $bad\n";
    if(!$run)echo "Preview only. Add &run=1 to upload.\n";
    exit;
}

/* One-time admin tool: moves EXISTING employee photos (stored as base64 inside database.json) and the
   company logo/seal (stored in /assets) to Cloudinary.
   Log in as Admin, then open  index.php?tool=migrate_images  (preview)  /  &run=1 (move).
   Safe to repeat: anything already on Cloudinary is skipped. */
if($_SERVER['REQUEST_METHOD']==='GET' && ($_GET['tool']??'')==='migrate_images'){
    header('Content-Type: text/plain; charset=utf-8');
    if(($_SESSION['role']??'')!=='admin'){http_response_code(403);exit("Admin login required. Log in first, then reopen this link.\n");}
    $run=isset($_GET['run']);
    dbLockedReload();
    $todo=0;$done=0;$bad=0;
    foreach(($db['employees']??[]) as $i=>$e){
        $ph=(string)($e['photo']??'');
        if(strpos($ph,'data:image/')!==0)continue;
        $todo++;
        if(!$run){echo "WOULD MOVE  employee photo: ".($e['id']??'?')."\n";continue;}
        $r=dataUriToCloud($ph,'employee_photos','emp_'.preg_replace('/[^A-Za-z0-9]/','',(string)($e['id']??'x')));
        if(!$r['ok']){echo "FAILED   employee ".($e['id']??'?')." : {$r['message']}\n";$bad++;continue;}
        $db['employees'][$i]['photo']=$r['url'];$done++;echo "MOVED    employee photo: ".($e['id']??'?')."\n";
    }
    foreach(['logo','seal'] as $k){
        $u=(string)($db['company'][$k]??'');
        if($u===''||preg_match('#^https?://#i',$u))continue;
        $todo++;
        if(strpos($u,'data:image/')===0){ $bin=null; $mime='image/png'; if(!$run){echo "WOULD MOVE  company $k\n";continue;}
            $r=dataUriToCloud($u,'company_assets',$k); }
        else {
            $dir=realpath(__DIR__.'/assets');$file=realpath(__DIR__.'/'.ltrim($u,'/'));
            if(!$dir||!$file||strpos($file,$dir.DIRECTORY_SEPARATOR)!==0||!is_file($file)){echo "MISSING  $u\n";$bad++;continue;}
            if(!$run){echo "WOULD MOVE  $u\n";continue;}
            $mime=function_exists('mime_content_type')?mime_content_type($file):'image/png';
            $r=uploadToCloudinaryFolder((string)file_get_contents($file),$mime,'company_assets',$k);
        }
        if(!$r['ok']){echo "FAILED   company $k : {$r['message']}\n";$bad++;continue;}
        $db['company'][$k]=$r['url'];$done++;echo "MOVED    company $k\n";
    }
    if($run&&$done)saveOrFail($db);
    echo "\nImages to move: $todo | moved: $done | problems: $bad\n";
    if(!$run)echo "Preview only. Add &run=1 to move them.\n";
    exit;
}

/* ===================== Push notifications (Firebase Cloud Messaging, HTTP v1) =====================
   Setup: put the Firebase service-account key in this folder as  fcm_service_account.json  (Firebase console ->
   Project settings -> Service accounts -> Generate new private key).  Without that file push is simply switched off.
   Phones register their FCM token with action push_register after login; tokens live in table app_push (auto-created).
   Messages are DATA-ONLY: the Android app (TejodharMessagingService) builds the notification itself.
   Sending happens after the page response, so approvals / chat are not slowed down. */
function pushCfg(){
    static $c=null; if($c!==null)return $c;
    $c=false; $f=__DIR__.'/fcm_service_account.json';
    if(is_file($f)){
        $j=json_decode((string)@file_get_contents($f),true);
        if(is_array($j)&&!empty($j['private_key'])&&!empty($j['client_email'])&&!empty($j['project_id']))$c=$j;
    }
    return $c;
}
function pushPdo(){
    static $ok=false;
    $pdo=dataPdo(); if(!$pdo)return null;
    if($ok)return $pdo;
    $my=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql';
    try{$pdo->query('SELECT token FROM app_push LIMIT 1')->fetchAll();}
    catch(Throwable $e){
        try{
            $pdo->exec($my
              ?"CREATE TABLE IF NOT EXISTS app_push (token VARCHAR(255) CHARACTER SET ascii NOT NULL PRIMARY KEY, role VARCHAR(16) CHARACTER SET ascii NOT NULL, usr VARCHAR(100) NOT NULL, emp_id VARCHAR(64) NOT NULL DEFAULT '', ts BIGINT NOT NULL, KEY k_role (role), KEY k_emp (emp_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
              :"CREATE TABLE IF NOT EXISTS app_push (token TEXT PRIMARY KEY, role TEXT NOT NULL, usr TEXT NOT NULL, emp_id TEXT NOT NULL DEFAULT '', ts INTEGER NOT NULL)");
        }catch(Throwable $e2){error_log('Push table setup failed: '.$e2->getMessage());return null;}
    }
    $ok=true; return $pdo;
}
function pushB64($s){return rtrim(strtr(base64_encode($s),'+/','-_'),'=');}
function pushAccessToken($cfg,&$err=null){
    $pdo=pushPdo();
    if($pdo){
        try{$q=$pdo->prepare('SELECT v FROM app_store WHERE store=? AND k=?');$q->execute(['_push','fcm_at']);$r=$q->fetch();
            if($r){$j=json_decode((string)$r[0],true);if(is_array($j)&&!empty($j['t'])&&(int)($j['exp']??0)>time()+120)return $j['t'];}
        }catch(Throwable $e){}
    }
    if(!function_exists('curl_init')){$err='PHP cURL is not enabled on this hosting account.';return null;}
    if(!function_exists('openssl_sign')){$err='PHP openssl is not enabled on this hosting account.';return null;}
    $now=time();
    $h=pushB64(json_encode(['alg'=>'RS256','typ'=>'JWT']));
    $p=pushB64(json_encode(['iss'=>$cfg['client_email'],'scope'=>'https://www.googleapis.com/auth/firebase.messaging','aud'=>'https://oauth2.googleapis.com/token','iat'=>$now,'exp'=>$now+3600]));
    $sig='';
    if(!openssl_sign($h.'.'.$p,$sig,$cfg['private_key'],OPENSSL_ALGO_SHA256)){$err='Could not sign the token - is fcm_service_account.json the full key file?';return null;}
    $ch=curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>10,
        CURLOPT_POSTFIELDS=>http_build_query(['grant_type'=>'urn:ietf:params:oauth:grant-type:jwt-bearer','assertion'=>$h.'.'.$p.'.'.pushB64($sig)])]);
    $res=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $ce=curl_error($ch); curl_close($ch);
    $j=is_string($res)?json_decode($res,true):null;
    if(!is_array($j)||empty($j['access_token'])){$err='Google sign-in failed (HTTP '.$code.') '.($ce?:(is_array($j)?($j['error_description']??$j['error']??''):'')); return null;}
    if($pdo){try{$pdo->prepare('REPLACE INTO app_store (store,k,v) VALUES (?,?,?)')->execute(['_push','fcm_at',json_encode(['t'=>$j['access_token'],'exp'=>$now+(int)($j['expires_in']??3600)])]);}catch(Throwable $e){}}
    return $j['access_token'];
}
/* Queue a notification. $target: ['role'=>'admin'] | ['emp'=>[ids]] | ['all'=>true,'except'=>'role|usr'] */
function pushQueue(array $target,$title,$body,array $data=[]){
    static $reg=false; global $pushQueue;
    if(!is_array($pushQueue))$pushQueue=[];
    $pushQueue[]=[$target,(string)$title,(string)$body,$data];
    if(!$reg){$reg=true;register_shutdown_function('pushFlush');}
}
function pushTrim($s,$n){$s=trim(preg_replace('/\s+/u',' ',(string)$s));if($s===null)$s='';return function_exists('mb_substr')?mb_substr($s,0,$n,'UTF-8'):substr($s,0,$n);}
function pushTokensFor($pdo,array $t,$limit=400){
    if(!empty($t['role'])){$q=$pdo->prepare('SELECT token FROM app_push WHERE role=? LIMIT '.(int)$limit);$q->execute([(string)$t['role']]);}
    elseif(!empty($t['emp'])){
        $ids=array_values(array_unique(array_map('strval',(array)$t['emp']))); if(!$ids)return [];
        $q=$pdo->prepare("SELECT token FROM app_push WHERE role='emp' AND emp_id IN (".implode(',',array_fill(0,count($ids),'?')).") LIMIT ".(int)$limit);$q->execute($ids);
    }elseif(!empty($t['all'])){
        $ex=(string)($t['except']??'');
        $q=$pdo->prepare("SELECT token FROM app_push WHERE CONCAT(role,'|',usr)<>? LIMIT ".(int)$limit);
        if($pdo->getAttribute(PDO::ATTR_DRIVER_NAME)!=='mysql')$q=$pdo->prepare("SELECT token FROM app_push WHERE (role||'|'||usr)<>? LIMIT ".(int)$limit);
        $q->execute([$ex]);
    }else return [];
    $o=[]; foreach($q->fetchAll() as $r)$o[]=(string)$r[0]; return $o;
}
/* Sends every queued message (runs at the end of the request, after the reply has been sent). */
function pushFlush(){
    global $pushQueue,$dbLockHandle;
    if(empty($pushQueue))return;
    $queue=$pushQueue; $pushQueue=[];
    try{
        /* Release the portal's global file lock + the session first so other requests are not blocked while we talk to Google. */
        @ignore_user_abort(true); @set_time_limit(40);
        if(function_exists('session_write_close'))@session_write_close();
        if(!empty($dbLockHandle)){@flock($dbLockHandle,LOCK_UN);@fclose($dbLockHandle);$dbLockHandle=null;}
        if(function_exists('fastcgi_finish_request'))@fastcgi_finish_request();
        $cfg=pushCfg(); if(!$cfg)return;
        $pdo=pushPdo(); if(!$pdo)return;
        $jobs=[]; // token => [title,body,data]
        foreach($queue as $m){foreach(pushTokensFor($pdo,$m[0]) as $tok){$jobs[]=[$tok,$m[1],$m[2],$m[3]];}}
        if(!$jobs)return;
        $err=null; $at=pushAccessToken($cfg,$err);
        if(!$at){error_log('Push: '.$err);return;}
        $dead=pushSendMany($cfg,$at,$jobs);
        if($dead){$d=$pdo->prepare('DELETE FROM app_push WHERE token=?');foreach($dead as $tok){try{$d->execute([$tok]);}catch(Throwable $e){}}}
    }catch(Throwable $e){error_log('Push flush failed: '.$e->getMessage());}
}
/* Parallel FCM v1 sends.  Returns the tokens Google says are no longer valid. $log (optional) collects results. */
function pushSendMany($cfg,$at,array $jobs,&$log=null){
    $dead=[]; if(!function_exists('curl_multi_init'))return $dead;
    $url='https://fcm.googleapis.com/v1/projects/'.rawurlencode($cfg['project_id']).'/messages:send';
    foreach(array_chunk($jobs,25) as $chunk){
        $mh=curl_multi_init(); $hs=[];
        foreach($chunk as $i=>$j){
            $data=[]; foreach(($j[3]??[]) as $k=>$v)$data[(string)$k]=(string)$v;
            $data['title']=pushTrim($j[1],80); $data['body']=pushTrim($j[2],240);
            $msg=['message'=>['token'=>$j[0],'data'=>$data,'android'=>['priority'=>'HIGH','ttl'=>'86400s']]];
            $ch=curl_init($url);
            curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>12,
                CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$at,'Content-Type: application/json'],
                CURLOPT_POSTFIELDS=>json_encode($msg,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
            curl_multi_add_handle($mh,$ch); $hs[$i]=$ch;
        }
        do{$st=curl_multi_exec($mh,$run); if($run)curl_multi_select($mh,1.0);}while($run&&$st===CURLM_OK);
        foreach($hs as $i=>$ch){
            $res=curl_multi_getcontent($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
            if($code>=200&&$code<300){if($log!==null)$log[]='OK';}
            else{
                $e=json_decode((string)$res,true); $status=is_array($e)?(string)($e['error']['status']??''):''; $emsg=is_array($e)?(string)($e['error']['message']??''):'';
                if($code===404||$status==='NOT_FOUND'||$status==='UNREGISTERED'||($code===400&&stripos($emsg,'registration token')!==false))$dead[]=$chunk[$i][0];
                if($log!==null)$log[]='HTTP '.$code.' '.$status.' '.$emsg;
                error_log('Push send failed: HTTP '.$code.' '.$status.' '.$emsg);
            }
            curl_multi_remove_handle($mh,$ch); curl_close($ch);
        }
        curl_multi_close($mh);
    }
    return $dead;
}
/* Project managers (is_manager) on the same project as $empId, excluding $empId itself. */
function pushManagersOf($db,$empId){
    $proj='';foreach(($db['employees']??[]) as $e){if((string)($e['id']??'')===(string)$empId){$proj=strtolower(trim((string)($e['project']??'')));break;}}
    if($proj==='')return [];
    $o=[];foreach(($db['employees']??[]) as $e){
        if(empty($e['is_manager'])||!empty($e['terminated']))continue;
        if((string)($e['id']??'')===(string)$empId)continue;
        if(strtolower(trim((string)($e['project']??'')))===$proj)$o[]=(string)$e['id'];
    }
    return $o;
}
function pushLeaveText($r){
    return (['CL'=>'Casual Leave','SL'=>'Sick Leave','LOP'=>'Loss of Pay','OD'=>'On Duty'][strtoupper((string)($r['leave_type']??''))]??(string)($r['leave_type']??'Leave')).' '.($r['date_from']??'').(($r['date_to']??'')!==($r['date_from']??'')?' → '.($r['date_to']??''):'');
}
function pushReqText($r){
    $t=strtoupper((string)($r['request_type']??''));
    if($t==='ATTENDANCE'){$s=strtoupper((string)($r['attendance_status']??''));return 'Missed attendance '.($r['date']??'').' ('.(['P'=>'Present','H'=>'Half Day','OD'=>'On Duty'][$s]??$s).')';}
    return 'Forgot punch '.$t.' '.($r['punch_time']??'').' on '.($r['date']??'');
}

/* ===================== Team Chat (common chat for admin + all users) =====================
   One shared room. Tables app_chat (messages) and app_chat_seen (who has read up to which message) are created
   automatically on first use. Photos and documents are stored on Cloudinary (folder team_chat).
   Actions: chat_poll, chat_send, chat_delete, chat_seen.  Sender name/role always come from the login session. */
function chatPdo(){
    static $ok=false;
    $pdo=dataPdo(); if(!$pdo)return null;
    if($ok)return $pdo;
    $my=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql';
    try{$pdo->query('SELECT id FROM app_chat LIMIT 1')->fetchAll();}
    catch(Throwable $e){
        try{
            $pdo->exec($my
              ?"CREATE TABLE IF NOT EXISTS app_chat (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, ts BIGINT NOT NULL, role VARCHAR(16) CHARACTER SET ascii NOT NULL, usr VARCHAR(100) NOT NULL, name VARCHAR(120) NOT NULL, label VARCHAR(80) NOT NULL, msg TEXT NOT NULL, deleted TINYINT NOT NULL DEFAULT 0, file_url TEXT NULL, file_name VARCHAR(200) NULL, file_kind VARCHAR(8) NULL, KEY ix_ts (ts)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
              :"CREATE TABLE IF NOT EXISTS app_chat (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, role TEXT NOT NULL, usr TEXT NOT NULL, name TEXT NOT NULL, label TEXT NOT NULL, msg TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0, file_url TEXT NULL, file_name TEXT NULL, file_kind TEXT NULL)");
        }catch(Throwable $e2){error_log('Chat table setup failed: '.$e2->getMessage());return null;}
    }
    try{$pdo->query('SELECT file_url,file_name,file_kind FROM app_chat LIMIT 1')->fetchAll();}
    catch(Throwable $e){
        try{foreach(["ALTER TABLE app_chat ADD COLUMN file_url TEXT NULL","ALTER TABLE app_chat ADD COLUMN file_name VARCHAR(200) NULL","ALTER TABLE app_chat ADD COLUMN file_kind VARCHAR(8) NULL"] as $sql)$pdo->exec($sql);}
        catch(Throwable $e2){error_log('Chat column upgrade failed: '.$e2->getMessage());return null;}
    }
    try{$pdo->query('SELECT upto FROM app_chat_seen LIMIT 1')->fetchAll();}
    catch(Throwable $e){
        try{
            $pdo->exec($my
              ?"CREATE TABLE IF NOT EXISTS app_chat_seen (skey VARCHAR(130) NOT NULL PRIMARY KEY, role VARCHAR(16) CHARACTER SET ascii NOT NULL, name VARCHAR(120) NOT NULL, label VARCHAR(80) NOT NULL, upto BIGINT UNSIGNED NOT NULL DEFAULT 0, ts BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
              :"CREATE TABLE IF NOT EXISTS app_chat_seen (skey TEXT PRIMARY KEY, role TEXT NOT NULL, name TEXT NOT NULL, label TEXT NOT NULL, upto INTEGER NOT NULL DEFAULT 0, ts INTEGER NOT NULL)");
        }catch(Throwable $e2){error_log('Chat seen table setup failed: '.$e2->getMessage());return null;}
    }
    try{$pdo->query('SELECT wrapped FROM app_chat_keys LIMIT 1')->fetchAll();}
    catch(Throwable $e){
        try{
            $pdo->exec($my
              ?"CREATE TABLE IF NOT EXISTS app_chat_keys (skey VARCHAR(130) NOT NULL, dev VARCHAR(40) CHARACTER SET ascii NOT NULL, pub TEXT NOT NULL, wrapped TEXT NULL, wpub TEXT NULL, name VARCHAR(120) NOT NULL DEFAULT '', label VARCHAR(80) NOT NULL DEFAULT '', ts BIGINT NOT NULL, PRIMARY KEY (skey,dev)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
              :"CREATE TABLE IF NOT EXISTS app_chat_keys (skey TEXT NOT NULL, dev TEXT NOT NULL, pub TEXT NOT NULL, wrapped TEXT NULL, wpub TEXT NULL, name TEXT NOT NULL DEFAULT '', label TEXT NOT NULL DEFAULT '', ts INTEGER NOT NULL, PRIMARY KEY (skey,dev))");
        }catch(Throwable $e2){error_log('Chat keys table setup failed: '.$e2->getMessage());return null;}
    }
    $ok=true; return $pdo;
}
/* ---- End-to-end encryption helpers. The server only ever stores/relays ciphertext and public keys. ---- */
function chatB64u($s,$min,$max){return is_string($s)&&preg_match('/^[A-Za-z0-9_-]{'.(int)$min.','.(int)$max.'}$/',$s)===1;}
/* Message envelope {"v":1,"iv":..,"ct":..} (AES-256-GCM, made in the browser). Returns canonical JSON or null. */
function chatEncOk($enc){
    if(!is_string($enc)||strlen($enc)>12000)return null;
    $j=json_decode($enc,true);
    if(!is_array($j)||($j['v']??0)!==1||!chatB64u($j['iv']??null,16,16)||!chatB64u($j['ct']??null,22,11000))return null;
    return json_encode(['v'=>1,'iv'=>$j['iv'],'ct'=>$j['ct']]);
}
function chatPubOk($pub){ /* P-256 public key as JWK -> canonical JSON or null */
    $j=is_string($pub)?json_decode($pub,true):$pub;
    if(!is_array($j)||($j['kty']??'')!=='EC'||($j['crv']??'')!=='P-256'||!chatB64u($j['x']??null,43,43)||!chatB64u($j['y']??null,43,43))return null;
    return json_encode(['kty'=>'EC','crv'=>'P-256','x'=>$j['x'],'y'=>$j['y']]);
}
function chatWrapOk($w){ /* wrapped room key {"iv":..,"ct":..} */
    $j=is_string($w)?json_decode($w,true):null;
    if(!is_array($j)||!chatB64u($j['iv']??null,16,16)||!chatB64u($j['ct']??null,40,80))return null;
    return json_encode(['iv'=>$j['iv'],'ct'=>$j['ct']]);
}
/* Encrypted attachment: the browser sends iv+ciphertext (base64). We cannot look inside, so only the size is checked. */
function chatSaveEncUpload($b64){
    $bin=base64_decode((string)$b64,true);
    if($bin===false||strlen($bin)<29)return ['ok'=>false,'message'=>'Could not read the file.'];
    if(strlen($bin)>7*1024*1024)return ['ok'=>false,'message'=>'File is too large.'];
    $r=chatCloudUpload($bin,'application/octet-stream','raw','chat_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.enc');
    return $r['ok']?['ok'=>true,'url'=>$r['url']]:$r;
}
function chatIdentity($db){
    $role=(string)($_SESSION['role']??''); $user=(string)($_SESSION['user']??'');
    $name=$user; $label='User';
    if($role==='admin'){
        $label='Admin';
        foreach(($db['admin_users']??[]) as $a){if(($a['user']??'')===$user&&trim((string)($a['name']??''))!==''){$name=(string)$a['name'];break;}}
    }elseif($role==='emp'){
        $label='Employee';
        foreach(($db['employees']??[]) as $e){if(($e['id']??'')===($_SESSION['employee_id']??'')){$name=(string)($e['name']??$user);break;}}
    }elseif($role==='contractor'){
        $label='Contractor';
        foreach(($db['contractors']??[]) as $c){if(($c['id']??'')===($_SESSION['contractor_id']??'')){$name=(string)($c['name']??$user);break;}}
    }elseif($role==='security'){
        $label='Security'.(trim((string)($_SESSION['site']??''))!==''?' - '.$_SESSION['site']:'');
    }
    if(function_exists('mb_substr')){$name=mb_substr($name,0,120);$label=mb_substr($label,0,80);$user=mb_substr($user,0,100);}
    $me=['role'=>$role,'usr'=>$user,'name'=>$name,'label'=>$label];
    $me['key']=$role.'|'.$user;
    return $me;
}
function chatRow($r,$me){
    $f=null;
    $isEnc=(strpos((string)$r[6],'{"v":1,')===0);
    if(!empty($r[7])&&strpos((string)$r[7],'https://')===0)$f=['url'=>(string)$r[7],'name'=>(string)$r[8],'kind'=>((string)$r[9]==='enc'?'enc':((string)$r[9]==='img'?'img':'doc'))];
    return ['id'=>(int)$r[0],'ts'=>(int)$r[1],'name'=>(string)$r[4],'label'=>(string)$r[5],'role'=>(string)$r[2],'text'=>$isEnc?'':(string)$r[6],'enc'=>$isEnc?(string)$r[6]:null,'file'=>$f,'mine'=>((string)$r[2]===$me['role']&&(string)$r[3]===$me['usr'])];
}
function chatCloudUpload($bin,$mime,$res,$publicId){
    if(!defined('CLOUDINARY_CLOUD_NAME')||CLOUDINARY_CLOUD_NAME===''||CLOUDINARY_API_KEY===''||CLOUDINARY_API_SECRET==='')return ['ok'=>false,'message'=>'Cloudinary is not configured.'];
    if(!function_exists('curl_init'))return ['ok'=>false,'message'=>'PHP cURL is not enabled on this hosting account.'];
    $folder='team_chat'; $ts=time();
    $sp=['folder'=>$folder,'public_id'=>$publicId,'timestamp'=>$ts]; ksort($sp);
    $sig=sha1(http_build_query($sp,'','&',PHP_QUERY_RFC3986).CLOUDINARY_API_SECRET);
    $tmp=tempnam(sys_get_temp_dir(),'tc_');
    if($tmp===false||file_put_contents($tmp,$bin)===false)return ['ok'=>false,'message'=>'Unable to create temporary upload file.'];
    $ch=curl_init('https://api.cloudinary.com/v1_1/'.rawurlencode(CLOUDINARY_CLOUD_NAME).'/'.$res.'/upload');
    curl_setopt_array($ch,[
        CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>['file'=>new CURLFile($tmp,$mime,$publicId),'api_key'=>CLOUDINARY_API_KEY,'timestamp'=>$ts,'signature'=>$sig,'folder'=>$folder,'public_id'=>$publicId],
        CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_TIMEOUT=>90,
        CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,
    ]);
    $resp=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$cerr=curl_error($ch);
    curl_close($ch);@unlink($tmp);
    if($resp===false||$cerr!=='')return ['ok'=>false,'message'=>'Upload connection failed: '.$cerr];
    $d=json_decode($resp,true);
    if($code<200||$code>=300||!is_array($d)||empty($d['secure_url']))return ['ok'=>false,'message'=>'Upload failed: '.(is_array($d)&&!empty($d['error']['message'])?$d['error']['message']:'HTTP '.$code)];
    return ['ok'=>true,'url'=>(string)$d['secure_url']];
}
/* Validates a data: URI sent by the chat and stores it. Photos (jpg/png/webp/gif, max 6 MB) and documents
   (pdf, doc, docx, xls, xlsx, ppt, pptx, txt, csv, max 4 MB) only. */
function chatSaveUpload($name,$dataUri){
    if(!preg_match('#^data:([A-Za-z0-9/+.\-]+);base64,(.+)$#s',$dataUri,$m))return ['ok'=>false,'message'=>'Could not read the file.'];
    $bin=base64_decode($m[2],true);
    if($bin===false||$bin==='')return ['ok'=>false,'message'=>'Could not read the file.'];
    $size=strlen($bin);
    $name=trim((string)preg_replace('/[\x00-\x1F\x7F\/\\\\]+/','',$name));
    if($name==='')$name='file';
    if(function_exists('mb_substr'))$name=mb_substr($name,0,150);
    $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
    $base=trim((string)preg_replace('/[^A-Za-z0-9_-]+/','_',pathinfo($name,PATHINFO_FILENAME)),'_-');
    $base=substr($base===''?'file':$base,0,40);
    $uid='chat_'.date('Ymd_His').'_'.bin2hex(random_bytes(3));
    $img=@getimagesizefromstring($bin);
    if($img!==false&&in_array($img['mime']??'',['image/jpeg','image/png','image/webp','image/gif'],true)){
        if($size>6*1024*1024)return ['ok'=>false,'message'=>'Photo is too large (max 6 MB).'];
        $r=chatCloudUpload($bin,$img['mime'],'image',$uid);
        return $r['ok']?['ok'=>true,'url'=>$r['url'],'name'=>$name,'kind'=>'img']:$r;
    }
    if(!in_array($ext,['pdf','doc','docx','xls','xlsx','ppt','pptx','txt','csv'],true))return ['ok'=>false,'message'=>'This file type is not allowed. Send a photo, PDF, Word, Excel, PowerPoint, text or CSV file.'];
    if($size>4*1024*1024)return ['ok'=>false,'message'=>'Document is too large (max 4 MB).'];
    if($ext==='pdf'&&substr($bin,0,4)!=='%PDF')return ['ok'=>false,'message'=>'This PDF file looks damaged.'];
    $mimes=['pdf'=>'application/pdf','txt'=>'text/plain','csv'=>'text/csv'];
    $r=chatCloudUpload($bin,$mimes[$ext]??'application/octet-stream','raw',$uid.'_'.$base.'.'.$ext);
    return $r['ok']?['ok'=>true,'url'=>$r['url'],'name'=>$name,'kind'=>'doc']:$r;
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_GET['action'])){
    header('Content-Type: application/json; charset=utf-8');
    $input=json_decode(file_get_contents('php://input'),true); if(!is_array($input))$input=[];
    $action=$_GET['action'];

    /* CSRF defence: browsers always send Origin on cross-site POSTs. Reject if it is not this site. */
    $__origin=(string)($_SERVER['HTTP_ORIGIN']??'');
    if($__origin!==''){
        $__oh=strtolower((string)parse_url($__origin,PHP_URL_HOST));
        $__hh=strtolower(preg_replace('/:\d+$/','',(string)($_SERVER['HTTP_HOST']??'')));
        if($__oh===''||$__oh!==$__hh){http_response_code(403);echo json_encode(['status'=>'error','message'=>'Cross-site request blocked.']);exit;}
    }

    if(!in_array($action,['login','logout','forgot_password_reset','bio_login_options','bio_login_verify','bio_native_login'],true) && !empty($_SESSION['role']) && ($swState=swTouch($action!=='session_check'))!=='ok'){
        /* 'replaced' = a newer tab of this same browser owns the shared session: keep it alive, only reject this old tab. */
        if($swState==='gone'){session_unset();session_destroy();}
        http_response_code(401);
        echo json_encode(['status'=>'error','session_expired'=>true,'message'=>'You were logged out: session expired, or this account logged in again somewhere else. Please log in again.']);
        exit;
    }
    if($action==='idle_ping'||$action==='session_check'){if(empty($_SESSION['role']))sessionGoneReply();echo json_encode(['status'=>'success']);exit;}
    if(isDemo()){
        if(in_array($action,['admin_storage_status','admin_merge_records','admin_import_begin','admin_import_chunk','admin_import_finish','admin_json_import','first_run_json_import','save_admin_creds','bio_reg_options','bio_reg_verify','bio_remove','bio_status','update_cashbook_bill','update_contractor_payment_image'],true)){
            http_response_code(403);echo json_encode(['status'=>'error','message'=>'Not available in the demo account.']);exit;
        }
        unset($input['bill_data']);
    }
    /* First-page JSON upload: usable WITHOUT login, but only while the MySQL database is still brand new (default admin, no data).
       After the first successful import (or once any real data exists) this is refused and only the logged-in admin import works. */
    if($action==='first_run_status'){
        $pdo=dataPdo();
        echo json_encode(['status'=>'success','mysql'=>!!$pdo,'open'=>$pdo?dataIsPristine($pdo):false]);exit;
    }
    if($action==='first_run_json_import'){
        $pdo=dataPdo();
        if(!$pdo){echo json_encode(['status'=>'error','message'=>'MySQL is not connected. Check db_config.php.']);exit;}
        if(!dataIsPristine($pdo)){http_response_code(403);echo json_encode(['status'=>'error','message'=>'Database already has data. Log in as admin and use the import option in Settings.']);exit;}
        $files=is_array($input['files']??null)?$input['files']:[];
        if(!$files){echo json_encode(['status'=>'error','message'=>'No file received.']);exit;}
        list($report,$deleted)=dataImportUploadedJson($pdo,$files);
        echo json_encode(['status'=>'success','report'=>$report,'deleted'=>$deleted]);exit;
    }

    /* Terminated-employee / completed-notice-period account restriction: once
       an employee's access enters its 15-day grace window, their login stays
       active but every action except Payslip & Calendar viewing is blocked
       server-side here. */
    if((($_SESSION['role']??'')==='emp') && !empty($_SESSION['restricted']) && !in_array($action,['login','logout','refresh_portal_data','bio_login_options','bio_login_verify'],true)){
        http_response_code(403);
        echo json_encode(['status'=>'error','message'=>'This account\'s access is limited to Payslip & Calendar only.']);
        exit;
    }

    /* ---- Push token registration (phone app) ---- */
    if($action==='push_register'||$action==='push_unregister'){
        if(empty($_SESSION['role']))sessionGoneReply();
        if(isDemo()){echo json_encode(['status'=>'success','skipped'=>true]);exit;}
        $tok=trim((string)($input['token']??''));
        if(!preg_match('/^[A-Za-z0-9:_\-]{20,250}$/',$tok)){echo json_encode(['status'=>'error','message'=>'Bad token.']);exit;}
        $pp=pushPdo(); if(!$pp){echo json_encode(['status'=>'error','message'=>'Push needs the MySQL database.']);exit;}
        try{
            if($action==='push_unregister'){$pp->prepare('DELETE FROM app_push WHERE token=?')->execute([$tok]);}
            else{
                $pRole=(string)$_SESSION['role'];$pUser=substr((string)($_SESSION['user']??''),0,100);$pEmp=$pRole==='emp'?substr((string)($_SESSION['employee_id']??''),0,64):'';
                $pp->prepare('REPLACE INTO app_push (token,role,usr,emp_id,ts) VALUES (?,?,?,?,?)')->execute([$tok,$pRole,$pUser,$pEmp,time()]);
                if(random_int(1,50)===1)$pp->prepare('DELETE FROM app_push WHERE ts<?')->execute([time()-120*86400]); /* housekeeping: phones unused for 120 days */
            }
            echo json_encode(['status'=>'success','push'=>pushCfg()?'on':'server_not_configured']);exit;
        }catch(Throwable $e){error_log('Push register: '.$e->getMessage());echo json_encode(['status'=>'error','message'=>'Could not save the push token.']);exit;}
    }

    /* ---- Team Chat actions (before the heavy DB reload: chat never needs the main database lock) ---- */
    if($action==='chat_poll'||$action==='chat_send'||$action==='chat_delete'||$action==='chat_seen'||$action==='chat_key_pub'||$action==='chat_key_pending'||$action==='chat_key_put'){
        if(empty($_SESSION['role']))sessionGoneReply();
        if(isDemo()){echo json_encode(['status'=>'error','message'=>'Chat is not available in the demo account.']);exit;}
        $__cp=chatPdo();
        if(!$__cp){echo json_encode(['status'=>'error','message'=>'Chat needs the MySQL database. Check db_config.php.']);exit;}
        $__me=chatIdentity($db);
        try{
            if($action==='chat_poll'){
                $after=max(0,(int)($input['after']??0));
                $seenTo=max(0,(int)($input['seen']??0));
                if($seenTo>0){ // this reader has the chat open and has read up to this message
                    try{
                        $q=$__cp->prepare('SELECT upto FROM app_chat_seen WHERE skey=?'); $q->execute([$__me['key']]); $cur=$q->fetch();
                        if(!$cur)$__cp->prepare('INSERT INTO app_chat_seen (skey,role,name,label,upto,ts) VALUES (?,?,?,?,?,?)')->execute([$__me['key'],$__me['role'],$__me['name'],$__me['label'],$seenTo,time()]);
                        elseif((int)$cur[0]<$seenTo)$__cp->prepare('UPDATE app_chat_seen SET upto=?,ts=?,name=?,label=? WHERE skey=?')->execute([$seenTo,time(),$__me['name'],$__me['label'],$__me['key']]);
                    }catch(Throwable $e){}
                }
                if($after===0){
                    $q=$__cp->query('SELECT id,ts,role,usr,name,label,msg,file_url,file_name,file_kind FROM app_chat WHERE deleted=0 ORDER BY id DESC LIMIT 80');
                    $rows=array_reverse($q->fetchAll());
                }else{
                    $q=$__cp->prepare('SELECT id,ts,role,usr,name,label,msg,file_url,file_name,file_kind FROM app_chat WHERE deleted=0 AND id>? ORDER BY id ASC LIMIT 100');
                    $q->execute([$after]); $rows=$q->fetchAll();
                }
                $msgs=[]; foreach($rows as $r)$msgs[]=chatRow($r,$__me);
                $gone=[];
                if($after>0){
                    $q=$__cp->prepare('SELECT id FROM app_chat WHERE deleted=1 AND id>? AND id<=?');
                    $q->execute([max(0,$after-200),$after]);
                    foreach($q->fetchAll() as $r)$gone[]=(int)$r[0];
                }
                /* How many other people have seen each of my latest messages */
                $seen=new stdClass;
                $q=$__cp->prepare('SELECT id FROM app_chat WHERE deleted=0 AND role=? AND usr=? ORDER BY id DESC LIMIT 25');
                $q->execute([$__me['role'],$__me['usr']]); $mine=[]; foreach($q->fetchAll() as $r)$mine[]=(int)$r[0];
                if($mine){
                    $q=$__cp->prepare('SELECT upto FROM app_chat_seen WHERE skey<>?'); $q->execute([$__me['key']]);
                    $uptos=[]; foreach($q->fetchAll() as $r)$uptos[]=(int)$r[0];
                    foreach($mine as $mid){$n=0;foreach($uptos as $u){if($u>=$mid)$n++;}$seen->{(string)$mid}=$n;}
                }
                echo json_encode(['status'=>'success','messages'=>$msgs,'deleted'=>$gone,'seen'=>$seen,'me'=>['role'=>$__me['role'],'usr'=>$__me['usr'],'name'=>$__me['name'],'admin'=>$__me['role']==='admin']],JSON_UNESCAPED_UNICODE);exit;
            }
            if($action==='chat_key_pub'){ /* register this device's public key; returns my wrapped room key if an admin already issued one */
                $dev=(string)($input['dev']??''); $pub=chatPubOk($input['pub']??'');
                if(!preg_match('/^[A-Za-z0-9_-]{16,40}$/',$dev)||$pub===null){echo json_encode(['status'=>'error','message'=>'Bad key.']);exit;}
                $q=$__cp->prepare('SELECT pub,wrapped,wpub FROM app_chat_keys WHERE skey=? AND dev=?'); $q->execute([$__me['key'],$dev]); $row=$q->fetch();
                if(!$row){$__cp->prepare('INSERT INTO app_chat_keys (skey,dev,pub,wrapped,wpub,name,label,ts) VALUES (?,?,?,NULL,NULL,?,?,?)')->execute([$__me['key'],$dev,$pub,$__me['name'],$__me['label'],time()]);$row=[$pub,null,null];}
                elseif((string)$row[0]!==$pub){$__cp->prepare('UPDATE app_chat_keys SET pub=?,wrapped=NULL,wpub=NULL,name=?,label=?,ts=? WHERE skey=? AND dev=?')->execute([$pub,$__me['name'],$__me['label'],time(),$__me['key'],$dev]);$row=[$pub,null,null];}
                $cnt=(int)$__cp->query("SELECT COUNT(*) FROM app_chat_keys WHERE wrapped IS NOT NULL")->fetchColumn();
                echo json_encode(['status'=>'success','wrapped'=>$row[1]?:null,'wpub'=>$row[2]?:null,'empty'=>$cnt===0]);exit;
            }
            if($action==='chat_key_pending'){ /* admin devices only: who still needs the room key */
                if($__me['role']!=='admin'){http_response_code(403);echo json_encode(['status'=>'error','message'=>'Admin only.']);exit;}
                $q=$__cp->query("SELECT skey,dev,pub,name,label FROM app_chat_keys WHERE wrapped IS NULL AND skey<>'_init' ORDER BY ts LIMIT 40"); $o=[];
                foreach($q->fetchAll() as $r)$o[]=['skey'=>(string)$r[0],'dev'=>(string)$r[1],'pub'=>(string)$r[2],'name'=>(string)$r[3],'label'=>(string)$r[4]];
                echo json_encode(['status'=>'success','pending'=>$o],JSON_UNESCAPED_UNICODE);exit;
            }
            if($action==='chat_key_put'){ /* admin devices only: store room key wrapped for other devices (or create the very first room key) */
                if($__me['role']!=='admin'){http_response_code(403);echo json_encode(['status'=>'error','message'=>'Admin only.']);exit;}
                $items=is_array($input['items']??null)?array_slice($input['items'],0,40):[];
                if(!empty($input['init'])){
                    $have=(int)$__cp->query("SELECT COUNT(*) FROM app_chat_keys WHERE wrapped IS NOT NULL")->fetchColumn();
                    if($have>0){echo json_encode(['status'=>'error','message'=>'key_exists']);exit;}
                    /* only one admin device may create the first key: the marker row is the lock (stale after 60 s) */
                    $mk=$__cp->prepare("SELECT ts FROM app_chat_keys WHERE skey='_init' AND dev='_'"); $mk->execute(); $mr=$mk->fetch();
                    if($mr&&(int)$mr[0]>time()-60){echo json_encode(['status'=>'error','message'=>'key_exists']);exit;}
                    if($mr)$__cp->prepare("UPDATE app_chat_keys SET ts=? WHERE skey='_init' AND dev='_'")->execute([time()]);
                    else $__cp->prepare("INSERT INTO app_chat_keys (skey,dev,pub,ts) VALUES ('_init','_','',?)")->execute([time()]);
                }
                $up=$__cp->prepare('UPDATE app_chat_keys SET wrapped=?,wpub=? WHERE skey=? AND dev=? AND wrapped IS NULL'); $n=0;
                foreach($items as $it){
                    if(!is_array($it))continue;
                    $w=chatWrapOk($it['wrapped']??''); $wp=chatPubOk($it['wpub']??'');
                    if($w===null||$wp===null||!preg_match('/^[A-Za-z0-9_-]{16,40}$/',(string)($it['dev']??''))||(string)($it['skey']??'')==='_init')continue;
                    $up->execute([$w,$wp,(string)($it['skey']??''),(string)$it['dev']]); $n+=$up->rowCount();
                }
                echo json_encode(['status'=>'success','stored'=>$n]);exit;
            }
            if($action==='chat_send'){
                $encMsg=chatEncOk($input['enc']??'');
                if($encMsg===null){echo json_encode(['status'=>'error','message'=>'Chat is now end-to-end encrypted. Close and reopen the app (or refresh the page) to update, then send again.']);exit;}
                $f=$input['file']??null; $hasFile=is_array($f)&&!empty($f['enc']);
                $now=time();
                $q=$__cp->prepare('SELECT MAX(ts) FROM app_chat WHERE role=? AND usr=?');
                $q->execute([$__me['role'],$__me['usr']]); $lt=(int)($q->fetchColumn()?:0);
                if($now-$lt<1){echo json_encode(['status'=>'error','message'=>'You are sending too fast. Wait a second.']);exit;}
                $fUrl=null;$fName=null;$fKind=null;
                if($hasFile){
                    $up=chatSaveEncUpload((string)$f['enc']);
                    if(empty($up['ok'])){echo json_encode(['status'=>'error','message'=>$up['message']??'Upload failed.']);exit;}
                    $fUrl=$up['url'];$fName='';$fKind='enc';
                }
                $__cp->prepare('INSERT INTO app_chat (ts,role,usr,name,label,msg,file_url,file_name,file_kind) VALUES (?,?,?,?,?,?,?,?,?)')->execute([$now,$__me['role'],$__me['usr'],$__me['name'],$__me['label'],$encMsg,$fUrl,$fName,$fKind]);
                $id=(int)$__cp->lastInsertId();
                pushQueue(['all'=>true,'except'=>$__me['key']],$__me['name'].($__me['role']==='admin'?' (Admin)':''),'New message',['type'=>'chat','tab'=>'chat','tag'=>'chat','id'=>(string)$id]);
                if(random_int(1,40)===1){ // housekeeping: drop messages older than 90 days and long-deleted rows
                    $__cp->prepare('DELETE FROM app_chat WHERE ts<?')->execute([$now-90*86400]);
                    $__cp->prepare('DELETE FROM app_chat WHERE deleted=1 AND ts<?')->execute([$now-7*86400]);
                }
                echo json_encode(['status'=>'success','message'=>chatRow([$id,$now,$__me['role'],$__me['usr'],$__me['name'],$__me['label'],$encMsg,$fUrl,$fName,$fKind],$__me)],JSON_UNESCAPED_UNICODE);exit;
            }
            if($action==='chat_delete'){
                $id=(int)($input['id']??0);
                $q=$__cp->prepare('SELECT role,usr FROM app_chat WHERE id=? AND deleted=0'); $q->execute([$id]); $r=$q->fetch();
                if(!$r){echo json_encode(['status'=>'success']);exit;}
                $own=((string)$r[0]===$__me['role']&&(string)$r[1]===$__me['usr']);
                if(!$own){http_response_code(403);echo json_encode(['status'=>'error','message'=>'Only the person who posted can delete this message.']);exit;}
                $__cp->prepare('UPDATE app_chat SET deleted=1 WHERE id=?')->execute([$id]);
                echo json_encode(['status'=>'success']);exit;
            }
            if($action==='chat_seen'){
                $id=(int)($input['id']??0);
                $q=$__cp->prepare('SELECT role,usr FROM app_chat WHERE id=? AND deleted=0'); $q->execute([$id]); $r=$q->fetch();
                if(!$r){echo json_encode(['status'=>'error','message'=>'Message not found.']);exit;}
                $own=((string)$r[0]===$__me['role']&&(string)$r[1]===$__me['usr']);
                if(!$own&&$__me['role']!=='admin'){http_response_code(403);echo json_encode(['status'=>'error','message'=>'Only the sender can see this.']);exit;}
                $q=$__cp->prepare('SELECT name,label FROM app_chat_seen WHERE upto>=? AND skey<>? ORDER BY name');
                $q->execute([$id,((string)$r[0]).'|'.((string)$r[1])]);
                $list=[]; foreach($q->fetchAll() as $x)$list[]=['name'=>(string)$x[0],'label'=>(string)$x[1]];
                echo json_encode(['status'=>'success','seen'=>$list],JSON_UNESCAPED_UNICODE);exit;
            }
        }catch(Throwable $e){
            error_log('Chat error: '.$e->getMessage());
            echo json_encode(['status'=>'error','message'=>'Chat is temporarily unavailable.']);exit;
        }
    }

    if($action==='forgot_password_reset'){
        // Employee self-service recovery: username + registered DOB + new password.
        // Only employee accounts participate because DOB is stored in the Employee Master.
        $username=trim((string)($input['username']??''));
        $dob=trim((string)($input['dob']??''));
        $newPass=(string)($input['new_password']??'');
        if($username===''||$dob===''||$newPass===''){
            echo json_encode(['status'=>'error','message'=>'Username, date of birth and new password are required.']);exit;
        }
        if(strlen($newPass)<8){
            echo json_encode(['status'=>'error','message'=>'New password must contain at least 8 characters.']);exit;
        }
        if(($__w=rlBlocked('forgot',$username,true))>0)rlDeny($__w);
        // Accept the date-picker format (YYYY-MM-DD) and common stored formats.
        $normalizeDob=function($v){
            $v=trim((string)$v);
            if($v==='') return '';
            if(preg_match('/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/',$v,$m)) return sprintf('%04d-%02d-%02d',(int)$m[1],(int)$m[2],(int)$m[3]);
            if(preg_match('/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/',$v,$m)) return sprintf('%04d-%02d-%02d',(int)$m[3],(int)$m[2],(int)$m[1]);
            return strtolower($v);
        };
        $requestedDob=$normalizeDob($dob);
        $foundIndex=-1;
        foreach(($db['employees']??[]) as $ei=>$e){
            if(strcasecmp(trim((string)($e['user']??'')),$username)!==0) continue;
            if($normalizeDob($e['dob']??'')!==$requestedDob) continue;
            $foundIndex=$ei;
            break;
        }
        if($foundIndex<0){
            rlFail('forgot',$username,true);
            echo json_encode(['status'=>'error','message'=>'Username or date of birth does not match the registered employee record.']);exit;
        }
        rlClear('forgot',$username);
        $db['employees'][$foundIndex]['pass']=pwHash($newPass);
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Password reset successfully. You can now log in with your new password.']);exit;
    }

    /* ================= Biometric login (WebAuthn passkeys) =================
       Fingerprint / face / screen-lock of the phone. Needs HTTPS. Public keys live in biometrics.json
       (the private key never leaves the phone). */
    if(strpos((string)$action,'bio_')===0){
        $b64u=function($d){return rtrim(strtr(base64_encode($d),'+/','-_'),'=');};
        $b64d=function($d){return base64_decode(strtr((string)$d,'-_','+/'));};
        $bioRead=function(){$a=dataGet('biometrics');return is_array($a)?$a:[];};
        $bioWrite=function($a){return dataStoreSet('biometrics',$a)!==null;};
        $rpId=preg_replace('/:\d+$/','',(string)($_SERVER['HTTP_HOST']??''));
        $origin='https://'.($_SERVER['HTTP_HOST']??'');
        $cbor=null;
        $cbor=function($d,&$o) use(&$cbor){
            $ib=ord($d[$o++]);$mt=$ib>>5;$ai=$ib&31;
            if($ai<24)$v=$ai;elseif($ai==24){$v=ord($d[$o]);$o+=1;}elseif($ai==25){$v=unpack('n',substr($d,$o,2))[1];$o+=2;}elseif($ai==26){$v=unpack('N',substr($d,$o,4))[1];$o+=4;}else{throw new Exception('cbor');}
            if($mt==0)return $v;
            if($mt==1)return -1-$v;
            if($mt==2||$mt==3){$x=substr($d,$o,$v);$o+=$v;return $x;}
            if($mt==4){$a=[];for($i=0;$i<$v;$i++)$a[]=$cbor($d,$o);return $a;}
            if($mt==5){$m=[];for($i=0;$i<$v;$i++){$k=$cbor($d,$o);$m[$k]=$cbor($d,$o);}return $m;}
            if($mt==7){return $v==20?false:($v==21?true:null);}
            throw new Exception('cbor');
        };
        $derLen=function($n){return $n<128?chr($n):($n<256?"\x81".chr($n):"\x82".pack('n',$n));};
        $derInt=function($b) use($derLen){$b=ltrim($b,"\0");if($b===''||(ord($b[0])&0x80))$b="\0".$b;return "\x02".$derLen(strlen($b)).$b;};
        $coseToPem=function($k) use($derInt,$derLen){
            $kty=$k[1]??null;$alg=$k[3]??null;
            if($kty==2&&$alg==-7&&($k[-1]??1)==1){
                $der=hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200').("\x04".$k[-2].$k[-3]);
            }elseif($kty==3&&$alg==-257){
                $rsa="\x30".$derLen(strlen($derInt($k[-1]).$derInt($k[-2]))).$derInt($k[-1]).$derInt($k[-2]);
                $bit="\x03".$derLen(strlen($rsa)+1)."\0".$rsa;
                $algid=hex2bin('300d06092a864886f70d0101010500');
                $in=$algid.$bit;$der="\x30".$derLen(strlen($in)).$in;
            }else return null;
            return "-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode($der),64,"\n")."-----END PUBLIC KEY-----\n";
        };
        $accountOk=function($role,$user) use($db){ // returns session array or null (account must still exist / be allowed)
            if($role==='admin'){
                if($user===($db['admin']['user']??''))return ['role'=>'admin','user'=>$user,'super'=>isSuperAdminUser($user)];
                foreach(($db['admin_users']??[]) as $a) if(($a['user']??'')===$user)return ['role'=>'admin','user'=>$user,'super'=>isSuperAdminUser($user)];
                return null;
            }
            if($role==='emp'){
                foreach(($db['employees']??[]) as $e) if(($e['user']??'')===$user){
                    $st=employeeAccessState($e);
                    if($st['blocked'])return null;
                    if($st['restricted'])return ['role'=>'emp','employee_id'=>$e['id'],'user'=>$user,'restricted'=>true,'termination_date'=>$st['anchor_date'],'restriction_reason'=>$st['reason']];
                    return ['role'=>'emp','employee_id'=>$e['id'],'user'=>$user];
                }
                return null;
            }
            if($role==='security'){foreach(($db['security']??[]) as $g) if(($g['user']??'')===$user)return ['role'=>'security','site'=>$g['site'],'user'=>$user];return null;}
            if($role==='contractor'){foreach(($db['contractors']??[]) as $c) if(($c['user']??'')===$user)return ['role'=>'contractor','contractor_id'=>$c['id'],'user'=>$user];return null;}
            return null;
        };
        $checkClient=function($clientB64,$type) use($b64d,$b64u,$origin){
            $cj=$b64d($clientB64);$c=json_decode($cj,true);
            if(!is_array($c)||($c['type']??'')!==$type)return null;
            $exp=$_SESSION['bio_chal']??'';$_SESSION['bio_chal']='';
            if($exp===''||!hash_equals($exp,(string)($c['challenge']??'')))return null;
            if(($c['origin']??'')!==$origin)return null;
            return $cj;
        };

        if($action==='bio_login_options'){
            $ch=$b64u(random_bytes(32));$_SESSION['bio_chal']=$ch;
            echo json_encode(['status'=>'success','challenge'=>$ch,'rpId'=>$rpId]);exit;
        }
        if($action==='bio_login_verify'){
            $fail=function($m){http_response_code(401);echo json_encode(['status'=>'error','message'=>$m]);exit;};
            $cj=$checkClient($input['clientDataJSON']??'','webauthn.get');
            if($cj===null)$fail('Biometric check expired. Please try again.');
            $store=$bioRead();$cid=(string)($input['id']??'');
            if(!isset($store[$cid]))$fail('This phone is not registered for biometric login. Login with password and enable it first.');
            $rec=$store[$cid];
            if(($rec['type']??'')==='native')$fail('Biometric check failed.');
            $ad=$b64d($input['authenticatorData']??'');
            if(strlen($ad)<37||substr($ad,0,32)!==hash('sha256',$rpId,true))$fail('Biometric check failed.');
            $flags=ord($ad[32]);
            if(!($flags&1)||!($flags&4))$fail('Fingerprint / face verification was not completed.');
            $ok=openssl_verify($ad.hash('sha256',$cj,true),$b64d($input['signature']??''),$rec['pem'],OPENSSL_ALGO_SHA256);
            if($ok!==1)$fail('Biometric check failed.');
            $cnt=unpack('N',substr($ad,33,4))[1];
            if($cnt!==0&&$cnt<=(int)($rec['count']??0))$fail('Biometric check failed.');
            $session=$accountOk($rec['role'],$rec['user']);
            if($session===null)$fail('This account can no longer log in. Please contact Admin/HR.');
            $store[$cid]['count']=$cnt;$store[$cid]['last']=date('Y-m-d H:i:s');$bioWrite($store);
            if(!empty($_SESSION['role'])&&swKey($_SESSION)!==swKey($session)){swRelease();}
            $claim=swClaim($session,$input['tab']??'');
            if($claim===null){http_response_code(500);echo json_encode(['status'=>'error','duplicate'=>true,'message'=>'Login tracking file could not be written. Please check the MySQL connection in db_config.php.']);exit;}
            $_SESSION=$session;
            echo json_encode(['status'=>'success','role'=>$session['role'],'username'=>$session['user'],'restricted'=>!empty($session['restricted']),'termination_date'=>$session['termination_date']??null,'restriction_reason'=>$session['restriction_reason']??null]);exit;
        }
        /* Android app (WebView has no passkeys): the app keeps a random token in the phone's Keystore and
           releases it only after fingerprint / face / screen-lock. Only a SHA-256 hash of the token is stored here. */
        if($action==='bio_native_login'){
            $fail=function($m){http_response_code(401);echo json_encode(['status'=>'error','message'=>$m]);exit;};
            $tok=(string)($input['token']??'');
            if(strlen($tok)<20||strlen($tok)>200)$fail('This phone is not registered for biometric login. Login with password and enable it first.');
            $h=hash('sha256',$tok);$cid='nat_'.substr($h,0,32);
            $store=$bioRead();$rec=$store[$cid]??null;
            if($rec===null||($rec['type']??'')!=='native'||!hash_equals((string)($rec['hash']??''),$h))$fail('This phone is not registered for biometric login. Login with password and enable it first.');
            $session=$accountOk($rec['role'],$rec['user']);
            if($session===null)$fail('This account can no longer log in. Please contact Admin/HR.');
            $store[$cid]['last']=date('Y-m-d H:i:s');$bioWrite($store);
            if(!empty($_SESSION['role'])&&swKey($_SESSION)!==swKey($session)){swRelease();}
            $claim=swClaim($session,$input['tab']??'');
            if($claim===null){http_response_code(500);echo json_encode(['status'=>'error','duplicate'=>true,'message'=>'Login tracking file could not be written. Please check the MySQL connection in db_config.php.']);exit;}
            $_SESSION=$session;
            echo json_encode(['status'=>'success','role'=>$session['role'],'username'=>$session['user'],'restricted'=>!empty($session['restricted']),'termination_date'=>$session['termination_date']??null,'restriction_reason'=>$session['restriction_reason']??null]);exit;
        }
        // The actions below need a logged-in session
        if(empty($_SESSION['role'])||empty($_SESSION['user'])){http_response_code(401);echo json_encode(['status'=>'error','message'=>'Please login first.']);exit;}
        if($action==='bio_native_register'){
            $tok=$b64u(random_bytes(32));$h=hash('sha256',$tok);
            $store=$bioRead();
            $store['nat_'.substr($h,0,32)]=['type'=>'native','role'=>$_SESSION['role'],'user'=>$_SESSION['user'],'hash'=>$h,'count'=>0,'created'=>date('Y-m-d H:i:s'),'label'=>substr(preg_replace('/[^\w \-\.]/','',(string)($input['label']??'Android app')),0,40)];
            if(!$bioWrite($store)){echo json_encode(['status'=>'error','message'=>'Could not save. Please check the MySQL connection in db_config.php.']);exit;}
            echo json_encode(['status'=>'success','token'=>$tok]);exit;
        }
        if($action==='bio_status'){
            $n=0;foreach($bioRead() as $r) if(($r['role']??'')===$_SESSION['role']&&($r['user']??'')===$_SESSION['user'])$n++;
            echo json_encode(['status'=>'success','count'=>$n,'user'=>$_SESSION['user']]);exit;
        }
        if($action==='bio_reg_options'){
            $ch=$b64u(random_bytes(32));$_SESSION['bio_chal']=$ch;
            $u=(string)$_SESSION['user'];
            echo json_encode(['status'=>'success','challenge'=>$ch,'rpId'=>$rpId,'userId'=>$b64u(hash('sha256',$_SESSION['role'].'|'.strtolower($u),true)),'userName'=>$u]);exit;
        }
        if($action==='bio_reg_verify'){
            $fail=function($m){echo json_encode(['status'=>'error','message'=>$m]);exit;};
            $cj=$checkClient($input['clientDataJSON']??'','webauthn.create');
            if($cj===null)$fail('Biometric setup expired. Please try again.');
            try{
                $o=0;$att=$cbor($b64d($input['attestationObject']??''),$o);
                $ad=$att['authData']??'';
                if(strlen($ad)<55||substr($ad,0,32)!==hash('sha256',$rpId,true))$fail('Biometric setup failed.');
                if(!(ord($ad[32])&0x40))$fail('No credential received from the phone.');
                $clen=unpack('n',substr($ad,53,2))[1];
                $credId=substr($ad,55,$clen);
                $o=55+$clen;$key=$cbor($ad,$o);
            }catch(Exception $ex){$fail('Biometric setup failed.');}
            $pem=$coseToPem($key);
            if($pem===null||openssl_pkey_get_public($pem)===false)$fail('This phone uses an unsupported biometric key type.');
            $store=$bioRead();
            $store[$b64u($credId)]=['role'=>$_SESSION['role'],'user'=>$_SESSION['user'],'pem'=>$pem,'count'=>0,'created'=>date('Y-m-d H:i:s'),'label'=>substr(preg_replace('/[^\w \-\.]/','',(string)($input['label']??'Phone')),0,40)];
            if(!$bioWrite($store))$fail('Could not save. Please check the MySQL connection in db_config.php.');
            echo json_encode(['status'=>'success']);exit;
        }
        if($action==='bio_remove'){
            $store=$bioRead();foreach($store as $k=>$r) if(($r['role']??'')===$_SESSION['role']&&($r['user']??'')===$_SESSION['user'])unset($store[$k]);
            $bioWrite($store);echo json_encode(['status'=>'success']);exit;
        }
        echo json_encode(['status'=>'error','message'=>'Unknown action.']);exit;
    }

    if($action==='login'){
        $username=trim($input['username']??''); $password=(string)($input['password']??'');
        $ok=false; $session=[];
        if(($__w=rlBlocked('login',$username))>0)rlDeny($__w);
        // Role is intentionally NOT supplied by the login form. Identify the portal
        // automatically from the username + password credentials.
        if($username!=='' && $password!==''){
            if(DEMO_ENABLED && hash_equals(DEMO_USER,$username) && hash_equals(DEMO_PASS,$password)){
                $ok=true; $session=['role'=>'admin','user'=>DEMO_USER,'demo'=>true];
                if(dataStoreSet('demo',demoDatabase())===null){http_response_code(500);echo json_encode(['status'=>'error','message'=>'Demo data could not be prepared. Check the MySQL connection.']);exit;}
            }
            if(!$ok && $username===($db['admin']['user']??'') && pwVerify($db['admin']['pass']??'',$password)){
                $ok=true; $session=['role'=>'admin','user'=>$username,'super'=>isSuperAdminUser($username)];
            }
            if(!$ok){
                foreach(($db['admin_users']??[]) as $a){
                    if(($a['user']??'')===$username && pwVerify($a['pass']??'',$password)){$ok=true; $session=['role'=>'admin','user'=>$username,'super'=>isSuperAdminUser($username)]; break;}
                }
            }
            if(!$ok){
                foreach(($db['employees']??[]) as $e) if(($e['user']??'')===$username && pwVerify($e['pass']??'',$password)){
                    $state=employeeAccessState($e);
                    if($state['blocked']){
                        http_response_code(403);
                        $why=$state['reason']==='terminated'
                            ? 'This account was terminated on '.$state['anchor_date'].'.'
                            : 'The notice period ended on '.$state['anchor_date'].'.';
                        echo json_encode(['status'=>'error','message'=>$why.' The 15-day access window has ended and login is no longer available. Please contact Admin/HR.']);
                        exit;
                    }
                    if($state['restricted']){
                        $ok=true;$session=['role'=>'emp','employee_id'=>$e['id'],'user'=>$username,'restricted'=>true,'termination_date'=>$state['anchor_date'],'restriction_reason'=>$state['reason']];
                    } else {
                        $ok=true;$session=['role'=>'emp','employee_id'=>$e['id'],'user'=>$username];
                    }
                    break;
                }
            }
            if(!$ok){
                foreach(($db['security']??[]) as $g) if(($g['user']??'')===$username && pwVerify($g['pass']??'',$password)){$ok=true;$session=['role'=>'security','site'=>$g['site'],'user'=>$username];break;}
            }
            if(!$ok){
                foreach(($db['contractors']??[]) as $c) if(($c['user']??'')===$username && pwVerify($c['pass']??'',$password)){
                    $ok=true;$session=['role'=>'contractor','contractor_id'=>$c['id'],'user'=>$username];break;
                }
            }
        }
        if(!$ok){
            // Give a specific message when the username exists but the password is wrong.
            // This is intentionally kept separate from the successful authentication path.
            $userExists=false;
            if($username!==''){
                if($username===($db['admin']['user']??'')) $userExists=true;
                if(!$userExists) foreach(($db['admin_users']??[]) as $a) if(($a['user']??'')===$username){$userExists=true;break;}
                if(!$userExists) foreach(($db['employees']??[]) as $e) if(($e['user']??'')===$username){$userExists=true;break;}
                if(!$userExists) foreach(($db['security']??[]) as $g) if(($g['user']??'')===$username){$userExists=true;break;}
                if(!$userExists) foreach(($db['contractors']??[]) as $c) if(($c['user']??'')===$username){$userExists=true;break;}
            }
            rlFail('login',$username);
            http_response_code(401);
            echo json_encode(['status'=>'error','message'=>'Invalid username or password']);
            exit;
        }
        rlClear('login',$username);
        if(!empty($_SESSION['role']) && swKey($_SESSION)!==swKey($session)){swRelease();} // switching accounts in same browser: free the old one
        if(!empty($session['demo'])){session_regenerate_id(true);$claim=true;}else{$claim=swClaim($session,$input['tab']??'');}
        if($claim===null){
            http_response_code(500);
            echo json_encode(['status'=>'error','duplicate'=>true,'message'=>'Login tracking file could not be written. Please check the MySQL connection in db_config.php.']);
            exit;
        }
        $_SESSION=$session;
        echo json_encode(['status'=>'success','role'=>$session['role'],'super'=>!empty($session['super']),'restricted'=>!empty($session['restricted']),'termination_date'=>$session['termination_date']??null,'restriction_reason'=>$session['restriction_reason']??null]);exit;
    }
    if($action==='logout'){
        /* Logout must ALWAYS end this browser's session. (Before, the session was kept whenever another tab of the
           same browser owned the login slot, so the Exit/Log out button appeared to do nothing.) */
        try{swRelease(true);}catch(\Throwable $e){}
        try{$__pt=trim((string)($input['push_token']??''));if($__pt!==''&&!empty($_SESSION['role'])&&($__pp=pushPdo())){$__pp->prepare('DELETE FROM app_push WHERE token=?')->execute([$__pt]);}}catch(\Throwable $e){}
        session_unset();
        if(ini_get('session.use_cookies')){$cp=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$cp['path'],$cp['domain'],$cp['secure'],$cp['httponly']);}
        session_destroy();
        echo json_encode(['status'=>'success']);exit;
    }
    /* add_cashbook_entry locks itself AFTER the (slow) Cloudinary upload so it does not block everyone meanwhile. */
    if(!in_array($action,['login','logout','forgot_password_reset','idle_ping','session_check','admin_merge_records','admin_import_begin','admin_import_chunk','admin_import_finish','refresh_portal_data','add_cashbook_entry','save_contractor_payment','update_contractor_payment_image'],true)){ dbLockedReload(); }
    if($action==='admin_storage_status'){
        requireRole(['admin']);
        $pdo=dataPdo(); $out=['status'=>'success','mysql'=>!!$pdo,'stores'=>new stdClass,'legacy'=>[]];
        if($pdo){$st=[];foreach(array_keys(dataLegacyFiles()) as $k){list($rows)=dataReadStore($pdo,$k);$st[$k]=count($rows);}$out['stores']=$st;}
        foreach(array_merge(array_values(dataLegacyFiles()),['data.json']) as $f)if(is_file(__DIR__.'/'.$f))$out['legacy'][]=$f;
        echo json_encode($out);exit;
    }
    /* Admin adds a PARTIAL export (contractors / contractor_attendance / contractor_payments / cashbook) to the live data.
       Nothing is replaced: records that already exist (same id / same day) are kept, only missing ones are added. */
    if($action==='admin_merge_records'){
        requireRole(['admin']);
        $in=is_array($input['data']??null)?$input['data']:[];
        $rep=['contractors_added'=>0,'contractors_existing'=>0,'attendance_days_added'=>0,'attendance_days_existing'=>0,'payments_added'=>0,'payments_existing'=>0,'cashbook_added'=>0];
        $r=dataStoreTx('database',function(&$d) use($in,&$rep){
            foreach(['contractors','contractor_payments','cashbook'] as $k)if(!isset($d[$k])||!is_array($d[$k]))$d[$k]=[];
            if(!isset($d['contractor_attendance'])||!is_array($d['contractor_attendance']))$d['contractor_attendance']=[];
            $has=function($list,$id){foreach($list as $x)if((string)($x['id']??'')===(string)$id)return true;return false;};
            foreach((is_array($in['contractors']??null)?$in['contractors']:[]) as $c){
                if(!is_array($c)||(string)($c['id']??'')==='')continue;
                if($has($d['contractors'],$c['id'])){$rep['contractors_existing']++;continue;}
                $c['pass']=(string)($c['pass']??'');
                $c['assigned_employee_ids']=array_values(array_unique(array_map('strval',is_array($c['assigned_employee_ids']??null)?$c['assigned_employee_ids']:[])));
                $c['created_by']=(string)($c['created_by']??'Admin');
                $d['contractors'][]=$c;$rep['contractors_added']++;
            }
            foreach((is_array($in['contractor_attendance']??null)?$in['contractor_attendance']:[]) as $key=>$days){
                if(!is_array($days))continue;
                if(!isset($d['contractor_attendance'][$key]))$d['contractor_attendance'][$key]=[];
                foreach($days as $day=>$rec){
                    if(isset($d['contractor_attendance'][$key][$day])){$rep['attendance_days_existing']++;continue;}
                    $d['contractor_attendance'][$key][$day]=$rec;$rep['attendance_days_added']++;
                }
            }
            foreach((is_array($in['contractor_payments']??null)?$in['contractor_payments']:[]) as $x){
                if(!is_array($x)||(string)($x['id']??'')==='')continue;
                if($has($d['contractor_payments'],$x['id'])){$rep['payments_existing']++;continue;}
                $d['contractor_payments'][]=$x;$rep['payments_added']++;
            }
            foreach((is_array($in['related_cashbook_entries']??null)?$in['related_cashbook_entries']:[]) as $x){
                if(!is_array($x)||(string)($x['id']??'')==='')continue;
                if($has($d['cashbook'],$x['id']))continue;
                $d['cashbook'][]=$x;$rep['cashbook_added']++;
            }
            return true;
        });
        if($r===null){echo json_encode(['status'=>'error','message'=>'MySQL write failed: '.($GLOBALS['dataLastError']?:'unknown').' (nothing changed)']);exit;}
        echo json_encode(['status'=>'success','report'=>$rep]);exit;
    }
    /* Chunked admin import: the browser sends ONE top-level key per request (small requests, no host upload/time limit),
       rows are staged in store "imp_<store>", and admin_import_finish swaps them in atomically after checking every key arrived. */
    if(in_array($action,['admin_import_begin','admin_import_chunk','admin_import_finish'],true)){
        requireRole(['admin']);
        $pdo=dataPdo();
        if(!$pdo){echo json_encode(['status'=>'error','message'=>'MySQL is not connected. Check db_config.php.']);exit;}
        $store=(string)($input['store']??'');
        if(!in_array($store,['database','biometrics'],true)){echo json_encode(['status'=>'error','message'=>'Unknown store.']);exit;}
        $stage='imp_'.$store;
        try{
            if($action==='admin_import_begin'){
                $pdo->prepare('DELETE FROM app_store WHERE store=?')->execute([$stage]);
                echo json_encode(['status'=>'success']);exit;
            }
            if($action==='admin_import_chunk'){
                $k=(string)($input['key']??''); $raw=$input['value']??null;
                if($k===''||strlen($k)>255||!is_string($raw)){echo json_encode(['status'=>'error','message'=>'Bad chunk.']);exit;}
                $v=json_decode($raw,true);
                if($v===null&&trim($raw)!=='null'){echo json_encode(['status'=>'error','message'=>'Chunk "'.$k.'" is not valid JSON.']);exit;}
                $j=json_encode($v,DATA_FLAGS); if($j===false){echo json_encode(['status'=>'error','message'=>'Chunk "'.$k.'" could not be encoded.']);exit;}
                $pdo->prepare('REPLACE INTO app_store (store,k,v) VALUES (?,?,?)')->execute([$stage,$k,$j]);
                echo json_encode(['status'=>'success','bytes'=>strlen($j)]);exit;
            }
            /* finish */
            $keys=is_array($input['keys']??null)?array_map('strval',$input['keys']):[];
            $st=$pdo->prepare('SELECT k FROM app_store WHERE store=?');$st->execute([$stage]);
            $have=[];foreach($st->fetchAll() as $r)$have[$r[0]]=true;
            $missing=array_values(array_filter($keys,function($k)use($have){return !isset($have[$k]);}));
            if(!$keys||$missing){echo json_encode(['status'=>'error','message'=>'Import incomplete, missing: '.implode(', ',array_slice($missing,0,10)).'. Nothing was changed.']);exit;}
            if($store==='database'&&(!isset($have['company'])||!isset($have['employees']))){echo json_encode(['status'=>'error','message'=>'This does not look like the app database (needs "company" and "employees"). Nothing was changed.']);exit;}
            $my=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql';
            $pdo->beginTransaction();
            if($my){$q=$pdo->prepare("SELECT v FROM app_store WHERE store='_lock' AND k=? FOR UPDATE");$q->execute([$store]);$q->fetchAll();}
            list(,$ledOld)=dataReadStore($pdo,$store);
            $pdo->prepare('DELETE FROM app_store WHERE store=?')->execute([$store]);
            $pdo->prepare('INSERT INTO app_store (store,k,v) SELECT ?,k,v FROM app_store WHERE store=?')->execute([$store,$stage]);
            $pdo->prepare('DELETE FROM app_store WHERE store=?')->execute([$stage]);
            dataMeta($pdo,'migrated:'.$store);dataMeta($pdo,'verified:'.$store);
            list(,$ledNew)=dataReadStore($pdo,$store);
            try{ledgerAppend($pdo,$store,$ledOld,$ledNew);}catch(Throwable $le){error_log('Ledger append failed (import): '.$le->getMessage());}
            $pdo->commit();
            $n=$pdo->prepare('SELECT COUNT(*) FROM app_store WHERE store=?');$n->execute([$store]);$cnt=(int)$n->fetchAll()[0][0];
            if($cnt!==count($keys)){echo json_encode(['status'=>'error','message'=>'Imported but row count differs ('.$cnt.' of '.count($keys).').']);exit;}
            $deleted=dataCleanupLegacy();
            echo json_encode(['status'=>'success','rows'=>$cnt,'deleted'=>$deleted]);exit;
        }catch(Throwable $e){
            if($pdo->inTransaction())$pdo->rollBack();
            echo json_encode(['status'=>'error','message'=>'MySQL error: '.$e->getMessage().' (nothing was changed)']);exit;
        }
    }
    /* Admin uploads old database.json / biometrics.json (or data.json) -> replaces the MySQL copy, verifies it, then deletes the old files on the server. */
    if($action==='admin_json_import'){
        requireRole(['admin']);
        $pdo=dataPdo();
        if(!$pdo){echo json_encode(['status'=>'error','message'=>'MySQL is not connected. Check db_config.php.']);exit;}
        $files=is_array($input['files']??null)?$input['files']:[];
        if(!$files){echo json_encode(['status'=>'error','message'=>'No file received. The file may be larger than the server upload limit ('.ini_get('post_max_size').'). Upload database.json on its own.']);exit;}
        list($report,$deleted)=dataImportUploadedJson($pdo,$files);
        echo json_encode(['status'=>'success','report'=>$report,'deleted'=>$deleted]);exit;
    }
    if($action==='refresh_portal_data'){
        requireRole(['admin','emp','contractor','security']);
        $freshDb=dataGet(dbStore());
        if(!is_array($freshDb)){echo json_encode(['status'=>'error','message'=>'Could not refresh portal data.']);exit;}
        // Return the current database snapshot so assignment changes made by Admin/Employee
        // are immediately visible to the logged-in Contractor portal after refresh.
        echo json_encode(['status'=>'success','db'=>cpScopeDb(pwPublicDb($freshDb))],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
    }

    if($action==='save_company'){
        requireRole('admin');
        $db['company']['name']=trim($input['name']??'');

        $db['company']['addr']=trim($input['addr']??'');
        $db['company']['size']=max(40,min(200,(int)($input['size']??80)));
        $db['company']['login_size']=max(40,min(400,(int)($input['login_size']??160)));
        $db['company']['logo']=COMPANY_LOGO_URL; // logo is fixed (see COMPANY_LOGO_URL)
        $db['company']['seal']=COMPANY_SEAL_URL; // seal is fixed (see COMPANY_SEAL_URL)
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Company profile saved successfully.']); exit;
    }

    if($action==='save_admin_creds'){
        requireRole('admin');
        $user=trim($input['user']??''); $pass=trim($input['pass']??'');
        /* A normal Admin may only change their OWN login; adding/changing another admin needs Super Admin. */
        if(empty($_SESSION['super'])&&strcasecmp($user,(string)($_SESSION['user']??''))!==0){
            echo json_encode(['status'=>'error','message'=>'Only a Super Admin can create or change another admin\'s login.']);exit;
        }
        $prevHash='';
        if(($db['admin']['user']??'')===$user)$prevHash=(string)($db['admin']['pass']??'');
        if($prevHash===''){foreach(($db['admin_users']??[]) as $a0){if(($a0['user']??'')===$user){$prevHash=(string)($a0['pass']??'');break;}}}
        if(!$user||($pass===''&&$prevHash==='')){echo json_encode(['status'=>'error','message'=>'Username and password are required.']);exit;}
        $hash=($pass!==''?pwHash($pass):$prevHash);
        $db['admin']['user']=$user;$db['admin']['pass']=$hash;
        if(!isset($db['admin_users'])||!is_array($db['admin_users']))$db['admin_users']=[];
        $found=false; foreach($db['admin_users'] as $i=>$a){if(($a['user']??'')===$user){$db['admin_users'][$i]=['user'=>$user,'pass'=>$hash];$found=true;break;}}
        if(!$found)$db['admin_users'][]=['user'=>$user,'pass'=>$hash];
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Admin credentials updated.']);exit;
    }

    if($action==='save_security_creds'){
        requireRole('admin');
        $sites=$input['sites']??[];
        if(!is_array($sites)||count($sites)===0){echo json_encode(['status'=>'error','message'=>'No site credentials provided.']);exit;}
        $clean=[];
        foreach($sites as $s){
            $site=trim($s['site']??'');$user=trim($s['user']??'');$pass=trim($s['pass']??'');
            $prevG='';foreach(($db['security']??[]) as $g0){if(($g0['user']??'')===$user){$prevG=(string)($g0['pass']??'');break;}}
            if($prevG===''){foreach(($db['security']??[]) as $g0){if(($g0['site']??'')===$site){$prevG=(string)($g0['pass']??'');break;}}}
            if(!$site||!$user||($pass===''&&$prevG==='')){echo json_encode(['status'=>'error','message'=>'Each site needs a name, username and password.']);exit;}
            $clean[]=['site'=>$site,'user'=>$user,'pass'=>($pass!==''?pwHash($pass):$prevG)];
        }
        $db['security']=$clean;saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Security guard credentials updated.']);exit;
    }

    if($action==='assign_employee_contractors'){
        requireRole('admin');
        $employeeId=trim((string)($input['employee_id']??''));
        if(!$employeeId){echo json_encode(['status'=>'error','message'=>'Select an employee first.']);exit;}
        $contractorIds=$input['contractor_ids']??[];
        if(!is_array($contractorIds))$contractorIds=[];
        $contractorIds=array_values(array_unique(array_filter(array_map('strval',$contractorIds),fn($v)=>trim($v)!=='')));
        $found=false;
        foreach($db['employees'] as $ei=>$e){
            if((string)($e['id']??'')===$employeeId){$db['employees'][$ei]['contractor_ids']=$contractorIds;$db['employees'][$ei]['contractor_id']=$contractorIds[0]??'';$found=true;break;}
        }
        if(!$found){echo json_encode(['status'=>'error','message'=>'Employee not found.']);exit;}
        foreach($contractorIds as $cid){$valid=false;foreach(($db['contractors']??[]) as $c){if((string)($c['id']??'')===$cid){$valid=true;break;}}if(!$valid){echo json_encode(['status'=>'error','message'=>'One or more selected contractors do not exist.']);exit;}}
        foreach($db['contractors'] as $ci=>$c){
            $ids=array_map('strval',is_array($c['assigned_employee_ids']??null)?$c['assigned_employee_ids']:[]);
            if(in_array((string)$c['id'],$contractorIds,true)){if(!in_array($employeeId,$ids,true))$ids[]=$employeeId;}
            else{$ids=array_values(array_filter($ids,fn($eid)=>(string)$eid!==$employeeId));}
            $db['contractors'][$ci]['assigned_employee_ids']=array_values(array_unique($ids));
        }
        saveOrFail($db);echo json_encode(['status'=>'success','message'=>'Contractor assignment updated.']);exit;
    }

    if($action==='assign_employee_credentials'){
        requireRole('admin');
        $employeeId=trim((string)($input['employee_id']??''));
        $user=trim((string)($input['user']??''));
        $pass=(string)($input['pass']??'');
        if(!$employeeId){echo json_encode(['status'=>'error','message'=>'Select an employee first.']);exit;}
        $prevEH='';foreach($db['employees'] as $e0){if((string)($e0['id']??'')===$employeeId){$prevEH=(string)($e0['pass']??'');break;}}
        /* Portal login is optional here: with no username entered, project / contractor assignment still goes ahead and any existing login stays untouched. */
        if($user===''){
            if($pass!==''){echo json_encode(['status'=>'error','message'=>'Enter a username for the password.']);exit;}
            echo json_encode(['status'=>'success','message'=>'No login change.','skipped'=>true]);exit;
        }
        if($pass===''&&$prevEH===''){echo json_encode(['status'=>'error','message'=>'Enter a password for this new portal login.']);exit;}
        foreach($db['employees'] as $e){
            if((string)($e['id']??'')!==$employeeId && strcasecmp(trim((string)($e['user']??'')),$user)===0){
                echo json_encode(['status'=>'error','message'=>'Username already exists for another employee.']);exit;
            }
        }
        $found=false;
        foreach($db['employees'] as $ei=>$e){
            if((string)($e['id']??'')===$employeeId){
                $db['employees'][$ei]['user']=$user;
                $db['employees'][$ei]['pass']=($pass!==''?pwHash($pass):$prevEH);
                $found=true;
                break;
            }
        }
        if(!$found){echo json_encode(['status'=>'error','message'=>'Employee not found.']);exit;}
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Employee login credentials updated.']);exit;
    }

    if($action==='assign_employee_project'){
        requireRole('admin');
        $employeeId=trim((string)($input['employee_id']??''));
        $project=trim((string)($input['project']??''));
        $shift=trim((string)($input['shift']??'shift1'));
        if(!in_array($shift,['shift1','shift2'],true))$shift='shift1';
        if(!$employeeId){echo json_encode(['status'=>'error','message'=>'Select an employee first.']);exit;}
        $found=false;
        foreach($db['employees'] as $ei=>$e){if((string)($e['id']??'')===$employeeId){$db['employees'][$ei]['project']=$project;$db['employees'][$ei]['shift']=$shift;$db['employees'][$ei]['assignment_updated_at']=date('c');$found=true;break;}}
        if(!$found){echo json_encode(['status'=>'error','message'=>'Employee not found.']);exit;}
        saveOrFail($db);echo json_encode(['status'=>'success','message'=>$project!==''?'Project assigned to employee.':'Project assignment removed.']);exit;
    }

    if($action==='save_employee'){
        requireRole('admin');
        $id=trim($input['id']??'');
        if(!$id){echo json_encode(['status'=>'error','message'=>'Employee ID is required.']);exit;}
        $found=false; $index=-1; $existing=[];
        foreach($db['employees'] as $i=>$employee){
            if(($employee['id']??'')===$id){$found=true;$index=$i;$existing=$employee;break;}
        }
        // Employee Master never edits project, contractor assignments, or portal credentials.
        $input['project']=$existing['project']??'';
        $input['contractor_ids']=$existing['contractor_ids']??(($existing['contractor_id']??'')?[$existing['contractor_id']]:[]);
        $input['contractor_id']=$existing['contractor_id']??(($input['contractor_ids'][0]??''));
        $input['user']=$existing['user']??'';
        $input['pass']=$existing['pass']??'';
        // Termination status is managed only via terminate_employee/reinstate_employee/rejoin_employee below.
        $input['terminated']=$existing['terminated']??false;
        $input['termination_date']=$existing['termination_date']??'';
        $input['termination_reason']=$existing['termination_reason']??'';
        $input['employment_history']=$existing['employment_history']??[];
        $input['notice_period_end']=$existing['notice_period_end']??'';
        $input['notice_period_reason']=$existing['notice_period_reason']??'';
        // Employee photo: new uploads arrive as base64 from the browser; store them in Cloudinary and keep only the URL.
        $ph=(string)($input['photo']??'');
        if(strpos($ph,'data:image/')===0){
            $pr=dataUriToCloud($ph,'employee_photos','emp_'.preg_replace('/[^A-Za-z0-9]/','',$id));
            if(!$pr['ok']){echo json_encode(['status'=>'error','message'=>$pr['message']]);exit;}
            $input['photo']=$pr['url'];
        }
        if($found)$db['employees'][$index]=$input;else $db['employees'][]=$input;
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Employee saved. Project, contractor access and login credentials are managed from Project Assign.']);exit;
    }

    if($action==='delete_employee'){
        requireRole('admin');
        $id=trim($input['id']??'');
        $db['employees']=array_values(array_filter($db['employees'],function($e)use($id){return ($e['id']??'')!==$id;}));
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Employee deleted.']);exit;
    }

    if($action==='terminate_employee'){
        requireRole('admin');
        $id=trim($input['id']??'');
        $date=trim($input['date']??'');
        $date=$date!==''?$date:date('Y-m-d');
        $reason=trim($input['reason']??'');
        $found=false;
        foreach($db['employees'] as $i=>$e){
            if(($e['id']??'')===$id){
                $db['employees'][$i]['terminated']=true;
                $db['employees'][$i]['termination_date']=$date;
                $db['employees'][$i]['termination_reason']=$reason;
                // Termination supersedes any running notice period.
                $db['employees'][$i]['notice_period_end']='';
                $db['employees'][$i]['notice_period_reason']='';
                $found=true;
                break;
            }
        }
        if(!$found){echo json_encode(['status'=>'error','message'=>'Employee not found.']);exit;}
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Employee marked as terminated. The account stays active for 15 days (payslip download / account access only) and then login is blocked.','termination_date'=>$date]);exit;
    }

    if($action==='set_notice_period'){
        requireRole('admin');
        $id=trim($input['id']??'');
        $end=trim($input['end_date']??'');
        if(!$end){echo json_encode(['status'=>'error','message'=>'Last working day is required.']);exit;}
        $reason=trim($input['reason']??'');
        $found=false;
        foreach($db['employees'] as $i=>$e){
            if(($e['id']??'')===$id){
                $db['employees'][$i]['notice_period_end']=$end;
                $db['employees'][$i]['notice_period_reason']=$reason;
                $found=true;
                break;
            }
        }
        if(!$found){echo json_encode(['status'=>'error','message'=>'Employee not found.']);exit;}
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Notice period set. Full access continues until '.$end.', then the account stays live for 15 more days (Payslip & Calendar only) before login locks automatically.','notice_period_end'=>$end]);exit;
    }

    if($action==='clear_notice_period'){
        requireRole('admin');
        $id=trim($input['id']??'');
        $found=false;
        foreach($db['employees'] as $i=>$e){
            if(($e['id']??'')===$id){
                $db['employees'][$i]['notice_period_end']='';
                $db['employees'][$i]['notice_period_reason']='';
                $found=true;
                break;
            }
        }
        if(!$found){echo json_encode(['status'=>'error','message'=>'Employee not found.']);exit;}
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Notice period cleared. Full normal access continues.']);exit;
    }

    if($action==='reinstate_employee'){
        requireRole('admin');
        $id=trim($input['id']??'');
        $found=false;
        foreach($db['employees'] as $i=>$e){
            if(($e['id']??'')===$id){
                $db['employees'][$i]['terminated']=false;
                $db['employees'][$i]['termination_date']='';
                $db['employees'][$i]['termination_reason']='';
                $found=true;
                break;
            }
        }
        if(!$found){echo json_encode(['status'=>'error','message'=>'Employee not found.']);exit;}
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Employee reinstated. Full login access restored.']);exit;
    }

    if($action==='rejoin_employee'){
        requireRole('admin');
        $id=trim($input['id']??'');
        $rejoinDate=trim($input['rejoin_date']??'');
        $rejoinDate=$rejoinDate!==''?$rejoinDate:date('Y-m-d');
        $found=false;
        foreach($db['employees'] as $i=>$e){
            if(($e['id']??'')===$id){
                // Rejoin is for an employee who left and is formally coming back —
                // unlike Reinstate (a same-window correction of a mistaken
                // termination), this keeps the past termination on record.
                if(!empty($e['terminated'])){
                    if(!isset($db['employees'][$i]['employment_history']) || !is_array($db['employees'][$i]['employment_history'])){
                        $db['employees'][$i]['employment_history']=[];
                    }
                    $db['employees'][$i]['employment_history'][]=[
                        'termination_date'=>$e['termination_date']??'',
                        'termination_reason'=>$e['termination_reason']??'',
                        'rejoin_date'=>$rejoinDate
                    ];
                }
                $db['employees'][$i]['terminated']=false;
                $db['employees'][$i]['termination_date']='';
                $db['employees'][$i]['termination_reason']='';
                $found=true;
                break;
            }
        }
        if(!$found){echo json_encode(['status'=>'error','message'=>'Employee not found.']);exit;}
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Employee marked as rejoined on '.$rejoinDate.'. Full login access restored.','rejoin_date'=>$rejoinDate]);exit;
    }

    if($action==='save_shifts'){
        requireRole('admin');
        foreach(['shift1','shift2'] as $sid){
            if(isset($input[$sid]['name']))$db['shifts'][$sid]['name']=trim($input[$sid]['name']);
            if(isset($input[$sid]['start']))$db['shifts'][$sid]['start']=trim($input[$sid]['start']);
            if(isset($input[$sid]['end']))$db['shifts'][$sid]['end']=trim($input[$sid]['end']);
        }
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Shift timings updated.']);exit;
    }

    if($action==='save_contractor'){
        requireRole(['admin','emp']);
        $id=trim($input['id']??'');
        if(!$id){echo json_encode(['status'=>'error','message'=>'Contractor ID is required.']);exit;}
        $requestedIds=is_array($input['assigned_employee_ids']??null)?$input['assigned_employee_ids']:[];
        $requestedIds=array_values(array_unique(array_map('strval',$requestedIds)));
        $isEmp=(($_SESSION['role']??'')==='emp');
        $existingIndex=-1;
        foreach($db['contractors'] as $index=>$contractor){
            if((string)($contractor['id']??'')===(string)$id){$existingIndex=$index;break;}
        }
        if($isEmp && $existingIndex>=0){
            $existing=$db['contractors'][$existingIndex];
            $myEmpId=(string)($_SESSION['employee_id']??'');
            $existingAssigned=array_map('strval',is_array($existing['assigned_employee_ids']??null)?$existing['assigned_employee_ids']:[]);
            $canEdit=in_array($myEmpId,$existingAssigned,true) || (string)($existing['created_by']??'')===(string)($_SESSION['user']??'');
            if(!$canEdit){echo json_encode(['status'=>'error','message'=>'You can update only contractors assigned to you or created by you.']);exit;}
            // Employee cannot remove their own access; preserve existing assignments and ensure self remains assigned.
            $requestedIds=$existingAssigned;
            if($myEmpId!=='' && !in_array($myEmpId,$requestedIds,true))$requestedIds[]=$myEmpId;
        }
        if($isEmp){
            $myEmpId=(string)($_SESSION['employee_id']??'');
            if($myEmpId!=='' && !in_array($myEmpId,$requestedIds,true))$requestedIds[]=$myEmpId;
        }
        $ctPassIn=trim($input['pass']??'');
        $ctPassStored=($ctPassIn!==''?pwHash($ctPassIn):($existingIndex>=0?(string)($db['contractors'][$existingIndex]['pass']??''):''));
        $record=['id'=>$id,'name'=>trim($input['name']??''),
            'mason_rate'=>(float)($input['mason_rate']??0),'helper_rate'=>(float)($input['helper_rate']??0),
            'carpenter_rate'=>(float)($input['carpenter_rate']??0),'plumber_rate'=>(float)($input['plumber_rate']??0),
            'painter_rate'=>(float)($input['painter_rate']??0),
            'contact'=>trim($input['contact']??''),
            'user'=>trim($input['user']??''),'pass'=>$ctPassStored,
            'created_by'=>($existingIndex>=0 ? ($db['contractors'][$existingIndex]['created_by']??($_SESSION['user']??'Admin')) : ($_SESSION['user']??'Admin')),
            'assigned_employee_ids'=>array_values(array_unique($requestedIds))];
        if($existingIndex>=0)$db['contractors'][$existingIndex]=$record; else $db['contractors'][]=$record;
        // Admin contractor assignment is the single source of truth. Keep the
        // employee-side contractor list exactly synchronized with it.
        if(!$isEmp){
            $assigned=array_map('strval',$record['assigned_employee_ids']);
            foreach($db['employees'] as $ei=>$employee){
                $eid=(string)($employee['id']??'');
                $cids=is_array($employee['contractor_ids']??null)?array_map('strval',$employee['contractor_ids']):[];
                $cids=array_values(array_unique(array_filter($cids,fn($cid)=>(string)$cid!==$id)));
                if(in_array($eid,$assigned,true)) array_unshift($cids,$id);
                $cids=array_values(array_unique($cids));
                $db['employees'][$ei]['contractor_ids']=$cids;
                $db['employees'][$ei]['contractor_id']=$cids[0]??'';
            }
        }
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Contractor saved successfully.','contractor'=>$record]);exit;
    }

    if($action==='delete_contractor'){
        requireRole('admin');
        $id=trim($input['id']??'');
        $db['contractors']=array_values(array_filter($db['contractors'],function($c)use($id){return ($c['id']??'')!==$id;}));
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Contractor deleted.']);exit;
    }

    if($action==='add_salary_advance'){
        requireRole('admin');
        $employeeId=trim($input['employee_id']??'');
        $date=trim($input['date']??'');
        $amount=(float)($input['amount']??0);
        $note=trim($input['note']??'');
        if(!$employeeId||!$date||$amount<=0){echo json_encode(['status'=>'error','message'=>'Employee, date and a valid amount are required.']);exit;}
        $forMonth=trim($input['for_month']??'');
        if(!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/',$forMonth))$forMonth=substr($date,0,7);
        $fmY=(int)substr($forMonth,0,4);$fmM=(int)substr($forMonth,5,2)-1;
        if(in_array($employeeId.'-'.$fmM.'-'.$fmY,$db['locked_payroll']??[],true)){echo json_encode(['status'=>'error','message'=>'Salary for '.date('F Y',mktime(0,0,0,$fmM+1,1,$fmY)).' is already credited (payroll locked). Unlock it first or choose another month.']);exit;}
        $record=['id'=>uniqid('adv_',true),'employee_id'=>$employeeId,'date'=>$date,'for_month'=>$forMonth,'amount'=>$amount,'note'=>$note];
        $db['salary_advances'][]=$record;
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Salary advance recorded.','record'=>$record]);exit;
    }

    if($action==='delete_salary_advance'){
        requireRole('admin');
        $id=trim($input['id']??'');
        $db['salary_advances']=array_values(array_filter($db['salary_advances'],function($a)use($id){return ($a['id']??'')!==$id;}));
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Salary advance deleted.']);exit;
    }

    if($action==='add_holiday'){
        requireRole('admin');
        $date=trim($input['date']??'');
        $name=trim($input['name']??'');
        $double=!empty($input['double_pay']);
        if(!$date){echo json_encode(['status'=>'error','message'=>'Holiday date is required.']);exit;}
        if(!isset($db['holidays']))$db['holidays']=[];
        $record=['id'=>uniqid('hol_',true),'date'=>$date,'name'=>$name?:'Company Holiday','double_pay'=>$double];
        $db['holidays'][]=$record;
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Holiday added.','record'=>$record]);exit;
    }

    if($action==='delete_holiday'){
        requireRole('admin');
        $id=trim($input['id']??'');
        $db['holidays']=array_values(array_filter($db['holidays']??[],function($h)use($id){return ($h['id']??'')!==$id;}));
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Holiday removed.']);exit;
    }

    if($action==='lock_payroll'){
        requireRole('admin');
        $key=trim($input['key']??'');
        if(!$key){echo json_encode(['status'=>'error','message'=>'Missing period key.']);exit;}
        if(!isset($db['locked_payroll']))$db['locked_payroll']=[];
        if(!in_array($key,$db['locked_payroll'],true))$db['locked_payroll'][]=$key;
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Payroll period locked.']);exit;
    }

    if($action==='unlock_payroll'){
        requireRole('admin');
        $key=trim($input['key']??'');
        $db['locked_payroll']=array_values(array_filter($db['locked_payroll']??[],function($k)use($key){return $k!==$key;}));
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Payroll period unlocked.']);exit;
    }

    if($action==='mark_salary_paid'){
        requireRole('admin');
        $key=trim($input['key']??'');
        if(!preg_match('/^[A-Za-z0-9_.-]+-(\d|1[01])-\d{4}$/',$key)){echo json_encode(['status'=>'error','message'=>'Invalid salary period.']);exit;}
        if(!isset($db['salary_paid'])||!is_array($db['salary_paid']))$db['salary_paid']=[];
        $rec=['date'=>date('Y-m-d'),'at'=>date('c')];
        $db['salary_paid'][$key]=$rec;
        if(!isset($db['locked_payroll'])||!is_array($db['locked_payroll']))$db['locked_payroll']=[];
        if(!in_array($key,$db['locked_payroll'],true))$db['locked_payroll'][]=$key; // paid salary = payroll closed
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Salary marked as PAID. Payroll for this month is now locked.','record'=>$rec]);exit;
    }

    if($action==='unmark_salary_paid'){
        requireRole('admin');
        $key=trim($input['key']??'');
        if(isset($db['salary_paid'][$key]))unset($db['salary_paid'][$key]);
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Paid mark removed. Payroll stays locked until you unlock it.']);exit;
    }

    /* Keeps the app in step with Cloudinary: if a bill file was deleted in the Cloudinary console, the entry no longer
       shows a bill. Only clears an entry when Cloudinary answered successfully AND the file is truly absent. */
    if($action==='sync_cashbook_bills'){
        requireRole(['emp','admin']);
        $live=listCloudBillIds();
        if($live===null){echo json_encode(['status'=>'success','checked'=>false,'cleared'=>[]]);exit;}
        $liveSet=array_flip($live);$cleared=[];
        foreach(($db['cashbook']??[]) as $i=>$c){
            $u=(string)($c['bill_url']??'');
            if($u==='')continue;
            $pid=cloudBillPublicId($u);
            if($pid!==null && !isset($liveSet[$pid])){
                $db['cashbook'][$i]['bill_url']='';$db['cashbook'][$i]['bill_type']='';$db['cashbook'][$i]['bill_deleted']=true;
                $cleared[]=(string)$c['id'];
            }
        }
        if($cleared)saveOrFail($db);
        echo json_encode(['status'=>'success','checked'=>true,'cleared'=>$cleared]);exit;
    }

    if($action==='add_cashbook_entry'){
    requireRole(['emp']);
    $employeeId=(string)($_SESSION['employee_id']??'');
    $date=trim($input['date']??date('Y-m-d'));
    $project=trim($input['project']??'');
    $category=trim($input['category']??'');
    $description=trim($input['description']??'');
    $income=(float)($input['income']??0);
    $expense=(float)($input['expense']??0);
    $billData=trim((string)($input['bill_data']??''));
    $billName=trim((string)($input['bill_name']??''));
    $employee=null;
    foreach(($db['employees']??[]) as $e){if((string)($e['id']??'')===$employeeId){$employee=$e;break;}}
    $assignedProject=trim((string)($employee['project']??''));
    if(!$employeeId||!$date||!$assignedProject){echo json_encode(['status'=>'error','message'=>'Employee or assigned project not found.']);exit;}
    if($project!==$assignedProject){echo json_encode(['status'=>'error','message'=>'You can add cash book entries only for your assigned project.']);exit;}
    if($description===''){echo json_encode(['status'=>'error','message'=>'Enter description.']);exit;}
    if(!in_array($category,['Petrol','Petti cash','Expenses'],true)){echo json_encode(['status'=>'error','message'=>'Invalid category.']);exit;}
    if($income<0||$expense<0){echo json_encode(['status'=>'error','message'=>'Amount cannot be negative.']);exit;}
    if($income<=0 && $expense<=0){echo json_encode(['status'=>'error','message'=>'Enter an amount greater than 0.']);exit;}
    if($income>0 && $expense>0){echo json_encode(['status'=>'error','message'=>'Select either Income or Expense, not both.']);exit;}
    // Cash bills can be uploaded for both Income and Expense entries.
    $billUrl='';
    $billType='';
    $billOriginalName='';
    if($billData!==''){
        $up=prepareAndUploadCashBill($billData,$billName,$date);
        if(!$up['ok']){echo json_encode(['status'=>'error','message'=>$up['message']]);exit;}
        $billUrl=$up['url'];$billType=$up['type'];$billOriginalName=$up['name'];
    }
    $record=[
        'id'=>uniqid('cb_',true),'employee_id'=>$employeeId,'date'=>$date,'project'=>$project,
        'category'=>$category,'description'=>$description,'income'=>$income,'expense'=>$expense,'created_by'=>'emp',
        'bill_url'=>$billUrl,'bill_type'=>$billType,'bill_name'=>$billOriginalName,
        'created_at'=>date('Y-m-d H:i:s')
    ];
    dbLockedReload();
    if(!isset($db['cashbook'])||!is_array($db['cashbook']))$db['cashbook']=[];
    $db['cashbook'][]=$record;
    saveOrFail($db);
    echo json_encode(['status'=>'success','message'=>'Cash book entry added.','record'=>$record]);exit;
}

    if($action==='update_cashbook_bill'){
        // Add / replace / remove the bill of an already-saved entry. Employee-only, own entries only.
        requireRole(['emp']);
        $id=trim($input['id']??'');
        $remove=!empty($input['remove']);
        $billData=trim((string)($input['bill_data']??''));
        $billName=trim((string)($input['bill_name']??''));
        if(!$remove&&$billData===''){echo json_encode(['status'=>'error','message'=>'Choose a bill file.']);exit;}
        $idx=null;
        foreach(($db['cashbook']??[]) as $i=>$c){if(($c['id']??'')===$id){$idx=$i;break;}}
        if($idx===null){echo json_encode(['status'=>'error','message'=>'Entry not found.']);exit;}
        $entry=$db['cashbook'][$idx];
        if(($entry['employee_id']??'')!==(string)($_SESSION['employee_id']??'')){
            echo json_encode(['status'=>'error','message'=>'You can only change bills of your own cash book entries.']);exit;
        }
        $oldUrl=(string)($entry['bill_url']??'');
        $newUrl='';$newType='';$newName='';
        if(!$remove){
            $up=prepareAndUploadCashBill($billData,$billName!==''?$billName:'',(string)($entry['date']??date('Y-m-d')));
            if(!$up['ok']){echo json_encode(['status'=>'error','message'=>$up['message']]);exit;}
            $newUrl=$up['url'];$newType=$up['type'];$newName=$up['name'];
        }
        dbLockedReload();
        $idx=null;
        foreach(($db['cashbook']??[]) as $i=>$c){if(($c['id']??'')===$id){$idx=$i;break;}}
        if($idx===null){
            if($newUrl!=='')deleteCashBillFile($newUrl);
            echo json_encode(['status'=>'error','message'=>'Entry not found.']);exit;
        }
        $db['cashbook'][$idx]['bill_url']=$newUrl;
        $db['cashbook'][$idx]['bill_type']=$newType;
        $db['cashbook'][$idx]['bill_name']=$newName;
        unset($db['cashbook'][$idx]['bill_deleted']);
        saveOrFail($db);
        $msg=$remove?'Bill removed.':($oldUrl!==''?'Bill replaced.':'Bill added.');
        if($oldUrl!==''){
            $del=deleteCashBillFile($oldUrl);
            if(!$del['ok'])$msg.=' Warning: old bill file could not be deleted ('.$del['message'].').';
        }
        echo json_encode(['status'=>'success','message'=>$msg,'record'=>$db['cashbook'][$idx]]);exit;
    }

if($action==='delete_cashbook_entry'){
        // Cash Book is employee-only: Admin cannot delete entries, and an employee may
        // only delete their own.
        requireRole(['emp']);
        $id=trim($input['id']??'');
        $entry=null;
        foreach($db['cashbook'] as $c){if(($c['id']??'')===$id){$entry=$c;break;}}
        if(!$entry){echo json_encode(['status'=>'error','message'=>'Entry not found.']);exit;}
        if(($entry['employee_id']??'')!==(string)($_SESSION['employee_id']??'')){
            echo json_encode(['status'=>'error','message'=>'You can only delete your own cash book entries.']);exit;
        }
        $db['cashbook']=array_values(array_filter($db['cashbook'],function($c)use($id){return ($c['id']??'')!==$id;}));
        saveOrFail($db);
        /* Entry is gone from the database; now remove its bill file (cloud or local) so nothing is left orphaned. */
        $msg='Cash book entry deleted.';
        $billUrl=(string)($entry['bill_url']??'');
        if($billUrl!==''){
            $del=deleteCashBillFile($billUrl);
            $msg.=$del['ok']?' Bill image deleted.':' Warning: bill image could not be deleted ('.$del['message'].').';
        }
        echo json_encode(['status'=>'success','message'=>$msg]);exit;
    }

    if($action==='add_owner_payment'){
    // Owner Direct Payment: amount paid by the Owner straight to a vendor/party,
    // never handled as cash by the employee. It is NOT part of the Cash Book
    // income/expense/balance, but IS counted in the project's Overall Site Spending
    // (Overall Site Spending = Cash Book Expense + Owner Direct Payments).
    requireRole(['emp']);
    $employeeId=(string)($_SESSION['employee_id']??'');
    $date=trim($input['date']??date('Y-m-d'));
    $project=trim($input['project']??'');
    $description=trim($input['description']??'');
    $paidTo=trim($input['paid_to']??'');
    $amount=(float)($input['amount']??0);
    $employee=null;
    foreach(($db['employees']??[]) as $e){if((string)($e['id']??'')===$employeeId){$employee=$e;break;}}
    $assignedProject=trim((string)($employee['project']??''));
    if(!$employeeId||!$date||!$assignedProject){echo json_encode(['status'=>'error','message'=>'Employee or assigned project not found.']);exit;}
    if($project!==$assignedProject){echo json_encode(['status'=>'error','message'=>'You can add owner payments only for your assigned project.']);exit;}
    if($description===''){echo json_encode(['status'=>'error','message'=>'Enter description.']);exit;}
    if($amount<=0){echo json_encode(['status'=>'error','message'=>'Enter an amount greater than 0.']);exit;}
    $record=[
        'id'=>uniqid('op_',true),'employee_id'=>$employeeId,'date'=>$date,'project'=>$project,
        'description'=>$description,'paid_to'=>$paidTo,'amount'=>$amount,'created_by'=>'emp',
        'created_at'=>date('Y-m-d H:i:s')
    ];
    if(!isset($db['owner_payments'])||!is_array($db['owner_payments']))$db['owner_payments']=[];
    $db['owner_payments'][]=$record;
    saveOrFail($db);
    echo json_encode(['status'=>'success','message'=>'Owner payment added.','record'=>$record]);exit;
}

if($action==='delete_owner_payment'){
        // Owner Payments are employee-only: Admin cannot delete entries, and an
        // employee may only delete their own.
        requireRole(['emp']);
        $id=trim($input['id']??'');
        $entry=null;
        foreach(($db['owner_payments']??[]) as $c){if(($c['id']??'')===$id){$entry=$c;break;}}
        if(!$entry){echo json_encode(['status'=>'error','message'=>'Entry not found.']);exit;}
        if(($entry['employee_id']??'')!==(string)($_SESSION['employee_id']??'')){
            echo json_encode(['status'=>'error','message'=>'You can only delete your own owner payment entries.']);exit;
        }
        $db['owner_payments']=array_values(array_filter($db['owner_payments'],function($c)use($id){return ($c['id']??'')!==$id;}));
        saveOrFail($db); echo json_encode(['status'=>'success','message'=>'Owner payment deleted.']);exit;
    }

    if($action==='save_contractor_attendance'){
        requireRole(['admin','emp','contractor']);
        $key=trim($input['key']??'');$day=(int)($input['day']??0);
        $attendanceContractorId=contractorIdFromAttendanceKey($key);
        if(($_SESSION['role']??'')==='contractor' && $attendanceContractorId!==($_SESSION['contractor_id']??'')){echo json_encode(['status'=>'error','message'=>'You can edit only your assigned contractor attendance.']);exit;}
        if(($_SESSION['role']??'')==='emp'){
            $myEmpId=(string)($_SESSION['employee_id']??'');$myUser=(string)($_SESSION['user']??'');$allowed=false;
            foreach(($db['contractors']??[]) as $c){if((string)($c['id']??'')===$attendanceContractorId){$ids=array_map('strval',is_array($c['assigned_employee_ids']??null)?$c['assigned_employee_ids']:[]);$allowed=in_array($myEmpId,$ids,true)||(string)($c['created_by']??'')===$myUser;break;}}
            if(!$allowed){echo json_encode(['status'=>'error','message'=>'You can edit attendance only for contractors assigned to you or created by you.']);exit;}
        }
        if(!$key||$day<1||$day>31){echo json_encode(['status'=>'error','message'=>'Invalid attendance data.']);exit;}
        $clamp=function($v){return max(0,min(999,(float)$v));};
        $record=[
            'mason'=>$clamp($input['mason']??0),'helper'=>$clamp($input['helper']??0),
            'carpenter'=>$clamp($input['carpenter']??0),'plumber'=>$clamp($input['plumber']??0),
            'painter'=>$clamp($input['painter']??0),
            'mason_ot'=>$clamp($input['mason_ot']??0),'helper_ot'=>$clamp($input['helper_ot']??0),
            'carpenter_ot'=>$clamp($input['carpenter_ot']??0),'plumber_ot'=>$clamp($input['plumber_ot']??0),
            'painter_ot'=>$clamp($input['painter_ot']??0)
        ];
        // Optional worker-wise OT entries. Legacy trade-level records remain supported.
        if(isset($input['worker_ot']) && is_array($input['worker_ot'])){
            $workerOt=[];
            foreach(['mason','helper','carpenter','plumber','painter'] as $trade){
                $vals=is_array($input['worker_ot'][$trade]??null)?$input['worker_ot'][$trade]:[];
                $count=(int)$record[$trade]; $clean=[];
                for($i=0;$i<min($count,100);$i++) $clean[]=max(0,min(24,(float)($vals[$i]??0)));
                $workerOt[$trade]=$clean;
                $record[$trade.'_ot']=array_sum($clean);
            }
            $record['worker_ot']=$workerOt;
        }
        if(!isset($db['contractor_attendance'][$key]))$db['contractor_attendance'][$key]=[];
        $db['contractor_attendance'][$key][$day]=$record;
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Attendance saved.']);exit;
    }

    /* ================= Contractor Bill / Labour Payment =================
       Weekly (Mon-Sun) payments made to a contractor, with an optional reference image/PDF.
       The weekly bill itself is derived from Contractor Attendance x trade rates; only the PAYMENTS are stored here.
       Any unpaid part simply carries into the next week's "balance brought forward" (calculated in the app). */
    function cpCanManage($db,$cid){
        $role=$_SESSION['role']??'';
        if($role==='admin')return true;
        if($role!=='emp')return false;
        $myEmpId=(string)($_SESSION['employee_id']??'');$myUser=(string)($_SESSION['user']??'');
        foreach(($db['contractors']??[]) as $c){
            if((string)($c['id']??'')===(string)$cid){
                $ids=array_map('strval',is_array($c['assigned_employee_ids']??null)?$c['assigned_employee_ids']:[]);
                return in_array($myEmpId,$ids,true)||(string)($c['created_by']??'')===$myUser;
            }
        }
        return false;
    }
    function cpValidDate($s){$d=DateTime::createFromFormat('!Y-m-d',(string)$s);return $d&&$d->format('Y-m-d')===(string)$s?$d:null;}

    if($action==='save_contractor_payment'){
        requireRole(['admin','emp']);
        $cid=trim((string)($input['contractor_id']??''));
        $week=trim((string)($input['week_start']??''));
        $paidDate=trim((string)($input['paid_date']??date('Y-m-d')));
        $amount=round((float)($input['amount']??0),2);
        $mode=trim((string)($input['mode']??'Cash'));
        if(!in_array($mode,['Cash','UPI','Bank Transfer','Cheque','Other'],true))$mode='Cash';
        $note=mb_substr(trim((string)($input['note']??'')),0,300);
        $billData=trim((string)($input['bill_data']??''));$billName=trim((string)($input['bill_name']??''));
        $known=false;foreach(($db['contractors']??[]) as $c){if((string)($c['id']??'')===$cid){$known=true;break;}}
        if(!$known){echo json_encode(['status'=>'error','message'=>'Contractor not found.']);exit;}
        if(!cpCanManage($db,$cid)){echo json_encode(['status'=>'error','message'=>'You can record payments only for contractors assigned to you or created by you.']);exit;}
        $wd=cpValidDate($week);
        if(!$wd||$wd->format('N')!=='1'){echo json_encode(['status'=>'error','message'=>'Invalid week.']);exit;}
        if(!cpValidDate($paidDate)){echo json_encode(['status'=>'error','message'=>'Invalid payment date.']);exit;}
        if($amount<=0||$amount>100000000){echo json_encode(['status'=>'error','message'=>'Enter a valid amount greater than 0.']);exit;}
        $img=['url'=>'','type'=>'','name'=>''];
        if($billData!==''){
            $up=prepareAndUploadCashBill($billData,$billName!==''?$billName:('Labour Payment - '.$cid.' - '.$paidDate),$paidDate);
            if(!$up['ok']){echo json_encode(['status'=>'error','message'=>$up['message']]);exit;}
            $img=['url'=>$up['url'],'type'=>$up['type'],'name'=>$up['name']];
        }
        dbLockedReload();
        if(!isset($db['contractor_payments'])||!is_array($db['contractor_payments']))$db['contractor_payments']=[];
        $record=[
            'id'=>uniqid('cp_',true),'contractor_id'=>$cid,'week_start'=>$week,'amount'=>$amount,'paid_date'=>$paidDate,
            'mode'=>$mode,'note'=>$note,'image_url'=>$img['url'],'image_type'=>$img['type'],'image_name'=>$img['name'],
            'created_by'=>(string)($_SESSION['user']??($_SESSION['role']??'')),'created_at'=>date('Y-m-d H:i:s')
        ];
        $db['contractor_payments'][]=$record;
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Payment saved.','record'=>$record]);exit;
    }

    if($action==='delete_contractor_payment'){
        requireRole(['admin','emp']);
        $id=trim((string)($input['id']??''));$entry=null;
        foreach(($db['contractor_payments']??[]) as $r){if((string)($r['id']??'')===$id){$entry=$r;break;}}
        if(!$entry){echo json_encode(['status'=>'error','message'=>'Payment not found.']);exit;}
        if(!cpCanManage($db,$entry['contractor_id']??'')){echo json_encode(['status'=>'error','message'=>'You cannot change payments of this contractor.']);exit;}
        $db['contractor_payments']=array_values(array_filter($db['contractor_payments'],function($r)use($id){return (string)($r['id']??'')!==$id;}));
        saveOrFail($db);
        $msg='Payment deleted.';
        $u=(string)($entry['image_url']??'');
        if($u!==''){$del=deleteCashBillFile($u);if(!$del['ok'])$msg.=' Warning: reference image could not be deleted ('.$del['message'].').';}
        echo json_encode(['status'=>'success','message'=>$msg]);exit;
    }

    if($action==='update_contractor_payment_image'){
        requireRole(['admin','emp']);
        $id=trim((string)($input['id']??''));$remove=!empty($input['remove']);
        $billData=trim((string)($input['bill_data']??''));$billName=trim((string)($input['bill_name']??''));
        if(!$remove&&$billData===''){echo json_encode(['status'=>'error','message'=>'Choose an image or PDF.']);exit;}
        $entry=null;foreach(($db['contractor_payments']??[]) as $r){if((string)($r['id']??'')===$id){$entry=$r;break;}}
        if(!$entry){echo json_encode(['status'=>'error','message'=>'Payment not found.']);exit;}
        if(!cpCanManage($db,$entry['contractor_id']??'')){echo json_encode(['status'=>'error','message'=>'You cannot change payments of this contractor.']);exit;}
        $n=['url'=>'','type'=>'','name'=>''];
        if(!$remove){
            $up=prepareAndUploadCashBill($billData,$billName!==''?$billName:('Labour Payment - '.($entry['contractor_id']??'')),(string)($entry['paid_date']??date('Y-m-d')));
            if(!$up['ok']){echo json_encode(['status'=>'error','message'=>$up['message']]);exit;}
            $n=['url'=>$up['url'],'type'=>$up['type'],'name'=>$up['name']];
        }
        dbLockedReload();
        $idx=null;foreach(($db['contractor_payments']??[]) as $i=>$r){if((string)($r['id']??'')===$id){$idx=$i;break;}}
        if($idx===null){if($n['url']!=='')deleteCashBillFile($n['url']);echo json_encode(['status'=>'error','message'=>'Payment not found.']);exit;}
        $old=(string)($db['contractor_payments'][$idx]['image_url']??'');
        $db['contractor_payments'][$idx]['image_url']=$n['url'];
        $db['contractor_payments'][$idx]['image_type']=$n['type'];
        $db['contractor_payments'][$idx]['image_name']=$n['name'];
        saveOrFail($db);
        $msg=$remove?'Image removed.':($old!==''?'Image replaced.':'Image added.');
        if($old!==''){$del=deleteCashBillFile($old);if(!$del['ok'])$msg.=' Warning: old image could not be deleted ('.$del['message'].').';}
        echo json_encode(['status'=>'success','message'=>$msg,'record'=>$db['contractor_payments'][$idx]]);exit;
    }

    function isPayrollLocked($db,$key){
        return in_array($key,$db['locked_payroll']??[],true);
    }

    /* Terminated employees: attendance is PERMANENTLY locked. Unlike payroll lock this has no Unlock
       button and cannot be bypassed by unlocking payroll. It lifts only if Admin reinstates / rejoins the employee. */
    function isTerminatedAttendanceLocked($db,$key){
        $empId=employeeIdFromAttendanceKey($key);
        foreach(($db['employees']??[]) as $e){
            if((string)($e['id']??'')===(string)$empId)return !empty($e['terminated']);
        }
        return false;
    }
    function terminatedLockMsg(){return 'This employee is terminated. Attendance is permanently locked and cannot be changed.';}

    // Casual/Sick leave are capped per calendar year. Pending requests count
    // toward the quota too (so it can't be over-committed before approval);
    // a rejected request simply stops counting once it moves to history.
    function leaveDaysUsedInYear($db,$empId,$leaveType,$year,$excludeId=null){
        $total=0;
        $approvedHistory=array_filter($db['leave_history']??[],function($r){return ($r['result']??'')==='approved';});
        $all=array_merge($db['leave_requests']??[],$approvedHistory);
        foreach($all as $r){
            if($excludeId!==null && ($r['id']??'')===$excludeId)continue;
            if((string)($r['emp_id']??'')!==(string)$empId)continue;
            if(strtoupper((string)($r['leave_type']??''))!==$leaveType)continue;
            $rf=DateTime::createFromFormat('!Y-m-d',$r['date_from']??'');$rt=DateTime::createFromFormat('!Y-m-d',$r['date_to']??'');
            if(!$rf||!$rt)continue;
            $cursor=clone $rf;
            while($cursor<=$rt){
                if((int)$cursor->format('Y')===$year)$total++;
                $cursor->modify('+1 day');
            }
        }
        return $total;
    }
    // Checks a [from,to] range against the annual quota for CL/SL, split by
    // calendar year if the range crosses a year boundary. Returns an error
    // message string on failure, or null if within quota (or not a capped type).
    function checkLeaveQuota($db,$empId,$leaveType,$from,$to,$excludeId=null){
        static $quotaMap=['CL'=>12,'SL'=>12];
        if(!isset($quotaMap[$leaveType]))return null;
        $quota=$quotaMap[$leaveType];
        $perYear=[];$cursor=clone $from;
        while($cursor<=$to){$y=(int)$cursor->format('Y');$perYear[$y]=($perYear[$y]??0)+1;$cursor->modify('+1 day');}
        foreach($perYear as $y=>$cnt){
            $used=leaveDaysUsedInYear($db,$empId,$leaveType,$y,$excludeId);
            if($used+$cnt>$quota){
                $remaining=max(0,$quota-$used);
                return leaveTypeName($leaveType).' balance for '.$y.' is insufficient. '.$remaining.' day(s) remaining out of '.$quota.'.';
            }
        }
        return null;
    }
    function leaveTypeName($t){return ['CL'=>'Casual Leave','SL'=>'Sick Leave','LOP'=>'Loss of Pay','OD'=>'On Duty'][$t]??$t;}

    if($action==='save_attendance'){
        $role=$_SESSION['role']??'';
        if($role==='contractor'){
            $empKey=trim($input['key']??''); $empId=employeeIdFromAttendanceKey($empKey);
            if(!contractorAssignedToEmployee($_SESSION['contractor_id']??'',$empId)){echo json_encode(['status'=>'error','message'=>'This employee is not assigned to your contractor.']);exit;}
        }else{echo json_encode(['status'=>'error','message'=>'Manual attendance entry is not allowed for Admin. Please use Missed Attendance approval instead.']);exit;}
        $key=trim($input['key']??'');$day=(int)($input['day']??0);$status=$input['status']??'A';
        if(!$key||$day<1||$day>31){echo json_encode(['status'=>'error','message'=>'Invalid attendance data.']);exit;}
        if(isPayrollLocked($db,$key)){echo json_encode(['status'=>'error','message'=>'This payroll period is locked. Ask Admin to unlock it first.']);exit;}
        if(isTerminatedAttendanceLocked($db,$key)){echo json_encode(['status'=>'error','message'=>terminatedLockMsg()]);exit;}
        if(!isset($db['attendance'][$key]))$db['attendance'][$key]=[];
        $db['attendance'][$key][$day]=$status;saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Attendance saved.']);exit;
    }

    // Shared authorization check used by the punch-related actions below.
    // - admin / security: may act on any employee (security marks attendance at the gate).
    // - contractor: only employees assigned to that contractor.
    // - emp: only their own attendance/punch record.
    function authorizeAttendanceAction($key){
        $role=$_SESSION['role']??'';
        $empId=employeeIdFromAttendanceKey($key);
        if($role==='admin'||$role==='security')return true;
        if($role==='contractor'){
            if(!contractorAssignedToEmployee($_SESSION['contractor_id']??'',$empId)){
                echo json_encode(['status'=>'error','message'=>'This employee is not assigned to your contractor.']);exit;
            }
            return true;
        }
        if($role==='emp'){
            if(($_SESSION['employee_id']??'')!==$empId){
                echo json_encode(['status'=>'error','message'=>'You can only update your own attendance.']);exit;
            }
            return true;
        }
        http_response_code(403);
        echo json_encode(['status'=>'error','message'=>'Access denied.']);exit;
    }

    if($action==='mark_self_attendance'){
        $key=trim($input['key']??'');$day=(int)($input['day']??0);$status=$input['status']??'';
        if(!$key||$day<1||$day>31||!in_array($status,['P','H'],true)){echo json_encode(['status'=>'error','message'=>'Invalid attendance.']);exit;}
        authorizeAttendanceAction($key);
        if(faceRequired($db)){echo json_encode(['status'=>'error','message'=>'Face recognition is on: please use Punch In / Punch Out.']);exit;}
        if(isPayrollLocked($db,$key)){echo json_encode(['status'=>'error','message'=>'This payroll period is locked. Ask Admin to unlock it first.']);exit;}
        if(isTerminatedAttendanceLocked($db,$key)){echo json_encode(['status'=>'error','message'=>terminatedLockMsg()]);exit;}
        if(!isset($db['attendance'][$key]))$db['attendance'][$key]=[];
        if(isset($db['attendance'][$key][$day])){echo json_encode(['status'=>'error','message'=>'Attendance already logged.']);exit;}
        $db['attendance'][$key][$day]=$status;saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Attendance logged successfully.']);exit;
    }

    if(in_array($action,['ledger_anchor_status','ledger_anchor_prepare','ledger_anchor_save','ledger_anchor_list','ledger_anchor_get','ledger_doc_check','ledger_doc_register'],true)){
        if(($_SESSION['role']??'')!=='admin'){echo json_encode(['status'=>'error','message'=>'Admin only.']);exit;}
        $pdo=dataPdo(); if(!$pdo){echo json_encode(['status'=>'error','message'=>'MySQL is not available.']);exit;}
        try{
            ledgerEnsureExtra($pdo);
            if($action==='ledger_anchor_status'){
                $head=ledgerHead($pdo);
                $l=$pdo->query('SELECT ts,height FROM app_anchors ORDER BY id DESC LIMIT 1')->fetchAll();
                $due=$head&&(!$l||((int)$l[0][1]<$head[0]&&(time()-(int)$l[0][0])>20*3600));
                echo json_encode(['status'=>'success','due'=>(bool)$due]);exit;
            }
            if($action==='ledger_anchor_prepare'){
                $head=ledgerHead($pdo);
                if(!$head){echo json_encode(['status'=>'error','message'=>'The chain is empty. Save some data in the portal first, then anchor.']);exit;}
                $ds=ledgerDocScan($pdo,true);
                $text="Tejodhar HR Portal - Integrity Anchor\nChain height: ".$head[0]."\nChain head: ".$head[1]."\nDocuments: ".$ds['count']."\nDocuments root: ".$ds['root']."\nTime (UTC): ".gmdate('Y-m-d H:i:s')."\n";
                echo json_encode(['status'=>'success','text'=>$text,'height'=>$head[0],'head'=>$head[1],'docs'=>$ds['count']]);exit;
            }
            if($action==='ledger_anchor_save'){
                $text=(string)($input['text']??'');$proofs=is_array($input['proofs']??null)?$input['proofs']:[];
                if(strlen($text)>2000||!preg_match('/^Chain height: (\d+)$/m',$text,$m1)||!preg_match('/^Chain head: ([0-9a-f]{64})$/m',$text,$m2)||!preg_match('/^Documents: (\d+)$/m',$text,$m3)||!preg_match('/^Documents root: ([0-9a-f]{64})$/m',$text,$m4)){echo json_encode(['status'=>'error','message'=>'Invalid anchor text.']);exit;}
                $q=$pdo->prepare('SELECT block_hash FROM app_ledger WHERE height=?');$q->execute([(int)$m1[1]]);$b=$q->fetchAll();
                if(!$b||$b[0][0]!==$m2[1]){echo json_encode(['status'=>'error','message'=>'Anchor does not match the chain. Try again.']);exit;}
                $digest=hash('sha256',$text,true);$magic=ledgerOtsMagic();$good=[];
                foreach($proofs as $cal=>$pb){
                    if(!preg_match('/^[a-z0-9-]{1,30}$/',(string)$cal))continue;
                    $bin=base64_decode((string)$pb,true);
                    if($bin===false||strlen($bin)<66||strlen($bin)>20000)continue;
                    if(substr($bin,0,31)!==$magic||ord($bin[31])!==1||ord($bin[32])!==8||substr($bin,33,32)!==$digest)continue;
                    $good[$cal]=base64_encode($bin);
                }
                if(!$good){echo json_encode(['status'=>'error','message'=>'No valid OpenTimestamps proof was received.']);exit;}
                $pdo->prepare('INSERT INTO app_anchors (ts,height,head_hash,docs,docs_root,anchor_text,proofs) VALUES (?,?,?,?,?,?,?)')->execute([time(),(int)$m1[1],$m2[1],(int)$m3[1],$m4[1],$text,json_encode($good)]);
                echo json_encode(['status'=>'success','calendars'=>array_keys($good)]);exit;
            }
            if($action==='ledger_anchor_list'){
                $rows=[];foreach($pdo->query('SELECT id,ts,height,head_hash,docs,proofs FROM app_anchors ORDER BY id DESC LIMIT 10')->fetchAll() as $r){
                    $rows[]=['id'=>(int)$r[0],'time'=>date('Y-m-d H:i',(int)$r[1]),'height'=>(int)$r[2],'head'=>$r[3],'docs'=>(int)$r[4],'calendars'=>array_keys((array)json_decode($r[5],true))];
                }
                echo json_encode(['status'=>'success','anchors'=>$rows]);exit;
            }
            if($action==='ledger_anchor_get'){
                $q=$pdo->prepare('SELECT height,anchor_text,proofs FROM app_anchors WHERE id=?');$q->execute([(int)($input['id']??0)]);$r=$q->fetchAll();
                $cal=(string)($input['cal']??'');$pr=$r?json_decode($r[0][2],true):[];
                if(!$r||!isset($pr[$cal])){echo json_encode(['status'=>'error','message'=>'Anchor not found.']);exit;}
                echo json_encode(['status'=>'success','height'=>(int)$r[0][0],'text'=>$r[0][1],'ots'=>$pr[$cal]]);exit;
            }
            if($action==='ledger_doc_register'){
                $h=strtolower(trim((string)($input['sha256']??'')));
                $name=trim((string)($input['name']??'')); $project=trim((string)($input['project']??''));
                $size=(int)($input['size']??0);
                if(!preg_match('/^[0-9a-f]{64}$/',$h)){echo json_encode(['status'=>'error','message'=>'Invalid document fingerprint.']);exit;}
                if($name===''||strlen($name)>180||strlen($project)>120||$size<0){echo json_encode(['status'=>'error','message'=>'Enter a valid document title and project.']);exit;}
                $label='registered/'.($project!==''?$project.'/':'').$name;
                $ph=sha1($label); $now=time();
                $q=$pdo->prepare('SELECT path,size,ts FROM app_docs WHERE path_hash=? AND sha256=?');$q->execute([$ph,$h]);
                $existing=$q->fetchAll();
                if($existing){echo json_encode(['status'=>'success','message'=>'This exact document is already registered.','path'=>$label,'time'=>date('Y-m-d H:i',(int)$existing[0][2])]);exit;}
                $ins=$pdo->prepare('INSERT INTO app_docs (path_hash,sha256,path,size,ts) VALUES (?,?,?,?,?)');
                $ins->execute([$ph,$h,$label,$size,$now]);
                echo json_encode(['status'=>'success','message'=>'Document fingerprint registered. The file itself was not uploaded. Keep the original PDF safe.','path'=>$label,'time'=>date('Y-m-d H:i',$now)]);exit;
            }
            if($action==='ledger_doc_check'){
                $h=strtolower(trim((string)($input['sha256']??'')));
                if(!preg_match('/^[0-9a-f]{64}$/',$h)){echo json_encode(['status'=>'error','message'=>'Invalid hash.']);exit;}
                ledgerDocScan($pdo,true);
                $q=$pdo->prepare('SELECT path,size,ts FROM app_docs WHERE sha256=? ORDER BY ts ASC LIMIT 10');$q->execute([$h]);
                $m=[];foreach($q->fetchAll() as $r)$m[]=['path'=>$r[0],'size'=>(int)$r[1],'time'=>date('Y-m-d H:i',(int)$r[2])];
                echo json_encode(['status'=>'success','matches'=>$m]);exit;
            }
        }catch(Throwable $e){error_log('ledger action '.$action.': '.$e->getMessage());echo json_encode(['status'=>'error','message'=>'Ledger error: '.$e->getMessage()]);exit;}
    }

    if($action==='ledger_verify'){
        if(($_SESSION['role']??'')!=='admin'){echo json_encode(['status'=>'error','message'=>'Admin only.']);exit;}
        $r=ledgerVerify(); $r['status']='success'; echo json_encode($r,JSON_UNESCAPED_UNICODE);exit;
    }

    /* ---------- Face recognition security actions ---------- */
    if(in_array($action,['save_face_settings','face_status','face_verify','face_identify','face_enroll','face_remove','face_admin_data','face_snap','face_clear_log'],true)){
        if(isDemo()){echo json_encode(['status'=>'error','message'=>'Face recognition is not available in the demo account.']);exit;}
        $fcfg=faceCfg($db);
        $faceEmp=function($id) use($db){foreach(($db['employees']??[]) as $e){if((string)($e['id']??'')===(string)$id)return $e;}return null;};

        if($action==='save_face_settings'){
            requireRole('admin');
            $in=is_array($input['settings']??null)?$input['settings']:[];
            $db['face_ai']=[
                'enabled'=>!empty($in['enabled']),'require_emp'=>!empty($in['require_emp']),'require_guard'=>!empty($in['require_guard']),
                'liveness'=>!empty($in['liveness']),'guard_identify'=>!empty($in['guard_identify']),'allow_unenrolled'=>!empty($in['allow_unenrolled']),'snapshots'=>!empty($in['snapshots']),
                'threshold'=>max(0.35,min(0.65,(float)($in['threshold']??0.5)))
            ];
            saveOrFail($db);
            faceLogAdd(['result'=>$db['face_ai']['enabled']?'feature_on':'feature_off','by'=>(string)($_SESSION['user']??''),'role'=>'admin']);
            echo json_encode(['status'=>'success','settings'=>faceCfg($db),'message'=>$db['face_ai']['enabled']?'Face recognition is ON.':'Face recognition is OFF.']);exit;
        }

        if($action==='face_status'){
            requireRole(['admin','emp','security','contractor']);
            $empId=trim((string)($input['emp_id']??''));
            if($empId===''||!$faceEmp($empId)){echo json_encode(['status'=>'error','message'=>'Unknown employee.']);exit;}
            authorizeAttendanceAction($empId.'-0-0');
            $t=faceTemplates();
            echo json_encode(['status'=>'success','required'=>faceRequired($db),'enrolled'=>!empty($t[$empId]['descriptors']),'allow_unenrolled'=>$fcfg['allow_unenrolled'],'liveness'=>$fcfg['liveness'],'snapshots'=>$fcfg['snapshots']]);exit;
        }

        if($action==='face_identify'){
            /* Guard portal: who is this face? 1-to-many match against all enrolled employees. */
            requireRole(['security','admin']);
            if(!$fcfg['enabled']||!$fcfg['guard_identify']){echo json_encode(['status'=>'error','message'=>'Face scan is turned off by Admin.']);exit;}
            if(($w=rlBlocked('face','identify'))>0)rlDeny($w);
            $snap=(string)($input['snap']??'');
            if($snap!==''&&(!$fcfg['snapshots']||strpos($snap,'data:image/jpeg;base64,')!==0||strlen($snap)>24000))$snap='';
            $who=['role'=>(string)($_SESSION['role']??''),'by'=>(string)($_SESSION['user']??''),'site'=>(string)($_SESSION['site']??''),'purpose'=>'identify'];
            if(empty($input['live'])&&$fcfg['liveness']){rlFail('face','identify');faceLogAdd($who+['result'=>'liveness_fail','score'=>null],$snap);echo json_encode(['status'=>'error','message'=>'Liveness check failed. Please blink or turn your head when asked.']);exit;}
            $probe=$input['descriptor']??null;
            if(!faceDescOk($probe)){echo json_encode(['status'=>'error','message'=>'No clear face captured. Please try again.']);exit;}
            $best=9.0;$second=9.0;$bid=null;
            foreach(faceTemplates() as $id=>$tpl){
                $e=$faceEmp($id);if(!$e||!empty($e['terminated'])||empty($tpl['descriptors']))continue;
                $d=faceBest($tpl['descriptors'],$probe);
                if($d<$best){$second=$best;$best=$d;$bid=(string)$id;}elseif($d<$second){$second=$d;}
            }
            if($bid===null||$best>$fcfg['threshold']||($second-$best)<0.04){
                rlFail('face','identify');faceLogAdd($who+['result'=>'no_match','score'=>$bid===null?null:round($best,3)],$snap);
                echo json_encode(['status'=>'error','message'=>'Face not recognised. Try again, or enter the Employee ID.']);exit;
            }
            $emp=$faceEmp($bid);
            $_SESSION['face_ok']=is_array($_SESSION['face_ok']??null)?$_SESSION['face_ok']:[];
            $_SESSION['face_ok'][$bid]=time()+120;
            rlClear('face','identify');
            faceLogAdd($who+['emp_id'=>$bid,'emp_name'=>(string)($emp['name']??''),'result'=>'match','score'=>round($best,3)],$snap);
            echo json_encode(['status'=>'success','match'=>true,'emp_id'=>$bid,'name'=>(string)($emp['name']??''),'message'=>'Face recognised.']);exit;
        }

        if($action==='face_verify'){
            requireRole(['admin','emp','security','contractor']);
            $empId=trim((string)($input['emp_id']??''));
            $emp=$faceEmp($empId);
            if(!$emp){echo json_encode(['status'=>'error','message'=>'Unknown employee.']);exit;}
            authorizeAttendanceAction($empId.'-0-0');
            if(!$fcfg['enabled']){echo json_encode(['status'=>'success','match'=>true,'message'=>'Face recognition is off.']);exit;}
            if(($w=rlBlocked('face',$empId))>0)rlDeny($w);
            $snap=(string)($input['snap']??'');
            if($snap!==''&&(!$fcfg['snapshots']||strpos($snap,'data:image/jpeg;base64,')!==0||strlen($snap)>24000))$snap='';
            $who=['emp_id'=>$empId,'emp_name'=>(string)($emp['name']??''),'role'=>(string)($_SESSION['role']??''),'by'=>(string)($_SESSION['user']??''),'site'=>(string)($_SESSION['site']??''),'purpose'=>substr((string)($input['purpose']??''),0,12)];
            if(empty($input['live'])&&$fcfg['liveness']){
                rlFail('face',$empId);faceLogAdd($who+['result'=>'liveness_fail','score'=>null],$snap);
                echo json_encode(['status'=>'error','message'=>'Liveness check failed. Please blink or turn your head when asked.']);exit;
            }
            $probe=$input['descriptor']??null;
            if(!faceDescOk($probe)){echo json_encode(['status'=>'error','message'=>'No clear face captured. Please try again.']);exit;}
            $t=faceTemplates();
            if(empty($t[$empId]['descriptors'])){
                faceLogAdd($who+['result'=>'not_enrolled','score'=>null],$snap);
                if($fcfg['allow_unenrolled']){echo json_encode(['status'=>'success','match'=>true,'bypass'=>true,'message'=>'Face not enrolled - allowed.']);exit;}
                echo json_encode(['status'=>'error','message'=>'Your face is not enrolled yet. Please ask Admin to enrol it.']);exit;
            }
            $best=faceBest($t[$empId]['descriptors'],$probe);
            if($best<=$fcfg['threshold']){
                $_SESSION['face_ok']=is_array($_SESSION['face_ok']??null)?$_SESSION['face_ok']:[];
                $_SESSION['face_ok'][$empId]=time()+120;
                rlClear('face',$empId);
                faceLogAdd($who+['result'=>'match','score'=>round($best,3)],$snap);
                echo json_encode(['status'=>'success','match'=>true,'message'=>'Face verified.']);exit;
            }
            rlFail('face',$empId);
            faceLogAdd($who+['result'=>'no_match','score'=>round($best,3)],$snap);
            echo json_encode(['status'=>'error','message'=>'Face did not match this employee.']);exit;
        }

        requireRole('admin'); /* everything below is admin only */

        if($action==='face_enroll'){
            $empId=trim((string)($input['emp_id']??''));$emp=$faceEmp($empId);
            $descs=$input['descriptors']??null;
            if(!$emp){echo json_encode(['status'=>'error','message'=>'Unknown employee.']);exit;}
            if(!is_array($descs)||count($descs)<3||count($descs)>10){echo json_encode(['status'=>'error','message'=>'Capture at least 3 face samples.']);exit;}
            $clean=[];foreach($descs as $d){if(!faceDescOk($d)){echo json_encode(['status'=>'error','message'=>'Invalid face sample.']);exit;}$clean[]=array_map(function($x){return round((float)$x,5);},$d);}
            foreach(faceTemplates() as $oid=>$tpl){
                if((string)$oid===$empId||empty($tpl['descriptors']))continue;
                $dist=faceBest($tpl['descriptors'],$clean[0]);
                if($dist<0.4){$o=$faceEmp($oid);echo json_encode(['status'=>'error','message'=>'This face is already enrolled for '.($o['name']??$oid).'. One person cannot be enrolled under two IDs.']);exit;}
            }
            $r=dataStoreTx('face_data',function(&$a) use($empId,$clean){
                $t=is_array($a['templates']??null)?$a['templates']:[];
                $t[$empId]=['descriptors'=>$clean,'enrolled_at'=>date('Y-m-d H:i:s'),'by'=>(string)($_SESSION['user']??'')];
                $a['templates']=$t;return true;
            });
            if($r===null){echo json_encode(['status'=>'error','message'=>'Could not save the face data. Check the MySQL connection.']);exit;}
            faceLogAdd(['emp_id'=>$empId,'emp_name'=>(string)($emp['name']??''),'role'=>'admin','by'=>(string)($_SESSION['user']??''),'result'=>'enrolled']);
            echo json_encode(['status'=>'success','message'=>'Face enrolled for '.($emp['name']??$empId).'.']);exit;
        }

        if($action==='face_remove'){
            $empId=trim((string)($input['emp_id']??''));$emp=$faceEmp($empId);
            $r=dataStoreTx('face_data',function(&$a) use($empId){$t=is_array($a['templates']??null)?$a['templates']:[];unset($t[$empId]);$a['templates']=$t;return true;});
            if($r===null){echo json_encode(['status'=>'error','message'=>'Could not update the face data.']);exit;}
            faceLogAdd(['emp_id'=>$empId,'emp_name'=>(string)($emp['name']??''),'role'=>'admin','by'=>(string)($_SESSION['user']??''),'result'=>'removed']);
            echo json_encode(['status'=>'success','message'=>'Face data removed.']);exit;
        }

        if($action==='face_admin_data'){
            $s=dataGet('face_data');$s=is_array($s)?$s:[];
            $en=[];foreach((is_array($s['templates']??null)?$s['templates']:[]) as $id=>$t){if(!empty($t['descriptors']))$en[(string)$id]=['at'=>$t['enrolled_at']??'','n'=>count($t['descriptors'])];}
            $log=is_array($s['log']??null)?$s['log']:[];
            echo json_encode(['status'=>'success','enrolled'=>(object)$en,'log'=>array_reverse(array_slice($log,-200))]);exit;
        }

        if($action==='face_snap'){
            $id=preg_replace('/[^a-f0-9]/','',(string)($input['id']??''));
            $s=dataGet('face_data');$img=is_array($s)?($s['snap_'.$id]??''):'';
            echo json_encode(['status'=>$img!==''?'success':'error','img'=>$img,'message'=>'Snapshot not found.']);exit;
        }

        if($action==='face_clear_log'){
            $r=dataStoreTx('face_data',function(&$a){foreach(array_keys($a) as $k){if($k==='log'||strpos((string)$k,'snap_')===0)unset($a[$k]);}return true;});
            echo json_encode(['status'=>$r===null?'error':'success','message'=>$r===null?'Could not clear the log.':'Scan log cleared.']);exit;
        }
    }

    if($action==='record_punch'){
        $key=trim($input['key']??'');$day=(int)($input['day']??0);$type=$input['type']??'';$time=trim($input['time']??'');$site=trim($input['site']??'');$ts=(int)($input['ts']??0);
        if(!$key||$day<1||$day>31||!in_array($type,['IN','OUT'],true)||!$time){echo json_encode(['status'=>'error','message'=>'Invalid punch data.']);exit;}
        authorizeAttendanceAction($key);
        if(isPayrollLocked($db,$key)){echo json_encode(['status'=>'error','message'=>'This payroll period is locked. Ask Admin to unlock it first.']);exit;}
        if(isTerminatedAttendanceLocked($db,$key)){echo json_encode(['status'=>'error','message'=>terminatedLockMsg()]);exit;}
        $__fg=faceGate($db,employeeIdFromAttendanceKey($key));
        if($__fg!==null){echo json_encode(['status'=>'error','message'=>$__fg,'face_required'=>true]);exit;}
        if(!isset($db['punches'][$key]))$db['punches'][$key]=[];
        if(!isset($db['punches'][$key][$day]))$db['punches'][$key][$day]=[];
        $db['punches'][$key][$day][]=['time'=>$time,'type'=>$type,'site'=>$site,'ts'=>$ts];
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Punch recorded.']);exit;
    }

    if($action==='set_attendance_status'){
        $key=trim($input['key']??'');$day=(int)($input['day']??0);$status=$input['status']??'';
        if(!$key||$day<1||$day>31||!in_array($status,['P','H'],true)){echo json_encode(['status'=>'error','message'=>'Invalid attendance data.']);exit;}
        authorizeAttendanceAction($key);
        if(isPayrollLocked($db,$key)){echo json_encode(['status'=>'error','message'=>'This payroll period is locked. Ask Admin to unlock it first.']);exit;}
        if(isTerminatedAttendanceLocked($db,$key)){echo json_encode(['status'=>'error','message'=>terminatedLockMsg()]);exit;}
        if(faceRequired($db)&&empty($db['punches'][$key][$day])){echo json_encode(['status'=>'error','message'=>'Face recognition is on: attendance can only be set after a verified punch.']);exit;}
        if(!isset($db['attendance'][$key]))$db['attendance'][$key]=[];
        $db['attendance'][$key][$day]=$status;saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Attendance updated.']);exit;
    }

    if($action==='submit_request'){
        $date=trim($input['date']??'');$requestType=strtoupper(trim($input['request_type']??''));$punchTime=trim($input['punch_time']??'');$attendanceStatus=strtoupper(trim($input['attendance_status']??''));$reason=trim($input['reason']??'');
        $isAttendanceRequest=($requestType==='ATTENDANCE');
        if(!$date||!$reason||($isAttendanceRequest ? !in_array($attendanceStatus,['P','H','OD'],true) : (!in_array($requestType,['IN','OUT'],true)||!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/',$punchTime)))){
            echo json_encode(['status'=>'error','message'=>$isAttendanceRequest?'Please select Present, Half Day, or OD and enter a reason.':'Please select In/Out time and enter a valid punch time.']);exit;
        }
        $today=new DateTime('today');
        $picked=DateTime::createFromFormat('!Y-m-d',$date);
        if(!$picked){echo json_encode(['status'=>'error','message'=>'Invalid date.']);exit;}
        $diffDays=(int)$today->diff($picked)->format('%r%a');
        if($diffDays>0||$diffDays<-5){echo json_encode(['status'=>'error','message'=>'Forgot punch can only be applied for a date within the last 5 days.']);exit;}
        $role=$_SESSION['role']??'';
        $emp_id=(string)($input['emp_id']??'');$emp_name=(string)($input['emp_name']??'');
        if($role==='emp'){
            if(($_SESSION['employee_id']??'')!==$emp_id){echo json_encode(['status'=>'error','message'=>'You can only apply for your own attendance.']);exit;}
        }elseif($role!=='admin'){
            http_response_code(403);echo json_encode(['status'=>'error','message'=>'Access denied.']);exit;
        }
        foreach(($db['employees']??[]) as $__te){if((string)($__te['id']??'')===$emp_id&&!empty($__te['terminated'])){echo json_encode(['status'=>'error','message'=>terminatedLockMsg()]);exit;}}
        // Maximum 5 forgotten-punch applications per employee per submission month.
        $submissionMonth=date('Y-m');$monthlyCount=0;
        foreach(array_merge($db['requests']??[],$db['request_history']??[]) as $r){
            if((string)($r['emp_id']??'')===$emp_id && substr((string)($r['submitted']??''),0,7)===$submissionMonth){$monthlyCount++;}
        }
        if($monthlyCount>=5){echo json_encode(['status'=>'error','message'=>'Monthly limit reached. You can apply for a maximum of 5 forgotten In/Out punches per month.']);exit;}
        // Avoid duplicate pending requests for the same employee/date/type.
        foreach(($db['requests']??[]) as $r){
            if((string)($r['emp_id']??'')===$emp_id && ($r['date']??'')===$date && (strtoupper((string)($r['request_type']??''))===$requestType || ($isAttendanceRequest && strtoupper((string)($r['request_type']??''))==='ATTENDANCE'))){echo json_encode(['status'=>'error','message'=>'A pending request already exists for this date and punch type.']);exit;}
        }
        $req_id=uniqid('REQ_',true);
        $db['requests'][]=[
            'id'=>$req_id,'emp_id'=>$emp_id,'emp_name'=>$emp_name,'date'=>$date,
            'request_type'=>$requestType,'punch_time'=>$punchTime,'attendance_status'=>$attendanceStatus,'reason'=>$reason,
            'submitted'=>date('Y-m-d H:i:s')
        ];
        if($role==='emp'){$__r=['emp_id'=>$emp_id,'date'=>$date,'request_type'=>$requestType,'punch_time'=>$punchTime,'attendance_status'=>$attendanceStatus];
            pushQueue(['role'=>'admin'],$isAttendanceRequest?'Missed attendance request':'Forgot punch request',pushTrim(($emp_name!==''?$emp_name:$emp_id).' ('.$emp_id.'): '.pushReqText($__r).'. '.$reason,200),['type'=>'req_new','tab'=>'approvals']);}
        saveOrFail($db);echo json_encode(['status'=>'success','message'=>$isAttendanceRequest?'Missed attendance request submitted for approval.':'Forgot punch request submitted for approval.','id'=>$req_id,'monthly_used'=>$monthlyCount+1,'monthly_remaining'=>4-$monthlyCount]);exit;
    }

    if($action==='process_request'){
        requireRole('admin');
        $req_id=$input['req_id']??'';$approve=!empty($input['approve']);
        $rejectReason=pushTrim($input['reason']??'',300);
        if(!$approve&&$rejectReason===''){echo json_encode(['status'=>'error','message'=>'Please enter a reason for rejecting this request.']);exit;}
        foreach($db['requests'] as $index=>$request){
            if(($request['id']??'')===$req_id){
                if($approve){
                    $date=new DateTime($request['date']);
                    $key=$request['emp_id'].'-'.((int)$date->format('m')-1).'-'.$date->format('Y');
                    $day=(int)$date->format('d');
                    if(isPayrollLocked($db,$key)){echo json_encode(['status'=>'error','message'=>'This payroll period is locked. Unlock it before approving this request.']);exit;}
                    if(isTerminatedAttendanceLocked($db,$key)){echo json_encode(['status'=>'error','message'=>terminatedLockMsg()]);exit;}
                    $punchType=strtoupper((string)($request['request_type']??''));$punchTime=(string)($request['punch_time']??'');$attendanceStatus=strtoupper((string)($request['attendance_status']??''));
                    if($punchType==='ATTENDANCE' && in_array($attendanceStatus,['P','H','OD'],true)){
                        if(!isset($db['attendance'][$key]))$db['attendance'][$key]=[];
                        $db['attendance'][$key][$day]=$attendanceStatus;
                    } elseif(in_array($punchType,['IN','OUT'],true) && preg_match('/^([01]\d|2[0-3]):[0-5]\d$/',$punchTime)){
                        $punchDateTime=new DateTime($request['date'].' '.$punchTime.':00');
                        if(!isset($db['punches'][$key]))$db['punches'][$key]=[];
                        if(!isset($db['punches'][$key][$day]))$db['punches'][$key][$day]=[];
                        $db['punches'][$key][$day][]=['time'=>$punchTime,'type'=>$punchType,'site'=>'Forgot Punch (Approved)','ts'=>$punchDateTime->getTimestamp()*1000];
                        // If an approved correction completes an IN/OUT pair, calculate attendance automatically.
                        $punches=$db['punches'][$key][$day];$totalMs=0;$firstInTs=null;$lastOutTs=null;
                        usort($punches,function($a,$b){return (int)($a['ts']??0)<=> (int)($b['ts']??0);});
                        /* Worked time = first IN to last OUT of the day (same rule as the portal screens). */
                        foreach($punches as $pp){$t=(int)($pp['ts']??0);if($t<=0)continue;if(($pp['type']??'')==='IN'&&$firstInTs===null)$firstInTs=$t;elseif(($pp['type']??'')==='OUT'&&$firstInTs!==null&&$t>$firstInTs)$lastOutTs=$t;}
                        if($firstInTs!==null&&$lastOutTs!==null)$totalMs=$lastOutTs-$firstInTs;
                        if($totalMs>0){if(!isset($db['attendance'][$key]))$db['attendance'][$key]=[];$db['attendance'][$key]=$db['attendance'][$key]??[];$db['attendance'][$key][$day]=($totalMs/3600000)>4?'P':'H';}
                    }
                }
                $request['result']=$approve?'approved':'rejected';
                $request['processed']=date('Y-m-d H:i:s');
                if(!$approve)$request['reject_reason']=$rejectReason;
                pushQueue(['emp'=>[(string)($request['emp_id']??'')]],$approve?'Request approved ✅':'Request rejected ❌',pushTrim(pushReqText($request).($approve?'':'. Reason: '.$rejectReason),220),['type'=>'req_result','tab'=>'myreq']);
                if(!isset($db['request_history']))$db['request_history']=[];
                $db['request_history'][]=$request;
                if(count($db['request_history'])>300)$db['request_history']=array_slice($db['request_history'],-300);
                array_splice($db['requests'],$index,1);saveOrFail($db);
                echo json_encode(['status'=>'success','message'=>$approve?($punchType==='ATTENDANCE'?'Missed attendance approved and recorded.':'Forgot punch approved and recorded.'):'Request rejected.']);exit;
            }
        }
        echo json_encode(['status'=>'error','message'=>'Request not found.']);exit;
    }

    if($action==='add_measurement'){
        requireRole(['emp']);
        $employeeId=(string)($_SESSION['employee_id']??'');
        $emp=null;foreach(($db['employees']??[]) as $e){if((string)($e['id']??'')===$employeeId){$emp=$e;break;}}
        $project=trim((string)($emp['project']??''));
        if(!$emp||$project===''){echo json_encode(['status'=>'error','message'=>'No project is assigned to your account.']);exit;}
        $date=trim((string)($input['date']??''));
        if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)){echo json_encode(['status'=>'error','message'=>'Select a valid date.']);exit;}
        $sheet=mb_substr(trim((string)($input['sheet']??'')),0,100);
        $desc=mb_substr(trim((string)($input['description']??'')),0,200);
        $remarks=mb_substr(trim((string)($input['remarks']??'')),0,200);
        $unit=(string)($input['unit']??'');
        if($sheet===''){echo json_encode(['status'=>'error','message'=>'Enter the sheet / work item name.']);exit;}
        if($desc===''){echo json_encode(['status'=>'error','message'=>'Enter a description.']);exit;}
        if(!in_array($unit,['Cum','Sqm','Rmt','Nos','Kg','MT','Ltr','LS'],true)){echo json_encode(['status'=>'error','message'=>'Select a valid unit.']);exit;}
        $dims=[];$vals=[];
        foreach(['nos','length','breadth','depth'] as $f){
            $v=trim((string)($input[$f]??''));
            if($v===''){$vals[$f]=null;continue;}
            if(!is_numeric($v)||(float)$v<0||(float)$v>1000000){echo json_encode(['status'=>'error','message'=>'Measurements must be numbers between 0 and 1,000,000.']);exit;}
            $vals[$f]=(float)$v;$dims[]=(float)$v;
        }
        if(!$dims){echo json_encode(['status'=>'error','message'=>'Enter at least one measurement (Nos, Length, Breadth or Depth).']);exit;}
        $qty=1.0;foreach($dims as $v)$qty*=$v;$qty=round($qty,3);
        if($qty<=0){echo json_encode(['status'=>'error','message'=>'Quantity must be greater than 0.']);exit;}
        $deduct=!empty($input['deduct']);
        if($deduct)$qty=-$qty;
        if(!isset($db['measurements'])||!is_array($db['measurements']))$db['measurements']=[];
        $record=['id'=>uniqid('ms_',true),'date'=>$date,'project'=>$project,'sheet'=>$sheet,'description'=>$desc,
            'nos'=>$vals['nos'],'length'=>$vals['length'],'breadth'=>$vals['breadth'],'depth'=>$vals['depth'],
            'unit'=>$unit,'qty'=>$qty,'deduct'=>$deduct,'remarks'=>$remarks,
            'employee_id'=>$employeeId,'employee_name'=>(string)($emp['name']??''),'created'=>date('Y-m-d H:i:s')];
        $db['measurements'][]=$record;
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Measurement added.','record'=>$record]);exit;
    }

    if($action==='update_measurement'){
        requireRole(['admin','emp']);
        $id=trim((string)($input['id']??''));
        $idx=null;foreach(($db['measurements']??[]) as $i=>$m){if(($m['id']??'')===$id){$idx=$i;break;}}
        if($idx===null){echo json_encode(['status'=>'error','message'=>'Measurement not found.']);exit;}
        $old=$db['measurements'][$idx];
        if(($_SESSION['role']??'')==='emp'&&(string)($old['employee_id']??'')!==(string)($_SESSION['employee_id']??'')){
            echo json_encode(['status'=>'error','message'=>'You can only edit your own measurements.']);exit;
        }
        $date=trim((string)($input['date']??''));
        if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)){echo json_encode(['status'=>'error','message'=>'Select a valid date.']);exit;}
        $sheet=mb_substr(trim((string)($input['sheet']??'')),0,100);
        $desc=mb_substr(trim((string)($input['description']??'')),0,200);
        $remarks=mb_substr(trim((string)($input['remarks']??'')),0,200);
        $unit=(string)($input['unit']??'');
        if($sheet===''){echo json_encode(['status'=>'error','message'=>'Enter the sheet / work item name.']);exit;}
        if($desc===''){echo json_encode(['status'=>'error','message'=>'Enter a description.']);exit;}
        if(!in_array($unit,['Cum','Sqm','Rmt','Nos','Kg','MT','Ltr','LS'],true)){echo json_encode(['status'=>'error','message'=>'Select a valid unit.']);exit;}
        $dims=[];$vals=[];
        foreach(['nos','length','breadth','depth'] as $f){
            $v=trim((string)($input[$f]??''));
            if($v===''){$vals[$f]=null;continue;}
            if(!is_numeric($v)||(float)$v<0||(float)$v>1000000){echo json_encode(['status'=>'error','message'=>'Measurements must be numbers between 0 and 1,000,000.']);exit;}
            $vals[$f]=(float)$v;$dims[]=(float)$v;
        }
        if(!$dims){echo json_encode(['status'=>'error','message'=>'Enter at least one measurement (Nos, Length, Breadth or Depth).']);exit;}
        $qty=1.0;foreach($dims as $v)$qty*=$v;$qty=round($qty,3);
        if($qty<=0){echo json_encode(['status'=>'error','message'=>'Quantity must be greater than 0.']);exit;}
        $deduct=!empty($input['deduct']);
        if($deduct)$qty=-$qty;
        $rec=$old;
        $rec['date']=$date;$rec['sheet']=$sheet;$rec['description']=$desc;$rec['remarks']=$remarks;$rec['unit']=$unit;
        $rec['nos']=$vals['nos'];$rec['length']=$vals['length'];$rec['breadth']=$vals['breadth'];$rec['depth']=$vals['depth'];
        $rec['qty']=$qty;$rec['deduct']=$deduct;
        $rec['updated']=date('Y-m-d H:i:s');$rec['updated_by']=(string)($_SESSION['user']??'');
        $db['measurements'][$idx]=$rec;
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Measurement updated.','record'=>$rec]);exit;
    }

    if($action==='delete_measurement'){
        requireRole(['admin','emp']);
        $id=trim((string)($input['id']??''));
        $found=null;foreach(($db['measurements']??[]) as $m){if(($m['id']??'')===$id){$found=$m;break;}}
        if(!$found){echo json_encode(['status'=>'error','message'=>'Measurement not found.']);exit;}
        if(($_SESSION['role']??'')==='emp'&&(string)($found['employee_id']??'')!==(string)($_SESSION['employee_id']??'')){
            echo json_encode(['status'=>'error','message'=>'You can only delete your own measurements.']);exit;
        }
        $db['measurements']=array_values(array_filter($db['measurements'],function($m)use($id){return ($m['id']??'')!==$id;}));
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>'Measurement deleted.']);exit;
    }

    if($action==='submit_leave_request'){
        $role=$_SESSION['role']??'';
        if(!in_array($role,['emp','admin'],true)){http_response_code(403);echo json_encode(['status'=>'error','message'=>'Access denied.']);exit;}
        $leaveType=strtoupper(trim($input['leave_type']??''));
        if(!in_array($leaveType,['CL','SL','LOP','OD'],true)){echo json_encode(['status'=>'error','message'=>'Please select a valid leave type.']);exit;}
        $dateFrom=trim($input['date_from']??'');$dateTo=trim($input['date_to']??'');$reason=trim($input['reason']??'');
        $from=DateTime::createFromFormat('!Y-m-d',$dateFrom);$to=DateTime::createFromFormat('!Y-m-d',$dateTo);
        if(!$from||!$to||$reason===''){echo json_encode(['status'=>'error','message'=>'Please select valid dates and enter a reason.']);exit;}
        if($to<$from){echo json_encode(['status'=>'error','message'=>'End date cannot be before start date.']);exit;}
        $span=(int)$from->diff($to)->format('%a')+1;
        if($span>30){echo json_encode(['status'=>'error','message'=>'Leave requests can span a maximum of 30 days.']);exit;}
        $empId=(string)($input['emp_id']??'');$empName=(string)($input['emp_name']??'');
        if($role==='emp' && ($_SESSION['employee_id']??'')!==$empId){echo json_encode(['status'=>'error','message'=>'You can only apply for your own leave.']);exit;}
        $quotaError=checkLeaveQuota($db,$empId,$leaveType,$from,$to);
        if($quotaError){echo json_encode(['status'=>'error','message'=>$quotaError]);exit;}
        foreach(($db['leave_requests']??[]) as $r){
            if((string)($r['emp_id']??'')===$empId){
                $rf=DateTime::createFromFormat('!Y-m-d',$r['date_from']??'');$rt=DateTime::createFromFormat('!Y-m-d',$r['date_to']??'');
                if($rf && $rt && $from<=$rt && $to>=$rf){echo json_encode(['status'=>'error','message'=>'A pending leave request already overlaps these dates.']);exit;}
            }
        }
        $req_id=uniqid('LV_',true);
        $db['leave_requests'][]=[
            'id'=>$req_id,'emp_id'=>$empId,'emp_name'=>$empName,'leave_type'=>$leaveType,
            'date_from'=>$dateFrom,'date_to'=>$dateTo,'days'=>$span,'reason'=>$reason,
            'submitted'=>date('Y-m-d H:i:s')
        ];
        if($role==='emp'){$__t=$db['leave_requests'][count($db['leave_requests'])-1];$__who=($empName!==''?$empName:$empId).' ('.$empId.')';
            $__b=pushTrim($__who.': '.pushLeaveText($__t).' ('.$span.' day'.($span>1?'s':'').'). '.$reason,200);
            pushQueue(['role'=>'admin'],'New leave request',$__b,['type'=>'leave_new','tab'=>'approvals']);
            $__mg=pushManagersOf($db,$empId); if($__mg)pushQueue(['emp'=>$__mg],'New leave request',$__b,['type'=>'leave_new','tab'=>'approvals']);}
        saveOrFail($db);echo json_encode(['status'=>'success','message'=>'Leave request submitted for approval.','id'=>$req_id]);exit;
    }

    if($action==='process_leave_request'){
        $role=$_SESSION['role']??'';
        $req_id=$input['req_id']??'';$approve=!empty($input['approve']);
        $rejectReason=pushTrim($input['reason']??'',300);
        if(!$approve&&$rejectReason===''){echo json_encode(['status'=>'error','message'=>'Please enter a reason for rejecting this leave.']);exit;}
        $index=-1;$request=null;
        foreach(($db['leave_requests']??[]) as $i=>$r){if(($r['id']??'')===$req_id){$index=$i;$request=$r;break;}}
        if(!$request){echo json_encode(['status'=>'error','message'=>'Request not found.']);exit;}
        $targetEmpId=(string)($request['emp_id']??'');
        if($role==='admin'){
            // Admin may approve any leave request.
        }elseif($role==='emp'){
            $myId=(string)($_SESSION['employee_id']??'');
            if($myId===$targetEmpId){http_response_code(403);echo json_encode(['status'=>'error','message'=>'You cannot approve your own leave request.']);exit;}
            $me=null;$target=null;
            foreach($db['employees'] as $e){if((string)($e['id']??'')===$myId)$me=$e;if((string)($e['id']??'')===$targetEmpId)$target=$e;}
            if(!$me || empty($me['is_manager'])){http_response_code(403);echo json_encode(['status'=>'error','message'=>'You are not authorised to approve leave requests.']);exit;}
            $myProject=strtolower(trim((string)($me['project']??'')));$targetProject=strtolower(trim((string)($target['project']??'')));
            if(!$target || $myProject==='' || $myProject!==$targetProject){http_response_code(403);echo json_encode(['status'=>'error','message'=>'You can approve leave only for employees on your project.']);exit;}
        }else{
            http_response_code(403);echo json_encode(['status'=>'error','message'=>'Access denied.']);exit;
        }
        if($approve){
            $from=DateTime::createFromFormat('!Y-m-d',$request['date_from']??'');
            $to=DateTime::createFromFormat('!Y-m-d',$request['date_to']??'');
            if(!$from||!$to){echo json_encode(['status'=>'error','message'=>'Invalid leave dates on request.']);exit;}
            $leaveType=strtoupper((string)($request['leave_type']??''));
            $quotaError=checkLeaveQuota($db,$targetEmpId,$leaveType,$from,$to,$req_id);
            if($quotaError){echo json_encode(['status'=>'error','message'=>'Cannot approve: '.$quotaError]);exit;}
            // Pre-check every day's payroll lock status before writing anything, so
            // a mid-range locked period doesn't leave the leave half-applied.
            $cursor=clone $from;$days=[];
            while($cursor<=$to){
                $key=$targetEmpId.'-'.((int)$cursor->format('m')-1).'-'.$cursor->format('Y');
                if(isPayrollLocked($db,$key)){echo json_encode(['status'=>'error','message'=>'Payroll period for '.$cursor->format('M Y').' is locked. Unlock it before approving this leave.']);exit;}
                if(isTerminatedAttendanceLocked($db,$key)){echo json_encode(['status'=>'error','message'=>terminatedLockMsg()]);exit;}
                $days[]=['key'=>$key,'day'=>(int)$cursor->format('d')];
                $cursor->modify('+1 day');
            }
            foreach($days as $d){
                if(!isset($db['attendance'][$d['key']]))$db['attendance'][$d['key']]=[];
                $db['attendance'][$d['key']][$d['day']]=$leaveType;
            }
        }
        $request['result']=$approve?'approved':'rejected';
        $request['processed']=date('Y-m-d H:i:s');
        $request['processed_by']=$_SESSION['user']??'';
        if(!$approve)$request['reject_reason']=$rejectReason;
        pushQueue(['emp'=>[$targetEmpId]],$approve?'Leave approved ✅':'Leave rejected ❌',pushTrim(pushLeaveText($request).($approve?'':'. Reason: '.$rejectReason),220),['type'=>'leave_result','tab'=>'myleave']);
        if(!isset($db['leave_history']))$db['leave_history']=[];
        $db['leave_history'][]=$request;
        if(count($db['leave_history'])>300)$db['leave_history']=array_slice($db['leave_history'],-300);
        array_splice($db['leave_requests'],$index,1);
        saveOrFail($db);
        echo json_encode(['status'=>'success','message'=>$approve?'Leave request approved and recorded.':'Leave request rejected.']);exit;
    }

    echo json_encode(['status'=>'error','message'=>'Unknown action.']);exit;
}
?>
<!DOCTYPE html>
<html lang="en" class="login-active">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<link rel="preconnect" href="https://res.cloudinary.com" crossorigin>
<link rel="preload" as="image" href="<?php echo htmlspecialchars(COMPANY_LOGO_FAST); ?>" fetchpriority="high">
<link rel="dns-prefetch" href="https://cdnjs.cloudflare.com">
<link rel="dns-prefetch" href="https://cdn.jsdelivr.net">
<title><?php echo htmlspecialchars($db['company']['name']); ?></title>
<style>@media print{.cashbook-report-page-number{display: block !important;position: fixed !important;bottom: 6mm !important;right: 8mm !important;font-size: 9px !important;color: #475569 !important;font-weight: 600 !important;}.cashbook-report-page-number::after{content: "Page " counter(page) !important;}}@media screen{.cashbook-report-page-number{display: none !important;}}:root{--primary:#4f46e5;--success:#059669;--danger:#e11d48;--dark:#0f172a;--muted:#64748b;--border:#e2e8f0;--shadow:0 20px 50px rgba(15,23,42,.08)}*{box-sizing:border-box;font-family:"Segoe UI",Arial,sans-serif}html{overscroll-behavior-y:none}body{margin:0;color:var(--dark);background:linear-gradient(135deg,#f8fafc,#eef2ff);overscroll-behavior-y:none}html.login-active,body.login-active{background:#eef1f6;background-repeat:no-repeat;background-size:100% 100%}.hidden{display:none!important}nav{margin:18px;padding:12px 22px;border-radius:50px;background:rgba(255,255,255,.95);box-shadow:var(--shadow);display:flex;align-items:center;justify-content:space-between;position:sticky;top:15px;z-index:1000;min-height:64px}.nav-centered-logo{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);max-width:42vw;max-height:calc(100% - 12px);object-fit:contain}@media(max-width:600px){nav{margin:10px;padding:10px 14px;min-height:58px}.nav-centered-logo{max-width:55vw;max-height:calc(100% - 10px)}}.employee-profile-wrap{position:relative;display:none;flex-shrink:0;margin-right:10px}.employee-profile-btn{width:46px;height:46px;border-radius:50%;border:2px solid #e2e8f0;background:#eef2ff;overflow:hidden;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 5px 15px rgba(15,23,42,.10)}.employee-profile-btn img{width:100%;height:100%;object-fit:cover}.employee-profile-initial{font-size:17px;font-weight:900;color:#4338ca}.employee-profile-popup{position:absolute;left:0;top:56px;width:270px;background:#fff;border:1px solid #e2e8f0;border-radius:22px;box-shadow:0 22px 55px rgba(15,23,42,.18);padding:18px;display:none;z-index:3000}.employee-profile-popup.open{display:block}.profile-photo-large{width:76px;height:76px;border-radius:50%;object-fit:cover;border:3px solid #eef2ff;display:block;margin:0 auto 12px}.profile-photo-fallback{width:76px;height:76px;border-radius:50%;background:#eef2ff;color:#4338ca;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:900;margin:0 auto 12px}.profile-name{text-align:center;font-size:17px;font-weight:900;margin:0;color:#0f172a}.profile-id{text-align:center;font-size:12px;color:#64748b;margin:4px 0 14px}.profile-info{border-top:1px solid #eef2f7;padding-top:12px}.profile-info-row{display:flex;justify-content:space-between;gap:10px;padding:8px 0;font-size:12px}.profile-info-row span:first-child{color:#64748b;font-weight:700}.profile-info-row strong{text-align:right;color:#0f172a}.profile-close{position:absolute;right:10px;top:8px;border:0;background:transparent;color:#94a3b8;cursor:pointer;font-size:16px}@media(max-width:600px){.employee-profile-popup{left:-4px;width:250px}.employee-profile-wrap{margin-right:5px}.employee-profile-btn{width:42px;height:42px}}.container{max-width:1200px;margin:35px auto;padding:0 15px}.card{background:#fff;padding:30px;margin-bottom:25px;border-radius:28px;box-shadow:var(--shadow);border:1px solid #e5e7eb}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px}.form-group{margin-bottom:18px}label{display:block;margin-bottom:7px;padding-left:7px;color:var(--muted);font-size:11px;font-weight:900;letter-spacing:.7px;text-transform:uppercase}input,select,textarea{width:100%;padding:14px 18px;border:2px solid var(--border);background:#f8fafc;border-radius:18px;font-size:15px;outline:none}input:focus,select:focus,textarea:focus{background:#fff;border-color:var(--primary);box-shadow:0 0 0 5px rgba(99,102,241,.12)}.btn{border:0;border-radius:50px;padding:12px 22px;font-weight:800;cursor:pointer;transition:.2s}.btn:hover{transform:translateY(-2px)}.btn-primary{color:#fff;background:linear-gradient(135deg,#6366f1,#4338ca)}.btn-save{color:#fff;background:linear-gradient(135deg,#10b981,#047857)}.btn-danger{color:#fff;background:linear-gradient(135deg,#f43f5e,#be123c)}.login-wrap{min-height:100vh;min-height:100dvh;width:calc(100% + 30px);margin:-35px -15px -35px;padding:0;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;background:#fff !important;overscroll-behavior:none;}.login-wrap .lw-blob,.login-wrap .lw-dots{display:none !important}.login-card{position:relative;z-index:2;width:min(520px,calc(100% - 40px));min-height:0;height:auto;display:block;overflow:hidden;border-radius:24px;background:#fff;box-shadow:0 18px 52px rgba(15,34,71,.12);text-align:left;}.login-visual{position:relative;min-width:0;height:100%;overflow:hidden;background: linear-gradient(145deg,#ff9d12 0%,#ff7628 48%,#ff5660 100%);}.login-visual-overlay{position:absolute;inset:0;z-index:2;background: radial-gradient(circle at 13% 22%,rgba(255,255,255,.34) 0 3px,transparent 4px), radial-gradient(circle at 77% 20%,rgba(255,255,255,.32) 0 4px,transparent 5px), radial-gradient(circle at 56% 42%,rgba(255,255,255,.28) 0 3px,transparent 4px), linear-gradient(180deg,transparent 35%,rgba(114,38,26,.13) 100%);pointer-events:none;}.login-visual:before{content:"";position:absolute;z-index:1;left:-5%;right:-5%;bottom:-2%;height:40%;background: radial-gradient(ellipse at 7% 100%,#ffd629 0 17%,transparent 17.5%), radial-gradient(ellipse at 31% 110%,#ffb719 0 27%,transparent 27.5%), radial-gradient(ellipse at 58% 110%,#ffd62a 0 24%,transparent 24.5%), radial-gradient(ellipse at 87% 110%,#ffae21 0 23%,transparent 23.5%);opacity:.96;}.login-city-art{position:absolute;z-index:3;left:0;right:0;bottom:0;width:100%;height:46%;pointer-events:none;}.login-curve{position:absolute;z-index:6;top:0;right:-1px;width:128px;height:100%;pointer-events:none;}.login-curve svg{display:block;width:100%;height:100%}.login-curve path{fill:#fff}.login-visual-content{position:relative;z-index:7;height:100%;box-sizing:border-box;padding:56px 80px 42px 58px;display:flex;flex-direction:column;justify-content:space-between;color:#fff;}.login-kicker{font-size:12px;font-weight:900;letter-spacing:4px;text-transform:uppercase;}.login-welcome-area{margin-top:auto;margin-bottom:auto}.login-welcome-area h1{margin:0;font-size:clamp(48px,5.8vw,80px);line-height:.9;font-weight:950;letter-spacing:-2px;text-transform:uppercase;text-shadow:0 4px 16px rgba(100,35,15,.14);}.login-welcome-line{display:block;width:76px;height:6px;margin:22px 0 18px;border-radius:999px;background:#fff;}.login-welcome-area p{margin:0;font-size:24px;line-height:1.22;font-weight:800;}.login-welcome-area small{display:block;max-width:390px;margin-top:12px;font-size:13px;line-height:1.5;opacity:.92;}.login-construction-icons{display:flex;flex-wrap:wrap;gap:9px;max-width:490px;}.login-construction-icons span{padding:9px 12px;border:1px solid rgba(255,255,255,.35);border-radius:999px;background:rgba(15,34,71,.18);backdrop-filter:blur(7px);font-size:10px;font-weight:850;text-transform:uppercase;letter-spacing:.5px;}.login-panel{position:relative;min-width:0;height:100%;box-sizing:border-box;padding:44px clamp(32px,5vw,58px) 34px;display:flex;flex-direction:column;justify-content:center;background:#fff;overflow:hidden;}.login-panel:before{content:"";position:absolute;width:230px;height:230px;right:-132px;top:-132px;border-radius:50%;background:linear-gradient(135deg,#ffbe00,#ff6a25);opacity:.17;pointer-events:none;}.login-panel:after{content:"";position:absolute;width:205px;height:205px;left:-142px;bottom:-124px;border-radius:50%;background:#ffc800;opacity:.14;pointer-events:none;}.login-panel:before,.login-panel:after{display:none !important;content:none !important;}.login-panel>*{position:relative;z-index:3}.login-logo-row{padding:0 0 28px;margin:0;text-align:left;}.login-portal-logo{width:min(280px,100%);max-width:280px;max-height:82px;height:auto;object-fit:contain;object-position:left center;display:block;}.login-logo-fallback{display:flex;align-items:center;justify-content:flex-start}.login-company-name,.login-hero,.login-hero-slim,.login-brand,.login-tagline{display:none}.login-heading{margin:0 0 7px;color:#0f2247;font-size:34px;line-height:1.1;font-weight:900;letter-spacing:-.8px;}.login-subheading{margin:0 0 28px;color:#6b7280;font-size:14px;line-height:1.5;}.login-card .form-group{text-align:left;margin-bottom:16px}.login-card label{display:none}.login-input-wrap{position:relative}.login-input-wrap .login-input-icon{position:absolute;left:16px;top:50%;transform:translateY(-50%);width:19px;height:19px;color:#64748b;pointer-events:none;}.login-card input,.login-card select{box-sizing:border-box;width:100%;height:54px;background:#fff;border:1.5px solid #dfe5ed;border-radius:13px;padding:14px 15px 14px 47px;font-size:15px;color:#172033;transition:.2s;}#p{padding-left:47px;padding-right:47px}.login-card input:focus,.login-card select:focus{outline:none;border-color:#ff7a18;box-shadow:0 0 0 4px rgba(255,122,24,.10);}.login-pw-toggle{position:absolute;right:13px;top:50%;transform:translateY(-50%);background:none;border:0;padding:4px;cursor:pointer;color:#64748b;display:flex;}.login-pw-toggle svg{width:19px;height:19px}.login-forgot-link{display:block;text-align:right;font-size:12px;font-weight:700;color:#ef5b2a;text-decoration:none;margin:-1px 2px 21px;}.login-forgot-link:hover{text-decoration:underline}.login-card .btn-primary{width:100%;min-height:54px;box-sizing:border-box;background:linear-gradient(90deg,#ff9d12,#ff7623,#f04d37);color:#fff;font-size:16px;font-weight:850;padding:14px 42px 14px 20px;border:0;border-radius:14px;box-shadow:0 12px 25px rgba(244,93,35,.24);letter-spacing:.2px;display:flex;align-items:center;justify-content:center;gap:10px;position:relative;}.login-card .btn-primary:after{content:"→";position:absolute;right:19px;font-size:21px;font-weight:800;}.login-card .btn-primary:hover{filter:brightness(1.04);transform:translateY(-1px)}.login-social-divider,.login-social-row{display:none !important}.login-footer{margin:28px 0 0;text-align:center;font-size:10px;color:#9aa3b2;font-weight:600;}@media(min-width:801px){.login-wrap{background:#fff !important;}.login-card{width:min(520px,calc(100% - 40px));background:#fff;box-shadow:0 18px 52px rgba(15,34,71,.12);}.login-visual{display:none !important;}.login-panel:before, .login-panel:after{display:none !important;content:none !important;}.login-panel{width:100%;min-height:0;background:#fff;}}@media(max-width:800px){.login-wrap{width:100%;margin:-35px 0 -35px;padding:0;min-height:100dvh;min-height:100vh;display:block;background:#fff !important;overflow-x:hidden;overflow-y:auto;}.login-card{width:min(520px,100%);max-width:520px;min-height:100dvh;height:auto;margin:0 auto;border-radius:0;display:block;overflow:hidden;box-shadow:none;background:#fff;}.login-visual{display:none}.login-panel{min-height:100dvh;height:auto;padding:38px 26px 34px;justify-content:center;overflow:hidden;background:#fff;}.login-panel:before{display:none;width:auto;height:250px;left:0;right:0;top:0;opacity:1;background: radial-gradient(circle at 88% 14%,rgba(255,255,255,.24) 0 48px,transparent 49px), radial-gradient(circle at 4% 90%,rgba(255,255,255,.14) 0 56px,transparent 57px), linear-gradient(135deg,#ffa53f 0%,#ff7433 48%,#f6444e 100%);border-radius:0 0 30px 30px;}.login-panel:after{display:none;width:auto;height:250px;left:0;right:0;top:0;bottom:auto;opacity:.5;background:repeating-linear-gradient(135deg,rgba(255,255,255,.07) 0 2px,transparent 2px 26px);border-radius:0 0 30px 30px;}.login-logo-row{position:relative;z-index:2;margin:0;padding:0 0 24px;height:auto;display:flex;align-items:center;justify-content:center;text-align:center;}.login-portal-logo{width:auto;max-width:210px;max-height:70px;margin:0 auto;object-position:center;background:transparent;padding:0;border-radius:0;box-shadow:none;}.login-logo-fallback{justify-content:center;background:transparent;border-radius:0;box-shadow:none;margin:0 auto;}.login-heading{position:relative;z-index:2;margin:28px 0 6px;font-size:27px;text-align:left;}.login-subheading{position:relative;z-index:2;margin:0 0 26px;font-size:14px;text-align:left;}.login-card .form-group{margin-bottom:16px}.login-card input{height:56px;border-radius:16px;font-size:15px;background:#f6f7fb;border:1.5px solid #eef0f6;}.login-card input:focus{background:#fff;box-shadow:0 0 0 4px rgba(255,116,51,.12);}.login-forgot-link{margin:-2px 2px 24px;font-size:12.5px}.login-card .btn-primary{height:56px;border-radius:16px;box-shadow:0 14px 28px rgba(244,80,35,.30);letter-spacing:.3px;}.login-footer{margin-top:28px}}.login-wrap.force-mobile-login{width:100%;margin:-35px 0 -35px;min-height:100dvh;display:block;background:#fff !important;overflow-x:hidden;overflow-y:auto;}.login-wrap.force-mobile-login .login-card{width:min(520px,100%);max-width:520px;min-height:100dvh;height:auto;margin:0 auto;border-radius:0;display:block;overflow:hidden;box-shadow:none;background:#fff;}.login-wrap.force-mobile-login .login-visual{display:none}.login-wrap.force-mobile-login .login-panel{min-height:100dvh;height:auto;padding:38px 26px 34px;justify-content:center;overflow:hidden;background:#fff;}.login-wrap.force-mobile-login .login-panel:before{display:none;width:auto;height:250px;left:0;right:0;top:0;opacity:1;background: radial-gradient(circle at 88% 14%,rgba(255,255,255,.24) 0 48px,transparent 49px), radial-gradient(circle at 4% 90%,rgba(255,255,255,.14) 0 56px,transparent 57px), linear-gradient(135deg,#ffa53f 0%,#ff7433 48%,#f6444e 100%);border-radius:0 0 30px 30px;}.login-wrap.force-mobile-login .login-panel:after{display:none;width:auto;height:250px;left:0;right:0;top:0;bottom:auto;opacity:.5;background:repeating-linear-gradient(135deg,rgba(255,255,255,.07) 0 2px,transparent 2px 26px);border-radius:0 0 30px 30px;}.login-wrap.force-mobile-login .login-logo-row{position:relative;z-index:2;margin:0;padding:0 0 24px;height:auto;display:flex;align-items:center;justify-content:center;text-align:center;}.login-wrap.force-mobile-login .login-portal-logo{width:auto;max-width:210px;max-height:70px;margin:0 auto;object-position:center;background:transparent;padding:0;border-radius:0;box-shadow:none;}.login-wrap.force-mobile-login .login-logo-fallback{justify-content:center;background:transparent;border-radius:0;box-shadow:none;margin:0 auto;}.login-wrap.force-mobile-login .login-heading{position:relative;z-index:2;margin:28px 0 6px;font-size:27px;text-align:left;}.login-wrap.force-mobile-login .login-subheading{position:relative;z-index:2;margin:0 0 26px;font-size:14px;text-align:left;}.login-wrap.force-mobile-login .login-card .form-group{margin-bottom:16px}.login-wrap.force-mobile-login .login-card input{height:56px;border-radius:16px;font-size:15px;background:#f6f7fb;border:1.5px solid #eef0f6;}.login-wrap.force-mobile-login .login-card input:focus{background:#fff;box-shadow:0 0 0 4px rgba(255,116,51,.12);}.login-wrap.force-mobile-login .login-forgot-link{margin:-2px 2px 24px;font-size:12.5px}.login-wrap.force-mobile-login .login-card .btn-primary{height:56px;border-radius:16px;box-shadow:0 14px 28px rgba(244,80,35,.30);letter-spacing:.3px;}.login-wrap.force-mobile-login .login-footer{margin-top:28px}@media(max-width:380px){.login-panel{padding-left:20px;padding-right:20px}.login-logo-row{padding-top:54px}.login-heading{margin-top:35px;font-size:28px}.login-portal-logo{max-width:260px}}.cal-grid{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:clamp(4px,1.5vw,10px);width:100%;box-sizing:border-box}.day{position:relative;min-height:clamp(52px,16vw,78px);aspect-ratio:auto;display:flex;align-items:center;justify-content:center;flex-direction:column;border-radius:clamp(8px,2vw,16px);border:1px solid var(--border);background:#fff;font-weight:800;cursor:pointer;font-size:clamp(10px,2.6vw,14px);padding:4px 2px;overflow:hidden;box-sizing:border-box;min-width:0}.leave-star{position:absolute;top:2px;right:4px;font-size:clamp(9px,2.2vw,12px);line-height:1;color:#d97706;text-shadow:0 0 1px rgba(0,0,0,.15)}.day span{line-height:1.1}.day small{font-size:clamp(8px,2vw,11px);line-height:1.1}.day.P{background:#ecfdf5;color:#047857}.day.A{background:#fff1f2;color:#be123c}.day.H{background:#fffbeb;color:#b45309}.day.OD{background:#eff6ff;color:#1d4ed8}.day.CL{background:#f0fdfa;color:#0f766e}.day.SL{background:#fef2f2;color:#b91c1c}.day.LOP{background:#f8fafc;color:#475569}.day.SUN{background:#f1f5f9;color:#94a3b8;cursor:default}.day.HOL{background:#fdf4ff;color:#a21caf}.day.hascount{background:#eef2ff;color:#3730a3;border-color:#c7d2fe}.ot-tag{display:block;margin-top:1px;font-size:clamp(7px,1.7vw,9px);font-weight:900;color:#7c3aed;cursor:pointer;text-decoration:underline;line-height:1.1}.punch-summary{font-size:clamp(6.5px,1.7vw,8.5px);line-height:1.25;margin-top:1px;color:#334155;text-align:center}@media (max-width:420px){.cal-grid{gap:3px}.day{border-radius:8px;min-height:50px}.card{padding:12px}}.admin-layout{display:flex;gap:12px;align-items:flex-start;width:100%;max-width:100%;box-sizing:border-box}.admin-nav{display:flex;flex-direction:column;gap:6px;flex:0 0 96px;position:sticky;top:10px;min-width:0}.cashbook-table-wrap{width:100%;max-width:100%;overflow-x:auto;overflow-y:hidden;-webkit-overflow-scrolling:touch;box-sizing:border-box}.cashbook-table{width:100%;max-width:100%;box-sizing:border-box}.cashbook-table th,.cashbook-table td{overflow-wrap:normal;word-break:normal;box-sizing:border-box}.cashbook-table td.no-print .btn{white-space:nowrap;word-break:normal;overflow-wrap:normal;writing-mode:horizontal-tb;text-orientation:mixed}.nav-tab-btn{width:100%;padding:10px 6px;border-radius:12px;border:1px solid var(--border);background:#fff;font-weight:800;font-size:10px;line-height:1.25;white-space:normal;word-break:break-word;cursor:pointer;color:#475569;text-align:center}.nav-tab-btn.active{background:#4f46e5;color:#fff;border-color:#4f46e5}.admin-content{flex:1;min-width:0;display:flex;flex-direction:column;gap:0}.admin-tab{display:none}.admin-tab.active{display:block}.admin-layout,.admin-content,.admin-nav{box-sizing:border-box;min-width:0}.admin-content{width:100%;overflow-x:hidden}.admin-content .card,.admin-content .table-wrap,.admin-content .table-responsive{max-width:100%;box-sizing:border-box}.admin-content table{max-width:100%;}@media (min-width:801px){.admin-layout{display:grid;grid-template-columns:minmax(95px,120px) minmax(0,1fr);align-items:start;gap:16px;width:100%;}.admin-nav{width:100%;position:sticky;top:10px;}.nav-tab-btn{font-size:11px;padding:8px 6px;white-space:normal;word-break:normal;overflow-wrap:anywhere;}}@media (max-width:800px){.admin-layout{display:grid;grid-template-columns:minmax(90px,25%) minmax(0,1fr);align-items:start;gap:10px;width:100%;overflow:visible;}.admin-nav{width:100%;display:flex;flex-direction:column;gap:6px;position:sticky;top:10px;z-index:30;padding:0;background:transparent;overflow:visible;}.admin-nav::-webkit-scrollbar{display:none}.nav-tab-btn{flex:0 0 auto;width:100%;min-width:0;padding:7px 5px;font-size:9px;line-height:1.2;white-space:normal;word-break:normal;overflow-wrap:anywhere;text-align:left;}.admin-content{width:100%;max-width:100%;min-width:0;overflow-x:hidden;}.admin-content .card{width:100%;max-width:100%;overflow:hidden;}.admin-content table{width:100%;}.admin-content th,.admin-content td{overflow-wrap:normal;word-break:normal;white-space:nowrap;}.admin-content .form-grid{grid-template-columns:minmax(0,1fr)!important;}.admin-content table:not(.cashbook-table){display:block;overflow-x:auto;-webkit-overflow-scrolling:touch;}.admin-content table:not(.cashbook-table) thead, .admin-content table:not(.cashbook-table) tbody{display:table;width:100%;table-layout:auto;}}@media (max-width:480px){nav{width:calc(100% - 16px);margin:8px;}.admin-layout{grid-template-columns:minmax(82px,24%) minmax(0,1fr);gap:7px;}.admin-nav{gap:5px;padding:0;}.nav-tab-btn{width:100%;padding:7px 5px;font-size:8.5px;border-radius:10px;text-align:left;}.admin-content .card{padding:12px;}}.week-row{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;padding:12px;border:1px solid var(--border);border-radius:14px;margin-bottom:8px;background:#fafafa}.week-range{font-weight:800;font-size:12px;color:#334155}.week-breakdown{font-size:11px;color:#64748b}.week-total{font-weight:900;font-size:14px;color:#fff;background:#059669;padding:6px 14px;border-radius:999px;white-space:nowrap}.payment-note{font-size:11px;color:#64748b;background:#f8fafc;border:1px solid var(--border);padding:9px 11px;border-radius:12px;margin-bottom:10px}.week-section{border:1px solid var(--border);border-radius:16px;padding:10px;margin-bottom:12px;background:#fff}.week-section-head{display:flex;justify-content:space-between;gap:8px;align-items:center;flex-wrap:wrap;padding:4px 2px 9px;color:#334155;font-size:12px}.week-section-head strong{color:#059669}.day-payment-card{border:1px solid #e2e8f0;border-radius:14px;padding:11px 12px;margin-top:8px;background:#fafafa}.day-payment-title{display:flex;justify-content:space-between;gap:8px;align-items:center;font-size:12px;color:#0f172a}.day-payment-title span{font-weight:800;color:#64748b}.day-payment-card ol{margin:7px 0 6px;padding-left:24px;font-size:12px;color:#334155}.day-payment-card li{padding:1px 0}.day-payment-ot{font-size:11px;color:#b45309;font-weight:800;margin-top:4px}.day-payment-total{text-align:right;font-weight:900;color:#059669;font-size:13px;margin-top:6px}.ps-full-page{min-height:100vh;padding:40px 15px;background:linear-gradient(135deg,#cbd5e1,#e2e8f0)}.payslip{width:210mm;min-height:297mm;margin:auto;background:#fff;padding:12mm;color:#111827;box-shadow:0 25px 70px rgba(0,0,0,.2);font-family:Arial,sans-serif}.company-brand{display:flex;flex-direction:column;align-items:center;gap:2px;width:100%;overflow:hidden;text-align:center}.brand-logo{width:100%;display:flex;align-items:center;justify-content:center;line-height:0}.brand-logo .pay-logo{display:block;width:150px!important;height:auto!important;max-width:100%;object-fit:contain}.company-text{width:100%}.company-name{margin:0;line-height:1.2}.company-address{margin-top:0;font-size:11px;line-height:1.3;max-width:170mm;margin-left:auto;margin-right:auto}.pay-title{text-align:center;margin:20px 0}.pay-title span{padding:6px 18px;background:#eef2ff;color:#3730a3;border-radius:50px;font-size: 10px !important;line-height:1.2;font-weight:900}.summary{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:18px}.summary-box{padding:10px;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc}.summary-label{font-size:8px;color:#64748b;font-weight:800;text-transform:uppercase}.summary-value{margin-top:3px;font-size:11px;font-weight:900}.details,.salary{width:100%;border-collapse:collapse;font-size:10px;margin-bottom:18px}.details td{padding:7px 8px;border:1px solid #e2e8f0}.details .label{background:#f8fafc;color:#64748b;font-weight:800}.details .value{font-weight:800}.salary th{padding:9px;color:#fff;background:#111827;text-align:left}.salary td{padding:8px;border:1px solid #dbe3ec}.amount{text-align:right;white-space:nowrap}.salary .total{background:#f1f5f9;font-weight:900}.net{margin-top:20px;padding:16px 20px;display:flex;justify-content:space-between;align-items:center;background:#eef2ff;border:1px solid #c7d2fe;border-radius:16px}.net-label{font-size:9px;font-weight:900;color:#475569;text-transform:uppercase}.net-value{margin-top:2px;font-size:24px;font-weight:950;color:#312e81}.words{margin-top:5px;font-size:9px;color:#475569}.pay-footer{margin-top:30px;display:flex;justify-content:flex-end;align-items:flex-end;gap:4px;margin-left:auto;width:fit-content}.seal{width:105px;height:32px;display:flex;justify-content:center;align-items:flex-end}.seal img{max-width:100%;max-height:100%;object-fit:contain}.signature{width:190px;text-align:center}.signature-line{height:24px;border-bottom:1px solid #111827;margin-bottom:5px}.signature strong{font-size:10px}.signature small{display:block;margin-top:3px;font-size:8px;color:#64748b}.note{margin-top:25px;padding-top:8px;border-top:1px dashed #cbd5e1;text-align:center;font-size:8px;color:#64748b}@media(max-width:800px){.admin-layout{gap:8px;overflow-x:hidden}.admin-content{min-width:0;max-width:100%;overflow-x:hidden}#stab-cashbook .cashbook-table .amount, #tab-cashbookReport .cashbook-table .amount{white-space:normal;text-align:right}}@media print{@page{size:A4 portrait;margin:18mm 10mm 16mm}html,body{width:auto;min-height:0;margin:0;padding:0;background:#fff!important}body.cashbook-report-active>*{display:none!important}body.cashbook-report-active #fullPageDisplay{display:block!important}body.cashbook-report-active #fullPageDisplay *{visibility:visible}.no-print{display:none!important}.ps-full-page{display:block!important;width:100%!important;min-height:0!important;padding:0!important;margin:0!important;background:#fff!important}.payslip{box-sizing:border-box;width:190mm;height:auto;min-height:0;margin:0 auto!important;padding:10mm;background:#fff;box-shadow:none;border:0;border-radius:0;overflow:visible}.payslip *{box-sizing:border-box}.payslip .company-brand,.payslip .pay-title,.payslip .summary,.payslip .details,.payslip .salary,.payslip .net,.payslip .pay-footer,.payslip .note{break-inside:avoid;page-break-inside:avoid}.cashbook-print-report{position:relative;width:190mm;max-width:190mm;margin:0 auto!important;padding:20mm 0 16mm!important;background:#fff!important;box-shadow:none!important;border:0!important;border-radius:0!important;color:#111827!important}.cashbook-print-header{position:fixed;top:0;left:10mm;right:10mm;height:15mm;display:flex!important;align-items:center;justify-content:space-between;gap:8mm;background:#fff;border-bottom:1px solid #cbd5e1;padding:2mm 0 2mm;z-index:9999}.cashbook-print-header .cbh-left{display:flex;align-items:center;gap:4mm;min-width:0}.cashbook-print-header img{width:30mm;max-height:11mm;object-fit:contain}.cashbook-print-header .cbh-title{font-size:12pt;font-weight:900;letter-spacing:.4px;color:#0f172a;white-space:nowrap}.cashbook-print-header .cbh-address{font-size:7.5pt;color:#475569;text-align:right;max-width:95mm;line-height:1.2}.cashbook-print-footer{position:fixed;bottom:0;left:10mm;right:10mm;height:11mm;display:flex!important;align-items:center;justify-content:space-between;gap:8mm;background:#fff;border-top:1px solid #cbd5e1;padding:2mm 0 1mm;z-index:9999;font-size:7.5pt;color:#475569}.cashbook-print-footer .cbf-title{font-weight:900;color:#3730a3}.cashbook-print-footer .cbf-address{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cashbook-print-report .salary{width:100%;table-layout:fixed;font-size:8.5pt;margin-bottom:0}.cashbook-print-report .salary th{padding:2.5mm 2mm;font-size:8pt}.cashbook-print-report .salary td{padding:2.2mm 2mm;font-size:8pt;vertical-align:top;word-break:break-word}.cashbook-print-report .salary th:nth-child(1),.cashbook-print-report .salary td:nth-child(1){width:14%}.cashbook-print-report .salary th:nth-child(2),.cashbook-print-report .salary td:nth-child(2){width:16%}.cashbook-print-report .salary th:nth-child(3),.cashbook-print-report .salary td:nth-child(3){width:24%}.cashbook-print-report .salary th:nth-child(4),.cashbook-print-report .salary td:nth-child(4){width:13%}.cashbook-print-report .salary th:nth-child(5),.cashbook-print-report .salary td:nth-child(5),.cashbook-print-report .salary th:nth-child(6),.cashbook-print-report .salary td:nth-child(6),.cashbook-print-report .salary th:nth-child(7),.cashbook-print-report .salary td:nth-child(7){width:11%}.cashbook-print-report .salary thead{display:table-header-group}.cashbook-print-report .salary tr{break-inside:avoid;page-break-inside:avoid}.cashbook-print-report .cb-report-summary{break-inside:avoid;page-break-inside:avoid}.cashbook-print-report .cb-report-title{margin:0 0 5mm;text-align:center;font-size:13pt;font-weight:900;color:#3730a3}.cashbook-print-report .cb-report-meta{font-size:8.5pt;color:#475569;margin-bottom:5mm}.cashbook-print-report .cb-report-total{font-size:8.5pt;font-weight:900;margin:0 0 5mm}}@media(max-width:800px){.card{padding:20px}.company-brand{gap:2px}.company-brand .pay-logo{width:110px!important;max-width:65vw}.pay-title span{font-size:11px!important;padding:5px 14px}.company-name{font-size:15px}.summary{grid-template-columns:repeat(2,1fr)}.payslip{width:100%;min-height:auto;padding:20px;border-radius:18px}.pay-footer{flex-direction:column;gap:0;align-items:center}.pay-footer .seal{height:28px}.pay-footer .signature-line{height:20px}}@media(max-width:800px){.company-brand{gap:2px}.company-name{font-size:15px}}.idcard-wrap{display:flex;flex-wrap:wrap;gap:24px;justify-content:center;align-items:flex-start;padding:10px 0}.idcard-wrap.exporting{flex-wrap:nowrap!important;width:max-content!important}.idcard{width:54mm;height:85.6mm;border-radius:5mm;overflow:hidden;background:#fff;box-shadow:0 20px 45px rgba(15,23,42,.18);font-family:Arial,sans-serif;display:flex;flex-direction:column;position:relative;box-sizing:border-box}.idcard:before{content:"";position:absolute;inset:0;border:1.2mm solid #f1f5f9;border-radius:5mm;z-index:20;pointer-events:none}.idcard-front{background:#fff;position:relative;overflow:hidden}.idcard-front .fd{position:absolute;box-sizing:border-box;pointer-events:none;border-top:0;border-right:0}.idcard-front .fd-a{width:22mm;height:22mm;left:-3mm;bottom:-3mm;border-left:1.8mm solid rgba(14,165,184,.35);border-bottom:1.8mm solid rgba(14,165,184,.35)}.idcard-front .fd-b{width:16mm;height:16mm;left:1mm;bottom:1mm;border-left:1.8mm solid rgba(249,115,22,.4);border-bottom:1.8mm solid rgba(249,115,22,.4)}.idcard-front .fd-c{width:10mm;height:10mm;left:5mm;bottom:5mm;border-left:1.8mm solid rgba(37,99,235,.45);border-bottom:1.8mm solid rgba(37,99,235,.45)}.idcard-head{background:transparent;color:#0f172a;padding:5mm 4mm 1mm;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1mm;text-align:center;min-height:11mm;box-sizing:border-box;position:relative;z-index:4}.idcard-head .idcard-logo{height:9mm;max-width:31mm;object-fit:contain;border-radius:1mm;padding:.4mm;flex-shrink:0;position:relative;z-index:1}.idcard-head .idcard-company-name{font-size:7.2px;font-weight:950;line-height:1.1;max-width:100%;overflow:hidden;text-overflow:ellipsis;position:relative;z-index:1;letter-spacing:.15px;color:#263b73}.idcard-type{font-size:5px;letter-spacing:1px;font-weight:900;text-transform:uppercase;color:#64748b;position:relative;z-index:1}.idcard-body{flex:1;display:flex;flex-direction:column;padding:2mm 3.5mm 1.5mm;gap:1.7mm;align-items:center;overflow:hidden;min-height:0;position:relative;z-index:3}.idcard-photo{width:21mm;height:21mm;border-radius:50%;object-fit:cover;border:1.5mm solid #fff;outline:1px solid #dbeafe;box-shadow:0 4px 14px rgba(15,23,42,.16);flex-shrink:0;background:#eef2ff;display:flex;align-items:center;justify-content:center;font-weight:900;color:#29437d;font-size:18px}.idcard-info{width:100%;min-width:0;text-align:center}.idcard-name{font-size:10.5px;font-weight:950;color:#111827;margin:0 0 .8mm;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.idcard-desig{font-size:7px;color:#0f8b99;font-weight:900;margin:0 0 2mm;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:.2px}.idcard-meta{display:grid;grid-template-columns:1fr 1fr;gap:1mm;width:100%;margin-top:1mm}.idcard-meta-box{background:transparent;border:0;border-radius:0;padding:1mm .8mm;min-width:0}.idcard-meta-label{display:block;font-size:4.5px;color:#64748b;font-weight:900;text-transform:none;letter-spacing:.2px;margin-bottom:.4mm}.idcard-meta-value{display:block;font-size:6.2px;color:#111827;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.idcard-meta-box[style*="grid-column"]{grid-column:1 / -1!important}.idcard-foot{background:transparent;color:#334155;padding:1mm 3mm 2mm;font-size:5.3px;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-height:5mm;box-sizing:border-box;position:relative;z-index:4}.idcard-front-qr{position:relative;left:auto;right:auto;bottom:auto;transform:none;margin:auto auto 1mm;flex-shrink:0;width:14mm;height:14mm;background:#fff;border-radius:1mm;padding:1mm;box-sizing:border-box;box-shadow:0 2px 8px rgba(15,23,42,.16);z-index:8}.idcard-front-qr img,.idcard-front-qr canvas{width:100%!important;height:100%!important;display:block}.idcard-back{align-items:center;justify-content:flex-start;text-align:center;padding:8mm 4mm 4mm;background:#2f4278;position:relative;overflow:hidden;color:#fff}.idcard-back .bd1-group{position:absolute;inset:0;opacity:.9;pointer-events:none}.idcard-back .bd1{position:absolute;box-sizing:border-box;border-top:0;border-left:0}.idcard-back .bd1-a{width:34mm;height:34mm;right:-5mm;bottom:-5mm;border-right:2.4mm solid rgba(249,115,22,.5);border-bottom:2.4mm solid rgba(249,115,22,.5)}.idcard-back .bd1-b{width:27mm;height:27mm;right:0mm;bottom:0mm;border-right:2.4mm solid rgba(0,168,190,.55);border-bottom:2.4mm solid rgba(0,168,190,.55)}.idcard-back .bd1-c{width:20mm;height:20mm;right:5mm;bottom:5mm;border-right:2.4mm solid rgba(249,115,22,.4);border-bottom:2.4mm solid rgba(249,115,22,.4)}.idcard-back .bd1-d{width:13mm;height:13mm;right:10mm;bottom:10mm;border-right:2.4mm solid rgba(255,255,255,.6);border-bottom:2.4mm solid rgba(255,255,255,.6)}.idcard-back .bd2-group{position:absolute;inset:0;opacity:.65;pointer-events:none}.idcard-back .bd2{position:absolute;box-sizing:border-box;border-top:0;border-right:0}.idcard-back .bd2-a{width:22mm;height:22mm;left:-4mm;bottom:-4mm;border-left:2mm solid rgba(0,168,190,.45);border-bottom:2mm solid rgba(0,168,190,.45)}.idcard-back .bd2-b{width:14mm;height:14mm;left:1mm;bottom:1mm;border-left:2mm solid rgba(249,115,22,.45);border-bottom:2mm solid rgba(249,115,22,.45)}.idcard-back .back-brand{font-size:9px;font-weight:950;color:#22b6c7;margin-bottom:1.5mm;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;position:relative;z-index:3;text-shadow:0 1px 1px rgba(0,0,0,.12)}.idcard-back .back-subtitle{font-size:5.2px;color:#fff;font-weight:800;letter-spacing:.7px;text-transform:uppercase;margin-bottom:4mm;position:relative;z-index:3}.idcard-back .qr{margin:0 auto 2mm;padding:1.5mm;background:#fff;border-radius:1.5mm;border:1px solid rgba(255,255,255,.7);box-shadow:0 5px 18px rgba(0,0,0,.18);position:relative;z-index:3}.idcard-back .qr img,.idcard-back .qr canvas{width:15mm!important;height:15mm!important;display:block}.idcard-back .qr-label{font-size:5.5px;color:#fff;font-weight:900;letter-spacing:.4px;margin-bottom:2mm;position:relative;z-index:3}.idcard-back .addr{font-size:5.8px;color:#fff;line-height:1.3;padding:0 2mm;font-weight:700;position:relative;z-index:3;max-width:45mm}.idcard-back .instructions{font-size:4.8px;color:rgba(255,255,255,.85);margin-top:2.5mm;font-weight:800;text-transform:uppercase;letter-spacing:.25px;line-height:1.25;position:relative;z-index:3}.idcard-back .sign{margin-top:2.5mm;font-size:5.7px;color:#fff;font-weight:900;position:relative;z-index:3}.idcard-back .back-strip{margin-top:auto;padding-top:2mm;border-top:1px solid rgba(255,255,255,.28);width:100%;font-size:4.8px;color:rgba(255,255,255,.78);font-weight:800;position:relative;z-index:3}@media print{.idcard-wrap{gap:6mm;justify-content:center;align-items:flex-start;padding:0}.idcard{box-shadow:none;border:1px solid #e2e8f0}}@media(max-width:800px){.idcard-wrap{gap:16px}.idcard{width:54mm;max-width:100%;height:85.6mm}}.idflip{display:flex;flex-direction:column;align-items:center;gap:14px;padding:10px 0 4px}.idflip-stage{perspective:1400px;zoom:1.5;cursor:pointer;-webkit-tap-highlight-color:transparent;outline:none;border-radius:5mm}.idflip-stage:focus-visible{box-shadow:0 0 0 3px rgba(79,70,229,.45)}.idflip .idflip-inner{position:relative;display:block;width:54mm;height:85.6mm;padding:0;gap:0;transform-style:preserve-3d;-webkit-transform-style:preserve-3d;transition:transform .75s cubic-bezier(.4,.2,.2,1)}.idflip.is-flipped .idflip-inner{transform:rotateY(180deg)}.idflip .idflip-inner .idcard{position:absolute;inset:0;backface-visibility:hidden;-webkit-backface-visibility:hidden}.idflip .idflip-inner .idcard-back{transform:rotateY(180deg)}.idflip-controls{display:flex;flex-direction:column;align-items:center;gap:6px}.idflip-hint{font-size:11px;color:#64748b;font-weight:700}.idflip.flat{align-items:flex-start}.idflip.flat .idflip-stage{perspective:none;zoom:1}.idflip.flat .idflip-inner{display:flex!important;flex-wrap:nowrap;gap:24px;width:max-content;height:auto;padding:10px;transform:none!important;transform-style:flat;transition:none}.idflip.flat .idflip-inner .idcard{position:relative!important;inset:auto;transform:none!important;backface-visibility:visible;-webkit-backface-visibility:visible}.idcard-foot b{font-size:6.4px;font-weight:950;letter-spacing:.4px;color:#263b73}@media(max-width:360px){.idflip-stage{zoom:1.3}}@media(prefers-reduced-motion:reduce){.idflip .idflip-inner{transition:none}}@media print{.idflip{display:block;padding:0}.idflip-controls{display:none!important}.idflip-stage{zoom:1;perspective:none}.idflip .idflip-inner{display:flex!important;flex-wrap:wrap;gap:6mm;width:auto;height:auto;transform:none!important;justify-content:center}.idflip .idflip-inner .idcard{position:relative!important;inset:auto;transform:none!important;backface-visibility:visible}}.ms-table{width:100%;border-collapse:collapse;font-size:12px;min-width:640px}.ms-table th{background:#111827;color:#fff;padding:7px 6px;text-align:left;white-space:nowrap;font-size:11px}.ms-table td{border:1px solid #dbe3ec;padding:6px;vertical-align:top}.ms-num{text-align:right;white-space:nowrap}.ms-group td{background:#eef2ff;color:#3730a3;font-weight:900}.ms-sub td{background:#f1f5f9;font-weight:900}.ms-grand td{background:#e0e7ff;font-weight:950}.ms-deduct td{color:#be123c}.ms-small{display:block;color:#64748b;font-size:10px;margin-top:2px}.ms-ref th{background:#fff!important;color:#9a3412!important;border:1px solid #111;text-align:center;white-space:normal;font-size:11px}.ms-ref td{border:1px solid #111}.ms-c{text-align:center}.ms-red,.ms-red strong{color:#dc2626;font-weight:800}.ms-item td{background:#f8fafc}.ms-total td{border-top:1px solid #111}.ms-projbar{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:8px 10px;border:1px solid #111;border-bottom:0;font-size:12px;color:#1e3a8a;margin-top:14px}.ms-co{text-align:center;color:#6d28d9;margin-bottom:3mm}.ms-co1{font-size:12pt;font-weight:700}.ms-co2{font-size:8.5pt}.ms-title{border:1px solid #111;border-bottom:0;text-align:center;font:700 18pt Georgia,"Times New Roman",serif;color:#8a6d0b;padding:3mm 0}.ms-meta{display:flex;justify-content:space-between;gap:6mm;border:1px solid #111;border-bottom:0;padding:2.5mm 3mm;font-size:9pt;color:#1e3a8a}.ms-page{page-break-after:always}.ms-page:last-child{page-break-after:auto}#msPrintArea{display:none}#msPrintArea .ms-table{min-width:0;font-size:9pt}#msPrintArea .ms-table:not(.ms-ref) th{background:#111827!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}.ms-sign{display:flex;justify-content:space-between;gap:10mm;margin-top:16mm;font-size:9pt}.ms-sign div{flex:1;border-top:1px solid #111;padding-top:2mm;text-align:center}@media print{body.ms-printing>*:not(#msPrintArea){display:none!important}body.ms-printing #msPrintArea{display:block!important;background:#fff;color:#111;font-family:Arial,sans-serif}body.ms-printing #msPrintArea .ms-group td,body.ms-printing #msPrintArea .ms-sub td,body.ms-printing #msPrintArea .ms-grand td{-webkit-print-color-adjust:exact;print-color-adjust:exact}}.day-view-btn{display:block;margin:1px auto 0;background:none;border:none;font-size:clamp(7px,1.7vw,9px);font-weight:900;color:#4338ca;cursor:pointer;text-decoration:underline;line-height:1.1;padding:0}.modal-overlay{position:fixed;inset:0;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;z-index:9999;padding:18px}.modal-box{background:#fff;border-radius:22px;padding:22px;width:100%;max-width:420px;max-height:85vh;overflow:auto;box-shadow:0 25px 70px rgba(0,0,0,.3)}.modal-close-btn{border:0;background:#f1f5f9;color:#334155;width:32px;height:32px;border-radius:50%;font-weight:900;cursor:pointer;font-size:14px}.punch-total-box{flex:1;padding:12px 6px;border-radius:14px;text-align:center;font-weight:900;font-size:10px;letter-spacing:.5px;text-transform:uppercase}.punch-total-box span{display:block;margin-top:3px;font-size:20px}.password-wrap{position:relative;width:100%}.password-wrap input{padding-right:48px}.password-toggle{position:absolute;right:8px;top:50%;transform:translateY(-50%);width:34px;height:34px;border:0;background:transparent;border-radius:10px;cursor:pointer;color:#64748b;font-size:17px;display:flex;align-items:center;justify-content:center}.password-toggle:hover{background:#f1f5f9;color:#334155}.password-toggle:focus{outline:2px solid rgba(79,70,229,.25);outline-offset:1px}.pa-contractor-dropdown{position:relative;width:100%}.pa-contractor-toggle{width:100%;min-height:42px;padding:10px 12px;border:1px solid var(--border);border-radius:10px;background:#fff;display:flex;align-items:center;justify-content:space-between;font:inherit;color:#0f172a;cursor:pointer;text-align:left}.pa-contractor-menu{display:none;position:absolute;z-index:50;left:0;right:0;top:calc(100% + 5px);max-height:240px;overflow:auto;background:#fff;border:1px solid var(--border);border-radius:10px;box-shadow:0 12px 30px rgba(15,23,42,.12);padding:6px}.pa-contractor-menu.open{display:block}.pa-contractor-option{display:flex;align-items:center;gap:9px;padding:9px 10px;border-radius:8px;cursor:pointer;font-size:13px}.pa-contractor-option:hover{background:#f8fafc}.pa-contractor-option input{accent-color:#2563eb}.pa-contractor-empty{padding:12px;color:#64748b;font-size:12px;text-align:center}.notify-overlay{position:fixed;inset:0;background:rgba(15,23,42,.6);display:flex;align-items:center;justify-content:center;z-index:10000;padding:18px;animation:notifyFadeIn .15s ease}.notify-box{background:#fff;border-radius:18px;padding:22px 24px;width:100%;max-width:380px;box-shadow:0 25px 70px rgba(0,0,0,.35);text-align:left}.notify-msg{font-size:14px;line-height:1.5;color:#1e293b;white-space:pre-line;font-weight:600}.notify-actions{display:flex;justify-content:flex-end;margin-top:18px}.notify-ok{border:0;background:#4f46e5;color:#fff;font-weight:800;font-size:13px;padding:9px 22px;border-radius:12px;cursor:pointer}.notify-ok:hover{background:#4338ca}@keyframes notifyFadeIn{from{opacity:0}to{opacity:1}}.bill-modal{position:fixed;inset:0;background:rgba(15,23,42,.72);display:flex;align-items:center;justify-content:center;z-index:12000;padding:16px}.bill-modal-box{width:min(96vw,450px);height:min(46vh,425px);background:#fff;border-radius:22px;box-shadow:0 30px 90px rgba(0,0,0,.4);display:flex;flex-direction:column;overflow:hidden}.bill-modal-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 18px;border-bottom:1px solid #e2e8f0;background:#fff}.bill-modal-title{font-weight:900;color:#0f172a;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.bill-modal-close{border:0;background:#f1f5f9;color:#334155;border-radius:10px;width:38px;height:38px;font-size:20px;cursor:pointer}.bill-modal-body{flex:1;min-height:0;background:#f8fafc;display:flex;align-items:center;justify-content:center;overflow:auto;padding:12px}.bill-modal-body img{max-width:100%;max-height:100%;object-fit:contain;border-radius:10px;background:#fff}.bill-modal-body iframe{width:100%;height:100%;border:0;border-radius:10px;background:#fff}.bill-view-btn{padding:5px 10px!important;white-space:nowrap!important}@media(max-width:600px){.bill-modal{padding:8px}.bill-modal-box{width:90%;height:47vh;border-radius:16px}.bill-modal-head{padding:10px 12px}}.portal-nav-icon{width:34px;height:34px;min-width:34px;display:inline-flex;align-items:center;justify-content:center;border-radius:10px;background:linear-gradient(145deg,#123d73,#0b2345);border:1px solid rgba(255,255,255,.22);box-shadow:0 5px 12px rgba(2,18,45,.22),inset 0 1px 0 rgba(255,255,255,.18);color:#fff;margin:0 auto 6px;position:relative;overflow:hidden}.portal-nav-icon:after{content:"";position:absolute;inset:-40%;background:linear-gradient(115deg,transparent 35%,rgba(255,255,255,.22) 50%,transparent 65%);transform:translateX(-55%) rotate(12deg);transition:transform .5s ease}.nav-tab-btn:hover .portal-nav-icon:after{transform:translateX(55%) rotate(12deg)}.portal-nav-icon svg{width:20px;height:20px;display:block;position:relative;z-index:2;stroke:currentColor;fill:none;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}.nav-tab-btn{display:flex!important;flex-direction:column;align-items:center;justify-content:center;gap:0;min-height:72px;padding:8px 5px!important;transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease,background .18s ease}.nav-tab-btn:hover{transform:translateY(-1px);box-shadow:0 8px 18px rgba(15,23,42,.12)}.nav-tab-btn.active{background:linear-gradient(145deg,#0f3768,#0a2548)!important;border-color:#f97316!important;box-shadow:0 8px 18px rgba(15,55,104,.22),inset 0 1px 0 rgba(255,255,255,.12)}.nav-tab-btn.active .portal-nav-icon{background:linear-gradient(145deg,#ff8a1f,#e85b0c);border-color:rgba(255,255,255,.35);box-shadow:0 5px 13px rgba(249,115,22,.34),inset 0 1px 0 rgba(255,255,255,.3)}.nav-tab-btn .nav-label{display:block;max-width:100%;font-size:10px;line-height:1.2;font-weight:850;letter-spacing:.05px}.nav-tab-btn #approvalsBadge{position:absolute;top:5px;right:5px;margin:0!important;z-index:5}@media(max-width:700px){.admin-nav{flex-basis:76px!important;gap:5px!important}.nav-tab-btn{min-height:64px!important;padding:6px 3px!important;border-radius:11px!important}.portal-nav-icon{width:29px;height:29px;min-width:29px;border-radius:8px;margin-bottom:4px}.portal-nav-icon svg{width:17px;height:17px}.nav-tab-btn .nav-label{font-size:8.5px}}</style>

<style>.payslip-company-address{white-space:nowrap;overflow:hidden;text-overflow:clip;}</style>
<style>.tejodhar-global-footer, .login-footer, .footer, .site-footer, #footer{width: 100% !important;box-sizing: border-box !important;display: flex !important;flex-wrap: wrap !important;justify-content: center !important;align-items: center !important;align-content: center !important;gap: 6px 10px !important;margin: 24px auto 16px !important;padding: 8px 16px !important;text-align: center !important;line-height: 1.45 !important;font-size: 10px !important;}.tejodhar-global-footer span, .login-footer span, .footer span, .site-footer span, #footer span{display: inline !important;margin: 0 !important;padding: 0 !important;text-align: center !important;}@media (max-width: 600px){.tejodhar-global-footer, .login-footer, .footer, .site-footer, #footer{flex-direction: column !important;gap: 2px !important;padding: 8px 12px !important;margin: 18px auto 12px !important;text-align: center !important;}}</style>

<style id="tejodhar-footer-final-fix">.login-footer.tejodhar-global-footer{display:flex!important;justify-content:center!important;align-items:center!important;flex-wrap:wrap!important;gap:0 14px!important;width:100%!important;box-sizing:border-box!important;text-align:center!important;}.login-footer.tejodhar-global-footer .footer-since{display:inline-block!important;margin-left:14px!important;}.global-site-footer{display:flex!important;justify-content:center!important;align-items:center!important;flex-wrap:wrap!important;gap:0 14px!important;width:100%!important;box-sizing:border-box!important;text-align:center!important;}.global-site-footer .footer-year{display:inline-block!important;margin-left:14px!important;}@media(max-width:600px){.login-footer.tejodhar-global-footer,.global-site-footer{gap:2px 10px!important;padding-left:10px!important;padding-right:10px!important;}.login-footer.tejodhar-global-footer .footer-since,.global-site-footer .footer-year{margin-left:10px!important;}}</style>

<style id="admin-menu-action-final-fix">:is(#adminView,#empView) .admin-layout{display:grid !important;grid-template-columns:82px minmax(0,1fr) !important;gap:10px !important;align-items:start !important;width:100% !important;}:is(#adminView,#empView) .admin-nav{width: 68px !important;min-width: 68px !important;max-width: 68px !important;display:flex !important;flex-direction:column !important;gap:4px !important;position:sticky !important;top:10px !important;}:is(#adminView,#empView) .nav-tab-btn{width: 68px !important;min-width: 68px !important;max-width: 68px !important;min-height: 25px !important;padding:5px 3px !important;margin:0 !important;font-size:8px !important;line-height:1.1 !important;border-radius:7px !important;white-space:normal !important;overflow-wrap:anywhere !important;text-align:center !important;box-sizing:border-box !important;}:is(#adminView,#empView) .admin-content{min-width:0 !important;width:100% !important;}@media (max-width:800px){:is(#adminView,#empView) .admin-layout{grid-template-columns:68px minmax(0,1fr) !important;gap:7px !important;}:is(#adminView,#empView) .admin-nav, :is(#adminView,#empView) .nav-tab-btn{width:68px !important;min-width:68px !important;max-width:68px !important;}:is(#adminView,#empView) .nav-tab-btn{min-height:27px !important;padding:4px 2px !important;font-size:7px !important;border-radius:6px !important;}}</style>

<style>.delete-btn, .delete-button, .btn-delete, button.delete, a.delete-btn, button[title*="Delete" i], button[aria-label*="Delete" i]{height: 5px !important;min-height: 5px !important;max-height: 5px !important;padding-top: 0 !important;padding-bottom: 0 !important;line-height: 5px !important;overflow: hidden !important;box-sizing: border-box !important;}</style>
<style>.delete-btn, .delete-button, .btn-delete, button.delete, a.delete-btn, button[title*="Delete" i], button[aria-label*="Delete" i]{font-size: 5px !important;}</style>
<style></style>
<style>@media (max-width:600px){.delete-design-btn{width: 92px !important;min-width: 92px !important;height: 34px !important;min-height: 34px !important;max-height: 34px !important;font-size: 10px !important;gap: 7px !important;padding: 0 12px !important;}.delete-design-btn::before{font-size: 15px !important;}}</style>
<style>.delete-design-btn, .delete-design-btn.btn, button.delete-design-btn, a.delete-design-btn{position: relative !important;width: 68px !important;min-width: 68px !important;height: 25px !important;min-height: 25px !important;max-height: 25px !important;padding: 0 7px !important;display: inline-flex !important;align-items: center !important;justify-content: center !important;gap: 5px !important;box-sizing: border-box !important;overflow: hidden !important;border: 2px solid #b30000 !important;border-radius: 999px !important;background: linear-gradient(180deg,#ff1717 0%,#ed0000 48%,#c60000 100%) !important;color: #fff !important;font-family: Arial, Helvetica, sans-serif !important;font-size: 10px !important;font-weight: 700 !important;line-height: 1 !important;text-shadow: none !important;box-shadow: inset 0 2px 0 rgba(255,255,255,.28), inset 0 -3px 0 rgba(110,0,0,.24), 0 1px 2px rgba(0,0,0,.18) !important;transform: none !important;}.delete-design-btn::before{content: "" !important;width: 11px !important;height: 13px !important;flex: 0 0 11px !important;display: block !important;background: linear-gradient(#fff,#fff) 50% 0/11px 2px no-repeat, linear-gradient(#fff,#fff) 50% 3px/8px 10px no-repeat !important;border-radius: 2px 2px 4px 4px !important;box-shadow: inset 4px 5px 0 -3px #e60000, inset -4px 5px 0 -3px #e60000 !important;filter: none !important;}.delete-design-btn::after{content: "" !important;position: absolute !important;left: 0 !important;top: 2px !important;right: 0 !important;height: 8px !important;border-radius: 999px !important;background: linear-gradient(180deg,rgba(255,255,255,.24),rgba(255,255,255,0)) !important;pointer-events: none !important;}.delete-design-btn:hover, .delete-design-btn:focus{background: linear-gradient(180deg,#ff2020 0%,#ed0000 48%,#c60000 100%) !important;transform: none !important;}.delete-design-btn:active{transform: scale(.98) !important;}@media (max-width:600px){.delete-design-btn, .delete-design-btn.btn, button.delete-design-btn, a.delete-design-btn{width: 68px !important;min-width: 68px !important;height: 25px !important;min-height: 25px !important;max-height: 25px !important;font-size: 10px !important;}}</style>
<style>html, body{width: 100%;min-width: 100%;height: 100%;min-height: 100%;margin: 0 !important;padding: 0 !important;overflow: hidden;}body{min-height: 100dvh;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-container, .auth-wrapper{box-sizing: border-box;min-height: 100dvh;}@media (max-width: 600px){html, body{height: 100dvh !important;min-height: 100dvh !important;width: 100vw !important;min-width: 100vw !important;overflow: hidden !important;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-container, .auth-wrapper{width: 100vw !important;max-width: none !important;min-height: 100dvh !important;height: 100dvh !important;margin: 0 !important;border-radius: 0 !important;box-sizing: border-box !important;}.login-card, .login-box, .login-form, .auth-card{width: min(92vw, 430px) !important;max-width: 92vw !important;box-sizing: border-box !important;margin-left: auto !important;margin-right: auto !important;}}</style>
<style>html,body,.login-page,.login-container,.login-portal,.portal{background-image:none!important;}</style><style>html, body{width:100% !important;height:100% !important;min-width:100% !important;min-height:100% !important;margin:0 !important;padding:0 !important;overflow:hidden !important;background:none !important;background-image:none !important;}body > *{box-sizing:border-box;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{width:100vw !important;height:100dvh !important;min-height:100dvh !important;max-width:none !important;margin:0 !important;padding:0 !important;background:none !important;background-image:none !important;border-radius:0 !important;box-sizing:border-box !important;position:relative !important;inset:auto !important;}@media (max-width:600px){.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{width:100vw !important;height:100dvh !important;min-height:100dvh !important;}.login-card, .login-box, .login-form, .auth-card{width:92vw !important;max-width:430px !important;margin-left:auto !important;margin-right:auto !important;box-sizing:border-box !important;}}</style><style>html{width:100%;min-height:100%;overflow-x:hidden !important;overflow-y:auto !important;}body{width:100%;min-height:100dvh;height:auto !important;margin:0 !important;overflow-x:hidden !important;overflow-y:auto !important;-webkit-overflow-scrolling:touch;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{width:100vw !important;min-height:100dvh !important;height:auto !important;overflow-x:hidden !important;overflow-y:visible !important;box-sizing:border-box !important;}@media (max-width:600px){html, body{overflow-x:hidden !important;overflow-y:auto !important;-webkit-overflow-scrolling:touch !important;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{min-height:100dvh !important;height:auto !important;overflow:visible !important;}.login-card, .login-box, .login-form, .auth-card{max-height:none !important;overflow:visible !important;}}</style><style>html, body{scroll-behavior: auto !important;overscroll-behavior-y: auto !important;-webkit-overflow-scrolling: touch !important;}body{touch-action: pan-y !important;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{scroll-behavior: auto !important;overscroll-behavior-y: auto !important;-webkit-overflow-scrolling: touch !important;touch-action: pan-y !important;}@media (max-width:600px){html, body{scroll-behavior: auto !important;overflow-x: hidden !important;overflow-y: auto !important;-webkit-overflow-scrolling: touch !important;touch-action: pan-y !important;}*{scroll-behavior: auto !important;}}.login-wrap, .login-wrap.force-mobile-login{background:#fff !important;}.login-panel, .login-wrap.force-mobile-login .login-panel{background:#fff !important;}.login-panel::before, .login-panel::after, .login-wrap.force-mobile-login .login-panel::before, .login-wrap.force-mobile-login .login-panel::after{display:none !important;content:none !important;background:none !important;box-shadow:none !important;}.login-visual, .login-visual-overlay, .login-city-art, .login-curve{display:none !important;}.login-card{background:#fff !important;box-shadow:0 18px 52px rgba(15,34,71,.12) !important;}@media(max-width:800px){.login-wrap{background:#fff !important;}.login-card{background:#fff !important;box-shadow:none !important;}.login-panel{background:#fff !important;overflow:hidden !important;}.login-logo-row{background:transparent !important;}.login-portal-logo{background:transparent !important;box-shadow:none !important;}}#loginView.login-wrap .login-card::before, #loginView.login-wrap .login-card::after, #loginView.login-wrap .login-panel::before, #loginView.login-wrap .login-panel::after, #loginView.login-wrap .login-wrap::before, #loginView.login-wrap .login-wrap::after{content:none !important;display:none !important;background:none !important;background-image:none !important;box-shadow:none !important;border:0 !important;}#loginView.login-wrap .login-panel{background:#fff !important;background-image:none !important;}#loginView.login-wrap .login-card{background:#fff !important;background-image:none !important;}#loginView.login-wrap .login-visual, #loginView.login-wrap .login-visual-overlay, #loginView.login-wrap .login-city-art, #loginView.login-wrap .login-curve{display:none !important;}</style><style id="tejodhar-multicolour-login-css">
/* Login refresh: no building/photo backgrounds; responsive and selectable abstract colour themes. */
html.login-active,body.login-active{background:#f4f7fb!important;background-image:none!important;background-attachment:initial!important;color:#0f2247}
body.login-active{min-height:100dvh!important;overflow-x:hidden!important}
body.login-active .container{max-width:none!important;width:100%!important;margin:0!important;padding:0!important}
#loginView.login-wrap{width:100%!important;min-height:100dvh!important;height:auto!important;margin:0!important;padding:28px!important;display:flex!important;align-items:center!important;justify-content:center!important;overflow:visible!important;box-sizing:border-box!important;background:radial-gradient(circle at 12% 8%,color-mix(in srgb,var(--login-accent) 12%,transparent),transparent 28%),radial-gradient(circle at 92% 90%,color-mix(in srgb,var(--login-secondary) 12%,transparent),transparent 30%),#f4f7fb!important;background-image:radial-gradient(circle at 12% 8%,color-mix(in srgb,var(--login-accent) 12%,transparent),transparent 28%),radial-gradient(circle at 92% 90%,color-mix(in srgb,var(--login-secondary) 12%,transparent),transparent 30%)!important}
#loginView .login-card{width:min(100%,480px)!important;max-width:480px!important;margin:auto!important;border:1px solid #e1e8f0!important;border-radius:26px!important;background:#fff!important;box-shadow:0 24px 80px rgba(15,34,71,.13)!important;overflow:hidden!important}
#loginView .login-panel{padding:36px clamp(22px,5vw,42px) 30px!important;background:#fff!important;background-image:none!important}
#loginView .login-logo-row{padding:0!important;margin:0 0 24px!important;text-align:center!important;display:flex!important;justify-content:center!important;align-items:center!important}
#loginView .login-portal-logo{display:block!important;width:min(100%,300px)!important;max-width:300px!important;max-height:100px!important;height:auto!important;object-fit:contain!important;object-position:center!important;background:transparent!important}
#loginView .login-heading{color:#122b52!important;font-size:clamp(27px,4vw,34px)!important}
#loginView .login-subheading{margin-bottom:22px!important;color:#66758b!important}
#loginView .login-card input:focus,#loginView .login-card select:focus{border-color:var(--login-accent)!important;box-shadow:0 0 0 4px color-mix(in srgb,var(--login-accent) 14%,transparent)!important}
#loginView .login-forgot-link{color:var(--login-accent)!important}
#loginView .btn-primary,#loginView .login-card .btn-primary{background:linear-gradient(110deg,var(--login-accent),var(--login-secondary))!important;box-shadow:0 10px 22px color-mix(in srgb,var(--login-accent) 24%,transparent)!important}
#loginView .login-pw-toggle{color:var(--login-accent)!important}
#loginView .login-visual,#loginView .login-visual-overlay,#loginView .login-city-art,#loginView .login-curve{display:none!important}
#tejodharThemePicker{display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:9px;margin:0 0 22px;padding:12px 13px;border:1px solid #e8edf4;border-radius:16px;background:#f8fafc}
#tejodharThemePicker .theme-label{width:100%;text-align:center;font-size:10px;letter-spacing:1.5px;font-weight:850;color:#68778b;text-transform:uppercase;margin-bottom:2px}
#tejodharThemePicker button{width:25px;height:25px;min-width:25px;padding:0;border:3px solid #fff;border-radius:50%;cursor:pointer;box-shadow:0 0 0 1px #d3dce8;transition:transform .15s,box-shadow .15s}
#tejodharThemePicker button[aria-pressed="true"]{box-shadow:0 0 0 2px var(--login-accent),0 3px 8px #0002;transform:scale(1.12)}
#loginTicker{background:linear-gradient(90deg,var(--login-deep),var(--login-accent))!important;position:relative!important;left:auto!important;right:auto!important;bottom:auto!important;height:34px!important;box-shadow:none!important}
#loginTicker .lt-text{font-size:12px!important;letter-spacing:1px!important}
@media(min-width:900px){#loginView.login-wrap{padding:44px!important}#loginView .login-card{width:min(100%,500px)!important;max-width:500px!important}#loginView .login-panel{padding:40px 48px 34px!important}}
@media(max-width:600px){#loginView.login-wrap{padding:18px 12px 14px!important;align-items:center!important;min-height:100dvh!important}#loginView .login-card{width:100%!important;max-width:440px!important;border-radius:22px!important;box-shadow:0 14px 42px rgba(15,34,71,.11)!important}#loginView .login-panel{padding:25px 20px 24px!important}#loginView .login-logo-row{margin-bottom:20px!important}#loginView .login-portal-logo{max-width:250px!important;max-height:78px!important}#loginView .login-heading{font-size:28px!important}#loginView .login-card input,#loginView .login-card select{height:52px!important}#loginTicker{height:30px!important}#loginTicker .lt-text{font-size:11px!important}}
@media(max-width:360px){#loginView.login-wrap{padding:10px!important}#loginView .login-panel{padding:20px 15px!important}#tejodharThemePicker{gap:8px;padding:10px}}
</style>
<style id="tejodhar-login-ticker-css">
#loginTicker{display:none;position:fixed;left:0;right:0;bottom:0;height:42px;z-index:50;overflow:hidden;background:linear-gradient(90deg,#0f2247,#1e4b8f);box-shadow:0 -4px 14px rgba(15,34,71,.25);pointer-events:none;}
body.login-active #loginTicker{display:block;}
#loginTicker .lt-track{position:absolute;top:0;left:0;height:100%;display:flex;align-items:center;white-space:nowrap;will-change:transform;animation:ltScroll 14s linear infinite;}
#loginTicker .lt-text{color:#fff;font-size:16px;font-weight:800;letter-spacing:.6px;padding-right:60px;}
#loginTicker .lt-text b{color:#facc15;font-weight:800;}
@keyframes ltScroll{from{transform:translateX(0);}to{transform:translateX(-50%);}}
@media(max-width:600px){#loginTicker{height:38px;}#loginTicker .lt-text{font-size:14px;}}
@media print{#loginTicker{display:none!important;}}
@media(prefers-reduced-motion:reduce){#loginTicker .lt-track{animation-duration:30s;}}
</style>
<style id="tejodhar-theme-menu-css">
/* Keep the theme menu in the site header area, separate from the login card and existing hamburger. */
#tejodharLoginThemeMenu{position:fixed;top:8px;right:62px;z-index:100000;font:600 14px/1.4 system-ui,sans-serif}
#tejodharLoginThemeMenu>button{border:1px solid #dbe4ef;background:#fff;color:#10294d;border-radius:10px;min-width:40px;min-height:40px;padding:6px 10px;box-shadow:0 4px 14px #0002;font-size:18px;cursor:pointer}
#tejodharLoginThemeDropdown{display:none;position:absolute;right:0;top:46px;width:min(290px,calc(100vw - 24px));max-height:65vh;overflow:auto;background:#fff;color:#142b4d;border:1px solid #dbe4ef;border-radius:14px;padding:12px;box-shadow:0 16px 45px #00152c35}
#tejodharLoginThemeDropdown.open{display:block}
#tejodharLoginThemeDropdown .theme-menu-title{font-size:12px;text-transform:uppercase;letter-spacing:1px;color:#64748b;margin:3px 4px 10px}
#tejodharLoginThemeDropdown .theme-menu-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}
#tejodharLoginThemeDropdown button[data-theme]{display:flex;align-items:center;gap:8px;width:100%;padding:9px 7px;border:1px solid #dce5f0;border-radius:10px;background:#fff;color:#173253;text-align:left;font-size:12px;cursor:pointer}
#tejodharLoginThemeDropdown button[data-theme][aria-pressed="true"]{border:2px solid var(--login-accent,#f97316);background:#f8fafc}
#tejodharLoginThemeDropdown .theme-swatch{width:16px;height:16px;flex:0 0 16px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 0 1px #cbd5e1}
#tejodharThemePicker{display:none!important}
/* Avoid oversized blank/overlapping login wrappers on mobile. */
.login-wrap{box-sizing:border-box;width:100%!important;min-height:calc(100dvh - 52px)!important;margin:0!important;padding:24px 12px!important;display:flex!important;align-items:center!important;justify-content:center!important;overflow:visible!important;background:radial-gradient(circle at 12% 15%,#e0f2f1 0,transparent 36%),radial-gradient(circle at 90% 85%,#e6fffa 0,transparent 34%),#f3f6fb!important}
.login-card{box-sizing:border-box!important;width:min(100%,460px)!important;max-width:460px!important;min-height:0!important;height:auto!important;margin:0 auto!important;overflow:visible!important}
@media(max-width:600px){#tejodharLoginThemeMenu{top:7px;right:58px}#tejodharLoginThemeMenu>button{min-width:38px;min-height:38px}.login-wrap{min-height:calc(100dvh - 52px)!important;padding:20px 12px!important}.login-card{width:min(100%,430px)!important;max-width:430px!important;border-radius:22px!important}}
</style>
<style id="tejodhar-login-standalone-css">
/* Login page is standalone: no site header, avatar, hamburger or app menu while logged out */
body.login-active #siteNav,body.login-active #opMenuBtn,body.login-active #opMenu,body.login-active #employeeProfileWrap,body.login-active #employeeProfilePopup{display:none!important}
body.login-active .container{max-width:none!important;margin:0!important;padding:0!important}
body.login-active #loginView.login-wrap{position:fixed!important;inset:0!important;width:100%!important;height:100dvh!important;min-height:100dvh!important;margin:0!important;border-radius:0!important;background:#fff!important;z-index:2000!important;overflow-y:auto!important}
/* FIX: the login screen must never appear inside the portal. Earlier rules force display:flex!important on
   .login-wrap, which beat the .hidden class, so the login page stayed visible after login. These rules win
   (higher specificity + !important) and tie visibility to the login-active state. */
#loginView.login-wrap.hidden,body:not(.login-active) #loginView.login-wrap,body:not(.login-active) #loginTicker,body:not(.login-active) #tejodharLoginThemeMenu,body:not(.login-active) #tejodharThemePicker{display:none!important}
/* While logged out, no portal screen or header may show through the login page. */
body.login-active #siteNav,body.login-active #adminView,body.login-active #empView,body.login-active #securityView,body.login-active #contractorPortalView{display:none!important}
/* Once logged in, the portal views keep following the .hidden class normally. */
#siteNav.hidden,#adminView.hidden,#empView.hidden,#securityView.hidden,#contractorPortalView.hidden{display:none!important}
</style>
<style id="tejodhar-login-d2-m6">
/* Purple HR Portal login: desktop = hero panel + card, phone = card over gradient. Colours follow the selected theme (default Purple). */
#loginView{--lx-a:var(--login-accent,#7c3aed);--lx-b:var(--login-secondary,#c026d3);--lx-d:var(--login-deep,#321064)}
body.login-active #loginView.login-wrap{display:flex!important;position:fixed!important;inset:0!important;overflow-y:auto!important;padding:0!important;
 background:radial-gradient(circle at 18% 22%,color-mix(in srgb,var(--lx-b) 55%,transparent) 0,transparent 38%),radial-gradient(circle at 85% 90%,color-mix(in srgb,var(--lx-b) 45%,transparent) 0,transparent 40%),linear-gradient(135deg,var(--lx-d) 0%,color-mix(in srgb,var(--lx-a) 80%,var(--lx-d)) 55%,var(--lx-a) 100%)!important;background-image:radial-gradient(circle at 18% 22%,color-mix(in srgb,var(--lx-b) 55%,transparent) 0,transparent 38%),radial-gradient(circle at 85% 90%,color-mix(in srgb,var(--lx-b) 45%,transparent) 0,transparent 40%),linear-gradient(135deg,var(--lx-d) 0%,color-mix(in srgb,var(--lx-a) 80%,var(--lx-d)) 55%,var(--lx-a) 100%)!important}
#loginView .lx-waves{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}
body.login-active #loginTicker{display:none!important}
#loginView .lx-hero,#loginView .lx-foot{display:none}
#loginView .login-card{position:relative}
body.login-active #loginView.login-wrap .login-card{background:rgba(255,255,255,.97)!important;border:0!important;border-radius:28px!important;box-shadow:0 30px 80px rgba(20,8,60,.35)!important;overflow:hidden!important}
body.login-active #loginView .login-panel{background:transparent!important;display:block!important;min-height:0!important;height:auto!important;padding:34px 34px 26px!important}
#loginView .login-logo-row{padding:0!important;margin:0 0 14px!important;justify-content:center!important}
#loginView .login-portal-logo{width:var(--login-logo-w,190px)!important;max-width:100%!important;height:auto!important;aspect-ratio:1000/195;object-fit:contain;margin:0 auto!important}
#loginView .login-heading{text-align:center!important;font-size:28px!important;margin:0!important;color:#1b1250!important}
#loginView .login-subheading{text-align:center!important;margin:6px 0 20px!important;color:#5b5880!important}
#loginView .lx-row{display:flex;justify-content:space-between;align-items:center;margin:2px 0 16px}
#loginView .lx-remember{text-transform:none!important;letter-spacing:0!important;display:flex;align-items:center;gap:9px;font-size:14px;font-weight:600;color:#1b1250;cursor:pointer}
#loginView .lx-remember span{text-transform:none!important;font-size:14px}
#loginView .lx-remember input{width:20px;height:20px;flex:0 0 20px;accent-color:var(--lx-a);margin:0;padding:0}
#loginView .login-forgot-link{margin:0!important;display:inline!important;font-size:14px!important;font-weight:600!important;color:var(--lx-a)!important}
#loginView .lx-login-btn{display:flex!important;align-items:center;justify-content:center;gap:10px;height:54px;font-size:18px!important;border-radius:14px!important}
#loginView .lx-login-btn span{flex:0 0 auto}
#loginView .lx-or{display:flex;align-items:center;gap:14px;margin:20px 0 14px;color:#6b6890;font-size:13px;font-weight:700}
#loginView .lx-or:before,#loginView .lx-or:after{content:"";flex:1;height:1px;background:#e1def2}
#loginView .lx-roles{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
#loginView .lx-roles button{display:flex;flex-direction:column;align-items:center;gap:6px;padding:14px 6px;border:1px solid #e6e3f5;border-radius:14px;background:#fff;color:#4338ca;font:600 13px/1.2 inherit;cursor:pointer;box-shadow:0 2px 8px rgba(40,20,100,.06)}
#loginView .lx-roles button span{color:#1b1250}
#loginView .lx-roles button.c{color:#ea8a0c}
#loginView .lx-roles button.s{color:#16a34a}
#loginView .lx-copy{margin-top:20px;text-align:center;font-size:12px;color:#6b6890}
#loginView #bioLoginBtn{margin-top:12px!important}
#loginView .lx-bio-btn{display:flex;align-items:center;justify-content:center;gap:10px;padding:13px 16px;border:1.5px solid #4338ca;border-radius:12px;background:#fff;color:#4338ca;font-weight:700;font-size:15px;cursor:pointer}
#loginView .lx-bio-btn:active{background:#eef2ff}
@media(min-width:900px){
 body.login-active #loginView.login-wrap{flex-direction:row!important;align-items:center!important;justify-content:center!important;gap:56px;padding:40px 56px!important}
 #loginView .lx-hero{display:flex;flex-direction:column;gap:26px;justify-content:center;position:relative;width:min(560px,46vw);color:#fff}
 #loginView .lx-hero-logo{align-self:flex-start;background:#fff;border-radius:18px;padding:14px 22px;box-shadow:0 14px 40px rgba(20,8,60,.3)}
 #loginView .lx-hero-logo img{display:block;width:280px;height:auto}
 #loginView .lx-hero-text{display:flex;flex-direction:column;gap:2px;margin-top:6px}
 #loginView .lx-hero-text span{font-size:22px;opacity:.9}
 #loginView .lx-hero-text strong{font-size:clamp(40px,4.6vw,64px);line-height:1.02;font-weight:800;background:linear-gradient(180deg,#fff 30%,color-mix(in srgb,var(--lx-b) 40%,#fff));-webkit-background-clip:text;background-clip:text;color:transparent}
 #loginView .lx-hero-text em{font-style:normal;font-size:clamp(34px,3.6vw,50px);font-weight:800;margin-top:6px}
 #loginView .lx-hero-text small{font-size:20px;letter-spacing:3px;opacity:.85;margin-top:12px}
 #loginView .lx-tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
 #loginView .lx-tiles div{display:flex;flex-direction:column;align-items:center;gap:8px;padding:14px 6px;border:1px solid rgba(255,255,255,.28);border-radius:14px;background:rgba(255,255,255,.08);text-align:center;font-size:13px;line-height:1.25}
 #loginView .lx-hero-tag{padding-top:18px;border-top:1px solid rgba(255,255,255,.3);text-align:center;letter-spacing:4px;font-size:15px}
 body.login-active #loginView.login-wrap .login-card{width:460px!important;max-width:460px!important;margin:0!important;flex:0 0 460px}
 #loginView .login-logo-row{display:flex!important}
}
@media(max-width:899px){
 body.login-active #loginView.login-wrap{flex-direction:column!important;align-items:center!important;padding:64px 18px 24px!important}
 body.login-active #loginView.login-wrap .login-card{width:100%!important;max-width:440px!important;margin:0 auto!important;border-radius:26px!important}
 body.login-active #loginView .login-panel{padding:26px 20px 20px!important}
 #loginView .login-heading{font-size:26px!important}
 #loginView .lx-copy{display:none}
 #loginView .lx-foot{display:flex;flex-direction:column;align-items:center;gap:12px;margin:22px auto 0;color:#fff;font-size:13px;position:relative;width:100%;max-width:440px}
 #loginView .lx-foot-row{display:flex;justify-content:space-around;width:100%;font-weight:600;font-size:14px}
 #loginView .lx-foot-row span+span{border-left:1px solid rgba(255,255,255,.35);flex:1;text-align:center}
 #loginView .lx-foot-row span:first-child{flex:1;text-align:center}
}
#loginView .lx-login-btn.lx-busy{pointer-events:none;opacity:.92}
#loginView .lx-login-btn.lx-busy svg{display:none}
#loginView .lx-login-btn.lx-busy span{font-size:0}
#loginView .lx-login-btn.lx-busy span:before{content:"";display:inline-block;width:18px;height:18px;margin-right:10px;vertical-align:-3px;border:3px solid rgba(255,255,255,.5);border-top-color:#fff;border-radius:50%;animation:lxspin .7s linear infinite}
#loginView .lx-login-btn.lx-busy span:after{content:"Signing in\2026";font-size:18px}
@keyframes lxspin{to{transform:rotate(360deg)}}
/* Theme button as a pill */
#tejodharLoginThemeMenu{top:18px!important;right:20px!important}
#tejodharLoginThemeMenu>button{display:flex;align-items:center;gap:8px;min-width:0!important;min-height:0!important;height:44px;padding:0 16px!important;border-radius:14px!important;border:1.5px solid rgba(255,255,255,.7)!important;background:rgba(40,16,100,.45)!important;color:#fff!important;font:600 15px/1 system-ui,sans-serif!important;backdrop-filter:blur(6px);box-shadow:none!important}
</style>
<style id="tejodhar-logo-size"><?php $___ls=(int)($db['company']['login_size']??160);$___ns=(int)($db['company']['size']??80);echo ':root{'.($___ls!==160?'--login-logo-w:'.max(40,min(400,$___ls)).'px;':'').($___ns!==80?'--nav-logo-h:'.max(40,min(200,$___ns)).'px;':'').'}'; ?></style>

<style id="tejodhar-performance-fix">
/* Performance stability: reserve logo space before remote image decode and avoid
   image-driven layout movement on mobile and desktop. */
#loginView .login-logo-row{min-height:48px;display:flex;align-items:center;justify-content:center}
#loginView .login-portal-logo{display:block;width:min(210px,70vw);height:41px;aspect-ratio:210/41;object-fit:contain}
#navLogo{display:block;aspect-ratio:210/41;object-fit:contain}
@media (prefers-reduced-motion:reduce){
 *,*::before,*::after{scroll-behavior:auto!important;animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}
}
</style>
<style id="tejodhar-stable-login-performance-fix">
/* Stable first paint: avoid missing background-image requests and conflicting viewport rules. */
html.login-active, body.login-active { background-color:#f4f7fb !important; background-image:none !important; background-attachment:initial !important; }
#loginView.login-wrap, #loginView.login-wrap.force-mobile-login { width:100% !important; min-width:0 !important; max-width:none !important; min-height:100vh !important; min-height:100dvh !important; height:auto !important; margin:0 !important; padding:24px 16px !important; box-sizing:border-box !important; display:flex !important; align-items:center !important; justify-content:center !important; overflow:visible !important; background:#f4f7fb !important; background-image:none !important; }
#loginView.login-wrap .login-card { width:min(100%,480px) !important; max-width:480px !important; min-height:0 !important; height:auto !important; margin:0 auto !important; flex:0 1 auto !important; contain:layout style; }
#loginView.login-wrap .login-panel { width:100% !important; min-width:0 !important; height:auto !important; min-height:0 !important; padding:30px clamp(20px,5vw,40px) 26px !important; overflow:visible !important; }
#loginView.login-wrap .login-logo-row { min-height:52px !important; display:flex !important; align-items:center !important; justify-content:center !important; margin:0 0 18px !important; padding:0 !important; }
#loginView.login-wrap .login-portal-logo { display:block !important; width:min(210px,70vw) !important; height:41px !important; min-height:41px !important; max-height:65px !important; aspect-ratio:210/41 !important; object-fit:contain !important; margin:0 auto !important; }
#loginTicker { position:relative !important; left:auto !important; right:auto !important; bottom:auto !important; height:30px !important; margin-top:14px !important; }
#loginTicker .lt-track { animation-duration:28s !important; }
#loginView .login-card, #loginView .login-panel, #loginView .login-logo-row, #loginView .login-heading, #loginView .login-subheading { transition:none !important; }
@media(max-width:600px) { #loginView.login-wrap, #loginView.login-wrap.force-mobile-login { padding:16px 12px 12px !important; min-height:100vh !important; min-height:100dvh !important; } #loginView.login-wrap .login-card { width:100% !important; max-width:440px !important; border-radius:20px !important; } #loginView.login-wrap .login-panel { padding:24px 20px 22px !important; } #loginView.login-wrap .login-portal-logo { width:min(210px,70vw) !important; height:41px !important; } }
@media(prefers-reduced-motion:reduce) { #loginTicker .lt-track { animation:none !important; } }
</style>
</head>
<body class="login-active">
<div id="loginTicker" class="no-print" aria-label="We Build Trust, Tomorrow Dreams"><div class="lt-track"><span class="lt-text">We Build Trust, <b>Tomorrow Dreams</b></span><span class="lt-text">We Build Trust, <b>Tomorrow Dreams</b></span><span class="lt-text">We Build Trust, <b>Tomorrow Dreams</b></span><span class="lt-text">We Build Trust, <b>Tomorrow Dreams</b></span></div></div>
<nav id="siteNav" class="no-print hidden">
<div style="display:flex;align-items:center;gap:15px;min-width:0;flex:1;overflow:visible">
<div id="employeeProfileWrap" class="employee-profile-wrap">
<button type="button" id="employeeProfileBtn" class="employee-profile-btn" aria-label="Open employee profile"><span id="employeeProfileInitial" class="employee-profile-initial">E</span><img id="employeeProfileAvatar" src="" alt="Employee photo" style="display:none"></button>
<div id="employeeProfilePopup" class="employee-profile-popup" onclick="event.stopPropagation()"><button type="button" class="profile-close" onclick="closeEmployeeProfile()">✕</button><div id="employeeProfilePhotoLarge" class="profile-photo-fallback">E</div><p id="employeeProfileName" class="profile-name">Employee</p><div id="employeeProfileId" class="profile-id">Employee ID</div><div class="profile-info"><div class="profile-info-row"><span>Employee ID</span><strong id="employeeProfileIdValue">—</strong></div><div class="profile-info-row"><span>Date of Birth</span><strong id="employeeProfileDob">—</strong></div><div class="profile-info-row" id="employeeProfileContractorRow" style="display:none"><span>Contractor</span><strong id="employeeProfileContractor">—</strong></div></div></div>
</div>
<img id="navLogo" class="nav-centered-logo" decoding="async" src="<?php echo htmlspecialchars($db['company']['logo']===COMPANY_LOGO_URL?COMPANY_LOGO_FAST:$db['company']['logo']); ?>" style="<?php echo empty($db['company']['logo'])?'display:none;':'' ?>height:<?php echo (int)$db['company']['size']; ?>px;object-fit:contain;border-radius:12px;flex-shrink:0">
</div>
<button id="logoutBtn" class="btn hidden" style="flex-shrink:0;padding:0;min-width:0;background:transparent;border:0;box-shadow:none;line-height:0;cursor:pointer" onclick="logout()" title="Exit" aria-label="Exit"><img src="https://res.cloudinary.com/wpizqa3u/image/upload/q_auto/app_icons/exit.png" onerror="this.onerror=null;this.src='assets/icons/exit.png?v=1'" alt="Exit" width="40" height="40" style="display:block;width:40px;height:40px"></button>
</nav>

<div class="container no-print">
<div id="loginView" class="login-wrap">
  <svg class="lx-waves" viewBox="0 0 1440 900" preserveAspectRatio="none" aria-hidden="true"><path d="M0 640C220 560 360 760 640 700S1100 520 1440 620V900H0Z" fill="#fff" fill-opacity=".07"/><path d="M0 720C260 650 420 820 720 780S1180 640 1440 720V900H0Z" fill="#fff" fill-opacity=".09"/><path d="M0 120C200 40 420 220 700 120S1180 -20 1440 100V0H0Z" fill="#fff" fill-opacity=".07"/></svg>
  <aside class="lx-hero">
    <div class="lx-hero-text"><span>Welcome to</span><strong>Tejodhar<br>Construction</strong><em>HR Portal</em><small>People &nbsp;|&nbsp; Projects &nbsp;|&nbsp; Progress</small></div>
    <div class="lx-tiles">
      <div><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4.5" width="18" height="16" rx="3"/><path d="M8 2.5v4M16 2.5v4M3 10h18M9 15l2 2 4-4"/></svg><span>Attendance<br>Management</span></div>
      <div><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.3c2 .7 3.5 2.4 3.5 5.2"/></svg><span>Employee<br>Management</span></div>
      <div><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="3.5" width="17" height="17" rx="3"/><path d="M7 15l3-3 2.5 2L17 9"/></svg><span>Project<br>Assignment</span></div>
      <div><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 13h7M9 17h7"/></svg><span>Reports<br>&amp; Payslips</span></div>
    </div>
    <div class="lx-hero-tag">We Build Trust, Tomorrow Dreams</div>
  </aside>
  <div class="login-card">
    <section class="login-panel">
      <div class="login-logo-row">
        <img class="login-portal-logo" src="<?php echo htmlspecialchars(COMPANY_LOGO_FAST); ?>" onerror="this.onerror=null;this.src='assets/tejodhar-logo-original.png'" alt="Tejodhar Construction logo" width="210" height="41" fetchpriority="high" decoding="async">
      </div>
      <h2 class="login-heading">HR Portal Login</h2>
      <p class="login-subheading">Sign in to continue</p>

      <div class="form-group">
        <div class="login-input-wrap">
          <svg class="login-input-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.7 0 4.9-2.2 4.9-4.9S14.7 2.2 12 2.2 7.1 4.4 7.1 7.1 9.3 12 12 12zm0 2.5c-3.3 0-9.8 1.6-9.8 4.9v2.4h19.6v-2.4c0-3.3-6.5-4.9-9.8-4.9z"/></svg>
          <input id="u" placeholder="Username" autocomplete="username">
        </div>
      </div>

      <div class="form-group">
        <div class="login-input-wrap">
          <svg class="login-input-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M17 9V7a5 5 0 0 0-10 0v2a3 3 0 0 0-3 3v7a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-7a3 3 0 0 0-3-3zM9 7a3 3 0 0 1 6 0v2H9V7z"/></svg>
          <input id="p" type="password" placeholder="Password" autocomplete="current-password">
          <button type="button" class="login-pw-toggle" onclick="toggleLoginPw()" aria-label="Show password">
            <svg id="pwEyeIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M17.9 17.9A10.6 10.6 0 0 1 12 19c-6.5 0-10-7-10-7a18.6 18.6 0 0 1 4.2-5.2M9.5 4.6A10.7 10.7 0 0 1 12 4.3c6.5 0 10 7 10 7a18.6 18.6 0 0 1-2.2 3.1M14.1 14.1a3 3 0 1 1-4.2-4.2"></path>
              <line x1="1" y1="1" x2="23" y2="23"></line>
            </svg>
          </button>
        </div>
      </div>

      <div class="lx-row">
        <label class="lx-remember"><input type="checkbox" id="rememberMe"><span>Remember me</span></label>
        <a href="javascript:void(0)" class="login-forgot-link" onclick="showForgotPassword()">Login Help?</a>
      </div>
      <div id="loginError" role="alert" aria-live="polite" style="display:none;color:#dc2626;font-size:13px;font-weight:800;text-align:left;margin:-4px 2px 10px"></div>
      <button class="btn btn-primary lx-login-btn" style="width:100%" onclick="login()"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 4h5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-5M10 8l-4 4 4 4M6 12h10" transform="translate(24 0) scale(-1 1)"/></svg><span>Login</span></button>
      <button type="button" id="bioLoginBtn" class="btn lx-bio-btn" style="display:none;width:100%" onclick="bioLogin()"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 11v3.5c0 2-.5 3.8-1.5 5.5M8 10.5a4 4 0 0 1 8 0v2.2c0 1.6-.2 3.1-.7 4.6M5 12a7 7 0 0 1 14 0c0 1.2 0 2.4-.2 3.5M4.5 16c.4-1.3.5-2.6.5-4M9 20c.8-1.5 1.2-3 1.4-4.5"/></svg><span>Login with fingerprint</span></button>

      <div id="firstRunBox" style="display:none;margin:18px 0 4px;padding:14px;border:1.5px dashed #94a3b8;border-radius:14px;background:#f8fafc;text-align:left">
        <div style="font-weight:800;font-size:14px;color:#0f172a;margin-bottom:4px">First start: import old data</div>
        <div style="font-size:12px;color:#475569;margin-bottom:8px">Upload your old <b>database.json</b> (and <b>biometrics.json</b> / <b>data.json</b>) to MySQL. The old files on the server are deleted only after the copy in MySQL is verified.</div>
        <input type="file" id="firstRunFiles" accept=".json,application/json" multiple style="width:100%;font-size:12px">
        <button type="button" class="btn btn-primary" style="width:100%;margin-top:10px" onclick="firstRunImport()">Upload to MySQL</button>
        <div id="firstRunResult" style="white-space:pre-wrap;font-size:12px;font-weight:700;margin-top:8px;color:#0f172a"></div>
      </div>
      <script>
      (function(){fetch('?action=first_run_status',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}).then(function(r){return r.json()}).then(function(r){if(r&&r.status==='success'&&r.open){var b=document.getElementById('firstRunBox');if(b)b.style.display='block';}}).catch(function(){});})();
      async function firstRunImport(){
        var inp=document.getElementById('firstRunFiles'),out=document.getElementById('firstRunResult');
        if(!inp.files.length){alert('Choose database.json first.');return;}
        if(!confirm('Upload to MySQL and then delete the old JSON files from the server (only after verification)?'))return;
        var files={};
        for(var i=0;i<inp.files.length;i++){var f=inp.files[i];files[f.name]=await new Promise(function(res,rej){var fr=new FileReader();fr.onload=function(){res(fr.result)};fr.onerror=rej;fr.readAsText(f);});}
        out.textContent='Uploading\u2026';
        try{
          var r=await (await fetch('?action=first_run_json_import',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({files:files})})).json();
          if(r.status!=='success'){out.textContent=r.message||'Import failed.';return;}
          out.textContent=(r.report||[]).join('\n')+(r.deleted&&r.deleted.length?'\nDeleted old files: '+r.deleted.join(', '):'')+'\nReloading\u2026';
          setTimeout(function(){location.reload()},1800);
        }catch(e){out.textContent='Upload failed: '+e.message;}
      }
      </script>


      <div class="lx-or"><span>OR</span></div>
      <div class="lx-roles">
        <button type="button" onclick="document.getElementById('u').focus()"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/></svg><span>Admin</span></button>
        <button type="button" onclick="document.getElementById('u').focus()" class="c"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 17h18M5 17a7 7 0 0 1 14 0M12 6v4M9 17V9.5M15 17V9.5"/><path d="M4 20h16"/></svg><span>Contractor</span></button>
        <button type="button" onclick="document.getElementById('u').focus()" class="s"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/></svg><span>Security</span></button>
      </div>
      <div class="lx-copy">&copy; <?php echo date('Y'); ?> Tejodhar Construction. All Rights Reserved.</div>
    </section>
  </div>
  <div class="lx-foot"><div class="lx-foot-row"><span>People</span><span>Projects</span><span>Progress</span></div><div>We Build Trust, Tomorrow Dreams</div></div>
<script>(function(){var u=document.getElementById('u'),c=document.getElementById('rememberMe');if(!u||!c)return;try{var r=localStorage.getItem('tejodharRememberUser')||'';if(r){u.value=r;c.checked=true;}}catch(e){}
function save(){try{if(c.checked&&u.value.trim())localStorage.setItem('tejodharRememberUser',u.value.trim());else localStorage.removeItem('tejodharRememberUser');}catch(e){}}
c.addEventListener('change',save);u.addEventListener('change',save);document.addEventListener('click',function(e){if(e.target.closest&&e.target.closest('.lx-login-btn'))save();},true);})();</script>
</div>

<div id="forgotPasswordModal" class="hidden" style="position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px">
<div style="background:#fff;width:100%;max-width:390px;border-radius:18px;padding:24px;box-shadow:0 20px 60px rgba(15,23,42,.25)">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><h3 style="margin:0"></h3><button type="button" onclick="hideForgotPassword()" style="border:0;background:transparent;font-size:24px;cursor:pointer;color:#64748b">×</button></div>
<div style="width:44px;height:44px;border-radius:13px;background:linear-gradient(135deg,#0f2247,#1e4b8f);display:flex;align-items:center;justify-content:center;color:#fff;box-shadow:0 8px 20px rgba(15,34,71,.18);margin-bottom:12px"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="10" rx="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg></div>
<h3 style="margin:0;color:#0f2247;font-size:22px">Reset Password</h3>
<p style="font-size:13px;color:#64748b;line-height:1.5;margin:8px 0 18px">Enter your username and the <strong>date of birth registered by Admin/HR</strong>. If they match, you can create a new password.</p>
<div class="form-group"><label>Username</label><input id="forgotUser" placeholder="Enter username" autocomplete="username"></div>
<div class="form-group"><label>Date of Birth</label><input id="forgotDob" type="date" autocomplete="bday"></div>
<div class="form-group"><label>New Password</label><input id="forgotNewPass" type="password" placeholder="Minimum 8 characters" autocomplete="new-password"></div>
<div class="form-group"><label>Confirm Password</label><input id="forgotConfirmPass" type="password" placeholder="Re-enter new password" autocomplete="new-password"></div>
<div id="forgotResult" style="display:none;padding:10px 12px;border-radius:10px;font-size:13px;margin-top:10px;font-weight:700"></div>
<div style="display:flex;gap:10px;margin-top:16px"><button type="button" class="btn btn-primary" style="flex:1" onclick="submitForgotPassword()">Reset Password</button><button type="button" class="btn" style="flex:1" onclick="hideForgotPassword()">Cancel</button></div>
</div></div>

<div id="adminView" class="hidden">
<div class="admin-layout">
<div class="admin-nav">
<button class="nav-tab-btn active" data-tab="dashboard" onclick="showAdminTab('dashboard')">Approvals<span id="approvalsBadge" class="hidden" style="margin-left:6px;background:#be123c;color:#fff;border-radius:999px;padding:1px 7px;font-size:11px;font-weight:800"></span></button><button class="nav-tab-btn" data-tab="security" onclick="showAdminTab('security')">Admin Security</button>
<button class="nav-tab-btn" data-tab="company" onclick="showAdminTab('company')">Company Profile</button>
<button class="nav-tab-btn" data-tab="employee" onclick="showAdminTab('employee')">Employee Master</button>
<button class="nav-tab-btn" data-tab="idcard" onclick="showAdminTab('idcard')">ID Card</button>
<button class="nav-tab-btn" data-tab="projectAssign" onclick="showAdminTab('projectAssign')">Project Assign</button>
<button class="nav-tab-btn" data-tab="attendance" onclick="showAdminTab('attendance')">Attendance</button>
<button class="nav-tab-btn" data-tab="advance" onclick="showAdminTab('advance')">Salary Advance</button>
<button class="nav-tab-btn" data-tab="contractor" onclick="showAdminTab('contractor')">Contractor</button>
<button class="nav-tab-btn" data-tab="contractorAtt" onclick="showAdminTab('contractorAtt')">Contractor Attendance</button>
<button class="nav-tab-btn" data-tab="contractorBill" onclick="showAdminTab('contractorBill')">Contractor Bill</button>
<button class="nav-tab-btn" data-tab="cashbookReport" onclick="showAdminTab('cashbookReport');initAdminCashbookReport()">Cash Book Report</button>
<button class="nav-tab-btn" data-tab="measurement" onclick="showAdminTab('measurement')">Measurement Sheet</button>
<button class="nav-tab-btn" data-tab="spending" onclick="showAdminTab('spending')">Spending Dashboard</button>
<button class="nav-tab-btn" data-tab="faceSec" onclick="showAdminTab('faceSec')">Face Security</button><button class="nav-tab-btn" data-tab="settings" onclick="showAdminTab('settings');bioRefreshMenu();adminStorageRefresh()">Settings</button>
</div>
<div class="admin-content">
<div id="tab-settings" class="admin-tab"><div class="card"><h3 style="margin:0 0 12px">Settings</h3><div class="bio-settings-slot"></div></div>
<div class="card" id="blockchainSettingsCard" style="display:none!important"><h3 style="margin:0 0 6px">🔗 Data Integrity Chain</h3>
<p style="color:#64748b;font-size:12px;margin:0 0 12px">Every save is sealed into a hash chain. Verify checks that nothing was edited, deleted or changed directly in the database.</p>
<div style="display:flex;gap:8px;flex-wrap:wrap">
<button class="btn btn-primary" onclick="verifyLedger()">Verify chain</button>
<button class="btn btn-save" onclick="ledgerAnchorNow(false)">⛓ Anchor to Bitcoin</button></div>
<p style="color:#64748b;font-size:11px;margin:8px 0 0">Anchoring sends only a fingerprint (hash) to free OpenTimestamps servers, which later commit it to the Bitcoin blockchain. It is also done automatically about once a day when an admin opens the portal.</p>
<div id="ledgerResult" style="margin-top:12px;font-size:13px;font-weight:700"></div>
<div id="ledgerAnchors" style="margin-top:12px;font-size:12px"></div>
<div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--border)"><strong style="font-size:13px">Check a document</strong>
<p style="color:#64748b;font-size:11px;margin:4px 0 8px">Pick a file; it is fingerprinted in your browser (never uploaded) and matched against the documents stored in the portal.</p>
<input type="file" id="ledgerDocFile" style="padding:8px"><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"><button class="btn btn-primary" onclick="ledgerCheckDoc()">Check file</button><button class="btn btn-save" onclick="ledgerRegisterDoc()">Register document</button></div>
<div id="ledgerDocMeta" style="display:none;margin-top:8px"><input id="ledgerDocName" maxlength="180" placeholder="Document title (e.g. Cash Book Report.pdf)" style="width:100%;padding:10px;margin:4px 0"><input id="ledgerDocProject" maxlength="120" placeholder="Project (optional)" style="width:100%;padding:10px;margin:4px 0"><button class="btn btn-primary" onclick="ledgerSubmitRegistration()">Confirm registration</button></div>
<div id="ledgerDocResult" style="margin-top:8px;font-size:13px;font-weight:700"></div></div></div>
<div class="card" id="adminStorageCard"><h3 style="margin:0 0 6px">&#128451; Database (MySQL)</h3>
<div id="adminStorageStatus" style="font-size:13px;margin-bottom:10px">Checking&hellip;</div>
</div></div>
<div id="tab-spending" class="admin-tab"><div class="card"><h3 style="margin:0 0 4px">Overall Spending Dashboard</h3><p style="margin:0 0 16px;color:#64748b;font-size:13px">Sites, employee salary, labour payment and cash book expenses in one view, with a site-wise breakdown.</p>
<div class="sd-filters"><div class="form-group"><label for="spYear">Year</label><select id="spYear" onchange="renderSpendingDashboard()"></select></div><div class="form-group"><label for="spMonth">Month</label><select id="spMonth" onchange="renderSpendingDashboard()"></select></div></div>
<div id="spendingBody"></div></div></div>
<div id="tab-dashboard" class="admin-tab">
<div class="card"><h3>⏳ Pending Attendance Requests</h3><div id="requestQueue"></div></div>
<div class="card"><h3>Pending Leave Requests</h3><div id="leaveApprovalQueue"></div></div>
<div class="card">
<h3>📊 Workforce Dashboard</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Today’s project, shift and attendance overview.</p>
<div id="dashCards" class="summary" style="margin-top:15px"></div>
<div id="dashPresent" class="card" style="margin-top:15px"></div>
</div>
<div class="card"><h3>🏗️ Project & Contractor Workforce</h3><div id="dashProjects"></div></div>
<div class="card"><h3>🕒 Shift Summary</h3><div id="dashShifts"></div></div>
</div>

<div id="tab-security" class="admin-tab active">
<div class="card">
<div style="display:flex;justify-content:space-between;align-items:center"><h3>Admin Security</h3><button class="btn btn-save" onclick="saveAdmin()">Save</button></div>
<div class="grid">
<div class="form-group"><label>Username</label><input id="aUser" value="<?php echo htmlspecialchars($db['admin']['user']); ?>"></div>
<div class="form-group"><label>Password</label><input id="aPass" type="password" value="" placeholder="Leave blank to keep current password" autocomplete="new-password"></div>
</div></div>
<div class="card">
<div style="display:flex;justify-content:space-between;align-items:center"><h3>🛡️ Security Guard Login — Site Wise</h3><button class="btn btn-save" onclick="saveSecurity()">Save</button></div>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Each site has its own login. Whichever credentials the guard uses at login determines which site their scans are logged under.</p>
<?php for($i=1;$i<=2;$i++): $siteRow=$db['security'][$i-1]??['site'=>"Site $i",'user'=>"security$i",'pass'=>'security123']; ?>
<div class="grid" style="margin-top:<?php echo $i>1?'10px':'0'; ?>">
<div class="form-group"><label>Site Name</label><input id="sgSite<?php echo $i; ?>" value="<?php echo htmlspecialchars($siteRow['site']); ?>"></div>
<div class="form-group"><label>Username</label><input id="sgUser<?php echo $i; ?>" value="<?php echo htmlspecialchars($siteRow['user']); ?>"></div>
<div class="form-group"><label>Password</label><input id="sgPass<?php echo $i; ?>" type="password" value="" placeholder="Leave blank to keep current password" autocomplete="new-password"></div>
</div>
<?php endfor; ?>
</div>
</div>

<div id="tab-faceSec" class="admin-tab">
<div class="card">
<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap"><h3 style="margin:0">🧑 Face Recognition Security</h3>
<label class="face-switch" title="Master switch"><input type="checkbox" id="faEnabled" onchange="faceSaveSettings(true)"><span class="face-slider"></span><span id="faEnabledLbl">OFF</span></label></div>
<p style="color:#64748b;font-size:12px;margin:10px 0 14px">When ON, Punch In / Punch Out is accepted only after the person's face is live-scanned and matched to the enrolled face. The camera tracks the face on screen, and every scan (who, when, result, where) is logged below. Turn OFF to go back to normal punching at any time.</p>
<div id="faOptions" class="grid" style="gap:10px">
<label class="face-opt"><input type="checkbox" id="fa_require_emp"><span>Employee self punch<small>Employees must verify their face on their own phone.</small></span></label>
<label class="face-opt"><input type="checkbox" id="fa_require_guard"><span>Security guard scanner<small>The guard scans the employee's face together with the ID/QR.</small></span></label>
<label class="face-opt"><input type="checkbox" id="fa_guard_identify"><span>Guard "Face Scan" button<small>Guard portal can recognise an employee by face alone, without typing the ID.</small></span></label>
<label class="face-opt"><input type="checkbox" id="fa_liveness"><span>Liveness check<small>Asks for a blink or head turn, so a photo or video does not pass.</small></span></label>
<label class="face-opt"><input type="checkbox" id="fa_allow_unenrolled"><span>Allow punch if face not enrolled<small>Keep ON while you roll out; turn OFF once everyone is enrolled.</small></span></label>
<label class="face-opt"><input type="checkbox" id="fa_snapshots"><span>Save a small snapshot with every scan<small>Lets you review who was in front of the camera. Off by default (privacy).</small></span></label>
<div class="face-opt" style="align-items:center"><span style="flex:1">Match strictness<small>Stricter = fewer wrong matches, more retries.</small></span>
<select id="fa_threshold" style="padding:8px;border-radius:10px;border:1px solid #cbd5e1"><option value="0.45">Strict</option><option value="0.5">Balanced</option><option value="0.58">Lenient</option></select></div>
</div>
<div style="margin-top:14px"><button class="btn btn-save" onclick="faceSaveSettings(false)">Save settings</button></div>
</div>
<div class="card">
<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><h3 style="margin:0">Enrolled faces</h3><span id="faSummary" style="color:#64748b;font-size:12px;font-weight:800"></span></div>
<p style="color:#64748b;font-size:12px;margin:8px 0">Enrol each employee once, in person, using this device's camera (5 quick samples). Only a numeric face template is stored, never a photo.</p>
<div class="face-tblwrap"><table class="face-tbl"><thead><tr><th>Employee</th><th>Status</th><th></th></tr></thead><tbody id="faEmpBody"></tbody></table></div>
</div>
<div class="card">
<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><h3 style="margin:0">Face scan log (tracking)</h3><span><button class="btn" style="padding:6px 12px;font-size:12px" onclick="faceAdminInit()">Refresh</button> <button class="btn btn-danger" style="padding:6px 12px;font-size:12px" onclick="faceClearLog()">Clear log</button></span></div>
<div class="face-tblwrap" style="margin-top:10px"><table class="face-tbl"><thead><tr><th>Time (IST)</th><th>Employee</th><th>Result</th><th>Distance</th><th>Via</th><th>Snapshot</th></tr></thead><tbody id="faLogBody"></tbody></table></div>
<p style="color:#64748b;font-size:11px;margin:8px 0 0">Distance: lower is a closer match. The latest 500 scans are kept.</p>
</div>
</div>

<div id="tab-company" class="admin-tab">
<div class="card">
<div style="display:flex;justify-content:space-between;align-items:center"><h3>Company Profile</h3><button class="btn btn-save" onclick="saveCompany()">Save</button></div>
<div class="grid">
<div class="form-group" style="grid-column:1/-1"><label>Address (Single Line)</label><input id="cAddr" type="text" value="<?php echo htmlspecialchars($db['company']['addr']); ?>" style="width:100%;white-space:nowrap"></div>
</div>
<div class="grid">
<div class="form-group"><label>Logo</label><div style="border:1px solid var(--border);border-radius:14px;padding:10px;background:#f8fafc;text-align:center"><img src="<?php echo htmlspecialchars(COMPANY_LOGO_URL); ?>" alt="Company logo" style="max-width:100%;max-height:70px;object-fit:contain"><div style="font-size:11px;color:#64748b;margin-top:6px">Fixed hosted image (used on every screen)</div></div></div>
<div class="form-group"><label>Seal</label><div style="border:1px solid var(--border);border-radius:14px;padding:10px;background:#f8fafc;text-align:center"><img src="<?php echo htmlspecialchars(COMPANY_SEAL_URL); ?>" alt="Company seal" style="max-width:100%;max-height:70px;object-fit:contain"><div style="font-size:11px;color:#64748b;margin-top:6px">Fixed hosted image (used on payslips &amp; reports)</div></div></div>
<div class="form-group"><label>Logo Size</label><input id="cSize" type="range" min="40" max="200" value="<?php echo (int)$db['company']['size']; ?>" oninput="liveLogoSize(this.value)"><div id="cSizeVal" style="font-size:11px;color:#64748b;margin-top:4px;text-align:center"><?php echo (int)$db['company']['size']; ?>px</div></div>
<div class="form-group"><label>Login Page Logo Size</label><input id="cLoginSize" type="range" min="40" max="400" value="<?php echo (int)($db['company']['login_size']??160); ?>" oninput="liveLoginLogoSize(this.value)"><div id="cLoginSizeVal" style="font-size:11px;color:#64748b;margin-top:4px;text-align:center"><?php echo (int)($db['company']['login_size']??160); ?>px</div></div>
</div></div>
</div>

<div id="tab-employee" class="admin-tab">
<div class="card">
<h3>Employee Master</h3>
<div id="empStatusBanner" class="hidden" style="margin-bottom:12px;padding:10px 14px;border-radius:12px;font-size:12.5px;font-weight:600;line-height:1.5"></div>
<div class="form-group"><label>Employee</label><select id="empSelector" onchange="loadEmployee()"><option value="new">+ New Employee</option></select></div>
<div class="grid">
<div class="form-group"><label>Employee ID</label><input id="eID"></div><div class="form-group"><label>Name</label><input id="eName"></div>
<div class="form-group"><label>Designation</label><input id="eDes"></div><div class="form-group"><label>Project</label><input id="eProject" readonly title="Project is managed from Project Assign"></div>
<div class="form-group"><label>DOJ</label><input id="eDOJ"></div><div class="form-group"><label>DOB</label><input id="eDOB" type="date"></div>
<div class="form-group"><label>Grade</label><input id="eGrade"></div>
<div class="form-group" style="display:flex;align-items:center;gap:8px;padding-top:22px"><label style="margin:0"><input type="checkbox" id="eIsManager" style="width:auto;accent-color:#2563eb"> Authorised Manager <span style="color:#64748b;font-size:11px">(can approve leave for their project)</span></label></div>
<div class="form-group"><label>Bank</label><input id="eBank"></div><div class="form-group"><label>Account</label><input id="eAcc"></div>
<div class="form-group"><label>PAN</label><input id="ePAN"></div>
<div class="form-group"><label>UAN</label><input id="eUAN"></div>
<div class="form-group"><label>ESI No</label><input id="eESINo"></div>
</div>
<div class="form-group" style="margin-top:10px">
<label>Employee Photo</label>
<div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">
<img id="ePhotoPreview" src="" alt="" style="display:none;width:84px;height:84px;object-fit:cover;border-radius:12px;border:1px solid var(--border)">
<div style="display:flex;flex-direction:column;gap:6px">
<div style="display:flex;gap:8px;flex-wrap:wrap">
<label class="btn btn-save" style="margin:0;cursor:pointer">Upload from File<input id="ePhotoFile" type="file" accept="image/*" style="display:none" onchange="encodeEmployeePhoto(this)"></label>
<label class="btn btn-save" style="margin:0;cursor:pointer">📷 Take Photo<input id="ePhotoCamera" type="file" accept="image/*" capture="user" style="display:none" onchange="encodeEmployeePhoto(this)"></label>
<button type="button" class="btn btn-danger" onclick="removeEmployeePhoto()">Remove</button>
</div>
<span style="color:#64748b;font-size:12px">Photos are automatically resized for storage. Upload from your device's gallery or capture directly with the camera.</span>
</div>
</div>
</div>
<h3>Salary</h3>
<div class="grid">
<div class="form-group"><label>Basic</label><input id="eBasic" type="number"></div><div class="form-group"><label>HRA</label><input id="eHRA" type="number"></div>
<div class="form-group"><label>LTA</label><input id="eLTA" type="number"></div><div class="form-group"><label>Special</label><input id="eSpecial" type="number"></div>
<div class="form-group"><label>Mobile</label><input id="eMobile" type="number"></div><div class="form-group"><label>CTC (Annual)</label><input id="eSalaryCTC" type="number" readonly style="background:#f1f5f9"></div>
<div class="form-group"><label>PF Deduction</label><input id="ePF" type="number" min="0"></div><div class="form-group"><label>PT</label><input id="ePT" type="number" min="0"></div><div class="form-group"><label>Employer PF</label><input id="eEPF" type="number" min="0"></div>
</div>
<button class="btn btn-save" onclick="saveEmployee()">Save Employee</button>
<button class="btn btn-danger delete-design-btn" onclick="deleteEmployee()">Delete</button>
<button class="btn btn-danger" id="empTerminateBtn" onclick="terminateEmployee()">⛔ Terminate Employee</button>
<button class="btn btn-save" id="empReinstateBtn" style="display:none" onclick="reinstateEmployee()">♻ Reinstate Employee</button>
<button class="btn btn-save" id="empRejoinBtn" style="display:none" onclick="rejoinEmployee()">🔄 Rejoin Employee</button>
<div style="margin-top:16px;padding-top:14px;border-top:1px dashed var(--border)">
<label style="display:block;margin-bottom:6px;font-weight:700;font-size:13px">📅 Notice Period</label>
<p style="color:#64748b;font-size:12px;margin:0 0 10px">Employee keeps full access until the last working day. After that, the account stays live for 15 more days (Payslip &amp; Calendar only), then login locks automatically.</p>
<div class="grid">
<div class="form-group"><label>Last Working Day</label><input id="eNoticeEnd" type="date"></div>
<div class="form-group"><label>Reason (optional)</label><input id="eNoticeReason" type="text" placeholder="e.g. Resignation"></div>
</div>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
<button class="btn btn-save" onclick="setNoticePeriod()">Save Notice Period</button>
<button class="btn btn-danger" id="empClearNoticeBtn" style="display:none" onclick="clearNoticePeriod()">Clear Notice Period</button>
</div>
</div>
</div>
</div>

<div id="tab-measurement" class="admin-tab">
<div class="card">
<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px"><h3 style="margin:0">📐 Measurement Sheet</h3><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-primary" onclick="initAdminMeasurement(true)">↻ Refresh</button><button class="btn btn-primary" onclick="msPrint('ams')">🖨 Print</button><button class="btn btn-save" onclick="msPdf('ams')">⬇ PDF</button><button class="btn btn-save" onclick="msCsv('ams')">⬇ CSV</button></div></div>
<div class="grid" style="margin-top:12px">
<div class="form-group"><label>Project</label><select id="amsProject" onchange="renderAdminMeasurement()"></select></div>
<div class="form-group"><label>Staff</label><select id="amsStaff" onchange="renderAdminMeasurement()"></select></div>
<div class="form-group"><label>From</label><input id="amsFrom" type="date" onchange="renderAdminMeasurement()"></div>
<div class="form-group"><label>To</label><input id="amsTo" type="date" onchange="renderAdminMeasurement()"></div>
<div class="form-group"><label>Search</label><input id="amsSheetQ" type="text" placeholder="Sheet or description" oninput="renderAdminMeasurementSoon()"></div>
</div>
<div id="amsList" style="margin-top:6px"></div>
</div>
</div>

<div id="tab-idcard" class="admin-tab">
<div class="card">
<h3>ID Card</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Select an employee to generate their digital ID card. Tap the card to flip between front and back.</p>
<div class="grid" style="align-items:end">
<div class="form-group">
<label>Select Employee</label>
<select id="idCardEmployeeSelector" onchange="loadIdCardEmployee()"><option value="">Select Employee</option></select>
</div>
<div class="form-group">
<button class="btn btn-primary" style="width:100%" onclick="generateSelectedEmployeeIdCard()">Generate ID Card</button>
</div>
</div>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
<button class="btn btn-save" onclick="downloadSelectedEmployeeIdCard()">⬇ Download ID Card</button>
</div>
<div id="idCardSelectedInfo" style="margin-top:8px;color:#64748b;font-size:12px"></div>
</div>
</div>

<div id="tab-projectAssign" class="admin-tab">
<div class="card">
<h3>Project Assign</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Admin only. Select an employee, assign a project, and assign one or multiple contractors. These controls are separate from Employee Master.</p>
<div class="grid">
<div class="form-group"><label>Search Employee</label><input id="paEmployeeSearch" placeholder="Search by name or employee ID" oninput="filterProjectEmployees()"></div>
<div class="form-group"><label>Select Employee</label><select id="paEmployeeSelector" onchange="loadProjectAssignment()"><option value="">Select Employee</option></select></div>
<div class="form-group"><label>Assigned Project</label><input id="paProject" placeholder="Enter project name"></div>
<div class="form-group"><label>Employee Shift</label><select id="paShift" onchange="syncProjectShiftTime()"><option value="shift1">Shift 1</option><option value="shift2">Shift 2</option></select><div id="paShiftTime" style="font-size:12px;color:#64748b;margin-top:6px;padding:6px 9px;background:#f8fafc;border-radius:8px;text-align:center">08:00 AM – 06:00 PM</div></div>
<div class="form-group"><label>Employee Username</label><input id="paUser" placeholder="Portal username" autocomplete="username"></div>
<div class="form-group"><label>Employee Password</label><input id="paPass" type="password" placeholder="Portal password" autocomplete="new-password"></div>
<div class="form-group"><label>Assigned Contractor(s) <span style="color:#64748b;font-size:11px">(Multiple allowed)</span></label>
<div class="pa-contractor-dropdown" id="paContractorDropdown">
<button type="button" class="pa-contractor-toggle" onclick="toggleContractorDropdown()"><span id="paContractorSummary">Select Contractor(s)</span><span>▾</span></button>
<div class="pa-contractor-menu" id="paContractorMenu"></div>
</div>
<select id="paContractors" multiple hidden aria-hidden="true"></select>
<div style="font-size:11px;color:#64748b;margin-top:6px">Select one or multiple contractors from the dropdown.</div></div>
</div>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
<button type="button" class="btn btn-save" onclick="saveProjectAssignment()">Assign / Update Project & Contractor(s)</button>
<button type="button" class="btn" onclick="clearProjectAssignment()">Clear</button>
</div>
<div id="paStatus" style="margin-top:14px"></div>
<div style="margin-top:22px;padding-top:18px;border-top:1px solid var(--border)">
<h3 style="display:flex;justify-content:space-between;align-items:center">🕐 Shift Timings <button class="btn btn-save" style="font-size:11px;padding:6px 12px" onclick="saveShifts()">Save Shifts</button></h3>
<div class="form-group" style="max-width:420px">
<label>Shift</label>
<select id="shiftTimingSelector" onchange="loadShiftTiming()"><option value="shift1">Shift 1</option><option value="shift2">Shift 2</option></select>
<div id="shiftTimingPreview" style="font-size:12px;color:#64748b;margin-top:6px;padding:7px 10px;background:#f8fafc;border-radius:8px;text-align:center">08:00 AM – 06:00 PM</div>
</div>
<div class="grid">
<div class="form-group"><label>Start Time</label><input id="shiftSelectedStart" type="time" value="<?php echo htmlspecialchars($db['shifts']['shift1']['start']); ?>" onchange="previewShiftTiming()"></div>
<div class="form-group"><label>End Time</label><input id="shiftSelectedEnd" type="time" value="<?php echo htmlspecialchars($db['shifts']['shift1']['end']); ?>" onchange="previewShiftTiming()"></div>
</div>
<div style="font-size:12px;color:#64748b;margin-top:-4px">Shift 1: 08:00 AM – 06:00 PM &nbsp; • &nbsp; Shift 2: 09:00 AM – 07:00 PM</div>
</div>
</div>
</div>

<div id="tab-attendance" class="admin-tab">
<div class="card">
<h3>Attendance</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">View-only. To correct a missed day, approve it under the Requests tab — Admin can no longer edit a day's status directly here.</p>
<div class="grid">
<div class="form-group"><label>Month</label><select id="attM" onchange="renderAdminCalendar()"></select></div>
<div class="form-group"><label>Year</label><input id="attY" type="number" onchange="renderAdminCalendar()"></div>
<div class="form-group"><label>Employee</label><select id="attE" onchange="renderAdminCalendar()"></select></div>
</div>
<div id="calendar" class="cal-grid"></div>
<div id="payrollLockBar" style="margin-top:16px;padding:12px;border-radius:12px;background:#f8fafc;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"></div>
<div id="salaryPaidBar" style="margin-top:10px;padding:12px;border-radius:12px;background:#f8fafc;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"></div>
<div style="margin-top:25px;padding-top:20px;border-top:2px dashed var(--border)">
<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
<div>
<h4 style="margin:0">🕒 Punch History</h4>
<p style="color:#64748b;font-size:12px;margin:2px 0 0">Quick look at the latest day — expand for the rest of the month, or open the full record on its own page.</p>
</div>
<button type="button" class="btn" style="background:#e2e8f0;color:#334155;white-space:nowrap" onclick="openFullPunchHistoryPage()">⤢ Open Full History</button>
</div>
<div id="punchTodaySummary" style="margin-top:14px"></div>
<details id="punchHistoryDetails" style="margin-top:14px">
<summary style="cursor:pointer;font-weight:800;color:#4f46e5;font-size:12px">Show other days this month</summary>
<div id="punchHistory" style="margin-top:10px"></div>
</details>
</div>
</div>

<div class="card">
<h3>🎉 Company Holidays</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Holidays are paid like a Sunday. If an employee is marked Present on a holiday with "Double Pay" checked, one extra day's pay is added to their payslip.</p>
<div class="grid">
<div class="form-group"><label>Date</label><input id="holDate" type="date"></div>
<div class="form-group"><label>Name</label><input id="holName" placeholder="e.g. Independence Day"></div>
<div class="form-group"><label style="display:flex;align-items:center;gap:6px;margin-top:22px"><input id="holDouble" type="checkbox" style="width:auto"> Double pay if worked</label></div>
</div>
<button class="btn btn-save" onclick="saveHoliday()">Add Holiday</button>
<div id="holList" style="margin-top:15px"></div>
</div>
</div>

<div id="tab-advance" class="admin-tab">
<div class="card">
<h3>Salary Advance</h3>
<div class="grid">
<div class="form-group"><label>Employee</label><select id="advEmp" onchange="renderAdvanceList()"></select></div>
<div class="form-group"><label>Advance Date</label><input id="advDate" type="date"></div>
<div class="form-group"><label>Deduct From Salary Month</label><select id="advForMonth"></select></div>
<div class="form-group"><label>Amount</label><input id="advAmount" type="number"></div>
</div>
<div class="form-group"><label>Note (optional)</label><input id="advNote" placeholder="Reason / remarks"></div>
<button class="btn btn-save" onclick="saveSalaryAdvance()">Add Advance</button>
<hr style="margin:18px 0;border:none;border-top:1px solid var(--border)">
<div class="grid">
<div class="form-group"><label>Filter Month</label><select id="advM" onchange="renderAdvanceList()"></select></div>
<div class="form-group"><label>Filter Year</label><input id="advY" type="number" onchange="renderAdvanceList()"></div>
</div>
<div id="advList" style="margin-top:15px"></div>
</div>
</div>

<div id="tab-contractor" class="admin-tab">
<div class="card">
<h3>Contractors</h3>
<div class="form-group"><label>Contractor</label><select id="contractorSelector" onchange="loadContractor()"><option value="new">+ New Contractor</option></select></div>
<div class="grid">
<div class="form-group"><label>Contractor ID</label><input id="ctID"></div>
<div class="form-group"><label>Name</label><input id="ctName"></div>
<div class="form-group"><label>Mason Rate / Day</label><input id="ctMasonRate" type="number"></div>
<div class="form-group"><label>Helper Rate / Day</label><input id="ctHelperRate" type="number"></div>
<div class="form-group"><label>Carpenter Rate / Day</label><input id="ctCarpenterRate" type="number"></div>
<div class="form-group"><label>Plumber Rate / Day</label><input id="ctPlumberRate" type="number"></div>
<div class="form-group"><label>Painter Rate / Day</label><input id="ctPainterRate" type="number"></div>
<div class="form-group"><label>Contact</label><input id="ctContact"></div><div class="form-group"><label>Created By</label><input id="ctCreatedBy" readonly style="background:#f1f5f9"></div>
<div class="form-group"><label>Portal Username</label><input id="ctUser"></div>
<div class="form-group"><label>Portal Password</label><input id="ctPass" type="password" autocomplete="new-password"></div>
</div>
<button class="btn btn-save" onclick="saveContractor()">Save Contractor</button>
<button class="btn btn-danger delete-design-btn" onclick="deleteContractor()">Delete</button>

</div>
</div>

<div id="tab-contractorBill" class="admin-tab">
<div class="card">
<h3>Contractor Bill / Labour Payment</h3>
<p style="color:#64748b;font-size:12px;margin-top:-8px">Weekly (Mon–Sun) labour bill from Contractor Attendance. Record what was paid each week; any unpaid balance is added to the next week automatically. The contractor sees the same paid / balance figures in their portal.</p>
<div class="form-group"><label>Contractor</label><select id="lbSel" onchange="renderLabourBill('lb')"></select></div>
<div id="lbBody"></div>
</div>
</div>

<div id="tab-cashbookReport" class="admin-tab"><div class="cashbook-report-page-number" aria-hidden="true"></div>
<div class="card">
<h3>Employee-wise Cash Book Report</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Admin can view and print Cash Book reports only by selecting an employee.</p>
<div class="grid">
<div class="form-group"><label>Employee</label><select id="adminCashbookEmployee" onchange="renderAdminCashbookReport()"><option value="">Select Employee</option></select></div>
</div>
<div id="adminCashbookSummary" class="summary" style="margin-top:12px"></div>
<div id="adminCashbookList" style="margin-top:15px"></div>
<h4 style="margin:20px 0 0">🏦 Owner Direct Payments</h4>
<div id="adminOwnerPaySummary" class="summary" style="margin-top:12px"></div>
<div id="adminOwnerPayList" style="margin-top:15px"></div>
<h4 style="margin:20px 0 0">📊 Overall Site Spending</h4>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Overall Site Spending = Cash Book Expense + Owner Direct Payments.</p>
<div id="adminOverallSpendSummary" class="summary" style="margin-top:12px"></div>
<div style="margin-top:15px;display:flex;justify-content:flex-end">
<button id="adminCashbookPrintBtn" class="btn btn-primary hidden" onclick="printAdminCashbookReport()">🖨 Print / Report — A4</button>
</div>
</div>
</div>

<div id="tab-contractorAtt" class="admin-tab">
<div class="card">
<h3>Contractor Attendance</h3>
<p style="color:#64748b;font-size:12px;margin-top:-8px">Standard shift 9:00 AM – 6:00 PM. Click a day to enter the head count worked per trade (and any OT hours).</p>
<div class="grid">
<div class="form-group"><label>Month</label><select id="ctAttM" onchange="renderContractorCalendar()"></select></div>
<div class="form-group"><label>Year</label><input id="ctAttY" type="number" onchange="renderContractorCalendar()"></div>
<div class="form-group"><label>Contractor</label><select id="ctAttE" onchange="renderContractorCalendar()"></select></div>
</div>
<div id="contractorCalendar" class="cal-grid"></div>
<div id="ctDayEditor" class="hidden" style="margin-top:15px;padding:15px;border:2px dashed #c7d2fe;border-radius:16px">
<h4 id="ctDayEditorTitle" style="margin:0 0 10px">Day</h4>
<p style="color:#64748b;font-size:11px;margin-top:-6px">OT rate is auto-calculated per trade as Daily Rate ÷ 8 hours.</p>
<div class="grid">
<div class="form-group"><label>Mason Count</label><input id="ctCntMason" type="number" min="0"></div>
<div class="form-group"><label>Mason OT Hrs</label><input id="ctCntMasonOT" type="number" min="0"></div>
<div class="form-group"><label>Helper Count</label><input id="ctCntHelper" type="number" min="0"></div>
<div class="form-group"><label>Helper OT Hrs</label><input id="ctCntHelperOT" type="number" min="0"></div>
<div class="form-group"><label>Carpenter Count</label><input id="ctCntCarpenter" type="number" min="0"></div>
<div class="form-group"><label>Carpenter OT Hrs</label><input id="ctCntCarpenterOT" type="number" min="0"></div>
<div class="form-group"><label>Plumber Count</label><input id="ctCntPlumber" type="number" min="0"></div>
<div class="form-group"><label>Plumber OT Hrs</label><input id="ctCntPlumberOT" type="number" min="0"></div>
<div class="form-group"><label>Painter Count</label><input id="ctCntPainter" type="number" min="0"></div>
<div class="form-group"><label>Painter OT Hrs</label><input id="ctCntPainterOT" type="number" min="0"></div>
</div>
<button class="btn btn-save" onclick="saveDayCount()">Save Day</button>
</div>
<p id="ctPresentCount" style="margin-top:25px;font-weight:800;color:#059669"></p>
<div id="ctWeeklyPayment" style="margin-top:25px;padding-top:20px;border-top:2px dashed var(--border)"></div>
</div>
</div>
</div>
</div>
</div>

<div id="empView" class="hidden">
<div id="empRestrictedBanner" class="hidden" style="border:1px solid rgba(0,0,0,.08);padding:12px 16px;border-radius:12px;margin-bottom:14px;font-size:13px;font-weight:600"></div>
<div class="admin-layout">
<div class="admin-nav">
<button class="nav-tab-btn active" data-stab="today" onclick="showStaffTab('today')">Today's Attendance</button>
<button class="nav-tab-btn" data-stab="applyAtt" onclick="showStaffTab('applyAtt')">Apply Missed Attendance</button>
<button class="nav-tab-btn" data-stab="leave" onclick="showStaffTab('leave')">Apply Leave</button>
<button class="nav-tab-btn" data-stab="payslip" onclick="showStaffTab('payslip')">Payslip & Calendar</button>
<button class="nav-tab-btn" data-stab="advances" onclick="showStaffTab('advances')">Salary Advances</button>
<button class="nav-tab-btn" data-stab="cashbook" onclick="showStaffTab('cashbook')">Cash Book</button>
<button class="nav-tab-btn" data-stab="measurement" onclick="showStaffTab('measurement')">Measurement Sheet</button>
<button class="nav-tab-btn" data-stab="contractor" onclick="showStaffTab('contractor')">Add Contractor</button>
<button class="nav-tab-btn" data-stab="contractorAtt" onclick="showStaffTab('contractorAtt')">Contractor Attendance</button>
<button class="nav-tab-btn" data-stab="contractorBill" onclick="showStaffTab('contractorBill')">Contractor Bill</button>
<button class="nav-tab-btn" data-stab="settings" onclick="showStaffTab('settings');bioRefreshMenu()">Settings</button>
</div>
<div class="admin-content">

<div id="stab-settings" class="admin-tab"><div class="card"><h3 style="margin:0 0 12px">Settings</h3><div class="bio-settings-slot"></div></div></div>

<div id="stab-today" class="admin-tab active">
<div class="card">
<h3>Today's Attendance</h3>
<p style="color:#64748b;font-size:12px">Punch in when you arrive and punch out when you leave. Up to 4 hours worked = Half Day, more than that = Full Day — calculated automatically.</p>
<div style="display:flex;gap:10px;margin-top:10px">
<button class="btn btn-save" style="flex:1" onclick="selfPunch('IN')">🟢 Punch In</button>
<button class="btn btn-danger" style="flex:1" onclick="selfPunch('OUT')">🔴 Punch Out</button>
</div>
<div id="selfPunchBox" style="margin-top:15px;text-align:left"></div>
</div>
<div class="card" style="margin-top:15px">
<h3>Employee Attendance</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">View your day-wise attendance and punch history.</p>
<div class="grid">
<div class="form-group"><label>Month</label><select id="vM" onchange="renderStaffCalendar()"></select></div>
<div class="form-group"><label>Year</label><input id="vY" type="number" onchange="renderStaffCalendar()"></div>
</div>
<div id="staffCal" class="cal-grid"></div>
</div>
</div>

<div id="stab-applyAtt" class="admin-tab">
<div class="card">
<h3>Apply for Missed Attendance</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Missed attendance? Apply for <strong>Present, Half Day, OD</strong>, or a forgotten In/Out punch. You can submit a maximum of <strong>5 missed-attendance requests per month</strong>. Requests can only be raised for a date within the last 5 days.</p>
<div id="forgotPunchLimit" style="padding:10px 12px;border-radius:10px;background:#eff6ff;color:#1d4ed8;font-size:12px;font-weight:800;margin-bottom:12px"></div>
<div class="grid">
<div class="form-group"><label>Date</label><input id="reqDate" type="date"></div>
<div class="form-group"><label>Request Type</label><select id="reqPunchType" onchange="toggleMissedAttendanceFields()"><option value="IN">Forgot In Time</option><option value="OUT">Forgot Out Time</option><option value="ATTENDANCE">Missed Attendance</option></select></div>
</div>
<div class="grid">
<div class="form-group" id="reqPunchTimeGroup"><label>Actual Punch Time</label><input id="reqPunchTime" type="time"></div>
<div class="form-group hidden" id="reqAttendanceStatusGroup"><label>Attendance</label><select id="reqAttendanceStatus"><option value="P">Present</option><option value="H">Half Day</option><option value="OD">OD - On Duty</option></select></div>
<div class="form-group"><label>Reason</label><input id="reqReason" placeholder="Why was the attendance/punch missed?"></div>
</div>
<button id="submitForgotPunchBtn" class="btn btn-primary" style="width:100%;margin-top:10px" onclick="submitAttendanceRequest()">Submit Request</button>
</div>
<div class="card" style="margin-top:15px">
<h3>⏳ My Pending Requests</h3>
<div id="myRequestList"></div>
</div>
<div class="card" style="margin-top:15px">
<h3>📜 My Request History</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Past missed-attendance requests you submitted, and whether Admin approved or rejected them.</p>
<div class="form-group"><label>Select a past request</label><select id="myRequestHistorySelect" onchange="showMyRequestHistoryDetail()"></select></div>
<div id="myRequestHistoryDetail"></div>
</div>
</div>

<div id="stab-leave" class="admin-tab">
<div class="card">
<h3>Apply for Leave</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Select a leave type and date range. Your request goes to Admin (or your project's Authorised Manager) for approval.</p>
<div id="leaveBalanceBox" style="margin-bottom:12px"></div>
<div class="grid">
<div class="form-group"><label>Leave Type</label><select id="lvType"><option value="CL">CL - Casual Leave</option><option value="SL">SL - Sick Leave</option><option value="LOP">LOP - Loss of Pay</option><option value="OD">OD - On Duty</option></select></div>
<div class="form-group"><label>From</label><input id="lvFrom" type="date"></div>
<div class="form-group"><label>To</label><input id="lvTo" type="date"></div>
</div>
<div class="form-group"><label>Reason</label><input id="lvReason" placeholder="Reason for leave"></div>
<button id="submitLeaveBtn" class="btn btn-primary" style="width:100%;margin-top:10px" onclick="submitLeaveRequest()">Submit Leave Request</button>
</div>
<div class="card" style="margin-top:15px">
<h3>⏳ My Pending Leave Requests</h3>
<div id="myLeaveRequestList"></div>
</div>
<div class="card" style="margin-top:15px">
<h3>📜 My Leave History</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Past leave requests and whether they were approved or rejected.</p>
<div id="myLeaveHistoryList"></div>
</div>
<div id="leaveApprovalsCardStaff" class="card hidden" style="margin-top:15px">
<h3>Leave Approvals — Your Project</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">You're an Authorised Manager. Pending leave requests from employees on your project appear here.</p>
<div id="staffLeaveApprovalQueue"></div>
</div>
</div>

<div id="stab-myqr" class="admin-tab">
<div class="card" style="text-align:center">
<h3>My QR Code</h3>
<p style="color:#64748b;font-size:12px">Show this to the Security Guard's scanner to mark your attendance for the day.</p>
<div id="myQRBox" style="margin-top:15px"></div>
<p id="myQRIdLabel" style="margin-top:10px;font-weight:800;color:#334155"></p>
</div>
</div>

<div id="stab-measurement" class="admin-tab">
<div class="card">
<h3>Measurement Sheet</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Quantity = Nos × Length × Breadth × Depth. Leave unused fields blank. Tick Deduct for openings or deductions.</p>
<div class="grid">
<div class="form-group"><label>Date</label><input id="msDate" type="date"></div>
<div class="form-group"><label>Project</label><select id="msProject"></select></div>
<div class="form-group"><label>Sheet / Work Item</label><input id="msSheet" type="text" maxlength="100" placeholder="e.g. RCC Footing – Block A"></div>
<div class="form-group"><label>Description</label><input id="msDesc" type="text" maxlength="200" placeholder="e.g. F1 footing"></div>
<div style="grid-column:1/-1;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 12px"><div class="form-group"><label>Nos</label><input id="msNos" type="number" min="0" step="any" inputmode="decimal" oninput="msPreview()"></div>
<div class="form-group"><label>Length</label><input id="msL" type="number" min="0" step="any" inputmode="decimal" oninput="msPreview()"></div>
<div class="form-group"><label>Breadth</label><input id="msB" type="number" min="0" step="any" inputmode="decimal" oninput="msPreview()"></div>
<div class="form-group"><label>Depth / Height</label><input id="msD" type="number" min="0" step="any" inputmode="decimal" oninput="msPreview()"></div>
</div>
<div class="form-group"><label>Unit</label><select id="msUnit" onchange="msPreview()"><option>Cum</option><option>Sqm</option><option>Rmt</option><option>Nos</option><option>Kg</option><option>MT</option><option>Ltr</option><option>LS</option></select></div>
<div class="form-group"><label>Remarks (optional)</label><input id="msRemarks" type="text" maxlength="200"></div>
</div>
<div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;margin:4px 0 14px">
<label style="display:flex;align-items:center;gap:8px;margin:0;padding:0;text-transform:none;font-size:13px;color:#0f172a"><input id="msDeduct" type="checkbox" style="width:auto" onchange="msPreview()"> Deduct (−)</label>
<strong style="font-size:14px">Quantity: <span id="msQtyPreview">—</span></strong>
</div>
<button class="btn btn-save" style="width:100%" onclick="msAdd()">➕ Add Measurement</button>
</div>
<div class="card">
<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px"><h3 style="margin:0">📐 My Measurements</h3><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-primary" onclick="msPrint('msf')">🖨 Print</button><button class="btn btn-save" onclick="msPdf('msf')">⬇ PDF</button><button class="btn btn-save" onclick="msCsv('msf')">⬇ CSV</button></div></div>
<div class="grid" style="margin-top:12px">
<div class="form-group"><label>From</label><input id="msfFrom" type="date" onchange="renderStaffMeasurement()"></div>
<div class="form-group"><label>To</label><input id="msfTo" type="date" onchange="renderStaffMeasurement()"></div>
<div class="form-group"><label>Search</label><input id="msfSheetQ" type="text" placeholder="Sheet or description" oninput="renderStaffMeasurement()"></div>
</div>
<div id="msList" style="margin-top:6px"></div>
</div>
</div>

<div id="stab-idcard" class="admin-tab">
<div class="card">
<h3>My ID Card</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Your digital company ID card. Tap the card (or the Flip button) to see the back. Download saves both sides as a PNG.</p>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
<button class="btn btn-primary" onclick="generateMyIdCard(true)">Generate ID Card</button>
<button class="btn btn-save" onclick="downloadMyIdCard()">⬇ Download ID Card</button>
</div>
<div id="idCardLiveStatus" style="margin-top:8px;color:#64748b;font-size:12px">Card uses your latest employee details.</div>
</div>
</div>

<div id="stab-payslip" class="admin-tab">

<div class="card"><h2 id="staffName">Welcome</h2>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Select the month and year to generate your pay slip.</p>
<div class="grid">
<div class="form-group"><label>Month</label><select id="psM"></select></div>
<div class="form-group"><label>Year</label><input id="psY" type="number"></div>
</div>
<button class="btn btn-primary" style="width:100%;margin-top:10px" onclick="viewPayslipFresh()">View Payslip</button>
</div>
</div>

<div id="stab-advances" class="admin-tab">
<div class="card">
<h3 style="display:flex;align-items:center;justify-content:space-between;gap:8px">My Salary Advances <span id="salaryAdvanceLiveStatus" style="font-size:10px;font-weight:700;color:#16a34a;white-space:nowrap">● Live</span></h3>
<div class="grid">
<div class="form-group"><label>Filter Month</label><select id="stAdvM" onchange="renderStaffAdvances()"></select></div>
<div class="form-group"><label>Filter Year</label><input id="stAdvY" type="number" onchange="renderStaffAdvances()"></div>
</div>
<div id="staffAdvList" style="margin-top:15px"></div>
</div>
</div>

<div id="stab-cashbook" class="admin-tab">
<div class="card">
<h3>Cash Book</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Select the project and category, enter the amount, then choose Income or Expense.</p>
<div class="grid">
<div class="form-group"><label>Date</label><input id="scbDate" type="date"></div>
<div class="form-group"><label>Project</label><select id="scbProject"></select></div>
<div class="form-group"><label>Description</label><input id="scbDescription" type="text" maxlength="200" placeholder="Enter description"></div>
<div class="form-group"><label>Category</label><select id="scbCategory">
<option value="">Select Category</option>
<option value="Petrol">Petrol</option>
<option value="Petti cash">Petti cash</option>
<option value="Expenses">Expenses</option>
</select></div>
<div class="form-group"><label>Amount (₹)</label><input id="scbAmount" type="number" min="0" step="0.01" placeholder="Enter amount"></div>
<div class="form-group"><label>Entry Type</label><select id="scbType" onchange="updateCashBillLock()">
<option value="income">Income</option>
<option value="expense">Expense</option>
</select></div>
<div class="form-group" id="scbBillWrap"><label>Upload Cash Bill</label><input id="scbBill" type="file" accept="image/jpeg,image/png,image/webp,application/pdf"><small id="scbBillHelp" style="display:block;color:#64748b;margin-top:6px">Available for Income and Expense entries • JPG, PNG, WEBP or PDF • Photos are auto-compressed to about 60 KB (PDF max 6 MB)</small></div>
</div>
<button class="btn btn-save" style="width:100%" onclick="saveCashbookEntryStaff()">➕ Add Entry</button>
</div>
<div class="card">
<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px"><h3 style="margin:0">📒 My Cash Book</h3><button class="btn btn-primary" onclick="generateCashbookReport()">🖨 Print / Report</button></div>
<div id="scbSummary" class="summary" style="margin-top:15px"></div>
<div id="scbList" style="margin-top:10px;overflow-x:auto"></div>
</div>
<div class="card">
<h3>🏦 Owner Direct Payment</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Use this only when the Owner pays an amount directly (not handed to you as cash). It will NOT be added to the Cash Book, but it WILL be counted in the project's Overall Site Spending.</p>
<div class="grid">
<div class="form-group"><label>Date</label><input id="opDate" type="date"></div>
<div class="form-group"><label>Project</label><select id="opProject"></select></div>
<div class="form-group"><label>Paid To (optional)</label><input id="opPaidTo" type="text" maxlength="150" placeholder="Vendor / party name"></div>
<div class="form-group"><label>Description</label><input id="opDescription" type="text" maxlength="200" placeholder="Enter description"></div>
<div class="form-group"><label>Amount (₹)</label><input id="opAmount" type="number" min="0" step="0.01" placeholder="Enter amount"></div>
</div>
<button class="btn btn-save" style="width:100%" onclick="saveOwnerPaymentStaff()">➕ Add Owner Payment</button>
</div>
<div class="card">
<h3 style="margin:0">🏦 Owner Direct Payments</h3>
<div id="opSummary" class="summary" style="margin-top:15px"></div>
<div id="opList" style="margin-top:10px;overflow-x:auto"></div>
</div>
<div class="card">
<h3 style="margin:0">📊 Overall Site Spending</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Overall Site Spending = Cash Book Expense + Owner Direct Payments.</p>
<div id="overallSpendSummary" class="summary" style="margin-top:15px"></div>
</div>
</div>

<div id="stab-contractor" class="admin-tab">
<div class="card">
<h3>Assigned Contractors</h3>
<p style="color:#64748b;font-size:12px;margin-top:-6px">Contractors assigned to you by Admin are shown here. You can edit/update contractors only when access has been given to your employee account. Contractors you create are also controlled by you.</p>
<div id="staffContractorAccess" style="margin:10px 0"></div>
<div class="form-group"><label>Select Contractor</label><select id="sContractorSelector" onchange="loadContractorStaff()"><option value="new">+ New Contractor</option></select></div>
<div class="grid">
<div class="form-group"><label>Contractor ID</label><input id="sCtID"></div>
<div class="form-group"><label>Name</label><input id="sCtName"></div>
<div class="form-group"><label>Mason Rate / Day</label><input id="sCtMasonRate" type="number"></div>
<div class="form-group"><label>Helper Rate / Day</label><input id="sCtHelperRate" type="number"></div>
<div class="form-group"><label>Carpenter Rate / Day</label><input id="sCtCarpenterRate" type="number"></div>
<div class="form-group"><label>Plumber Rate / Day</label><input id="sCtPlumberRate" type="number"></div>
<div class="form-group"><label>Painter Rate / Day</label><input id="sCtPainterRate" type="number"></div>
<div class="form-group"><label>Contact</label><input id="sCtContact"></div>
<div class="form-group"><label>Portal Username</label><input id="sCtUser"></div>
<div class="form-group"><label>Portal Password</label><input id="sCtPass" type="password" autocomplete="new-password"></div>
</div>
<button class="btn btn-save" onclick="saveContractorStaff()">Save Contractor</button>
<button class="btn btn-danger delete-design-btn" onclick="deleteContractorStaff()">Delete</button>
</div>
</div>

<div id="stab-contractorBill" class="admin-tab">
<div class="card">
<h3>Contractor Bill / Labour Payment</h3>
<p style="color:#64748b;font-size:12px;margin-top:-8px">Weekly (Mon–Sun) labour bill for your assigned contractors. Record what was paid each week; any unpaid balance is added to the next week automatically.</p>
<div class="form-group"><label>Contractor</label><select id="slbSel" onchange="renderLabourBill('slb')"></select></div>
<div id="slbBody"></div>
</div>
</div>

<div id="stab-contractorAtt" class="admin-tab">
<div class="card">
<h3>Contractor Attendance</h3>
<p style="color:#64748b;font-size:12px;margin-top:-8px">Standard shift 9:00 AM – 6:00 PM. Click a day to enter the head count worked per trade (and any OT hours).</p>
<div class="grid">
<div class="form-group"><label>Contractor</label><select id="sCtAttE" onchange="renderContractorCalendarStaff()"></select></div>
<div class="form-group"><label>Month</label><select id="sCtAttM" onchange="renderContractorCalendarStaff()"></select></div>
<div class="form-group"><label>Year</label><input id="sCtAttY" type="number" onchange="renderContractorCalendarStaff()"></div>
</div>
<div id="sContractorCalendar" class="cal-grid"></div>
<div id="sCtDayEditor" class="hidden" style="margin-top:15px;padding:15px;border:2px dashed #c7d2fe;border-radius:16px">
<h4 id="sCtDayEditorTitle" style="margin:0 0 10px">Day</h4>
<p style="color:#64748b;font-size:11px;margin-top:-6px">OT rate is auto-calculated per trade as Daily Rate ÷ 8 hours.</p>
<div class="grid">
<div class="form-group"><label>Mason Count</label><input id="sCtCntMason" type="number" min="0"></div>
<div class="form-group"><label>Mason OT Hrs</label><input id="sCtCntMasonOT" type="number" min="0"></div>
<div class="form-group"><label>Helper Count</label><input id="sCtCntHelper" type="number" min="0"></div>
<div class="form-group"><label>Helper OT Hrs</label><input id="sCtCntHelperOT" type="number" min="0"></div>
<div class="form-group"><label>Carpenter Count</label><input id="sCtCntCarpenter" type="number" min="0"></div>
<div class="form-group"><label>Carpenter OT Hrs</label><input id="sCtCntCarpenterOT" type="number" min="0"></div>
<div class="form-group"><label>Plumber Count</label><input id="sCtCntPlumber" type="number" min="0"></div>
<div class="form-group"><label>Plumber OT Hrs</label><input id="sCtCntPlumberOT" type="number" min="0"></div>
<div class="form-group"><label>Painter Count</label><input id="sCtCntPainter" type="number" min="0"></div>
<div class="form-group"><label>Painter OT Hrs</label><input id="sCtCntPainterOT" type="number" min="0"></div>
</div>
<button class="btn btn-save" onclick="saveDayCountStaff()">Save Day</button>
</div>
<p id="sCtPresentCount" style="margin-top:25px;font-weight:800;color:#059669"></p>
<div id="sCtWeeklyPayment" style="margin-top:25px;padding-top:20px;border-top:2px dashed var(--border)"></div>
</div>
</div>
</div>
</div>
</div>
</div>

<div id="securityView" class="hidden">
<div class="card" style="max-width:460px;margin:20px auto;text-align:center">
<h3>🛡️ Security Guard — Attendance Scanner</h3>
<p style="color:#4f46e5;font-weight:800;font-size:13px;margin-top:-8px">📍 <span id="securitySiteLabel"></span></p>
<div id="scanStatus" style="margin:15px 0;min-height:24px;font-weight:800"></div>

<div style="padding:15px;border:2px solid #4f46e5;border-radius:16px;background:#eef2ff">
<h4 style="margin:0 0 8px">Enter Employee ID</h4>
<p style="color:#475569;font-size:12px;margin-bottom:10px">Type or paste the ID from the employee's QR card, then mark In or Out.</p>
<input id="manualEmpId" placeholder="Employee ID" style="width:100%;text-align:center;font-weight:800;font-size:16px">
<div style="display:flex;gap:8px;margin-top:10px">
<button class="btn btn-save" style="flex:1" onclick="manualPunch('IN')">🟢 Mark In</button>
<button class="btn btn-danger" style="flex:1" onclick="manualPunch('OUT')">🔴 Mark Out</button>
</div>
</div>

<div style="margin-top:20px;padding-top:15px;border-top:1px solid var(--border)">
<div id="scanWrap" style="position:relative;width:100%;max-width:360px;margin:0 auto;display:none;line-height:0"><video id="scanVideo" style="width:100%;border-radius:16px;background:#000;display:block" playsinline muted autoplay></video><canvas id="scanOverlay" style="position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;border-radius:16px"></canvas></div>
<canvas id="scanCanvas" style="display:none"></canvas>
<div style="display:flex;gap:10px;margin-top:10px">
<button id="scanInBtn" class="btn btn-save" style="flex:1" onclick="startScan('IN')">🟢 In Time (camera)</button>
<button id="scanOutBtn" class="btn btn-danger" style="flex:1;opacity:0.5" onclick="startScan('OUT')">🔴 Out Time (camera)</button>
</div>
<button id="scanStopBtn" class="btn hidden" style="width:100%;margin-top:10px;background:#64748b;color:#fff" onclick="stopScan()">Stop Scan</button>
</div>

<div id="scanLog" style="margin-top:20px;text-align:left;max-height:220px;overflow-y:auto"></div>
</div>
<div class="card" style="max-width:460px;margin:20px auto"><h3 style="margin:0 0 12px">Settings</h3><div class="bio-settings-slot"></div></div>
</div>

<div id="contractorPortalView" class="hidden">
<div id="cpPayBanner"></div>
<div id="cpPaneTabs" class="lb-pane-tabs"><button type="button" class="active" data-pane="att" onclick="cpShowTab('att')">Attendance</button><button type="button" data-pane="bill" onclick="cpShowTab('bill')">Bill / Labour Payment</button></div>
<div class="card hidden" id="cpBillCard"><h3>Contractor Bill / Labour Payment — <span id="cpBillName"></span></h3><p style="color:#64748b;font-size:12px">Your weekly labour bill, what has been paid, and the balance carried to the next week.</p><div id="clbBody"></div></div>
<div class="card" id="cpAttCard">
<div class="manual-refresh-bar"><button type="button" id="cpManualRefresh" onclick="cpManualRefresh(this)">↻ Refresh</button></div>
<h3>Contractor Portal — <span id="cpContractorName"></span></h3>
<div class="grid" style="margin-top:8px">
<div class="form-group"><label>Month</label><select id="cpAttM" onchange="renderContractorPortal()"></select></div>
<div class="form-group"><label>Year</label><input id="cpAttY" type="number" onchange="renderContractorPortal()"></div>
</div>
<div id="cpDashboard" style="margin:8px 0 12px"></div>
<details style="margin-top:8px"><summary style="cursor:pointer;font-weight:800;font-size:13px;padding:8px 0">Weekly payment details</summary>
<div id="cpWeeklyPayment" style="margin-top:8px"></div>
<button class="btn btn-save" style="width:100%;margin-top:12px" onclick="downloadWeeklyStatement()">⬇ Download Weekly Statement (CSV)</button>
</details>
</div>
</div>
</div>
<div id="fullPageDisplay" class="hidden"><div class="ps-full-page"><div id="payslipTarget"></div></div></div>

<div id="punchModalOverlay" class="modal-overlay hidden" onclick="if(event.target===this)closePunchModal()">
<div class="modal-box">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
<h3 id="punchModalTitle" style="margin:0;font-size:15px">🕒 Punch History</h3>
<button type="button" class="modal-close-btn" onclick="closePunchModal()">✕</button>
</div>
<div id="punchModalSummary"></div>
<div id="punchModalRows"></div>
</div>
<div class="card"><h3 style="margin:0 0 12px">Settings</h3><div class="bio-settings-slot"></div></div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js">
</script>
<script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js">
</script>
<script>let db=<?php echo json_encode(cpScopeDb(pwPublicDb($db)),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); ?>;
let sessionUser=null,sessionSite=null,sessionContractor=null,logoData=db.company.logo||'',sealData=db.company.seal||'',employeePhotoData='',sessionRestricted=false,sessionTerminationDate='',sessionRestrictionReason='';
/* Custom in-app notification — replaces the native alert() popup so the
browser never shows "The page at ... says:"; only the action message appears. */
function notifyUser(message){
const existing=document.querySelector('.notify-overlay');if(existing)existing.remove();
const overlay=document.createElement('div');overlay.className='notify-overlay';
overlay.innerHTML=`<div class="notify-box"><div class="notify-msg"></div><div class="notify-actions"><button type="button" class="notify-ok">OK</button></div></div>`;
overlay.querySelector('.notify-msg').textContent=String(message??'');
const close=()=>overlay.remove();
overlay.querySelector('.notify-ok').addEventListener('click',close);
overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){close();document.removeEventListener('keydown',esc);}});
document.body.appendChild(overlay);
overlay.querySelector('.notify-ok').focus();
}
window.alert=notifyUser;
const months=['January','February','March','April','May','June','July','August','September','October','November','December'];
async function server(action,data,__retry){
try{
const response=await fetch(location.pathname+'?action='+encodeURIComponent(action),{method:'POST',headers:{'Content-Type':'application/json','X-Tab':(function(){try{return localStorage.getItem('swTab')||''}catch(e){return ''}})()},body:JSON.stringify(data)});
const text=await response.text();let result;try{result=JSON.parse(text)}catch(e){
 /* Hosting throttle / error page instead of JSON. Safe read-only actions are retried once automatically. */
 if(!__retry&&['session_check','idle_ping','refresh_portal_data'].indexOf(action)>=0){await new Promise(r=>setTimeout(r,1500));return server(action,data,true);}
 return{status:'error',message:'The server is busy or sent an unexpected reply (HTTP '+response.status+'). Please wait a few seconds and try again.',details:text.replace(/<[^>]*>/g,' ').trim().slice(0,200)}}
const lb=document.getElementById('logoutBtn');const uiLoggedIn=!!lb&&!lb.classList.contains('hidden');
if(result&&result.session_expired&&uiLoggedIn&&!window.__swExpiring){window.__swExpiring=true;alert(result.message);setTimeout(()=>location.reload(),400);}
return result;
}catch(error){return{status:'error',message:'Cannot connect to server.',details:error.message}}
}
function encodeImage(input,type){
if(!input.files||!input.files[0])return;
const file=input.files[0];
if(file.size>2*1024*1024){alert('Please use an image below 2 MB.');input.value='';return}
const reader=new FileReader();
reader.onload=e=>{
if(type==='logo'){
logoData=e.target.result;
db.company.logo=logoData;
updateBranding();
}else if(type==='seal'){
sealData=e.target.result;
}
};
reader.readAsDataURL(file);
input.value='';
}
function encodeEmployeePhoto(input){
if(!input.files||!input.files[0])return;
const file=input.files[0];
if(!file.type||!file.type.startsWith('image/')){alert('Please select a valid image file.');input.value='';return}
if(file.size>20*1024*1024){alert('Please use an image below 20 MB.');input.value='';return}
const reader=new FileReader();
reader.onload=e=>{
const img=new Image();
img.onload=()=>{
const maxDim=700;let w=img.width,h=img.height;
if(w>maxDim||h>maxDim){if(w>h){h=Math.round(h*maxDim/w);w=maxDim}else{w=Math.round(w*maxDim/h);h=maxDim}}
const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
const ctx=canvas.getContext('2d');ctx.drawImage(img,0,0,w,h);
let quality=0.82,dataUrl=canvas.toDataURL('image/jpeg',quality);
while(dataUrl.length>700000&&quality>0.35){quality-=0.15;dataUrl=canvas.toDataURL('image/jpeg',quality)}
employeePhotoData=dataUrl;
const p=document.getElementById('ePhotoPreview');p.src=employeePhotoData;p.style.display='inline-block';
};
img.onerror=()=>{alert('Could not read that image. Please try another file.')};
img.src=e.target.result;
};
reader.onerror=()=>{alert('Could not read that file.')};
reader.readAsDataURL(file);
input.value='';
}
function removeEmployeePhoto(){
employeePhotoData='';
const p=document.getElementById('ePhotoPreview');p.src='';p.style.display='none';
const f=document.getElementById('ePhotoFile');if(f)f.value='';
const c=document.getElementById('ePhotoCamera');if(c)c.value='';
}
async function saveCompany(){
const addrEl=document.getElementById('cAddr'), sizeEl=document.getElementById('cSize'), loginSizeEl=document.getElementById('cLoginSize');
if(!addrEl||!sizeEl){alert('Company Profile form is incomplete. Please reload the page.');return}
const addr=addrEl.value.replace(/[\r\n]+/g,' ').replace(/\s+/g,' ').trim();
const size=Number(sizeEl.value)||80;
const login_size=Number(loginSizeEl?loginSizeEl.value:160)||160;
const result=await server('save_company',{name:db.company.name||'',addr,size,login_size,logo:logoData,seal:sealData});
if(result.status==='success'){db.company.addr=addr;db.company.size=size;db.company.login_size=login_size;if(logoData)db.company.logo=logoData;if(sealData)db.company.seal=sealData;updateBranding();alert(result.message);}else alert(result.message+(result.details?'\n\n'+result.details:''));
}
function liveLogoSize(value){
const size=Math.max(40,Math.min(200,Number(value)||80));
const val=document.getElementById('cSizeVal');
if(val)val.innerText=size+'px';
db.company.size=size;
const navLogo=document.getElementById('navLogo');
if(navLogo){navLogo.style.height=size+'px';navLogo.style.width='auto';}document.documentElement.style.setProperty('--nav-logo-h',size+'px');
const siteNav=document.getElementById('siteNav');
if(siteNav)siteNav.style.minHeight=Math.max(64,size+24)+'px';
document.querySelectorAll('.pay-logo').forEach(img=>{
img.style.width=size+'px';
img.style.height='auto';
});
}
function liveLoginLogoSize(value){
const size=Math.max(40,Math.min(400,Number(value)||160));
const val=document.getElementById('cLoginSizeVal');
if(val)val.innerText=size+'px';
db.company.login_size=size;
document.documentElement.style.setProperty('--login-logo-w',size+'px');
document.querySelectorAll('.login-logo-fallback').forEach(el=>{
el.style.width=size+'px';
el.style.height=size+'px';
});
document.querySelectorAll('.login-portal-logo').forEach(el=>{
el.style.width=size+'px';
el.style.height='auto';
el.style.maxWidth='100%';
});
}
function updateBranding(){
const logo=document.getElementById('navLogo');
if(logo){
if(db.company.logo){logo.src=db.company.logo;logo.style.display='block';}
else{logo.style.display='none';}
logo.style.height=(db.company.size||80)+'px';
}
liveLogoSize(db.company.size||80);
liveLoginLogoSize(db.company.login_size||160);
}
function fitNavTitle(){}
async function saveAdmin(){
const result=await server('save_admin_creds',{user:document.getElementById('aUser').value.trim(),pass:document.getElementById('aPass').value});
if(result.status==='success'){db.admin.user=document.getElementById('aUser').value.trim();document.getElementById('aPass').value=''}
alert(result.message+(result.details?'\n\n'+result.details:''));
}
async function saveSecurity(){
const sites=[1,2].map(i=>({site:document.getElementById('sgSite'+i).value.trim(),user:document.getElementById('sgUser'+i).value.trim(),pass:document.getElementById('sgPass'+i).value}));
const result=await server('save_security_creds',{sites});
if(result.status==='success'){db.security=sites.map(x=>({site:x.site,user:x.user,pass:'',has_pass:true}));[1,2].forEach(i=>{document.getElementById('sgPass'+i).value='';});}
alert(result.message+(result.details?'\n\n'+result.details:''));
}
function calculateMonthlySalary(){return ['eBasic','eHRA','eLTA','eSpecial','eMobile'].reduce((sum,id)=>sum+(Number(document.getElementById(id)?.value)||0),0)}
function calculateAnnualCTC(){const annual=calculateMonthlySalary()*12;const el=document.getElementById('eSalaryCTC');if(el)el.value=annual||'';return annual}
function updateSalaryCTC(){calculateAnnualCTC()}
function fieldValue(id){const el=document.getElementById(id);return el?el.value:'';}
function employeeData(){return{
id:fieldValue('eID').trim(),name:fieldValue('eName').trim(),des:fieldValue('eDes').trim(),project:fieldValue('eProject'),doj:fieldValue('eDOJ'),dob:fieldValue('eDOB'),grade:fieldValue('eGrade').trim(),bank:fieldValue('eBank').trim(),acc:fieldValue('eAcc').trim(),ctc:calculateAnnualCTC(),pan:fieldValue('ePAN').trim(),uan:fieldValue('eUAN').trim(),esi_no:fieldValue('eESINo').trim(),photo:employeePhotoData,basic_rate:Number(fieldValue('eBasic'))||0,hra_rate:Number(fieldValue('eHRA'))||0,lta_rate:Number(fieldValue('eLTA'))||0,special_rate:Number(fieldValue('eSpecial'))||0,mobile_rate:Number(fieldValue('eMobile'))||0,pf_ded:Number(fieldValue('ePF'))||0,pt_ded:Number(fieldValue('ePT'))||0,emp_pf_ded:Number(fieldValue('eEPF'))||0,is_manager:!!document.getElementById('eIsManager')?.checked}}
function projectEmployeeOptions(list){
const sel=document.getElementById('paEmployeeSelector');if(!sel)return;
const current=sel.value;sel.innerHTML='<option value="">Select Employee</option>'+list.map(e=>`<option value="${escapeHTML(e.id||'')}">${escapeHTML(e.name||'')} — ${escapeHTML(e.id||'')}</option>`).join('');
if(list.some(e=>String(e.id)===String(current)))sel.value=current;
}
function filterProjectEmployees(){
const q=(document.getElementById('paEmployeeSearch').value||'').trim().toLowerCase();
const list=activeEmployees().filter(e=>!q||String(e.name||'').toLowerCase().includes(q)||String(e.id||'').toLowerCase().includes(q));
projectEmployeeOptions(list);
}
function toggleContractorDropdown(){document.getElementById('paContractorMenu')?.classList.toggle('open');}
function closeContractorDropdown(e){const box=document.getElementById('paContractorDropdown');if(box&&!box.contains(e.target))document.getElementById('paContractorMenu')?.classList.remove('open');}
document.addEventListener('click',closeContractorDropdown);
function renderContractorDropdown(){
const menu=document.getElementById('paContractorMenu'), sel=document.getElementById('paContractors'), summary=document.getElementById('paContractorSummary'); if(!menu||!sel||!summary)return;
const selected=new Set([...sel.selectedOptions].map(o=>String(o.value)));
const contractors=db.contractors||[];
if(!contractors.length){menu.innerHTML='<div class="pa-contractor-empty">No contractors available</div>';summary.textContent='No contractors available';return;}
menu.innerHTML=contractors.map(c=>{const id=String(c.id||'');const label=`${escapeHTML(c.name||'')} — ${escapeHTML(c.id||'')}`;return `<label class="pa-contractor-option"><input type="checkbox" value="${escapeHTML(id)}" ${selected.has(id)?'checked':''} onchange="toggleContractorSelection(this)"><span>${label}</span></label>`;}).join('');
const names=[...sel.selectedOptions].map(o=>o.textContent.trim()); summary.textContent=names.length?`${names.length} contractor${names.length>1?'s':''} selected`:'Select Contractor(s)';
}
function toggleContractorSelection(cb){const sel=document.getElementById('paContractors');if(!sel)return;const opt=[...sel.options].find(o=>String(o.value)===String(cb.value));if(opt)opt.selected=cb.checked;renderContractorDropdown();}
function loadProjectAssignment(){
const id=document.getElementById('paEmployeeSelector').value;
const e=(db.employees||[]).find(x=>String(x.id)===String(id));
const p=document.getElementById('paProject'), c=document.getElementById('paContractors');
if(!e){p.value='';document.getElementById('paUser').value='';document.getElementById('paPass').value='';document.getElementById('paShift').value='shift1';syncProjectShiftTime();[...c.options].forEach(o=>o.selected=false);renderContractorDropdown();document.getElementById('paStatus').innerHTML='';return;}
p.value=e.project||'';
document.getElementById('paShift').value=e.shift||'shift1';
syncProjectShiftTime();
document.getElementById('paUser').value=e.user||'';
document.getElementById('paPass').value='';document.getElementById('paPass').placeholder=e.has_pass?'Leave blank to keep current password':'Portal password';
const ids=(e.contractor_ids||((e.contractor_id||'')?[e.contractor_id]:[])).map(String);
[...c.options].forEach(o=>o.selected=ids.includes(String(o.value)));
renderContractorDropdown();
document.getElementById('paStatus').innerHTML=`<span style="color:#475569">Selected: <b>${escapeHTML(e.name||'')}</b> (${escapeHTML(e.id||'')})</span>`;
}
async function saveProjectAssignment(){
const employeeId=document.getElementById('paEmployeeSelector').value.trim();
if(!employeeId){alert('Select an employee first.');return;}
const project=document.getElementById('paProject').value.trim();
const shift=document.getElementById('paShift').value;
const user=document.getElementById('paUser').value.trim();
const pass=document.getElementById('paPass').value;
const contractorIds=[...document.getElementById('paContractors').selectedOptions].map(o=>o.value).filter(Boolean);
const credResult=await server('assign_employee_credentials',{employee_id:employeeId,user,pass});
if(credResult.status!=='success'){alert(credResult.message);return;}
const pResult=await server('assign_employee_project',{employee_id:employeeId,project,shift});
if(pResult.status!=='success'){alert(pResult.message);return;}
const cResult=await server('assign_employee_contractors',{employee_id:employeeId,contractor_ids:contractorIds});
if(cResult.status!=='success'){alert(cResult.message);return;}
const e=db.employees.find(x=>String(x.id)===String(employeeId));
if(e){if(user){e.user=user;if(pass)e.has_pass=true;}e.project=project;e.shift=shift;e.contractor_ids=contractorIds;e.contractor_id=contractorIds[0]||'';}
for(const c of db.contractors||[]){const ids=new Set((c.assigned_employee_ids||[]).map(String));if(contractorIds.map(String).includes(String(c.id)))ids.add(String(employeeId));else ids.delete(String(employeeId));c.assigned_employee_ids=[...ids];}
syncEmployees();syncContractors();loadProjectAssignment();
document.getElementById('paStatus').innerHTML='<span style="color:#166534;font-weight:700">Project and Contractor assignment updated successfully.</span>';
}
function clearProjectAssignment(){document.getElementById('paEmployeeSearch').value='';document.getElementById('paEmployeeSelector').value='';document.getElementById('paProject').value='';document.getElementById('paShift').value='shift1';syncProjectShiftTime();document.getElementById('paUser').value='';document.getElementById('paPass').value='';[...document.getElementById('paContractors').options].forEach(o=>o.selected=false);renderContractorDropdown();document.getElementById('paStatus').innerHTML='';filterProjectEmployees();}
async function saveEmployee(){
const employee=employeeData();if(!employee.id){alert('Employee ID is required.');return}
const result=await server('save_employee',employee);
if(result.status==='success'){const index=db.employees.findIndex(e=>e.id===employee.id);if(index>=0)db.employees[index]={...db.employees[index],...employee};else db.employees.push(employee);
syncEmployees();syncContractors()}
alert(result.message+(result.details?'\n\n'+result.details:''));
}
function loadEmployee(){
const id=document.getElementById('empSelector').value;if(id==='new'){clearEmployee();return}
const e=db.employees.find(x=>x.id===id);if(!e)return;
const map={eID:'id',eName:'name',eDes:'des',eProject:'project',eDOJ:'doj',eDOB:'dob',eGrade:'grade',eBank:'bank',eAcc:'acc',ePAN:'pan',eUAN:'uan',eESINo:'esi_no',eBasic:'basic_rate',eHRA:'hra_rate',eLTA:'lta_rate',eSpecial:'special_rate',eMobile:'mobile_rate',ePF:'pf_ded',ePT:'pt_ded',eEPF:'emp_pf_ded'};
Object.keys(map).forEach(id=>document.getElementById(id).value=e[map[id]]??(id==='eShift'?'shift1':''));
const mgr=document.getElementById('eIsManager');if(mgr)mgr.checked=!!e.is_manager;
employeePhotoData=e.photo||'';
const p=document.getElementById('ePhotoPreview');
if(employeePhotoData){p.src=employeePhotoData;p.style.display='inline-block';}else{p.src='';p.style.display='none';}
const ne=document.getElementById('eNoticeEnd'),nr=document.getElementById('eNoticeReason');
if(ne)ne.value=e.notice_period_end||'';
if(nr)nr.value=e.notice_period_reason||'';
renderEmployeeStatusBanner(e);
}
function clearEmployee(){['eID','eName','eDes','eProject','eDOJ','eDOB','eGrade','eBank','eAcc','ePAN','eUAN','eESINo','eBasic','eHRA','eLTA','eSpecial','eMobile','ePF','ePT','eEPF','eNoticeEnd','eNoticeReason'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});const mgr=document.getElementById('eIsManager');if(mgr)mgr.checked=false;const qr=document.getElementById('empQRBox');if(qr)qr.innerHTML='';removeEmployeePhoto();renderEmployeeStatusBanner(null);}
function employeeAccessState(e){
if(!e)return{blocked:false,restricted:false,anchorDate:null,reason:''};
let anchor=null,reason='';
if(e.terminated&&e.termination_date){anchor=e.termination_date;reason='terminated';}
else if(e.notice_period_end){anchor=e.notice_period_end;reason='notice_period';}
if(!anchor)return{blocked:false,restricted:false,anchorDate:null,reason:''};
const anchorDt=new Date(anchor+'T00:00:00');
if(Number.isNaN(anchorDt.getTime()))return{blocked:false,restricted:false,anchorDate:null,reason:''};
const today=new Date();today.setHours(0,0,0,0);
if(today<=anchorDt)return{blocked:false,restricted:false,anchorDate:anchor,reason};
const closes=new Date(anchorDt);closes.setDate(closes.getDate()+15);
if(today>closes)return{blocked:true,restricted:false,anchorDate:anchor,reason,closeDate:closes};
return{blocked:false,restricted:true,anchorDate:anchor,reason,closeDate:closes};
}
async function setNoticePeriod(){
const id=fieldValue('eID').trim();
if(!id){alert('Select an employee first.');return}
const end=fieldValue('eNoticeEnd');
if(!end){alert('Pick the last working day.');return}
const reason=fieldValue('eNoticeReason').trim();
if(!confirm('Set notice period ending '+end+' for this employee?\n\nThey keep full access until then. After that, the account stays live for 15 more days (Payslip & Calendar only), then login locks automatically.'))return;
const result=await server('set_notice_period',{id,end_date:end,reason});
if(result.status==='success'){
const idx=db.employees.findIndex(x=>x.id===id);
if(idx>=0){db.employees[idx].notice_period_end=end;db.employees[idx].notice_period_reason=reason;}
syncEmployees();
renderEmployeeStatusBanner(db.employees.find(x=>x.id===id));
}
alert(result.message);
}
async function clearNoticePeriod(){
const id=fieldValue('eID').trim();
if(!id){alert('Select an employee first.');return}
if(!confirm('Clear the notice period for this employee? Full normal access continues.'))return;
const result=await server('clear_notice_period',{id});
if(result.status==='success'){
const idx=db.employees.findIndex(x=>x.id===id);
if(idx>=0){db.employees[idx].notice_period_end='';db.employees[idx].notice_period_reason='';}
syncEmployees();
const ne=document.getElementById('eNoticeEnd'),nr=document.getElementById('eNoticeReason');
if(ne)ne.value='';if(nr)nr.value='';
renderEmployeeStatusBanner(db.employees.find(x=>x.id===id));
}
alert(result.message);
}
function employeeAccessCloseDate(dateStr){
if(!dateStr)return null;
const d=new Date(dateStr+'T00:00:00');
if(Number.isNaN(d.getTime()))return null;
d.setDate(d.getDate()+15);
return d;
}
function renderEmployeeStatusBanner(e){
const banner=document.getElementById('empStatusBanner');
const termBtn=document.getElementById('empTerminateBtn');
const reinstBtn=document.getElementById('empReinstateBtn');
const rejoinBtn=document.getElementById('empRejoinBtn');
const clearNoticeBtn=document.getElementById('empClearNoticeBtn');
if(!banner)return;
const history=(e&&Array.isArray(e.employment_history))?e.employment_history:[];
const historyLine=history.length?('<div style="margin-top:6px;font-weight:500">📋 '+history.length+' prior termination/rejoin cycle'+(history.length>1?'s':'')+' on record — last rejoined '+escapeHTML(history[history.length-1].rejoin_date||'—')+'.</div>'):'';
if(clearNoticeBtn)clearNoticeBtn.style.display=(e&&e.notice_period_end)?'':'none';
if(!e||!e.terminated){
if(termBtn)termBtn.style.display='';
if(reinstBtn)reinstBtn.style.display='none';
if(rejoinBtn)rejoinBtn.style.display='none';
if(e&&e.notice_period_end){
const state=employeeAccessState(e);
const endText=new Date(e.notice_period_end+'T00:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});
banner.classList.remove('hidden');
if(!state.blocked&&!state.restricted){
banner.style.background='#eff6ff';banner.style.color='#1d4ed8';
banner.innerHTML='📅 <strong>Notice period</strong> — last working day '+endText+(e.notice_period_reason?(' — '+escapeHTML(e.notice_period_reason)):'')+'. Full access continues until then; the account then stays live for 15 more days (Payslip &amp; Calendar only) before login locks.'+historyLine;
}else if(state.restricted){
const closeText=state.closeDate?state.closeDate.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}):'—';
banner.style.background='#fffbeb';banner.style.color='#b45309';
banner.innerHTML='⏳ Notice period ended on '+endText+'. Account access is now restricted to Payslip &amp; Calendar until '+closeText+'.'+historyLine;
}else{
banner.style.background='#f1f5f9';banner.style.color='#475569';
banner.innerHTML='🔒 Notice period ended on '+endText+'. The 15-day access window has closed — login is now blocked.'+historyLine;
}
return;
}
if(!historyLine){banner.classList.add('hidden');banner.innerHTML='';return;}
banner.classList.remove('hidden');
banner.style.background='#f1f5f9';banner.style.color='#475569';
banner.innerHTML=historyLine;
return;
}
const close=employeeAccessCloseDate(e.termination_date);
const now=new Date();now.setHours(0,0,0,0);
const expired=close?now>close:false;
const closeText=close?close.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}):'—';
banner.classList.remove('hidden');
banner.style.background=expired?'#f1f5f9':'#fef2f2';
banner.style.color=expired?'#475569':'#b91c1c';
banner.innerHTML='⛔ <strong>Terminated</strong> on '+escapeHTML(e.termination_date||'—')+(e.termination_reason?(' — '+escapeHTML(e.termination_reason)):'')+'. Account access (payslip download only) '+(expired?'closed on ':'closes on ')+closeText+(expired?' — login is now blocked.':' (15-day window).')+historyLine;
if(termBtn)termBtn.style.display='none';
if(reinstBtn)reinstBtn.style.display='';
if(rejoinBtn)rejoinBtn.style.display='';
}
async function terminateEmployee(){
const id=fieldValue('eID').trim();
if(!id){alert('Select an employee first.');return}
if(!confirm('Mark this employee as terminated?\n\nTheir account will stay active for 15 days for payslip download / account access only, then login will be blocked.'))return;
const reason=prompt('Reason for termination (optional):','')||'';
const result=await server('terminate_employee',{id,reason});
if(result.status==='success'){
const idx=db.employees.findIndex(x=>x.id===id);
if(idx>=0){db.employees[idx].terminated=true;db.employees[idx].termination_date=result.termination_date||new Date().toISOString().slice(0,10);db.employees[idx].termination_reason=reason;}
syncEmployees();
renderEmployeeStatusBanner(db.employees.find(x=>x.id===id));
}
alert(result.message);
}
async function reinstateEmployee(){
const id=fieldValue('eID').trim();
if(!id){alert('Select an employee first.');return}
if(!confirm('Reinstate this employee and restore full login access?'))return;
const result=await server('reinstate_employee',{id});
if(result.status==='success'){
const idx=db.employees.findIndex(x=>x.id===id);
if(idx>=0){db.employees[idx].terminated=false;db.employees[idx].termination_date='';db.employees[idx].termination_reason='';}
syncEmployees();
renderEmployeeStatusBanner(db.employees.find(x=>x.id===id));
}
alert(result.message);
}
async function rejoinEmployee(){
const id=fieldValue('eID').trim();
if(!id){alert('Select an employee first.');return}
const today=new Date().toISOString().slice(0,10);
const rejoinDate=prompt('Rejoin date (YYYY-MM-DD):',today);
if(rejoinDate===null)return;
if(!confirm('Mark this employee as rejoined on '+rejoinDate+'?\n\nFull login access will be restored and the earlier termination will be kept on their record.'))return;
const result=await server('rejoin_employee',{id,rejoin_date:rejoinDate});
if(result.status==='success'){
const idx=db.employees.findIndex(x=>x.id===id);
if(idx>=0){
const e=db.employees[idx];
if(e.terminated){
if(!Array.isArray(e.employment_history))e.employment_history=[];
e.employment_history.push({termination_date:e.termination_date||'',termination_reason:e.termination_reason||'',rejoin_date:result.rejoin_date||rejoinDate});
}
e.terminated=false;e.termination_date='';e.termination_reason='';
}
syncEmployees();
renderEmployeeStatusBanner(db.employees.find(x=>x.id===id));
}
alert(result.message);
}
function applyEmployeeRestrictionUI(){
const banner=document.getElementById('empRestrictedBanner');
const state=employeeAccessState(sessionUser);
sessionRestricted=state.restricted;
sessionTerminationDate=state.anchorDate||'';
sessionRestrictionReason=state.reason||'';
document.querySelectorAll('#empView .nav-tab-btn').forEach(b=>{b.style.display=(sessionRestricted&&b.dataset.stab!=='payslip')?'none':'';});
if(sessionRestricted){
const active=document.querySelector('#empView .nav-tab-btn.active')?.dataset?.stab||'';
if(active!=='payslip')showStaffTab('payslip');
}
if(!banner)return;
if(!sessionUser||!state.reason){banner.classList.add('hidden');banner.textContent='';return;}
const endText=state.anchorDate?new Date(state.anchorDate+'T00:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}):'';
const closeText=state.closeDate?(' Access to this account closes on '+state.closeDate.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})+'.'):'';
let msg='';
if(state.reason==='terminated'){
msg=state.restricted?('⛔ This account has been terminated. Only Payslip & Calendar access is available.'+closeText):('⛔ Your employment has been terminated, effective '+endText+'.');
banner.style.background='#fef2f2';banner.style.color='#b91c1c';
}else if(state.reason==='notice_period'){
if(state.restricted){msg='⏳ Your notice period has ended. Only Payslip & Calendar access is available.'+closeText;banner.style.background='#fffbeb';banner.style.color='#b45309';}
else{msg='📅 You are currently serving your notice period. Last working day: '+endText+'.';banner.style.background='#eff6ff';banner.style.color='#1d4ed8';}
}
banner.textContent=msg;
banner.classList.remove('hidden');
}
['eBasic','eHRA','eLTA','eSpecial','eMobile'].forEach(id=>{const el=document.getElementById(id);if(el)el.addEventListener('input',updateSalaryCTC)});
function formatShiftTime(v){if(!v)return '';const [h,m]=v.split(':').map(Number);const ap=h>=12?'PM':'AM';const hh=(h%12)||12;return `${String(hh).padStart(2,'0')}:${String(m).padStart(2,'0')} ${ap}`;}
function shiftRange(start,end){return `${formatShiftTime(start)} – ${formatShiftTime(end)}`;}
function previewShiftTiming(){const a=document.getElementById('shiftSelectedStart').value,b=document.getElementById('shiftSelectedEnd').value;const text=shiftRange(a,b);document.getElementById('shiftTimingPreview').textContent=text;}
function loadShiftTiming(){const sid=document.getElementById('shiftTimingSelector').value;const sh=db.shifts?.[sid]||db.shifts?.shift1;document.getElementById('shiftSelectedStart').value=sh.start;document.getElementById('shiftSelectedEnd').value=sh.end;previewShiftTiming();}
function syncSelectedShiftTime(){}
function syncProjectShiftTime(){const el=document.getElementById('paShift'),out=document.getElementById('paShiftTime');if(!el||!out)return;const sh=db.shifts?.[el.value]||db.shifts?.shift1;if(sh)out.textContent=shiftRange(sh.start,sh.end);}
async function saveShifts(){
const sid=document.getElementById('shiftTimingSelector').value;
const start=document.getElementById('shiftSelectedStart').value,end=document.getElementById('shiftSelectedEnd').value;
const payload={shift1:{name:'Shift 1',start:db.shifts?.shift1?.start||'08:00',end:db.shifts?.shift1?.end||'18:00'},shift2:{name:'Shift 2',start:db.shifts?.shift2?.start||'09:00',end:db.shifts?.shift2?.end||'19:00'}};
payload[sid]={name:sid==='shift1'?'Shift 1':'Shift 2',start:start,end:end};
const result=await server('save_shifts',payload);
if(result.status==='success'){db.shifts=payload;syncShiftLabels();loadShiftTiming();syncSelectedShiftTime()}
alert(result.message+(result.details?'\n\n'+result.details:''));
}
function syncShiftLabels(){
syncProjectShiftTime();
}
function generateEmployeeQR(){
const id=document.getElementById('eID').value.trim();if(!id){alert('Select or save an employee first.');return}
const box=document.getElementById('empQRBox');box.innerHTML='';
if(typeof QRCode==='undefined'){box.innerHTML='<p style="color:#be123c">QR library failed to load. Check your internet connection.</p>';return}
const wrap=document.createElement('div');wrap.style.cssText='display:inline-block;padding:15px;background:#fff;border:1px solid var(--border);border-radius:16px;text-align:center';
const qrDiv=document.createElement('div');wrap.appendChild(qrDiv);
const label=document.createElement('div');label.style.cssText='margin-top:8px;font-weight:800;font-size:12px';label.innerText=id;wrap.appendChild(label);
box.appendChild(wrap);
new QRCode(qrDiv,{text:id,width:180,height:180});
}
function idCardHTML(e){
const logo=db.company.logo?`<img class="idcard-logo" src="${db.company.logo}" crossorigin="anonymous">`:'';
const photo=e.photo?`<img class="idcard-photo" src="${e.photo}" crossorigin="anonymous">`:`<div class="idcard-photo">${employeeInitials(e.name)}</div>`;
const qrId='idcardQR_'+Math.random().toString(36).slice(2);
const frontQrId='idcardFrontQR_'+Math.random().toString(36).slice(2);
const html=`<div class="idflip" id="idFlipRoot">
<div class="idflip-stage" role="button" tabindex="0" aria-label="Flip ID card" onclick="flipIdCard()" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();flipIdCard()}">
<div class="idcard-wrap idflip-inner" id="idCardImageArea">
<div class="idcard idcard-front" id="idcardFront">
<span class="fd fd-c" aria-hidden="true"></span><span class="fd fd-b" aria-hidden="true"></span><span class="fd fd-a" aria-hidden="true"></span>
<div class="idcard-head">${logo}<div class="idcard-company-name">${escapeHTML(db.company.name||'')}</div><div class="idcard-type">Employee Digital ID Card</div></div>
<div class="idcard-body">
${photo}
<div class="idcard-info">
<p class="idcard-name">${escapeHTML(e.name||'')}</p>
<p class="idcard-desig">${escapeHTML(e.des||'Employee')}</p>
<div class="idcard-meta">
<div class="idcard-meta-box"><span class="idcard-meta-label">Joining Date</span><span class="idcard-meta-value">${escapeHTML(e.doj||'—')}</span></div>
<div class="idcard-meta-box"><span class="idcard-meta-label">Project</span><span class="idcard-meta-value">${escapeHTML(e.project||'—')}</span></div>
</div>
</div>
<div id="${frontQrId}" class="idcard-front-qr" title="Employee Attendance QR Code"></div>
</div>
<div class="idcard-foot"><b>ID No: ${escapeHTML(e.id||'')}</b></div>
</div>
<div class="idcard idcard-back" id="idcardBack">
<div class="bd1-group" aria-hidden="true"><span class="bd1 bd1-d"></span><span class="bd1 bd1-c"></span><span class="bd1 bd1-b"></span><span class="bd1 bd1-a"></span></div>
<div class="bd2-group" aria-hidden="true"><span class="bd2 bd2-b"></span><span class="bd2 bd2-a"></span></div>
<div class="back-brand">${escapeHTML(db.company.name||'')}</div>
<div class="back-subtitle">Scan for employee attendance</div>
<div id="${qrId}" class="qr"></div>
<div class="qr-label">SCAN FOR ATTENDANCE</div>
<div class="addr">${escapeHTML(formatAddressOneLine(db.company.addr||''))}</div>
<div class="instructions">If found, please return this card to the above address.</div>
<div class="sign">Employee Attendance QR</div>
<div class="back-strip">This card remains the property of the company and must be surrendered on separation.</div>
</div>
</div>
</div>
<div class="idflip-controls no-print"><button type="button" class="btn btn-primary" id="idFlipBtn" onclick="flipIdCard()">↻ Flip to back</button><span class="idflip-hint">Tap the card to flip</span></div>
</div>`;
return {html,qrId,frontQrId};
}
function renderIdCard(e,scrollToCard=true){
document.body.classList.remove('cashbook-report-active');
if(!e||!e.id){alert('Employee ID is required to generate a card.');return}
const adminIdCardTab=document.getElementById('tab-idcard');
if(adminIdCardTab && !adminIdCardTab.classList.contains('active')){
showAdminTab('idcard');
}
const {html,qrId,frontQrId}=idCardHTML(e);
document.getElementById('payslipTarget').innerHTML=html;
document.getElementById('fullPageDisplay').classList.remove('hidden');
if(scrollToCard) window.scrollTo(0,document.body.scrollHeight);
const qrBox=document.getElementById(qrId),frontQrBox=document.getElementById(frontQrId);
if(typeof QRCode==='undefined'){if(qrBox)qrBox.innerHTML='<p style="color:#be123c;font-size:9px">QR library failed to load.</p>';return}
if(qrBox)new QRCode(qrBox,{text:e.id,width:180,height:180});
if(frontQrBox)new QRCode(frontQrBox,{text:e.id,width:180,height:180});
}
function generateMyIdCard(scrollToCard=true){
if(!sessionUser){alert('Session expired. Please log in again.');return}
const cardTab=document.getElementById('stab-idcard');
if(cardTab && !cardTab.classList.contains('active')) showStaffTab('idcard', true);
renderIdCard(sessionUser, !!scrollToCard);
}
function waitForIdCardImages(area){
const imgs=Array.from(area.querySelectorAll('img'));
if(!imgs.length)return Promise.resolve();
return Promise.all(imgs.map(img=>{
if(img.complete && img.naturalWidth>0)return Promise.resolve();
return new Promise(resolve=>{
const done=()=>resolve();
img.addEventListener('load',done,{once:true});
img.addEventListener('error',done,{once:true});
setTimeout(done,4000);
});
}));
}
function flipIdCard(){
const root=document.getElementById('idFlipRoot');if(!root)return;
const back=root.classList.toggle('is-flipped');
const btn=document.getElementById('idFlipBtn');if(btn)btn.textContent=back?'↻ Flip to front':'↻ Flip to back';
}
async function captureIdCardCanvas(area){
if(typeof html2canvas==='undefined')throw new Error('html2canvas missing');
await waitForIdCardImages(area);
await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
const wrap=document.getElementById('idCardImageArea');
const flipRoot=document.getElementById('idFlipRoot');
if(flipRoot)flipRoot.classList.add('flat');
if(wrap)wrap.classList.add('exporting');
await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
try{
return await html2canvas(area,{
scale:3,useCORS:true,allowTaint:false,backgroundColor:'#ffffff',
logging:false,imageTimeout:15000
});
}finally{
if(wrap)wrap.classList.remove('exporting');
if(flipRoot)flipRoot.classList.remove('flat');
}
}
async function downloadMyIdCard(){
if(!sessionUser){alert('Session expired. Please log in again.');return}
if(!document.getElementById('fullPageDisplay')||document.getElementById('fullPageDisplay').classList.contains('hidden')){renderIdCard(sessionUser,false);}
await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
const area=document.getElementById('idCardImageArea');
if(!area){alert('Please wait for the ID card to load.');return}
try{
const canvas=await captureIdCardCanvas(area);
const link=document.createElement('a');
link.download='ID-Card-'+String(sessionUser.id||'employee').replace(/[^a-zA-Z0-9_-]/g,'_')+'.png';
link.href=canvas.toDataURL('image/png');
link.click();
}catch(err){console.error(err);alert('Unable to download the ID card. Please use Print / Save PDF.');}
}
function generateSelectedEmployeeIdCard(){
const id=document.getElementById('idCardEmployeeSelector')?.value||'';
if(!id){alert('Please select an employee first.');return}
const e=(db.employees||[]).find(x=>String(x.id)===String(id));
if(!e){alert('Selected employee was not found.');return}
renderIdCard(e);
}
async function downloadSelectedEmployeeIdCard(){
const id=document.getElementById('idCardEmployeeSelector')?.value||'';
if(!id){alert('Please select an employee first.');return}
const e=(db.employees||[]).find(x=>String(x.id)===String(id));
if(!e){alert('Selected employee was not found.');return}
renderIdCard(e,false);
await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
const area=document.getElementById('idCardImageArea');
if(!area){alert('Please generate the ID card first.');return}
try{
const canvas=await captureIdCardCanvas(area);
const link=document.createElement('a');
link.download='ID-Card-'+String(e.id||'employee').replace(/[^a-zA-Z0-9_-]/g,'_')+'.png';
link.href=canvas.toDataURL('image/png');
link.click();
}catch(err){console.error(err);alert('Unable to download the ID card. Please try again.');}
}
function loadIdCardEmployee(){
const id=document.getElementById('idCardEmployeeSelector')?.value||'';
const e=(db.employees||[]).find(x=>String(x.id)===String(id));
const info=document.getElementById('idCardSelectedInfo');
if(!info){return}
info.textContent=e?`${e.name||'Employee'} • ${e.id||''} • ${e.des||'Employee'}`:'';
}
function syncIdCardEmployees(){
const el=document.getElementById('idCardEmployeeSelector');
if(!el)return;
const current=el.value;
el.innerHTML='<option value="">Select Employee</option>'+activeEmployees().map(e=>`<option value="${escapeHTML(e.id)}">${escapeHTML(e.name)} [${escapeHTML(e.id)}]</option>`).join('');
if(activeEmployees().some(e=>String(e.id)===String(current)))el.value=current;
else if(activeEmployees().length)el.value=activeEmployees()[0].id;
loadIdCardEmployee();
}
async function deleteEmployee(){
const id=document.getElementById('eID').value.trim();if(!id){alert('Select employee first.');return}
if(!confirm('Delete this employee?'))return;
const result=await server('delete_employee',{id});
if(result.status==='success'){db.employees=db.employees.filter(e=>e.id!==id);syncEmployees();clearEmployee()}
alert(result.message);
}
function renderDashboard(){
const d=new Date(),day=d.getDate(),month=d.getMonth(),year=d.getFullYear();
const employees=(db.employees||[]).filter(e=>!e.terminated), punches=db.punches||{}, attendance=db.attendance||{}; /* terminated employees are hidden from the Workforce Dashboard */
let present=0,absent=0,late=0,inside=0,ot=0;const presentList=[],absentList=[];
const projectMap={},shiftMap={shift1:0,shift2:0};
employees.forEach(e=>{const key=`${e.id}-${month}-${year}`, rec=attendance[key]||{}, ps=punchSorted((punches[key]||{})[day]||[]), st=rec[day]||''; const ins=ps.filter(p=>p.type==='IN'), outs=ps.filter(p=>p.type==='OUT'), lastP=ps.filter(p=>p.type==='IN'||p.type==='OUT').slice(-1)[0], isIn=!!(lastP&&lastP.type==='IN'), isPresent=(st==='P'||ins.length>0); if(isPresent)present++; else absent++; if(isIn)inside++; (isPresent?presentList:absentList).push({e:e,ins:ins,outs:outs,isIn:isIn}); const sh=e.shift||'shift1'; if(shiftMap[sh]!==undefined)shiftMap[sh]++; if(ins.length){const mins=punchMinutesOfDay(ins[0]); if(mins!==null){const cfg=db.shifts?.[sh]||db.shifts?.shift1; const sm=Number((cfg?.start||'08:00').split(':')[0])*60+Number((cfg?.start||'08:00').split(':')[1]); if(mins>sm+10)late++;}} if(ps.some(p=>p.type==='OT'))ot++; const proj=e.project||'Unassigned'; if(!projectMap[proj])projectMap[proj]={employees:0,contractors:new Set(),shifts:{shift1:0,shift2:0}}; projectMap[proj].employees++; projectMap[proj].shifts[sh]=(projectMap[proj].shifts[sh]||0)+1; (e.contractor_ids||[]).forEach(cid=>{const c=(db.contractors||[]).find(x=>String(x.id)===String(cid));if(c)projectMap[proj].contractors.add(c.name||c.id);}); });
const cards=[['Employees',employees.length],['Present',present],['Absent',absent],['Late',late],['Inside Site',inside],['OT',ot]]; document.getElementById('dashCards').innerHTML=cards.map(x=>`<div class="summary-item"><strong>${x[1]}</strong><span>${x[0]}</span></div>`).join('');
(function(){const box=document.getElementById('dashPresent');if(!box)return;
const row=function(x,showTime){const e=x.e,inT=x.ins.length?punchTimeLabel(x.ins[0]):'',outT=x.outs.length?punchTimeLabel(x.outs[x.outs.length-1]):'';
const state=showTime?(x.ins.length?(x.isIn?'IN '+escapeHTML(inT)+' · <span style="color:#059669">Inside site</span>':'IN '+escapeHTML(inT)+' · OUT '+escapeHTML(outT)):'<span style="color:#b45309">Marked present, no punch</span>'):'';
return '<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:9px 0;border-bottom:1px solid var(--border)"><div><strong>'+escapeHTML(e.name||e.id)+'</strong> <span style="font-size:11px;color:#64748b">['+escapeHTML(e.id)+'] · '+escapeHTML(e.project||'Unassigned')+'</span></div><div style="font-size:12px;font-weight:700">'+state+'</div></div>';};
box.innerHTML='<strong>Present today ('+presentList.length+')</strong>'+(presentList.length?presentList.map(function(x){return row(x,true);}).join(''):'<p style="color:#64748b;margin:8px 0 0">Nobody is marked present yet.</p>')+(absentList.length?'<details style="margin-top:12px"><summary style="cursor:pointer;font-weight:800;color:#b91c1c">Absent / not marked ('+absentList.length+')</summary>'+absentList.map(function(x){return row(x,false);}).join('')+'</details>':'');})();
const projects=Object.entries(projectMap); document.getElementById('dashProjects').innerHTML=projects.length?projects.map(([name,v])=>`<div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;padding:12px 0;border-bottom:1px solid var(--border)"><div><strong>${escapeHTML(name)}</strong><div style="font-size:11px;color:#64748b;margin-top:3px">${v.contractors.size?escapeHTML([...v.contractors].join(', ')):'No contractor assigned'}</div></div><div style="font-size:12px;font-weight:800">${v.employees} employees · S1 ${v.shifts.shift1||0} · S2 ${v.shifts.shift2||0}</div></div>`).join(''):'<p style="color:#64748b">No project assignments yet.</p>';
const sh=db.shifts||{}; document.getElementById('dashShifts').innerHTML=['shift1','shift2'].map(id=>`<div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border)"><strong>${escapeHTML(sh[id]?.name||id)}</strong><span>${escapeHTML(shiftRange(sh[id]?.start,sh[id]?.end))} · ${shiftMap[id]||0} employees</span></div>`).join('');
}
function showAdminTab(name){try{ledgerAutoAnchor()}catch(e){}
document.body.classList.remove('cashbook-report-active');
const sharedDisplay=document.getElementById('fullPageDisplay');
if(sharedDisplay) sharedDisplay.classList.toggle('hidden', name!=='idcard');
if(name==='projectAssign'){setTimeout(()=>{filterProjectEmployees(); if(document.getElementById('paEmployeeSelector').value)loadProjectAssignment();},0)}
if(name==='cashbookReport'){setTimeout(()=>initAdminCashbookReport(),0)}
if(name==='spending'){setTimeout(()=>initSpendingDashboard(),0)}
if(name==='faceSec'){setTimeout(()=>{try{faceAdminInit()}catch(e){}},0)}
if(name==='measurement'){setTimeout(()=>initAdminMeasurement(),0)}
if(name==='contractorBill'){setTimeout(()=>renderLabourBill('lb',true),0)}
document.querySelectorAll('#adminView .admin-tab').forEach(el=>el.classList.remove('active'));
document.querySelectorAll(':is(#adminView,#empView) .nav-tab-btn').forEach(el=>el.classList.remove('active'));
document.getElementById('tab-'+name).classList.add('active');
document.querySelector(`:is(#adminView,#empView) .nav-tab-btn[data-tab="${name}"]`).classList.add('active');
}
function employeeInitials(name){const parts=String(name||'Employee').trim().split(/\s+/).filter(Boolean);return parts.slice(0,2).map(x=>x.charAt(0).toUpperCase()).join('')||'E';}
function formatProfileDob(value){if(!value)return 'Not provided';const d=new Date(String(value).includes('-')?String(value)+'T00:00:00':value);return Number.isNaN(d.getTime())?String(value):d.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});}
function renderEmployeeProfile(employee){const wrap=document.getElementById('employeeProfileWrap');if(!wrap)return;if(!employee){wrap.style.display='none';return;}wrap.style.display='block';const initials=employeeInitials(employee.name);const avatar=document.getElementById('employeeProfileAvatar'),initial=document.getElementById('employeeProfileInitial');initial.textContent=initials;if(employee.photo){avatar.src=employee.photo;avatar.style.display='block';initial.style.display='none';}else{avatar.style.display='none';initial.style.display='flex';}const photo=document.getElementById('employeeProfilePhotoLarge');if(employee.photo){photo.outerHTML='<img id="employeeProfilePhotoLarge" class="profile-photo-large" src="'+employee.photo.replace(/"/g,'&quot;')+'" alt="Employee photo">';}else{photo.outerHTML='<div id="employeeProfilePhotoLarge" class="profile-photo-fallback">'+initials+'</div>';}document.getElementById('employeeProfileName').textContent=employee.name||'Employee';document.getElementById('employeeProfileId').textContent=employee.id||'Employee ID';document.getElementById('employeeProfileIdValue').textContent=employee.id||'—';document.getElementById('employeeProfileDob').textContent=formatProfileDob(employee.dob);const cIds=(employee.contractor_ids||((employee.contractor_id||'')?[employee.contractor_id]:[])).map(String);const cRow=document.getElementById('employeeProfileContractorRow'),cEl=document.getElementById('employeeProfileContractor');if(cIds.length){const names=cIds.map(id=>{const c=(db.contractors||[]).find(x=>String(x.id)===id);return c?(c.name||c.id):null;}).filter(Boolean);if(names.length){cEl.textContent=names.join(', ');cRow.style.display='';}else{cRow.style.display='none';}}else{cRow.style.display='none';}}
function toggleEmployeeProfile(){const p=document.getElementById('employeeProfilePopup');if(!p)return;p.classList.toggle('open');}
function closeEmployeeProfile(){const p=document.getElementById('employeeProfilePopup');if(p)p.classList.remove('open');}
document.addEventListener('click',function(e){const w=document.getElementById('employeeProfileWrap');if(w&&w.style.display!=='none'&&!w.contains(e.target))closeEmployeeProfile();});
document.addEventListener('DOMContentLoaded',function(){const b=document.getElementById('employeeProfileBtn');if(b)b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();toggleEmployeeProfile();});});
function showStaffTab(name){
document.body.classList.remove('cashbook-report-active');
document.querySelectorAll('#empView .admin-tab').forEach(el=>el.classList.remove('active'));
document.querySelectorAll('#empView .nav-tab-btn').forEach(el=>el.classList.remove('active'));
const card=document.getElementById('stab-'+name);if(card)card.classList.add('active');
const nav=document.querySelector('#empView .admin-nav');if(nav)nav.style.display='flex';
const btn=document.querySelector(`#empView .nav-tab-btn[data-stab="${CSS.escape(name)}"]`);if(btn)btn.classList.add('active');
const content=document.querySelector('#empView .admin-content');if(content){content.style.marginLeft='';content.style.width='';}
document.getElementById('fullPageDisplay').classList.toggle('hidden', name!=='idcard');
if(name==='today'){renderSelfPunchUI();renderStaffCalendar();}
if(name==='applyAtt'){renderMyRequests();renderForgotPunchLimit();}
if(name==='leave'){renderMyLeaveRequests();renderStaffLeaveApprovals();}
if(name==='myqr'){generateMyQR();}
if(name==='measurement'){renderStaffMeasurement();}
if(name==='idcard'){if(sessionUser){renderIdCard(sessionUser,false);}}
if(name==='payslip'){renderStaffPayslip?.();}
if(name==='advances'){renderEmployeeAdvanceList?.();}
if(name==='cashbook'){renderStaffCashbook?.();}
if(name==='contractor'){syncContractorsStaff?.();}
if(name==='contractorAtt'){syncContractorsStaff?.();}
if(name==='contractorBill'){renderLabourBill?.('slb',true);}
}
function syncEmployees(){
const mk=e=>{const marker=e.terminated?'⛔ ':(e.notice_period_end?'🔔 ':'');return `<option value="${escapeHTML(e.id)}">${marker}${escapeHTML(e.name)} [${escapeHTML(e.id)}]</option>`;};
const options=db.employees.map(mk).join(''),activeOptions=activeEmployees().map(mk).join('');
document.getElementById('empSelector').innerHTML='<option value="new">+ New Employee</option>'+options;const ecs=document.getElementById('eContractor');if(ecs)ecs.innerHTML='<option value="">No Contractor</option>'+(db.contractors||[]).map(c=>`<option value="${escapeHTML(c.id)}">${escapeHTML(c.name||'')} [${escapeHTML(c.id||'')}]</option>`).join('');
syncIdCardEmployees();
document.getElementById('attE').innerHTML=activeOptions;if(activeEmployees().length)document.getElementById('attE').value=activeEmployees()[0].id;renderAdminCalendar();
document.getElementById('advEmp').innerHTML=activeOptions;if(activeEmployees().length)document.getElementById('advEmp').value=activeEmployees()[0].id;renderAdvanceList();
renderHolidayList();
filterProjectEmployees();
initAdminCashbookReport?.();
}
function advMonthKey(a){return a.for_month||String(a.date||'').slice(0,7);}
function advForTag(a){const k=advMonthKey(a);if(!a.date||k===String(a.date).slice(0,7))return '';const y=Number(k.slice(0,4)),m=Number(k.slice(5,7))-1;return ` <span style="font-size:11px;color:#b45309">(for ${months[m]} ${y})</span>`;}
function fillAdvForMonth(){
const sel=document.getElementById('advForMonth'),empEl=document.getElementById('advEmp');if(!sel||!empEl)return;
const emp=empEl.value,now=new Date();let cy=now.getFullYear(),cm=now.getMonth(),py=cy,pm=cm-1;if(pm<0){pm=11;py--;}
const locked=(y,m)=>(db.locked_payroll||[]).includes(`${emp}-${m}-${y}`);
const keep=sel.value;
sel.innerHTML=[[cy,cm],[py,pm]].map(([y,m])=>{const l=locked(y,m);return `<option value="${y}-${String(m+1).padStart(2,'0')}"${l?' disabled':''}>${months[m]} ${y}${m===cm&&y===cy?' (current)':' (previous)'}${l?' - salary credited':''}</option>`}).join('');
const ok=[...sel.options].find(o=>!o.disabled&&o.value===keep)||[...sel.options].find(o=>!o.disabled);
if(ok)sel.value=ok.value;
}
async function saveSalaryAdvance(){
const employee_id=document.getElementById('advEmp').value,date=document.getElementById('advDate').value,amount=Number(document.getElementById('advAmount').value)||0,note=document.getElementById('advNote').value;
if(!employee_id||!date||amount<=0){alert('Select employee, date and a valid amount.');return}
const forSel=document.getElementById('advForMonth'),for_month=forSel?forSel.value:'';
if(forSel&&(!for_month||(forSel.selectedOptions[0]&&forSel.selectedOptions[0].disabled))){alert('Salary for the selected month is already credited. Choose another month.');return}
const result=await server('add_salary_advance',{employee_id,date,amount,note,for_month});
if(result.status==='success'){
if(!Array.isArray(db.salary_advances))db.salary_advances=[];
db.salary_advances.push(result.record);
const fm=result.record.for_month||String(result.record.date||'').slice(0,7);
if(/^\d{4}-\d{2}$/.test(fm)){document.getElementById('advY').value=Number(fm.slice(0,4));document.getElementById('advM').value=Number(fm.slice(5,7))-1;}
document.getElementById('advDate').value='';document.getElementById('advAmount').value='';document.getElementById('advNote').value='';
try{await refreshPortalDatabase();}catch(e){}
renderAdvanceList();
alert(result.message);
}else{
alert((result.message||'Could not save advance.')+(result.details?'\n'+result.details:''));
}
}
function renderAdvanceList(){
const employeeId=document.getElementById('advEmp').value,box=document.getElementById('advList');if(!box)return;
fillAdvForMonth();
const mEl=document.getElementById('advM'),yEl=document.getElementById('advY');
const month=mEl&&mEl.value!==''?Number(mEl.value):null,year=yEl&&yEl.value!==''?Number(yEl.value):null;
const monthKey=(month!==null&&year!==null)?`${year}-${String(month+1).padStart(2,'0')}`:null;
let list=db.salary_advances.filter(a=>a.employee_id===employeeId);
if(monthKey)list=list.filter(a=>advMonthKey(a)===monthKey);
list=list.sort((a,b)=>b.date.localeCompare(a.date));
const total=list.reduce((s,a)=>s+Number(a.amount||0),0);
box.innerHTML=(list.length?list.map(a=>`<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)"><div><strong>${escapeHTML(a.date)}</strong>${advForTag(a)} — ₹ ${formatINR(a.amount)}${a.note?` <span style="color:#64748b">(${escapeHTML(a.note)})</span>`:''}</div><button class="btn btn-danger delete-design-btn" style="padding:4px 10px" onclick="deleteSalaryAdvance('${a.id}')">Delete</button></div>`).join(''):'<p style="color:#64748b">No advances recorded for this period.</p>')+`<div style="margin-top:10px;font-weight:800;color:#059669">Total Advance: ₹ ${formatINR(total)}</div>`;
}
async function deleteSalaryAdvance(id){
if(!confirm('Delete this advance record?'))return;
const result=await server('delete_salary_advance',{id});
if(result.status==='success'){db.salary_advances=db.salary_advances.filter(a=>a.id!==id);renderAdvanceList()}
alert((result.message||'')+(result.status!=='success'&&result.details?'\n'+result.details:''));
}
function renderStaffAdvances(){
const box=document.getElementById('staffAdvList');if(!box||!sessionUser)return;
const mEl=document.getElementById('stAdvM'),yEl=document.getElementById('stAdvY');
const month=mEl&&mEl.value!==''?Number(mEl.value):null,year=yEl&&yEl.value!==''?Number(yEl.value):null;
const monthKey=(month!==null&&year!==null)?`${year}-${String(month+1).padStart(2,'0')}`:null;
let list=(db.salary_advances||[]).filter(a=>a.employee_id===sessionUser.id);
if(monthKey)list=list.filter(a=>advMonthKey(a)===monthKey);
list=list.sort((a,b)=>b.date.localeCompare(a.date));
const total=list.reduce((s,a)=>s+Number(a.amount||0),0);
box.innerHTML=(list.length?list.map(a=>`<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)"><div><strong>${escapeHTML(a.date)}</strong>${advForTag(a)} — ₹ ${formatINR(a.amount)}${a.note?` <span style="color:#64748b">(${escapeHTML(a.note)})</span>`:''}</div></div>`).join(''):'<p style="color:#64748b">No salary advances recorded for this period.</p>')+`<div style="margin-top:10px;font-weight:800;color:#059669">Total Advance: ₹ ${formatINR(total)}</div>`;
}
function cashbookRunningRows(list){
const sorted=[...list].sort((a,b)=>(a.date||'').localeCompare(b.date||'')||String(a.id).localeCompare(String(b.id)));
let bal=0;
return sorted.map(c=>{bal+=Number(c.income||0)-Number(c.expense||0);return{...c,balance:bal};});
}
function cashbookRowHTML(c,showDelete){
const category=c.category||'';
const project=c.project||'';
const description=c.description||'';
const viewB=c.bill_url?`<button class="btn btn-primary bill-view-btn" type="button" onclick="viewCashBill('${c.id}')">View Bill</button>`:'<span style="color:#94a3b8;font-size:11px">No Bill</span>';
const editB=showDelete?`<div class="bill-edit-row" style="display:flex;gap:4px;justify-content:center;margin-top:4px;flex-wrap:wrap"><button class="btn" type="button" style="font-size:11px;padding:3px 8px" onclick="pickCashBill('${c.id}')">${c.bill_url?'Replace':'Add Bill'}</button>${c.bill_url?`<button class="btn btn-danger" type="button" style="font-size:11px;padding:3px 8px" onclick="removeCashBill('${c.id}')">Remove</button>`:''}</div>`:'';
const billBtn=viewB+editB;
return `<tr>
<td>${escapeHTML(c.date||'')}</td>
<td>${escapeHTML(project)}</td>
<td>${escapeHTML(description)}</td>
<td>${escapeHTML(category)}</td>
<td class="amount" style="color:#059669">${c.income?('₹ '+formatINR(c.income)):'-'}</td>
<td class="amount" style="color:#dc2626">${c.expense?('₹ '+formatINR(c.expense)):'-'}</td>
<td class="amount">₹ ${formatINR(c.balance)}</td>
<td class="no-print" style="text-align:center">${billBtn}</td>
${showDelete?`<td class="no-print"><button class="btn btn-danger cashbook-delete-btn delete-design-btn" title="Delete" aria-label="Delete" onclick="deleteCashbookEntry('${c.id}')">Del</button></td>`:''}
</tr>`;
}
function cashbookTableHTML(rows,showDelete){
if(!rows.length)return '<p style="color:#64748b">No cash book entries recorded.</p>';
return `<div class="cashbook-table-wrap cashbook-scroll-panel"><table class="salary cashbook-table" style="width:100%"><thead><tr><th>Date</th><th>Project</th><th>Description</th><th>Category</th><th>Income</th><th>Expense</th><th>Balance</th><th class="no-print">Bill</th>${showDelete?'<th class="no-print"></th>':''}</tr></thead><tbody>${rows.map(c=>cashbookRowHTML(c,showDelete)).join('')}</tbody></table></div>`;
}
function cashbookSummaryHTML(rows){
const income=rows.reduce((s,c)=>s+Number(c.income||0),0),expense=rows.reduce((s,c)=>s+Number(c.expense||0),0),balance=income-expense;
return `<div class="summary-box"><div class="summary-label">Income</div><div class="summary-value" style="color:#059669">₹ ${formatINR(income)}</div></div><div class="summary-box"><div class="summary-label">Expense</div><div class="summary-value" style="color:#dc2626">₹ ${formatINR(expense)}</div></div><div class="summary-box"><div class="summary-label">Balance</div><div class="summary-value">₹ ${formatINR(balance)}</div></div>`;
}
async function deleteCashbookEntry(id){
if(!confirm('Delete this cash book entry? Its bill image will also be permanently deleted.'))return;
const result=await server('delete_cashbook_entry',{id});
if(result.status==='success'){db.cashbook=(db.cashbook||[]).filter(c=>c.id!==id);renderStaffCashbook()}
alert(result.message);
}
function updateCashBillLock(){
const input=document.getElementById('scbBill');
const wrap=document.getElementById('scbBillWrap');
const help=document.getElementById('scbBillHelp');
if(input){input.disabled=false;}
if(wrap){wrap.style.opacity='1';}
if(help){help.textContent='Available for Income and Expense entries • JPG, PNG, WEBP or PDF • Photos are auto-compressed to about 60 KB (PDF max 6 MB)';}
}
function initStaffCashbookForm(){
const projectEl=document.getElementById('scbProject');
if(!projectEl||!sessionUser)return;
const dateEl=document.getElementById('scbDate');
if(dateEl&&!dateEl.value)dateEl.value=new Date().toISOString().slice(0,10);
const employee=(db.employees||[]).find(e=>String(e.id)===String(sessionUser.id))||sessionUser;
const assigned=String(employee.project||'').trim();
const optHTML=assigned
?`<option value="${escapeHTML(assigned)}">${escapeHTML(assigned)}</option>`
:'<option value="">No project assigned</option>';
projectEl.innerHTML=optHTML;
const opProjectEl=document.getElementById('opProject');
if(opProjectEl)opProjectEl.innerHTML=optHTML;
const opDateEl=document.getElementById('opDate');
if(opDateEl&&!opDateEl.value)opDateEl.value=new Date().toISOString().slice(0,10);
updateCashBillLock();
}
function compressBillImage(file){
return new Promise(resolve=>{
const url=URL.createObjectURL(file),img=new Image();
img.onload=()=>{
try{
/* Sharp text first: keep resolution high, convert to clean grayscale (bills are mostly text),
then lower JPEG quality only as far as needed to reach about 60 KB. */
const TARGET=60000,sizes=[1400,1200,1000];let best=null;
for(const MAX of sizes){
let w=img.naturalWidth,h=img.naturalHeight;const sc=Math.min(1,MAX/Math.max(w,h));w=Math.round(w*sc);h=Math.round(h*sc);
const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,w,h);x.drawImage(img,0,0,w,h);
const im=x.getImageData(0,0,w,h),p=im.data;
for(let i=0;i<p.length;i+=4){let g=0.299*p[i]+0.587*p[i+1]+0.114*p[i+2];g=(g-128)*1.15+128;g=g<0?0:g>255?255:g;p[i]=p[i+1]=p[i+2]=g;}
x.putImageData(im,0,0);
let q=0.75,d=c.toDataURL('image/jpeg',q);
while(d.length*0.75>TARGET&&q>0.46){q-=0.05;d=c.toDataURL('image/jpeg',q);}
if(!best||d.length<best.length)best=d;
if(d.length*0.75<=TARGET)break;
}
URL.revokeObjectURL(url);resolve(best);
}catch(e){URL.revokeObjectURL(url);resolve(null);}
};
img.onerror=()=>{URL.revokeObjectURL(url);resolve(null);};
img.src=url;
});
}
async function readCashBillFile(fileArg){
let file=fileArg;
if(!file){
const input=document.getElementById('scbBill');
if(!input||!input.files||!input.files[0])return null;
file=input.files[0];
}
const allowed=['image/jpeg','image/png','image/webp','application/pdf'];
if(!allowed.includes(file.type)){alert('Please upload JPG, PNG, WEBP or PDF only.');return false;}
if(file.type==='application/pdf'){if(file.size>6*1024*1024){alert('PDF is too large. Maximum allowed size for PDF is 6 MB.');return false;}}
else{
if(file.size>30*1024*1024){alert('Photo is too large. Please choose a photo below 30 MB.');return false;}
if(file.size>60000){
const packed=await compressBillImage(file);
if(packed)return {data:packed,name:file.name.replace(/\.[^.]+$/,'')+'.jpg'};
}
}
return await new Promise(resolve=>{const r=new FileReader();r.onload=()=>resolve({data:r.result,name:file.name});r.onerror=()=>resolve(false);r.readAsDataURL(file);});
}
let cashBillSyncAt=0,cashBillSyncBusy=false;
async function syncCashBills(force){
if(cashBillSyncBusy)return false;
if(!force&&Date.now()-cashBillSyncAt<30000)return false;
cashBillSyncBusy=true;cashBillSyncAt=Date.now();
try{
const r=await server('sync_cashbook_bills',{});
if(r&&r.status==='success'&&r.cleared&&r.cleared.length){
(db.cashbook||[]).forEach(c=>{if(r.cleared.includes(String(c.id))){c.bill_url='';c.bill_type='';c.bill_deleted=true;}});
return true;
}
}catch(e){}
finally{cashBillSyncBusy=false;}
return false;
}
async function viewCashBill(id){
if(await syncCashBills(true)){try{renderStaffCashbook?.();}catch(e){}}
const c=(db.cashbook||[]).find(x=>String(x.id)===String(id));
if(c&&c.bill_deleted&&!c.bill_url){alert('This bill image was deleted from the cloud, so it is no longer available.');return;}
if(!c||!c.bill_url){alert('No bill was uploaded for this entry.');return;}
const existing=document.querySelector('.bill-modal');if(existing)existing.remove();
const isPdf=(String(c.bill_type||'').toLowerCase()==='application/pdf'||/\.pdf($|[?#])/i.test(c.bill_url));
const src=String(c.bill_url);
const body=isPdf?window.pdfViewerHTML(src,'Cash Bill'):`<img src="${escapeHTML(src)}" alt="Cash Bill">`;
const modal=document.createElement('div');modal.className='bill-modal';modal.innerHTML=`<div class="bill-modal-box"><div class="bill-modal-head"><div class="bill-modal-title">${escapeHTML(c.bill_name||'Cash Bill')}</div><button class="bill-modal-close" type="button" aria-label="Close">×</button></div><div class="bill-modal-body">${body}</div></div>`;
modal.querySelector('.bill-modal-close').onclick=()=>modal.remove();
modal.addEventListener('click',e=>{if(e.target===modal)modal.remove();});
document.body.appendChild(modal);
}
function pickCashBill(id){
let inp=document.getElementById('cbBillPicker');
if(!inp){inp=document.createElement('input');inp.type='file';inp.id='cbBillPicker';inp.accept='image/jpeg,image/png,image/webp,application/pdf';inp.style.display='none';document.body.appendChild(inp);}
inp.value='';
inp.onchange=async()=>{
const f=inp.files&&inp.files[0];if(!f)return;
const c=(db.cashbook||[]).find(x=>String(x.id)===String(id));
if(c&&c.bill_url&&!confirm('Replace the existing bill? The old bill image will be permanently deleted.')){inp.value='';return;}
const bill=await readCashBillFile(f);
if(!bill){inp.value='';return;}
const r=await server('update_cashbook_bill',{id,bill_data:bill.data,bill_name:bill.name});
inp.value='';
if(r.status==='success'&&r.record){const i=(db.cashbook||[]).findIndex(x=>String(x.id)===String(id));if(i>=0)db.cashbook[i]=r.record;renderStaffCashbook();}
alert(r.message);
};
inp.click();
}
async function removeCashBill(id){
if(!confirm('Remove the bill from this entry? The bill image will be permanently deleted.'))return;
const r=await server('update_cashbook_bill',{id,remove:true});
if(r.status==='success'&&r.record){const i=(db.cashbook||[]).findIndex(x=>String(x.id)===String(id));if(i>=0)db.cashbook[i]=r.record;renderStaffCashbook();}
alert(r.message);
}
const MS_UNITS=['Cum','Sqm','Rmt','Nos','Kg','MT','Ltr','LS'];
function msNum(v){const n=Number(v);return Number.isFinite(n)?n:0;}
function msFmt(n){return (Math.round(msNum(n)*1000)/1000).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});}
function msDim(v){return(v===null||v===undefined||v==='')?'':msFmt(v);}
function msQtyFromInputs(nos,l,b,d,deduct){
const vals=[nos,l,b,d].map(x=>String(x==null?'':x).trim()).filter(x=>x!=='');
if(!vals.length)return null;
let q=1;for(const x of vals){const n=Number(x);if(!Number.isFinite(n)||n<0)return null;q*=n;}
q=Math.round(q*1000)/1000;return deduct?-q:q;}
function msPreview(){
const g=id=>document.getElementById(id);if(!g('msQtyPreview'))return;
const q=msQtyFromInputs(g('msNos').value,g('msL').value,g('msB').value,g('msD').value,g('msDeduct').checked);
g('msQtyPreview').textContent=q===null?'—':msFmt(q)+' '+g('msUnit').value;}
async function msRefresh(){try{const r=await server('refresh_portal_data',{});if(r&&r.status==='success'&&r.db)db.measurements=r.db.measurements||[];}catch(e){}}
function msRows(prefix){
const g=id=>document.getElementById(prefix+id);
let rows=(db.measurements||[]).slice();
const from=g('From')?g('From').value:'',to=g('To')?g('To').value:'',q=(g('SheetQ')?g('SheetQ').value:'').trim().toLowerCase();
const proj=g('Project')?g('Project').value:'',staff=g('Staff')?g('Staff').value:'';
if(from)rows=rows.filter(r=>(r.date||'')>=from);
if(to)rows=rows.filter(r=>(r.date||'')<=to);
if(q)rows=rows.filter(r=>String(r.sheet||'').toLowerCase().includes(q)||String(r.description||'').toLowerCase().includes(q));
if(proj)rows=rows.filter(r=>r.project===proj);
if(staff)rows=rows.filter(r=>String(r.employee_id)===staff);
rows.sort((a,b)=>String(a.date||'').localeCompare(String(b.date||''))||String(a.created||'').localeCompare(String(b.created||'')));
return rows;}
function msQ(r){let q=msNum(r.qty);if(q===0){const v=[r.nos,r.length,r.breadth,r.depth].filter(x=>x!==null&&x!==undefined&&x!=='');if(v.length){q=Math.round(v.reduce((p,x)=>p*msNum(x),1)*1000)/1000;if(r.deduct)q=-q;}}return q;}
function msTotals(rows){const t={};rows.forEach(r=>{t[r.unit]=(t[r.unit]||0)+msQ(r);});return Object.entries(t).map(([u,q])=>escapeHTML(msFmt(q)+' '+u)).join(' &nbsp;•&nbsp; ')||'—';}
function msItemTotal(list){const t={};list.forEach(r=>{const u=r.unit||'';t[u]=(t[u]||0)+msQ(r);});return Object.entries(t).map(([u,q])=>escapeHTML(msFmt(q)+' '+u)).join(' + ')||'—';}
function msCnt(v){if(v===null||v===undefined||v==='')return '';const n=Number(v);return Number.isInteger(n)?String(n):msFmt(n);}
function msPad(n){return String(n).padStart(2,'0');}
/* One project's rows -> reference-style table: Item no | Description | No | L | B | H/D | Quantity | Explanatory Notes */
function msItemsTable(rows,o){
const groups={},order=[];
rows.forEach(r=>{const k=r.sheet||'General';if(!groups[k]){groups[k]=[];order.push(k);}groups[k].push(r);});
const extra=(o.print?0:1)+(o.showStaff?1:0)+(o.canDelete?1:0);
const cols=8+extra;
let h='<table class="ms-table ms-ref"><thead><tr><th rowspan="2" style="width:9%">Item no</th><th rowspan="2" style="width:30%">Description or Particular</th><th rowspan="2" style="width:6%">No</th><th colspan="3" style="text-align:center">Dimensions</th><th rowspan="2" style="width:12%">Quantity</th><th rowspan="2" style="width:20%">Explanatory Notes</th>'+(o.print?'':'<th rowspan="2">Date</th>')+(o.showStaff?'<th rowspan="2">By</th>':'')+(o.canDelete?'<th rowspan="2" class="no-print"></th>':'')+'</tr><tr><th>Length (M)</th><th>Breadth (M)</th><th>Height / Depth (M)</th></tr></thead><tbody>';
order.forEach((k,gi)=>{
const list=groups[k];
h+=`<tr class="ms-item"><td>${msPad(gi+1)}</td><td colspan="${cols-1}"><strong>${escapeHTML(k)}</strong></td></tr>`;
list.forEach(r=>{
h+=`<tr class="${r.deduct?'ms-deduct':''}"><td></td><td>${r.deduct?'(−) ':''}${escapeHTML(r.description||'')}</td><td class="ms-c">${msCnt(r.nos)}</td><td class="ms-c">${msDim(r.length)}</td><td class="ms-c">${msDim(r.breadth)}</td><td class="ms-c">${msDim(r.depth)}</td><td class="ms-c"><strong>${msFmt(msQ(r))}</strong></td><td>${escapeHTML(r.remarks||'')}</td>${o.print?'':`<td style="white-space:nowrap">${escapeHTML(r.date||'')}</td>`}${o.showStaff?`<td>${escapeHTML(r.employee_name||r.employee_id||'')}</td>`:''}${o.canDelete?`<td class="no-print" style="white-space:nowrap"><button class="btn btn-primary" style="padding:4px 10px;font-size:11px" title="Edit" onclick="msEdit('${escapeHTML(r.id)}')">✎</button> <button class="btn btn-danger" style="padding:4px 10px;font-size:11px" onclick="msDelete('${escapeHTML(r.id)}')">✕</button></td>`:''}</tr>`;
});
h+=`<tr class="ms-total"><td></td><td><strong>Total – ${escapeHTML(k)}</strong></td><td></td><td></td><td></td><td></td><td class="ms-c ms-red">${msItemTotal(list)}</td><td></td>${'<td></td>'.repeat(extra)}</tr>`;
});
return '<div style="overflow-x:auto">'+h+'</tbody></table></div>';}
function msTableHTML(rows,o){
if(!rows.length)return '<p style="color:#64748b;font-size:13px">No measurements found.</p>';
const projects=[];rows.forEach(r=>{const k=r.project||'—';if(!projects.includes(k))projects.push(k);});
return projects.map((p,i)=>`<div class="ms-proj"><div class="ms-projbar"><span>Name of Project: <strong>${escapeHTML(p)}</strong></span><span>Sheet No: <strong>${msPad(i+1)}</strong></span></div>${msItemsTable(rows.filter(r=>(r.project||'—')===p),o)}</div>`).join('');}
function renderStaffMeasurement(){
const box=document.getElementById('msList');if(!box||!sessionUser)return;
const proj=document.getElementById('msProject'),dt=document.getElementById('msDate');
if(dt&&!dt.value)dt.value=new Date().toISOString().slice(0,10);
const emp=(db.employees||[]).find(e=>String(e.id)===String(sessionUser.id))||sessionUser;
const assigned=String(emp.project||'').trim();
if(proj)proj.innerHTML=assigned?`<option value="${escapeHTML(assigned)}">${escapeHTML(assigned)}</option>`:'<option value="">No project assigned</option>';
msPreview();
box.innerHTML=msTableHTML(msRows('msf'),{showStaff:false,canDelete:true});
if(!window.__msRefreshing){window.__msRefreshing=true;msRefresh().then(()=>{box.innerHTML=msTableHTML(msRows('msf'),{showStaff:false,canDelete:true});}).finally(()=>{window.__msRefreshing=false;});}}
function renderAdminMeasurement(){
const box=document.getElementById('amsList');if(!box)return;
box.innerHTML=msTableHTML(msRows('ams'),{showStaff:true,canDelete:true});}
function msBuildAdminFilters(){
const pSel=document.getElementById('amsProject'),sSel=document.getElementById('amsStaff');if(!pSel||!sSel)return;
const cp=pSel.value,cs=sSel.value;
const projects=[...new Set([...(db.employees||[]).map(e=>String(e.project||'').trim()),...(db.measurements||[]).map(m=>m.project)].filter(Boolean))].sort();
pSel.innerHTML='<option value="">All projects</option>'+projects.map(p=>`<option value="${escapeHTML(p)}">${escapeHTML(p)}</option>`).join('');
sSel.innerHTML='<option value="">All staff</option>'+activeEmployees().map(e=>`<option value="${escapeHTML(e.id)}">${escapeHTML(e.name)} [${escapeHTML(e.id)}]</option>`).join('');
pSel.value=cp;sSel.value=cs;}
async function initAdminMeasurement(force){
if(!document.getElementById('amsProject'))return;
msBuildAdminFilters();renderAdminMeasurement();
const now=Date.now();
if(!force&&window.__msAt&&now-window.__msAt<30000)return;
if(window.__msLoading)return;window.__msLoading=true;
try{await msRefresh();window.__msAt=Date.now();msBuildAdminFilters();renderAdminMeasurement();}
finally{window.__msLoading=false;}}
let __amsT=null;
function renderAdminMeasurementSoon(){clearTimeout(__amsT);__amsT=setTimeout(renderAdminMeasurement,150);}
async function msAdd(){
if(!sessionUser||window.__msBusy)return;
const g=id=>document.getElementById(id);
const data={date:g('msDate').value,sheet:g('msSheet').value.trim(),description:g('msDesc').value.trim(),nos:g('msNos').value,length:g('msL').value,breadth:g('msB').value,depth:g('msD').value,unit:g('msUnit').value,deduct:g('msDeduct').checked,remarks:g('msRemarks').value.trim()};
if(!g('msProject').value){alert('No project is assigned to your account.');return}
if(!data.date){alert('Select a date.');return}
if(!data.sheet){alert('Enter the sheet / work item name.');return}
if(!data.description){alert('Enter a description.');return}
const q=msQtyFromInputs(data.nos,data.length,data.breadth,data.depth,false);
if(q===null){alert('Enter at least one valid measurement (Nos, Length, Breadth or Depth).');return}
if(q<=0){alert('Quantity must be greater than 0.');return}
window.__msBusy=true;let result;try{result=await server('add_measurement',data);}finally{window.__msBusy=false;}
if(result.status==='success'){
db.measurements=db.measurements||[];db.measurements.push(result.record);
['msDesc','msNos','msL','msB','msD','msRemarks'].forEach(id=>g(id).value='');g('msDeduct').checked=false;
renderStaffMeasurement();
}else{alert(result.message||'Unable to add measurement.');}}
function msEdit(id){
const r=(db.measurements||[]).find(m=>m.id===id);if(!r)return;
const old=document.getElementById('msEditOverlay');if(old)old.remove();
const v=x=>(x===null||x===undefined)?'':escapeHTML(String(x));
const ov=document.createElement('div');ov.id='msEditOverlay';
ov.style.cssText='position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:99999;display:flex;align-items:center;justify-content:center;padding:12px';
ov.innerHTML=`<div style="background:#fff;border-radius:12px;padding:18px;width:100%;max-width:480px;max-height:92vh;overflow:auto"><h3 style="margin-top:0">Edit Measurement</h3>
<div class="form-group"><label>Date</label><input id="meDate" type="date" value="${v(r.date)}"></div>
<div class="form-group"><label>Sheet / Work Item</label><input id="meSheet" type="text" maxlength="100" value="${v(r.sheet)}"></div>
<div class="form-group"><label>Description</label><input id="meDesc" type="text" maxlength="200" value="${v(r.description)}"></div>
<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 12px">
<div class="form-group"><label>Nos</label><input id="meNos" type="number" min="0" step="any" value="${v(r.nos)}"></div>
<div class="form-group"><label>Length</label><input id="meL" type="number" min="0" step="any" value="${v(r.length)}"></div>
<div class="form-group"><label>Breadth</label><input id="meB" type="number" min="0" step="any" value="${v(r.breadth)}"></div>
<div class="form-group"><label>Depth / Height</label><input id="meD" type="number" min="0" step="any" value="${v(r.depth)}"></div></div>
<div class="form-group"><label>Unit</label><select id="meUnit">${MS_UNITS.map(u=>`<option${u===r.unit?' selected':''}>${u}</option>`).join('')}</select></div>
<div class="form-group"><label>Remarks</label><input id="meRemarks" type="text" maxlength="200" value="${v(r.remarks)}"></div>
<label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:13px;margin-bottom:12px"><input id="meDeduct" type="checkbox" style="width:auto"${r.deduct?' checked':''}> Deduct (−)</label>
<div style="display:flex;gap:8px"><button class="btn btn-save" style="flex:1" id="meSave">Save</button><button class="btn btn-danger" style="flex:1" id="meCancel">Cancel</button></div></div>`;
document.body.appendChild(ov);
const g=i=>document.getElementById(i);
g('meCancel').onclick=()=>ov.remove();
ov.addEventListener('click',e=>{if(e.target===ov)ov.remove();});
g('meSave').onclick=async()=>{
if(window.__msBusy)return;
const data={id,date:g('meDate').value,sheet:g('meSheet').value.trim(),description:g('meDesc').value.trim(),nos:g('meNos').value,length:g('meL').value,breadth:g('meB').value,depth:g('meD').value,unit:g('meUnit').value,deduct:g('meDeduct').checked,remarks:g('meRemarks').value.trim()};
if(!data.date||!data.sheet||!data.description){alert('Date, sheet and description are required.');return}
const q=msQtyFromInputs(data.nos,data.length,data.breadth,data.depth,false);
if(q===null||q<=0){alert('Enter valid measurements; quantity must be greater than 0.');return}
window.__msBusy=true;let res;try{res=await server('update_measurement',data);}finally{window.__msBusy=false;}
if(res&&res.status==='success'){const i=db.measurements.findIndex(m=>m.id===id);if(i>=0)db.measurements[i]=res.record;ov.remove();renderStaffMeasurement();renderAdminMeasurement();}
else alert((res&&res.message)||'Unable to update.');};}
async function msDelete(id){
if(!confirm('Delete this measurement?'))return;
const result=await server('delete_measurement',{id});
if(result.status==='success'){db.measurements=(db.measurements||[]).filter(m=>m.id!==id);renderStaffMeasurement();renderAdminMeasurement();}
else{alert(result.message||'Unable to delete.');}}
function msPdf(prefix){
if(!window.jspdf){alert('PDF library failed to load. Please try again.');return}
const rows=msRows(prefix);if(!rows.length){alert('No measurements to download.');return}
const g=id=>{const el=document.getElementById(prefix+id);return el?el.value:'';};
const from=g('From'),to=g('To');
const period=(from||to)?((from||'start')+' to '+(to||'today')):'All dates';
const {jsPDF}=window.jspdf;const doc=new jsPDF({orientation:'portrait',unit:'mm',format:'a4'});
const W=210,H=297,M=10;
const cols=[['Item no',14,'c'],['Description or Particular',54,'l'],['No',12,'c'],['Length (M)',20,'c'],['Breadth (M)',20,'c'],['Height/Depth (M)',22,'c'],['Quantity',22,'c'],['Explanatory Notes',26,'l']];
const tw=cols.reduce((a,c)=>a+c[1],0);
const xs=[];{let x=M;cols.forEach(c=>{xs.push(x);x+=c[1];});}
const clean=t=>String(t==null?'':t).replace(/[^\x20-\x7E -ÿ]/g,'?');
const num=v=>(v===null||v===undefined||v==='')?'':msFmt(v);
const company=(db.company&&db.company.name)||'';
const RED=[220,38,38],BROWN=[154,52,18],NAVY=[30,58,138];
let y=0,first=true;
function cell(i,text,yy,h,opt){const c=cols[i];doc.rect(xs[i],yy,c[1],h);const t=doc.splitTextToSize(String(text),c[1]-3);
const tx=c[2]==='c'?xs[i]+c[1]/2:xs[i]+1.5;doc.text(t,tx,yy+4,{align:c[2]==='c'?'center':'left'});return t.length;}
function colHead(){
doc.setFont('helvetica','bold');doc.setFontSize(8);doc.setTextColor(...BROWN);doc.setDrawColor(0);doc.setLineWidth(.2);
const h=12;
[0,1,2,6,7].forEach(i=>{doc.rect(xs[i],y,cols[i][1],h);const t=doc.splitTextToSize(cols[i][0],cols[i][1]-2);doc.text(t,xs[i]+cols[i][1]/2,y+h/2-(t.length-1)*1.6+1,{align:'center'});});
doc.rect(xs[3],y,cols[3][1]+cols[4][1]+cols[5][1],6);doc.text('Dimensions',xs[3]+(cols[3][1]+cols[4][1]+cols[5][1])/2,y+4.2,{align:'center'});
[3,4,5].forEach(i=>{doc.rect(xs[i],y+6,cols[i][1],6);doc.text(cols[i][0],xs[i]+cols[i][1]/2,y+10.2,{align:'center'});});
y+=h;}
function pageHead(proj,sheetNo,full){
if(!first)doc.addPage();first=false;
doc.setTextColor(0);doc.setDrawColor(0);doc.setLineWidth(.2);
if(full){
doc.setFont('helvetica','bold');doc.setFontSize(12);doc.setTextColor(109,40,217);doc.text(clean(company),W/2,M+4,{align:'center'});
const addr=clean(typeof formatAddressOneLine==='function'?formatAddressOneLine((db.company&&db.company.addr)||''):'');
doc.setFont('helvetica','normal');doc.setFontSize(8);doc.text(addr,W/2,M+9,{align:'center'});
y=M+13;doc.rect(M,y,tw,14);doc.setFont('times','bold');doc.setFontSize(20);doc.setTextColor(138,109,11);doc.text('MEASUREMENT SHEET',W/2,y+9.5,{align:'center'});y+=14;
}else{y=M;}
doc.rect(M,y,tw,8);doc.setFont('helvetica','bold');doc.setFontSize(8.5);doc.setTextColor(...NAVY);
doc.text('Name of Project: '+clean(proj),M+2,y+5.3);doc.text('Period: '+period,M+tw*0.62,y+5.3);doc.text('Sheet No: '+sheetNo,M+tw-2,y+5.3,{align:'right'});y+=8;
colHead();}
const unitTot=list=>{const t={};list.forEach(r=>{const u=r.unit||'';t[u]=(t[u]||0)+msQ(r);});return Object.entries(t).map(([u,q])=>msFmt(q)+' '+u).join(' + ')||'-';};
const projects=[];rows.forEach(r=>{const k=r.project||'-';if(!projects.includes(k))projects.push(k);});
projects.forEach((proj,pi)=>{
const sn=msPad(pi+1);const pr=rows.filter(r=>(r.project||'-')===proj);
let cont=false;
const ensure=h=>{if(y+h>H-M-22){pageHead(proj,sn,false);}};
pageHead(proj,sn,true);
const items=[];pr.forEach(r=>{const k=r.sheet||'General';if(!items.includes(k))items.push(k);});
items.forEach((it,ii)=>{
const list=pr.filter(r=>(r.sheet||'General')===it);
ensure(20);
doc.setFont('helvetica','normal');doc.setFontSize(8);doc.setTextColor(0);
{const h=6;for(let i=0;i<cols.length;i++)doc.rect(xs[i],y,cols[i][1],h);doc.text(msPad(ii+1),xs[0]+cols[0][1]/2,y+4.2,{align:'center'});doc.setFont('helvetica','bold');doc.text(clean(it),xs[1]+1.5,y+4.2);doc.setFont('helvetica','normal');y+=h;}
list.forEach(r=>{
const desc=doc.splitTextToSize((r.deduct?'(-) ':'')+clean(r.description),cols[1][1]-3);
const note=doc.splitTextToSize(clean(r.remarks),cols[7][1]-3);
const h=Math.max(6,Math.max(desc.length,note.length)*3.6+2.4);ensure(h);
doc.setFont('helvetica','normal');doc.setFontSize(8);doc.setTextColor(r.deduct?190:0,r.deduct?18:0,r.deduct?60:0);
for(let i=0;i<cols.length;i++)doc.rect(xs[i],y,cols[i][1],h);
doc.text(desc,xs[1]+1.5,y+4);
[[2,msCnt(r.nos)],[3,num(r.length)],[4,num(r.breadth)],[5,num(r.depth)],[6,msFmt(msQ(r))]].forEach(([i,v])=>doc.text(v,xs[i]+cols[i][1]/2,y+4,{align:'center'}));
doc.text(note,xs[7]+1.5,y+4);y+=h;});
ensure(7);
for(let i=0;i<cols.length;i++)doc.rect(xs[i],y,cols[i][1],6);
doc.setFont('helvetica','bold');doc.setTextColor(0);doc.text('Total - '+clean(it),xs[1]+1.5,y+4.2);
doc.setTextColor(...RED);doc.text(unitTot(list),xs[6]+cols[6][1]/2,y+4.2,{align:'center'});doc.setTextColor(0);y+=6;
});
if(y>H-M-24)pageHead(proj,sn,false);
const sy=Math.max(y+22,H-M-6);doc.setFont('helvetica','normal');doc.setFontSize(8);doc.setTextColor(0);
if(sy<H-M){['Prepared by','Checked by','Client / Consultant Representative'].forEach((t,k)=>{const sx=M+k*(tw/3);doc.line(sx+3,sy-8,sx+tw/3-5,sy-8);doc.text(t,sx+3,sy-4);});}
});
const n=doc.getNumberOfPages();
for(let i=1;i<=n;i++){doc.setPage(i);doc.setFont('helvetica','normal');doc.setFontSize(8);doc.setTextColor(100);doc.text('Page '+i+' of '+n,W-M,H-4,{align:'right'});}
doc.save('Measurement-Sheet-'+new Date().toISOString().slice(0,10)+'.pdf');}
function msCsv(prefix){
const rows=msRows(prefix);if(!rows.length){alert('No measurements to export.');return}
const safe=v=>{let t=String(v==null?'':v);if(/^[=+\-@\t\r]/.test(t))t="'"+t;return '"'+t.replace(/"/g,'""')+'"';};
const head=['Project','Sheet','Date','Description','Nos','Length','Breadth','Depth','Quantity','Unit','Client Sign','Type','Staff','Remarks'];
const lines=[head.map(safe).join(',')].concat(rows.map(r=>[r.project,r.sheet,r.date,r.description,r.nos,r.length,r.breadth,r.depth,msQ(r),r.unit,'',r.deduct?'Deduct':'Add',r.employee_name||r.employee_id,r.remarks].map(safe).join(',')));
const a=document.createElement('a');a.download='Measurement-Sheet-'+new Date().toISOString().slice(0,10)+'.csv';
a.href='data:text/csv;charset=utf-8,'+encodeURIComponent('\ufeff'+lines.join('\r\n'));a.click();}
function msPrint(prefix){
const rows=msRows(prefix);if(!rows.length){alert('No measurements to print.');return}
const admin=prefix==='ams';
const g=id=>{const el=document.getElementById(prefix+id);return el?el.value:'';};
const projects=[...new Set(rows.map(r=>r.project))].join(', ');
const from=g('From'),to=g('To');
const period=(from||to)?((from||'start')+' to '+(to||'today')):'All dates';
const by=admin?'All staff':(sessionUser&&sessionUser.name||'');
let area=document.getElementById('msPrintArea');
if(!area){area=document.createElement('div');area.id='msPrintArea';document.body.appendChild(area);}
const logo=db.company&&db.company.logo?`<img src="${escapeHTML(db.company.logo)}" style="height:14mm;object-fit:contain" crossorigin="anonymous">`:'';
const coName=escapeHTML((db.company&&db.company.name)||''),coAddr=escapeHTML(typeof formatAddressOneLine==='function'?formatAddressOneLine((db.company&&db.company.addr)||''):'');
const projList=[];rows.forEach(r=>{const k=r.project||'—';if(!projList.includes(k))projList.push(k);});
area.innerHTML=projList.map((p,i)=>`<div class="ms-page"><div class="ms-co">${logo}<div><div class="ms-co1">${coName}</div><div class="ms-co2">${coAddr}</div></div></div><div class="ms-title">MEASUREMENT SHEET</div><div class="ms-meta"><span>Name of Project: <strong>${escapeHTML(p)}</strong></span><span>Period: ${escapeHTML(period)}</span><span>Sheet No: <strong>${msPad(i+1)}</strong></span></div>${msItemsTable(rows.filter(r=>(r.project||'—')===p),{print:true,showStaff:false,canDelete:false})}<div class="ms-sign"><div>Prepared by${admin?'':' – '+escapeHTML(by)}</div><div>Checked by</div><div>Client / Consultant Representative</div></div></div>`).join('');
const st=document.createElement('style');st.id='msPageStyle';st.textContent='@page{size:A4 portrait;margin:10mm}';document.head.appendChild(st);
document.body.classList.add('ms-printing');
let finished=false;
const done=()=>{if(finished)return;finished=true;document.body.classList.remove('ms-printing');st.remove();area.innerHTML='';window.removeEventListener('afterprint',done);document.removeEventListener('pointerdown',done,true);};
window.addEventListener('afterprint',done);
setTimeout(()=>{try{window.print();}catch(e){done();}},400);
setTimeout(()=>{document.addEventListener('pointerdown',done,true);},2500);}
async function saveCashbookEntryStaff(){
if(!sessionUser)return;
const project=document.getElementById('scbProject').value.trim();
const category=document.getElementById('scbCategory').value;
const amount=Number(document.getElementById('scbAmount').value)||0;
const type=document.getElementById('scbType').value;
const date=document.getElementById('scbDate').value;
const description=document.getElementById('scbDescription').value.trim();
if(!date){alert('Select a date.');return}
if(!project){alert('No project is assigned to your account.');return}
if(!description){alert('Enter description.');return}
if(!category){alert('Select a category.');return}
if(amount<=0){alert('Enter an amount greater than 0.');return}
const income=type==='income'?amount:0,expense=type==='expense'?amount:0;
const bill=await readCashBillFile();
if(bill===false)return;
const result=await server('add_cashbook_entry',{employee_id:sessionUser.id,date,project,description,category,income,expense,bill_data:bill?.data||'',bill_name:bill?.name||''});
if(result.status==='success'){
db.cashbook.push(result.record);
document.getElementById('scbAmount').value='';
document.getElementById('scbDescription').value='';
document.getElementById('scbCategory').value='';
document.getElementById('scbType').value='income';
const billInput=document.getElementById('scbBill');if(billInput)billInput.value='';
renderStaffCashbook();
}
alert(result.message);
}
function renderStaffCashbook(){
if(typeof syncCashBills==='function'&&!window.__cbRendering){syncCashBills(false).then(ch=>{if(ch){window.__cbRendering=true;try{renderStaffCashbook();}finally{window.__cbRendering=false;}}});}
const box=document.getElementById('scbList'),sumBox=document.getElementById('scbSummary');if(!box||!sumBox||!sessionUser)return;
initStaffCashbookForm();
const list=(db.cashbook||[]).filter(c=>c.employee_id===sessionUser.id);
const rows=cashbookRunningRows(list);
sumBox.innerHTML=cashbookSummaryHTML(rows);
box.innerHTML=cashbookTableHTML(rows,true);
renderStaffOwnerPayments();
renderOverallSiteSpending('overallSpendSummary',rows,(db.owner_payments||[]).filter(o=>o.employee_id===sessionUser.id));
}
function ownerPaymentRowHTML(o,showDelete){
return `<tr>
<td>${escapeHTML(o.date||'')}</td>
<td>${escapeHTML(o.project||'')}</td>
<td>${escapeHTML(o.paid_to||'-')}</td>
<td>${escapeHTML(o.description||'')}</td>
<td class="amount" style="color:#7c3aed">₹ ${formatINR(o.amount)}</td>
${showDelete?`<td class="no-print"><button class="btn btn-danger cashbook-delete-btn delete-design-btn" title="Delete" aria-label="Delete" onclick="deleteOwnerPayment('${o.id}')">Del</button></td>`:''}
</tr>`;
}
function ownerPaymentTableHTML(rows,showDelete){
if(!rows.length)return '<p style="color:#64748b">No owner direct payments recorded.</p>';
return `<div class="cashbook-table-wrap cashbook-scroll-panel owner-payment-scroll"><table class="salary cashbook-table owner-cashbook-table" style="width:100%"><thead><tr><th>Date</th><th>Project</th><th>Paid To</th><th>Description</th><th>Amount</th>${showDelete?'<th class="no-print"></th>':''}</tr></thead><tbody>${rows.map(o=>ownerPaymentRowHTML(o,showDelete)).join('')}</tbody></table></div>`;
}
function ownerPaymentSummaryHTML(rows){
const total=rows.reduce((s,o)=>s+Number(o.amount||0),0);
return `<div class="summary-box"><div class="summary-label">Owner Direct Payments</div><div class="summary-value" style="color:#7c3aed">₹ ${formatINR(total)}</div></div>`;
}
function renderOverallSiteSpending(targetId,cashbookRows,ownerPayRows){
const box=document.getElementById(targetId);if(!box)return;
const cbExpense=cashbookRows.reduce((s,c)=>s+Number(c.expense||0),0);
const ownerTotal=ownerPayRows.reduce((s,o)=>s+Number(o.amount||0),0);
const overall=cbExpense+ownerTotal;
box.innerHTML=`<div class="summary-box"><div class="summary-label">Cash Book Expense</div><div class="summary-value" style="color:#dc2626">₹ ${formatINR(cbExpense)}</div></div><div class="summary-box"><div class="summary-label">Owner Direct Payments</div><div class="summary-value" style="color:#7c3aed">₹ ${formatINR(ownerTotal)}</div></div><div class="summary-box"><div class="summary-label">Overall Site Spending</div><div class="summary-value" style="color:#0f3f7a">₹ ${formatINR(overall)}</div></div>`;
}
async function deleteOwnerPayment(id){
if(!confirm('Delete this owner payment entry?'))return;
const result=await server('delete_owner_payment',{id});
if(result.status==='success'){db.owner_payments=(db.owner_payments||[]).filter(o=>o.id!==id);renderStaffCashbook()}
alert(result.message);
}
async function saveOwnerPaymentStaff(){
if(!sessionUser)return;
const project=document.getElementById('opProject').value.trim();
const paid_to=document.getElementById('opPaidTo').value.trim();
const amount=Number(document.getElementById('opAmount').value)||0;
const date=document.getElementById('opDate').value;
const description=document.getElementById('opDescription').value.trim();
if(!date){alert('Select a date.');return}
if(!project){alert('No project is assigned to your account.');return}
if(!description){alert('Enter description.');return}
if(amount<=0){alert('Enter an amount greater than 0.');return}
const result=await server('add_owner_payment',{employee_id:sessionUser.id,date,project,description,paid_to,amount});
if(result.status==='success'){
db.owner_payments=db.owner_payments||[];
db.owner_payments.push(result.record);
document.getElementById('opAmount').value='';
document.getElementById('opDescription').value='';
document.getElementById('opPaidTo').value='';
renderStaffCashbook();
}
alert(result.message);
}
function renderStaffOwnerPayments(){
const box=document.getElementById('opList'),sumBox=document.getElementById('opSummary');if(!box||!sumBox||!sessionUser)return;
const list=(db.owner_payments||[]).filter(o=>o.employee_id===sessionUser.id).sort((a,b)=>(b.date||'').localeCompare(a.date||''));
sumBox.innerHTML=ownerPaymentSummaryHTML(list);
box.innerHTML=ownerPaymentTableHTML(list,true);
}
function initAdminCashbookReport(){
const el=document.getElementById('adminCashbookEmployee');
if(!el)return;
const current=el.value;
const employees=activeEmployees();
el.innerHTML='<option value="">Select Employee</option>'+employees.map(e=>`<option value="${escapeHTML(e.id)}">${escapeHTML(e.name||'Employee')} [${escapeHTML(e.id||'')}]</option>`).join('');
if(employees.some(e=>String(e.id)===String(current)))el.value=current;
renderAdminCashbookReport();
}
function renderAdminCashbookReport(){
const el=document.getElementById('adminCashbookEmployee');
const listBox=document.getElementById('adminCashbookList');
const sumBox=document.getElementById('adminCashbookSummary');
const printBtn=document.getElementById('adminCashbookPrintBtn');
if(!el||!listBox||!sumBox)return;
const id=String(el.value||'');
const opSumBoxEmpty=document.getElementById('adminOwnerPaySummary'),opListBoxEmpty=document.getElementById('adminOwnerPayList'),overallBoxEmpty=document.getElementById('adminOverallSpendSummary');
if(!id){sumBox.innerHTML='';listBox.innerHTML='<p style="color:#64748b">Select an employee to view the Cash Book report.</p>';if(opSumBoxEmpty)opSumBoxEmpty.innerHTML='';if(opListBoxEmpty)opListBoxEmpty.innerHTML='';if(overallBoxEmpty)overallBoxEmpty.innerHTML='';if(printBtn)printBtn.classList.add('hidden');return;}
const employee=(db.employees||[]).find(e=>String(e.id)===id);
if(!employee){sumBox.innerHTML='';listBox.innerHTML='<p style="color:#dc2626">Employee not found.</p>';if(opSumBoxEmpty)opSumBoxEmpty.innerHTML='';if(opListBoxEmpty)opListBoxEmpty.innerHTML='';if(overallBoxEmpty)overallBoxEmpty.innerHTML='';if(printBtn)printBtn.classList.add('hidden');return;}
const rows=cashbookRunningRows((db.cashbook||[]).filter(c=>String(c.employee_id)===id));
sumBox.innerHTML=cashbookSummaryHTML(rows);
listBox.innerHTML=cashbookTableHTML(rows,false);
const opRows=(db.owner_payments||[]).filter(o=>String(o.employee_id)===id).sort((a,b)=>(b.date||'').localeCompare(a.date||''));
const opSumBox=document.getElementById('adminOwnerPaySummary'),opListBox=document.getElementById('adminOwnerPayList');
if(opSumBox)opSumBox.innerHTML=ownerPaymentSummaryHTML(opRows);
if(opListBox)opListBox.innerHTML=ownerPaymentTableHTML(opRows,false);
renderOverallSiteSpending('adminOverallSpendSummary',rows,opRows);
if(printBtn)printBtn.classList.toggle('hidden',false);
}
function printAdminCashbookReport(){
const id=document.getElementById('adminCashbookEmployee')?.value||'';
if(!id){alert('Select an employee first.');return;}
const employee=(db.employees||[]).find(e=>String(e.id)===String(id));
if(!employee){alert('Employee not found.');return;}
printCashbookA4(employee);
}
function generateCashbookReport(){
printCashbookA4();
}
function printCashbookA4(selectedEmployee){
const employee=selectedEmployee||sessionUser;
if(!employee)return;
const list=(db.cashbook||[]).filter(c=>c.employee_id===employee.id);
const rows=cashbookRunningRows(list);
const income=rows.reduce((s,c)=>s+Number(c.income||0),0);
const expense=rows.reduce((s,c)=>s+Number(c.expense||0),0);
const balance=income-expense;
const opRows=(db.owner_payments||[]).filter(o=>o.employee_id===employee.id).sort((a,b)=>(a.date||'').localeCompare(b.date||''));
const ownerTotal=opRows.reduce((s,o)=>s+Number(o.amount||0),0);
const overallSpend=expense+ownerTotal;
const now=new Date();
const periodLabel=rows.length ? (rows[0].date+' to '+rows[rows.length-1].date) : '—';
const address=formatAddressOneLine(db.company.addr||'');
const logo=db.company.logo ? `<img src="${db.company.logo}" alt="Tejodhar Construction">` : '';
const printWin=window.open('', '_blank', 'width=900,height=1200');
if(!printWin){alert('Please allow pop-ups to print the Cash Book report.');return;}
printWin.document.open();
printWin.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Cash Book Report</title>
<style>@page{size:A4 portrait;margin:0}*{box-sizing:border-box}html,body{margin:0;padding:0;background:#fff;color:#111827;font-family:Arial,sans-serif;font-size:10pt}.print-page{position:relative;width:210mm;height:297mm;background:#fff;page-break-after:always;break-after:page;overflow:hidden}.print-page:last-child{page-break-after:auto;break-after:auto}.page-header{position:absolute;top:10mm;left:10mm;right:10mm;height:15mm;background:#fff;border-bottom:1px solid #cbd5e1;display:flex;align-items:center;justify-content:space-between;gap:8mm;padding:2mm 0;z-index:10}.brand{display:flex;align-items:center;gap:4mm;min-width:0}.brand img{width:30mm;height:11mm;object-fit:contain;display:block}.brand-title{font-size:12pt;font-weight:900;letter-spacing:.3px;white-space:nowrap}.address{font-size:7.5pt;line-height:1.25;color:#475569;text-align:right;max-width:95mm}.header-dash{position:absolute;top:25mm;left:10mm;right:10mm;height:17mm;background:#fff;display:grid;grid-template-columns:repeat(3,1fr);gap:2mm;padding:1.6mm 0;border-bottom:1px solid #e2e8f0;z-index:9}.box{border:1px solid #dbe3ec;border-radius:2mm;padding:2mm;text-align:center;min-height:12mm}.label{font-size:6.5pt;font-weight:800;text-transform:uppercase;color:#64748b}.value{font-size:10pt;font-weight:900;margin-top:.5mm}.income{color:#059669}.expense{color:#dc2626}.balance{color:#0f3f7a}.page-content{position:absolute;top:44mm;bottom:31mm;left:10mm;right:10mm;overflow:hidden}.page-footer{position:absolute;bottom:8mm;left:10mm;right:10mm;height:20mm;background:#fff;border-top:1px solid #cbd5e1;z-index:10}.footer-dash{display:grid;grid-template-columns:repeat(3,1fr);gap:2mm;padding:1.6mm 0}.footer-dash .box{min-height:0;padding:1.4mm 2mm}.footer-dash .label{font-size:6.5pt}.footer-dash .value{font-size:10pt;margin-top:.5mm}.footer-strip{display:flex;align-items:center;justify-content:space-between;height:8mm;border-top:1px solid #e2e8f0;font-size:7.5pt;color:#475569}.footer-strip strong{color:#3730a3}.footer-page{font-weight:700;color:#475569}.report-title{margin:0 0 4mm;text-align:center;font-size:15pt;font-weight:900;color:#111827;border:1px solid #cbd5e1;background:#eef2f7;padding:3mm}.meta{font-size:9pt;line-height:1.6;margin-bottom:4mm}table.salary{width:100%;border-collapse:collapse;table-layout:fixed;font-size:8pt}.salary th{background:#111827;color:#fff;padding:2.2mm 1.5mm;text-align:left;font-size:7.5pt}.salary td{border:1px solid #dbe3ec;padding:2mm 1.5mm;vertical-align:top;word-break:break-word;overflow-wrap:anywhere}.salary tbody tr{break-inside:avoid;page-break-inside:avoid}.salary th:nth-child(1),.salary td:nth-child(1){width:14%}.salary th:nth-child(2),.salary td:nth-child(2){width:16%}.salary th:nth-child(3),.salary td:nth-child(3){width:24%}.salary th:nth-child(4),.salary td:nth-child(4){width:13%}.salary th:nth-child(5),.salary td:nth-child(5),.salary th:nth-child(6),.salary td:nth-child(6),.salary th:nth-child(7),.salary td:nth-child(7){width:11%}.salary .no-print{display:none!important}.owner-salary th:nth-child(1),.owner-salary td:nth-child(1){width:14%}.owner-salary th:nth-child(2),.owner-salary td:nth-child(2){width:18%}.owner-salary th:nth-child(3),.owner-salary td:nth-child(3){width:20%}.owner-salary th:nth-child(4),.owner-salary td:nth-child(4){width:33%}.owner-salary th:nth-child(5),.owner-salary td:nth-child(5){width:15%}.section-print-title{font-size:12pt;font-weight:900;text-align:center;background:#eef2f7;border:1px solid #cbd5e1;padding:2.5mm;margin:5mm 0 3mm}@media print{body{width:210mm}.print-page{width:210mm;height:297mm}.page-content{overflow:hidden}}</style><style id="tejodhar-multicolour-login-final">

</style></head><body><style id="op-theme-dropdown-style">.op-theme-section{margin:10px 14px 16px;padding:15px 14px 14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:14px}.op-theme-section label{display:block;margin:0 0 8px;padding:0;font-size:12px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:#475569}.op-theme-section select{display:block;width:100%;min-height:44px;padding:10px 38px 10px 12px;border:1px solid #cbd5e1;border-radius:10px;background:#fff;color:#0f172a;font-size:15px;font-weight:650;outline:none}.op-theme-section select:focus{border-color:#f97316;box-shadow:0 0 0 3px rgba(249,115,22,.15)}.op-theme-section small{display:block;margin-top:7px;color:#64748b;font-size:11px}@media(min-width:601px){#opMenu{left:auto;width:380px;box-shadow:-15px 0 40px rgba(15,23,42,.16)}#opMenu .op-top{padding-left:18px}}.login-card .btn-primary{background:linear-gradient(100deg,var(--login-accent,#f97316),var(--login-secondary,#fb923c))!important;box-shadow:0 12px 25px color-mix(in srgb,var(--login-accent,#f97316) 22%,transparent)!important}.login-card input:focus,.login-card select:focus{border-color:var(--login-accent,#f97316)!important;box-shadow:0 0 0 4px color-mix(in srgb,var(--login-accent,#f97316) 12%,transparent)!important}.login-forgot-link{color:var(--login-accent,#f97316)!important}</style>
</body></html>`);
printWin.document.close();
const doc=printWin.document;
const pageList=[];
const tableHeader=`<tr><th>Date</th><th>Project</th><th>Description</th><th>Category</th><th>Income</th><th>Expense</th><th>Balance</th><th class="no-print">Bill</th></tr>`;
const ownerHeader=`<tr><th>Date</th><th>Project</th><th>Paid To</th><th>Description</th><th>Amount</th></tr>`;
const cashRows=rows.map(c=>cashbookRowHTML(c,false).replace(/<td class="no-print"/g,'<td class="no-print"'));
const ownerRows=opRows.map(o=>ownerPaymentRowHTML(o,false));
function makePage(){
const p=doc.createElement('section');p.className='print-page';
p.innerHTML=`<div class="page-header"><div class="brand">${logo||'<div class="brand-title">TEJODHAR CONSTRUCTION</div>'}</div><div class="address">${escapeHTML(address)}</div></div>
<div class="header-dash"><div class="box"><div class="label">Income</div><div class="value income">₹ ${formatINR(income)}</div></div><div class="box"><div class="label">Expense</div><div class="value expense">₹ ${formatINR(expense)}</div></div><div class="box"><div class="label">Balance</div><div class="value balance">₹ ${formatINR(balance)}</div></div></div>
<div class="page-content"></div>
<div class="page-footer"><div class="footer-dash"><div class="box"><div class="label">Owner Direct Payments</div><div class="value" style="color:#7c3aed">₹ ${formatINR(ownerTotal)}</div></div><div class="box"><div class="label">Cash Book Expense</div><div class="value expense">₹ ${formatINR(expense)}</div></div><div class="box"><div class="label">Overall Site Spending</div><div class="value balance">₹ ${formatINR(overallSpend)}</div></div></div><div class="footer-strip"><strong>CASH BOOK REPORT &nbsp;|&nbsp; OWNER DIRECT PAYMENTS</strong><span class="footer-page"></span><span>Generated On: ${now.toLocaleDateString('en-IN')}</span></div></div>`;
doc.body.appendChild(p);pageList.push(p);return p;
}
function newTable(className,header){
const t=doc.createElement('table');t.className=`salary ${className||''}`;t.innerHTML=`<thead>${header}</thead><tbody></tbody>`;return t;
}
function fits(page,el){return page.querySelector('.page-content').scrollHeight <= page.querySelector('.page-content').clientHeight + 1;}
function addWithOverflow(page,node){
const content=page.querySelector('.page-content');content.appendChild(node);
if(!fits(page,node)){
content.removeChild(node);return false;
}
return true;
}
let page=makePage();
const first=page.querySelector('.page-content');
first.insertAdjacentHTML('beforeend',`<div class="report-title">CASH BOOK REPORT</div><div class="meta"><strong>Employee:</strong> ${escapeHTML(employee.name||'')} [${escapeHTML(employee.id||'')}] &nbsp;&nbsp; <strong>Report Period:</strong> ${escapeHTML(periodLabel)} &nbsp;&nbsp; <strong>Generated On:</strong> ${now.toLocaleDateString('en-IN')}</div>`);
let cashTable=null;
if(cashRows.length){
cashTable=newTable('cashbook-table',tableHeader);first.appendChild(cashTable);
for(const rowHTML of cashRows){
const tr=document.createElement('tbody');tr.innerHTML=rowHTML;const row=tr.firstElementChild;
cashTable.tBodies[0].appendChild(row);
if(!fits(page,row)){
cashTable.tBodies[0].removeChild(row);
page=makePage();cashTable=newTable('cashbook-table',tableHeader);page.querySelector('.page-content').appendChild(cashTable);cashTable.tBodies[0].appendChild(row);
}
}
}else{
first.insertAdjacentHTML('beforeend','<p style="color:#64748b">No cash book entries recorded.</p>');
}
if(ownerRows.length){
const title=document.createElement('div');title.className='section-print-title';title.textContent='OWNER DIRECT PAYMENTS';
if(!addWithOverflow(page,title)){
page=makePage();page.querySelector('.page-content').appendChild(title);
}
let ownerTable=newTable('owner-salary',ownerHeader);page.querySelector('.page-content').appendChild(ownerTable);
for(const rowHTML of ownerRows){
const temp=document.createElement('tbody');temp.innerHTML=rowHTML;const row=temp.firstElementChild;ownerTable.tBodies[0].appendChild(row);
if(!fits(page,row)){
ownerTable.tBodies[0].removeChild(row);page=makePage();ownerTable=newTable('owner-salary',ownerHeader);page.querySelector('.page-content').appendChild(ownerTable);ownerTable.tBodies[0].appendChild(row);
}
}
}else{
const title=document.createElement('div');title.className='section-print-title';title.textContent='OWNER DIRECT PAYMENTS';
if(!addWithOverflow(page,title)){page=makePage();page.querySelector('.page-content').appendChild(title);}
page.querySelector('.page-content').insertAdjacentHTML('beforeend','<p style="color:#64748b">No owner direct payments recorded.</p>');
}
pageList.forEach((p,i)=>{const n=p.querySelector('.footer-page');if(n)n.textContent=`Page ${i+1} of ${pageList.length}`;});
setTimeout(function(){printWin.focus();printWin.print();setTimeout(function(){printWin.close()},700)},500);
}
function leaveStarMark(status){return ['CL','SL','OD','LOP'].includes(status)?'<span class="leave-star" title="Approved leave">⭐</span>':'';}
/* Punch helpers: records are stored in the order they were SAVED (approved forgot-punches are appended
   at the end), so the array's last item is not necessarily the latest punch. Always sort by timestamp,
   and format the time from the timestamp so self punches and approved forgot-punches look the same. */
function punchSorted(list){return (list||[]).map((p,i)=>({p,i})).sort((a,b)=>((Number(a.p.ts)||0)-(Number(b.p.ts)||0))||(a.i-b.i)).map(x=>x.p);}
function punchTimeLabel(p){if(!p)return '';const ts=Number(p.ts);if(ts>0){try{return new Date(ts).toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',hour12:true,timeZone:'Asia/Kolkata'});}catch(e){}}return p.time||'';}
function punchMinutesOfDay(p){const ts=Number(p&&p.ts);if(ts>0){try{const parts=new Intl.DateTimeFormat('en-GB',{hour:'2-digit',minute:'2-digit',hourCycle:'h23',timeZone:'Asia/Kolkata'}).formatToParts(new Date(ts));const h=Number(parts.find(x=>x.type==='hour').value),m=Number(parts.find(x=>x.type==='minute').value);return h*60+m;}catch(e){}}const m=String(p&&p.time||'').match(/(\d+):(\d+)(?::\d+)?\s*(AM|PM)?/i);if(!m)return null;let h=Number(m[1]);if(m[3]){h=h%12+(m[3].toUpperCase()==='PM'?12:0);}return h*60+Number(m[2]);}
function punchSummary(key,day){
const punches=((db.punches||{})[key]||{})[day];
if(!punches||!punches.length)return '';
const sorted=punchSorted(punches),ins=sorted.filter(p=>p.type==='IN'),outs=sorted.filter(p=>p.type==='OUT');
const inTime=ins.length?punchTimeLabel(ins[0]):'',outTime=outs.length?punchTimeLabel(outs[outs.length-1]):'';
const shorten=t=>t.replace(':00 ',' ');
return `<div class="punch-summary">${inTime?('In '+shorten(inTime)):''}${outTime?('<br>Out '+shorten(outTime)):''}</div>`;
}
function activeEmployees(){return (db.employees||[]).filter(e=>!e.terminated);} /* terminated staff show ONLY in Employee Master */
function holidayPayableFor(e,year,month,day){
/* Terminated employees get no holiday pay (neither the paid holiday nor the double-pay bonus) for holidays after their termination date. */
if(e&&e.terminated&&e.termination_date){const ds=`${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;if(ds>String(e.termination_date).slice(0,10))return false;}
return true;
}
function isEmpAttendanceLocked(key){
const m=String(key).match(/^(.*)-(\d+)-(\d+)$/),emp=m&&(db.employees||[]).find(x=>String(x.id)===m[1]);
return !!(emp&&emp.terminated);
}
function holidayForDate(year,month,day){
const dateStr=`${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
return (db.holidays||[]).find(h=>h.date===dateStr);
}
function renderAdminCalendar(){
const month=Number(document.getElementById('attM').value),year=Number(document.getElementById('attY').value),employee=document.getElementById('attE').value,box=document.getElementById('calendar');box.innerHTML='';if(!employee){const ph=document.getElementById('punchHistory');if(ph)ph.innerHTML='';const ts=document.getElementById('punchTodaySummary');if(ts)ts.innerHTML='';const lb=document.getElementById('payrollLockBar');if(lb)lb.innerHTML='';return}
const days=new Date(year,month+1,0).getDate(),key=`${employee}-${month}-${year}`;if(!db.attendance[key])db.attendance[key]={};
for(let day=1;day<=days;day++){
const hol=holidayForDate(year,month,day);
const sunday=new Date(year,month,day).getDay()===0,status=hol?'HOL':(sunday?'SUN':(db.attendance[key][day]||'A')),cell=document.createElement('div');cell.className=`day ${status}`;cell.innerHTML=`${leaveStarMark(status)}<span>${day}</span><small>${status}</small>${punchSummary(key,day)}<button type="button" class="day-view-btn">🕒</button>`;
cell.querySelector('.day-view-btn').onclick=(ev)=>{ev.stopPropagation();showPunchModal(key,day,month,year)};
calAppend(box,cell,year,month,day)}
renderPunchHistory('punchHistory',key,month,year);
renderPunchTodaySummary(key,month,year);
renderPayrollLockBar(key);
}
function renderPayrollLockBar(key){
renderSalaryPaidBar(key);
const bar=document.getElementById('payrollLockBar');if(!bar)return;
if(isEmpAttendanceLocked(key)){bar.innerHTML=`<div><strong style="color:#be123c">🔒 Attendance Permanently Locked</strong><div style="font-size:12px;color:#64748b">This employee is terminated. Attendance can't be edited or unlocked.</div></div>`;return;}
const locked=(db.locked_payroll||[]).includes(key);
bar.innerHTML=locked?
`<div><strong style="color:#be123c">🔒 Payroll Locked</strong><div style="font-size:12px;color:#64748b">Attendance for this employee/month can't be edited.</div></div><button class="btn" style="background:#e2e8f0;color:#334155" onclick="unlockPayroll('${key}')">Unlock</button>`:
`<div><strong style="color:#059669">🔓 Payroll Open</strong><div style="font-size:12px;color:#64748b">Lock once the payslip is finalized to prevent further edits.</div></div><button class="btn btn-save" onclick="lockPayroll('${key}')">Lock Payroll</button>`;
}
function renderSalaryPaidBar(key){
const bar=document.getElementById('salaryPaidBar');if(!bar)return;
const paid=(db.salary_paid||{})[key];
if(paid){bar.innerHTML=`<div><strong style="color:#1d4ed8">✅ Salary Paid</strong><div style="font-size:12px;color:#64748b">Paid on ${escapeHTML(paid.date||'')}. The PAID seal shows on this month's payslip.</div></div><button class="btn" style="background:#e2e8f0;color:#334155" onclick="unmarkSalaryPaid('${key}')">Undo Paid</button>`;return;}
let balHTML='';
try{
const m=String(key).match(/^(.*)-(\d+)-(\d+)$/),emp=m&&(db.employees||[]).find(x=>String(x.id)===m[1]);
if(emp){const r=computeSalaryFor(emp,Number(m[2]),Number(m[3])),other=r.deductions-r.monthlyAdvance;
balHTML=`<div style="margin-top:8px;font-size:13px;line-height:1.7"><div>Total Salary: <strong>₹ ${formatINR(r.earnedTotal)}</strong></div><div>Advance: <strong style="color:#be123c">− ₹ ${formatINR(r.monthlyAdvance)}</strong></div>${other>0?`<div>Other Deductions (PF/PT): <strong style="color:#be123c">− ₹ ${formatINR(other)}</strong></div>`:''}<div style="font-size:15px;color:#059669;font-weight:800">Balance Amount: ₹ ${formatINR(r.netPay)}</div></div>`;}
}catch(err){}
bar.innerHTML=`<div><strong style="color:#b45309">💰 Salary Not Paid</strong><div style="font-size:12px;color:#64748b">Payroll summary for the selected employee and month. Marking paid adds the PAID seal to the payslip and locks this month's payroll.</div>${balHTML}</div><button class="btn btn-save" onclick="markSalaryPaid('${key}')">Mark Salary Paid</button>`;
}
async function markSalaryPaid(key){
if(!confirm('Mark salary as PAID for this employee and month?\n\nThe payroll will be locked and a PAID seal will appear on the payslip.'))return;
const result=await server('mark_salary_paid',{key});
if(result.status==='success'){if(!db.salary_paid||Array.isArray(db.salary_paid))db.salary_paid={};db.salary_paid[key]=result.record;if(!db.locked_payroll)db.locked_payroll=[];if(!db.locked_payroll.includes(key))db.locked_payroll.push(key);renderPayrollLockBar(key);}
alert(result.message);
}
async function unmarkSalaryPaid(key){
if(!confirm('Remove the PAID mark for this month?'))return;
const result=await server('unmark_salary_paid',{key});
if(result.status==='success'){if(db.salary_paid&&!Array.isArray(db.salary_paid))delete db.salary_paid[key];renderPayrollLockBar(key);}
alert(result.message);
}
async function lockPayroll(key){
const result=await server('lock_payroll',{key});
if(result.status==='success'){if(!db.locked_payroll)db.locked_payroll=[];if(!db.locked_payroll.includes(key))db.locked_payroll.push(key);renderPayrollLockBar(key);}
alert(result.message);
}
async function unlockPayroll(key){
const result=await server('unlock_payroll',{key});
if(result.status==='success'){db.locked_payroll=(db.locked_payroll||[]).filter(k=>k!==key);renderPayrollLockBar(key);}
alert(result.message);
}
async function saveHoliday(){
const date=document.getElementById('holDate').value,name=document.getElementById('holName').value,double_pay=document.getElementById('holDouble').checked;
if(!date){alert('Pick a date.');return}
const result=await server('add_holiday',{date,name,double_pay});
if(result.status==='success'){db.holidays=db.holidays||[];db.holidays.push(result.record);document.getElementById('holDate').value='';document.getElementById('holName').value='';document.getElementById('holDouble').checked=false;renderHolidayList();renderAdminCalendar();}
alert(result.message);
}
function renderHolidayList(){
const box=document.getElementById('holList');if(!box)return;
const list=(db.holidays||[]).slice().sort((a,b)=>a.date.localeCompare(b.date));
box.innerHTML=list.length?list.map(h=>`<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)"><div><strong>${escapeHTML(h.date)}</strong> — ${escapeHTML(h.name)}${h.double_pay?' <span style="color:#a21caf;font-size:11px">(Double Pay)</span>':''}</div><button class="btn btn-danger delete-design-btn" style="padding:4px 10px" onclick="deleteHoliday('${h.id}')">Delete</button></div>`).join(''):'<p style="color:#64748b">No holidays added yet.</p>';
}
async function deleteHoliday(id){
if(!confirm('Remove this holiday?'))return;
const result=await server('delete_holiday',{id});
if(result.status==='success'){db.holidays=(db.holidays||[]).filter(h=>h.id!==id);renderHolidayList();renderAdminCalendar();}
alert(result.message);
}
function renderPunchTodaySummary(key,month,year){
const box=document.getElementById('punchTodaySummary');if(!box)return;
const now=new Date();
let day=null,label='';
if(now.getMonth()===month&&now.getFullYear()===year){day=now.getDate();label='Today';}
else{
const monthPunches=(db.punches||{})[key]||{};
const withPunches=Object.keys(monthPunches).map(Number).filter(d=>monthPunches[d]&&monthPunches[d].length);
if(withPunches.length){day=Math.max(...withPunches);label=`${String(day).padStart(2,'0')}/${String(month+1).padStart(2,'0')}/${year}`;}
}
if(day===null){box.innerHTML='<p style="color:#64748b;font-size:12px">No punches recorded for this employee in this view.</p>';return}
const punches=((db.punches||{})[key]||{})[day]||[];
const insCount=punches.filter(p=>p.type==='IN').length,outsCount=punches.filter(p=>p.type==='OUT').length;
box.innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;padding:12px 14px;border:1px solid #e2e8f0;border-radius:14px;background:#f8fafc">
<div><strong>${escapeHTML(label)}</strong><div style="font-size:11px;color:#64748b;margin-top:2px">${punches.length?`${punches.length} punch${punches.length>1?'es':''} recorded`:'No punches recorded'}</div></div>
<div style="display:flex;gap:8px">
<span class="punch-total-box" style="background:#ecfdf5;color:#047857">IN<span>${insCount}</span></span>
<span class="punch-total-box" style="background:#fff1f2;color:#be123c">OUT<span>${outsCount}</span></span>
</div>
</div>`;
}
function openFullPunchHistoryPage(){
const month=Number(document.getElementById('attM').value),year=Number(document.getElementById('attY').value),employee=document.getElementById('attE').value;
if(!employee){alert('Select an employee first.');return}
const emp=db.employees.find(e=>String(e.id)===String(employee));
const key=`${employee}-${month}-${year}`,days=new Date(year,month+1,0).getDate(),rows=[];
for(let day=1;day<=days;day++){
const punches=((db.punches||{})[key]||{})[day];if(!punches||!punches.length)continue;
[...punches].sort((a,b)=>(a.ts||0)-(b.ts||0)).forEach(p=>rows.push({day,...p}));
}
rows.sort((a,b)=>(a.day-b.day)||((a.ts||0)-(b.ts||0)));
const rowsHtml=rows.length?rows.map(p=>{
const dateLabel=`${String(p.day).padStart(2,'0')}/${String(month+1).padStart(2,'0')}/${year}`,isSelf=p.site==='Self',typeColor=p.type==='IN'?'#059669':'#be123c';
return `<tr><td>${dateLabel}</td><td style="color:${typeColor};font-weight:800">${p.type}</td><td>${escapeHTML(p.time||'')}</td><td>${isSelf?'🙋 Self Punch':'🛡️ '+escapeHTML(p.site||'—')}</td></tr>`;
}).join(''):'<tr><td colspan="4" style="text-align:center;color:#64748b;padding:20px">No punches recorded this month.</td></tr>';
const html=`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Punch History — ${escapeHTML(emp&&emp.name||employee)} — ${months[month]} ${year}</title>
<style>body{font-family:system-ui,-apple-system,sans-serif;margin:0;padding:30px;background:#f8fafc;color:#1e293b}h1{font-size:20px;margin:0 0 4px}p.sub{color:#64748b;font-size:13px;margin:0 0 24px}table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.08)}th,td{padding:10px 14px;text-align:left;font-size:13px;border-bottom:1px solid #e2e8f0}th{background:#eef2ff;color:#3730a3;font-weight:800}tr:last-child td{border-bottom:none}</style><style>html, body{width: 100%;min-width: 100%;height: 100%;min-height: 100%;margin: 0 !important;padding: 0 !important;overflow: hidden;}body{min-height: 100dvh;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-container, .auth-wrapper{box-sizing: border-box;min-height: 100dvh;}@media (max-width: 600px){html, body{height: 100dvh !important;min-height: 100dvh !important;width: 100vw !important;min-width: 100vw !important;overflow: hidden !important;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-container, .auth-wrapper{width: 100vw !important;max-width: none !important;min-height: 100dvh !important;height: 100dvh !important;margin: 0 !important;border-radius: 0 !important;box-sizing: border-box !important;}.login-card, .login-box, .login-form, .auth-card{width: min(92vw, 430px) !important;max-width: 92vw !important;box-sizing: border-box !important;margin-left: auto !important;margin-right: auto !important;}}</style>
<style>html,body,.login-page,.login-container,.login-portal,.portal{background-image:none!important;}</style><style>html, body{width:100% !important;height:100% !important;min-width:100% !important;min-height:100% !important;margin:0 !important;padding:0 !important;overflow:hidden !important;background:none !important;background-image:none !important;}body > *{box-sizing:border-box;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{width:100vw !important;height:100dvh !important;min-height:100dvh !important;max-width:none !important;margin:0 !important;padding:0 !important;background:none !important;background-image:none !important;border-radius:0 !important;box-sizing:border-box !important;position:relative !important;inset:auto !important;}@media (max-width:600px){.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{width:100vw !important;height:100dvh !important;min-height:100dvh !important;}.login-card, .login-box, .login-form, .auth-card{width:92vw !important;max-width:430px !important;margin-left:auto !important;margin-right:auto !important;box-sizing:border-box !important;}}</style><style>html{width:100%;min-height:100%;overflow-x:hidden !important;overflow-y:auto !important;}body{width:100%;min-height:100dvh;height:auto !important;margin:0 !important;overflow-x:hidden !important;overflow-y:auto !important;-webkit-overflow-scrolling:touch;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{width:100vw !important;min-height:100dvh !important;height:auto !important;overflow-x:hidden !important;overflow-y:visible !important;box-sizing:border-box !important;}@media (max-width:600px){html, body{overflow-x:hidden !important;overflow-y:auto !important;-webkit-overflow-scrolling:touch !important;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{min-height:100dvh !important;height:auto !important;overflow:visible !important;}.login-card, .login-box, .login-form, .auth-card{max-height:none !important;overflow:visible !important;}}</style><style>html, body{scroll-behavior: auto !important;overscroll-behavior-y: auto !important;-webkit-overflow-scrolling: touch !important;}body{touch-action: pan-y !important;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{scroll-behavior: auto !important;overscroll-behavior-y: auto !important;-webkit-overflow-scrolling: touch !important;touch-action: pan-y !important;}@media (max-width:600px){html, body{scroll-behavior: auto !important;overflow-x: hidden !important;overflow-y: auto !important;-webkit-overflow-scrolling: touch !important;touch-action: pan-y !important;}*{scroll-behavior: auto !important;}}#loginView.login-wrap .login-card::before, #loginView.login-wrap .login-card::after, #loginView.login-wrap .login-panel::before, #loginView.login-wrap .login-panel::after, #loginView.login-wrap .login-wrap::before, #loginView.login-wrap .login-wrap::after{content:none !important;display:none !important;background:none !important;background-image:none !important;box-shadow:none !important;border:0 !important;}#loginView.login-wrap .login-panel{background:#fff !important;background-image:none !important;}#loginView.login-wrap .login-card{background:#fff !important;background-image:none !important;}#loginView.login-wrap .login-visual, #loginView.login-wrap .login-visual-overlay, #loginView.login-wrap .login-city-art, #loginView.login-wrap .login-curve{display:none !important;}</style></head><body>
<h1>🕒 Full Punch History</h1>
<p class="sub">${escapeHTML(emp&&emp.name||'Employee')} (${escapeHTML(employee)}) — ${months[month]} ${year}</p>
<table><thead><tr><th>Date</th><th>Type</th><th>Time</th><th>Source</th></tr></thead><tbody>${rowsHtml}</tbody></table>
</body></html>`;
const blob=new Blob([html],{type:'text/html'});
window.open(URL.createObjectURL(blob),'_blank');
}
function renderPunchHistory(containerId,key,month,year){
const box=document.getElementById(containerId);if(!box)return;
const days=new Date(year,month+1,0).getDate(),rows=[];
for(let day=1;day<=days;day++){
const punches=((db.punches||{})[key]||{})[day];if(!punches||!punches.length)continue;
[...punches].sort((a,b)=>(a.ts||0)-(b.ts||0)).forEach(p=>rows.push({day,...p}));
}
if(!rows.length){box.innerHTML='<p style="color:#64748b;font-size:12px">No punches recorded this month.</p>';return}
rows.sort((a,b)=>(a.ts||0)-(b.ts||0));
box.innerHTML=rows.map(p=>{
const dateLabel=`${String(p.day).padStart(2,'0')}/${String(month+1).padStart(2,'0')}/${String(year).slice(-2)}`,isSelf=p.site==='Self';
const siteTag=isSelf?`<span style="background:#fef3c7;color:#92400e;padding:2px 8px;border-radius:999px;font-weight:800;font-size:10px">🙋 Self Punch</span>`:`<span style="background:#e0e7ff;color:#3730a3;padding:2px 8px;border-radius:999px;font-weight:800;font-size:10px">🛡️ ${escapeHTML(p.site||'—')}</span>`;
const typeColor=p.type==='IN'?'#059669':'#be123c';
return `<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;padding:8px 0;border-bottom:1px solid var(--border);font-size:12px"><div><strong>${escapeHTML(dateLabel)}</strong> <span style="color:${typeColor};font-weight:900">${p.type}</span> @ ${escapeHTML(p.time||'')}</div>${siteTag}</div>`;
}).join('');
}
function showPunchModal(key,day,month,year){
const punches=((db.punches||{})[key]||{})[day]||[];
const sorted=[...punches].sort((a,b)=>(a.ts||0)-(b.ts||0));
const insCount=punches.filter(p=>p.type==='IN').length,outsCount=punches.filter(p=>p.type==='OUT').length;
const dateLabel=`${String(day).padStart(2,'0')}/${String(month+1).padStart(2,'0')}/${year}`;
document.getElementById('punchModalTitle').innerText=`🕒 Punch History — ${dateLabel}`;
document.getElementById('punchModalSummary').innerHTML=`<div style="display:flex;gap:8px;margin-bottom:16px">
<div class="punch-total-box" style="background:#ecfdf5;color:#047857">IN<span>${insCount}</span></div>
<div class="punch-total-box" style="background:#fff1f2;color:#be123c">OUT<span>${outsCount}</span></div>
<div class="punch-total-box" style="background:#eef2ff;color:#3730a3">TOTAL<span>${punches.length}</span></div>
</div>`;
document.getElementById('punchModalRows').innerHTML=sorted.length?sorted.map(p=>{
const isSelf=p.site==='Self',typeColor=p.type==='IN'?'#059669':'#be123c';
const siteTag=isSelf?`<span style="background:#fef3c7;color:#92400e;padding:2px 8px;border-radius:999px;font-weight:800;font-size:10px">🙋 Self Punch</span>`:`<span style="background:#e0e7ff;color:#3730a3;padding:2px 8px;border-radius:999px;font-weight:800;font-size:10px">🛡️ ${escapeHTML(p.site||'—')}</span>`;
return `<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;padding:9px 0;border-bottom:1px solid var(--border);font-size:12px"><div><span style="color:${typeColor};font-weight:900">${p.type}</span> @ ${escapeHTML(p.time||'')}</div>${siteTag}</div>`;
}).join(''):'<p style="color:#64748b;font-size:12px;text-align:center;padding:10px 0">No punches recorded for this date.</p>';
document.getElementById('punchModalOverlay').classList.remove('hidden');
}
function closePunchModal(){document.getElementById('punchModalOverlay').classList.add('hidden');}
function ctDayCounts(key,day){
const raw=(db.contractor_attendance[key]||{})[day];
const c={mason:0,helper:0,carpenter:0,plumber:0,painter:0,mason_ot:0,helper_ot:0,carpenter_ot:0,plumber_ot:0,painter_ot:0};
if(raw&&typeof raw==='object'){c.mason=Number(raw.mason)||0;c.helper=Number(raw.helper)||0;c.carpenter=Number(raw.carpenter)||0;c.plumber=Number(raw.plumber)||0;c.painter=Number(raw.painter)||0;c.mason_ot=Number(raw.mason_ot)||0;c.helper_ot=Number(raw.helper_ot)||0;c.carpenter_ot=Number(raw.carpenter_ot)||0;c.plumber_ot=Number(raw.plumber_ot)||0;c.painter_ot=Number(raw.painter_ot)||0;
// For worker-wise records, OT fields are sums of individual worker entries.
if(raw.worker_ot&&typeof raw.worker_ot==='object'){for(const t of ['mason','helper','carpenter','plumber','painter']){const vals=Array.isArray(raw.worker_ot[t])?raw.worker_ot[t]:[];c[t+'_ot']=vals.reduce((a,v)=>a+(Number(v)||0),0);}}
}
return c;
}
function ctDayTotal(c){return c.mason+c.helper+c.carpenter+c.plumber+c.painter}
function ctDayOTTotal(c){return c.mason_ot+c.helper_ot+c.carpenter_ot+c.plumber_ot+c.painter_ot}
function ctCost(contractor,c){
const mr=(contractor&&contractor.mason_rate)||0,hr=(contractor&&contractor.helper_rate)||0,cr=(contractor&&contractor.carpenter_rate)||0,pr=(contractor&&contractor.plumber_rate)||0,ptr=(contractor&&contractor.painter_rate)||0;
return c.mason*mr+c.helper*hr+c.carpenter*cr+c.plumber*pr+c.painter*ptr+(c.mason_ot||0)*(mr/8)+(c.helper_ot||0)*(hr/8)+(c.carpenter_ot||0)*(cr/8)+(c.plumber_ot||0)*(pr/8)+(c.painter_ot||0)*(ptr/8);
}
function contractorData(){return{id:document.getElementById('ctID').value.trim(),name:document.getElementById('ctName').value,mason_rate:Number(document.getElementById('ctMasonRate').value)||0,helper_rate:Number(document.getElementById('ctHelperRate').value)||0,carpenter_rate:Number(document.getElementById('ctCarpenterRate').value)||0,plumber_rate:Number(document.getElementById('ctPlumberRate').value)||0,painter_rate:Number(document.getElementById('ctPainterRate').value)||0,contact:document.getElementById('ctContact').value,user:document.getElementById('ctUser').value.trim(),pass:document.getElementById('ctPass').value,created_by:document.getElementById('ctCreatedBy').value||'Admin',assigned_employee_ids:[...document.querySelectorAll('#contractorEmployeeAssignments input:checked')].map(x=>x.value)}}
async function saveContractor(){
const contractor=contractorData();if(!contractor.id){alert('Contractor ID is required.');return}
const result=await server('save_contractor',contractor);
if(result.status==='success'){const saved=result.contractor||contractor;const index=db.contractors.findIndex(c=>c.id===contractor.id);if(index>=0)db.contractors[index]=saved;else db.contractors.push(saved);syncContractors();loadContractor()}
alert(result.message+(result.details?'\n\n'+result.details:''));
}
function loadContractor(){
const id=document.getElementById('contractorSelector').value;if(id==='new'){clearContractor();return}
const c=db.contractors.find(x=>x.id===id);if(!c)return;
document.getElementById('ctID').value=c.id;document.getElementById('ctName').value=c.name||'';document.getElementById('ctMasonRate').value=c.mason_rate||'';document.getElementById('ctHelperRate').value=c.helper_rate||'';document.getElementById('ctCarpenterRate').value=c.carpenter_rate||'';document.getElementById('ctPlumberRate').value=c.plumber_rate||'';document.getElementById('ctPainterRate').value=c.painter_rate||'';document.getElementById('ctContact').value=c.contact||'';document.getElementById('ctCreatedBy').value=c.created_by||'Admin';document.getElementById('ctUser').value=c.user||'';document.getElementById('ctPass').value='';renderContractorAssignments(c);
}
function renderContractorAssignments(c){const box=document.getElementById('contractorEmployeeAssignments');if(!box)return;const assigned=new Set((c&&c.assigned_employee_ids)||[]);if(!activeEmployees().length){box.innerHTML='<p style="color:#64748b;font-size:12px">No employees available.</p>';return}box.innerHTML=activeEmployees().map(e=>`<label style="display:flex;align-items:center;gap:8px;padding:9px 10px;border:1px solid var(--border);border-radius:12px;margin:5px 0;text-transform:none;letter-spacing:0;font-size:12px;color:#334155"><input type="checkbox" value="${escapeHTML(e.id)}" ${assigned.has(String(e.id))?'checked':''}> <span><strong>${escapeHTML(e.name||'')}</strong> [${escapeHTML(e.id||'')}]</span></label>`).join('')}
function clearContractor(){renderContractorAssignments(null);document.getElementById('ctCreatedBy').value='Admin';['ctID','ctName','ctMasonRate','ctHelperRate','ctCarpenterRate','ctPlumberRate','ctPainterRate','ctContact','ctUser','ctPass'].forEach(id=>document.getElementById(id).value='')}
async function deleteContractor(){
const id=document.getElementById('ctID').value.trim();if(!id){alert('Select contractor first.');return}
if(!confirm('Delete this contractor?'))return;
const result=await server('delete_contractor',{id});
if(result.status==='success'){db.contractors=db.contractors.filter(c=>c.id!==id);syncContractors();clearContractor()}
alert(result.message);
}
function syncContractors(){
const options=db.contractors.map(c=>`<option value="${escapeHTML(c.id)}">${escapeHTML(c.name)} [${escapeHTML(c.id)}]</option>`).join('');
document.getElementById('contractorSelector').innerHTML='<option value="new">+ New Contractor</option>'+options;
document.getElementById('ctAttE').innerHTML=options;if(db.contractors.length)document.getElementById('ctAttE').value=db.contractors[0].id;const ecs=document.getElementById('eContractor');if(ecs)ecs.innerHTML='<option value="">No Contractor</option>'+db.contractors.map(c=>`<option value="${escapeHTML(c.id)}">${escapeHTML(c.name||'')} [${escapeHTML(c.id||'')}]</option>`).join('');document.getElementById('ctDayEditor').classList.add('hidden');renderContractorCalendar();
const pa=document.getElementById('paContractors');if(pa){const current=[...pa.selectedOptions].map(o=>o.value);pa.innerHTML=(db.contractors||[]).map(c=>`<option value="${escapeHTML(c.id||'')}">${escapeHTML(c.name||'')} — ${escapeHTML(c.id||'')}</option>`).join('');[...pa.options].forEach(o=>o.selected=current.includes(o.value));renderContractorDropdown();}
}
function ctWeekInfo(date){
const dow=date.getDay(),diffToMonday=(dow+6)%7;const monday=new Date(date);monday.setDate(date.getDate()-diffToMonday);const sunday=new Date(monday);sunday.setDate(monday.getDate()+6);
const fmt=d=>`${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`;
return{key:`${monday.getFullYear()}-${monday.getMonth()}-${monday.getDate()}`,label:`${fmt(monday)} \u2013 ${fmt(sunday)} (Mon\u2013Sun)`};
}
function computeWeeklyBreakdown(key,month,year){
const days=new Date(year,month+1,0).getDate(),weeks=new Map();
for(let day=1;day<=days;day++){
const c=ctDayCounts(key,day);if(ctDayTotal(c)===0&&ctDayOTTotal(c)===0)continue;
const w=ctWeekInfo(new Date(year,month,day));
if(!weeks.has(w.key))weeks.set(w.key,{label:w.label,mason:0,helper:0,carpenter:0,plumber:0,painter:0,mason_ot:0,helper_ot:0,carpenter_ot:0,plumber_ot:0,painter_ot:0});
const wk=weeks.get(w.key);wk.mason+=c.mason;wk.helper+=c.helper;wk.carpenter+=c.carpenter;wk.plumber+=c.plumber;wk.painter+=c.painter;wk.mason_ot+=c.mason_ot;wk.helper_ot+=c.helper_ot;wk.carpenter_ot+=c.carpenter_ot;wk.plumber_ot+=c.plumber_ot;wk.painter_ot+=c.painter_ot;
}
return [...weeks.values()];
}
let weeklyPaymentData={};
function renderWeeklyPayment(containerId,key,month,year,contractor){
const box=document.getElementById(containerId);if(!box)return;
const days=new Date(year,month+1,0).getDate();
const entries=[];
for(let day=1;day<=days;day++){
const c=ctDayCounts(key,day);if(ctDayTotal(c)===0&&ctDayOTTotal(c)===0)continue;
const date=new Date(year,month,day);
entries.push({day,date,c,cost:ctCost(contractor,c),week:ctWeekInfo(date)});
}
if(!entries.length){box.innerHTML='';weeklyPaymentData[containerId]=null;return}
const weekMap=new Map();
entries.forEach(e=>{if(!weekMap.has(e.week.key))weekMap.set(e.week.key,{key:e.week.key,label:e.week.label})});
const weekList=[...weekMap.values()];
weeklyPaymentData[containerId]={entries,contractor,month,year};
const selId=containerId+'_weekSel';
const prevSel=document.getElementById(selId),prevKey=prevSel?prevSel.value:'';
let html=`<h4 style="margin:0 0 10px">\ud83d\udcb0 Weekly Payment Details</h4>`;
html+=`<div class="payment-note">Day-wise labour count and payment update automatically whenever attendance is saved. Pick a week to view its day-wise breakdown.</div>`;
html+=`<div class="form-group"><label>Select Week</label><select id="${selId}" onchange="renderWeekDays('${containerId}')">${weekList.map(w=>`<option value="${escapeHTML(w.key)}">\ud83d\udcc5 ${escapeHTML(w.label)}</option>`).join('')}</select></div>`;
html+=`<div id="${containerId}_weekBody"></div>`;
box.innerHTML=html;
{const s=document.getElementById(selId);if(s&&prevKey&&weekMap.has(prevKey))s.value=prevKey;}
renderWeekDays(containerId);
}
function renderWeekDays(containerId){
const data=weeklyPaymentData[containerId],body=document.getElementById(containerId+'_weekBody');if(!data||!body)return;
const selEl=document.getElementById(containerId+'_weekSel');if(!selEl)return;
const selectedKey=selEl.value,{entries,contractor,month,year}=data;
const weekEntries=entries.filter(e=>e.week.key===selectedKey);
const weekTotal=weekEntries.reduce((sum,x)=>sum+x.cost,0),weekLabel=weekEntries.length?weekEntries[0].week.label:'';
let html=`<div class="week-section"><div class="week-section-head"><span>\ud83d\udcc5 ${escapeHTML(weekLabel)}</span><strong>Week Total: \u20b9 ${formatINR(weekTotal)}</strong></div>`;
weekEntries.forEach(e=>{
const c=e.c, otHours=ctDayOTTotal(c);
const dateLabel=`${String(e.day).padStart(2,'0')}/${String(month+1).padStart(2,'0')}/${String(year).slice(-2)}`;
const items=[];
if(c.mason>0)items.push(`Mason ${c.mason}`);
if(c.helper>0)items.push(`Helper ${c.helper}`);
if(c.carpenter>0)items.push(`Carpenter ${c.carpenter}`);
if(c.plumber>0)items.push(`Plumber ${c.plumber}`);
if(c.painter>0)items.push(`Painter ${c.painter}`);
html+=`<div class="day-payment-card"><div class="day-payment-title"><strong>${escapeHTML(contractor?.name||'Contractor')} labour</strong><span>${dateLabel}</span></div><ol>${items.map(x=>`<li>${x}</li>`).join('')}</ol>${otHours>0?`<div class="day-payment-ot">OT: ${otHours} hrs</div>`:''}<div class="day-payment-total">Day Payment: \u20b9 ${formatINR(e.cost)}</div></div>`;
});
html+='</div>';
body.innerHTML=html;
}

function renderContractorFullDashboard(key,month,year,contractor,totals,cost){
 const box=document.getElementById('cpDashboard');if(!box)return;
 const trades=[['Mason','mason','mason_ot'],['Helper','helper','helper_ot'],['Carpenter','carpenter','carpenter_ot'],['Plumber','plumber','plumber_ot'],['Painter','painter','painter_ot']];
 const days=new Date(year,month+1,0).getDate(),rows=[];let workerDays=0;
 for(let d=1;d<=days;d++){const c=ctDayCounts(key,d),n=ctDayTotal(c),ot=ctDayOTTotal(c);if(n||ot){workerDays+=n;rows.push({d,c,n,ot,cost:ctCost(contractor,c)});}}
 const otTotal=trades.reduce((a,t)=>a+totals[t[2]],0);
 const tile=(label,value)=>`<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:12px;min-width:0"><div style="font-size:11px;color:#64748b;font-weight:700">${label}</div><div style="font-size:21px;font-weight:900;color:#0f172a;margin-top:4px">${value}</div></div>`;
 let h=`<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px;margin-bottom:12px">${tile('Worker-days',workerDays)}${tile('OT hours',Number(otTotal.toFixed(2)))}${tile('Labour cost','₹ '+formatINR(cost))}</div>`;
 h+=`<div style="overflow-x:auto;margin-bottom:12px"><table style="width:100%;border-collapse:collapse;font-size:12px"><thead><tr style="background:#eff6ff"><th style="padding:9px;text-align:left">Trade</th><th>Worker-days</th><th>OT hrs</th></tr></thead><tbody>`;
 trades.forEach(([label,k,ok])=>{if(!totals[k]&&!totals[ok])return;h+=`<tr style="border-bottom:1px solid #e2e8f0"><td style="padding:9px;font-weight:700">${label}</td><td style="text-align:center">${totals[k]}</td><td style="text-align:center">${Number(totals[ok].toFixed(2))}</td></tr>`;});
 h+='</tbody></table></div>';
 if(!rows.length)h+='<p style="font-size:12px;color:#64748b;padding:8px 0">No labour attendance recorded for this month.</p>';
 else{
  h+=`<details><summary style="cursor:pointer;font-weight:800;font-size:13px;padding:8px 0">Day-wise details</summary><div style="display:flex;justify-content:flex-end;margin:6px 0"><button type="button" class="btn" style="padding:8px 12px;background:#0f3f7a;color:white" onclick="downloadContractorDashboardCSV()">⬇ Export CSV</button></div><div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:12px;min-width:520px"><thead><tr style="background:#f8fafc"><th style="padding:8px;text-align:left">Date</th><th>Mason</th><th>Helper</th><th>Carp.</th><th>Plumb.</th><th>Paint.</th><th>Total</th><th>OT</th><th>Cost</th></tr></thead><tbody>`;
  rows.forEach(r=>{const date=`${String(r.d).padStart(2,'0')}/${String(month+1).padStart(2,'0')}`;h+=`<tr style="border-bottom:1px solid #e2e8f0"><td style="padding:8px">${date}</td><td style="text-align:center">${r.c.mason}</td><td style="text-align:center">${r.c.helper}</td><td style="text-align:center">${r.c.carpenter}</td><td style="text-align:center">${r.c.plumber}</td><td style="text-align:center">${r.c.painter}</td><td style="text-align:center;font-weight:800">${r.n}</td><td style="text-align:center">${r.ot}</td><td style="text-align:right">₹ ${formatINR(r.cost)}</td></tr>`;});
  h+='</tbody></table></div></details>';
 }
 box.innerHTML=h;
 window._contractorDashboardCSV={rows,month,year,totals,contractor};
}
function downloadContractorDashboardCSV(){const x=window._contractorDashboardCSV;if(!x)return;const {rows,month,year,totals,contractor}=x;let csv='Date,Mason,Helper,Carpenter,Plumber,Painter,Total Workers,OT Hours,Labour Cost INR\n';rows.forEach(r=>{csv+=`${String(r.d).padStart(2,'0')}/${String(month+1).padStart(2,'0')}/${year},${r.c.mason},${r.c.helper},${r.c.carpenter},${r.c.plumber},${r.c.painter},${r.n},${r.ot},${r.cost.toFixed(2)}\n`;});csv+=`TOTAL,${totals.mason},${totals.helper},${totals.carpenter},${totals.plumber},${totals.painter},,,,,\n`;const blob=new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8;'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=String(contractor?.name||'Contractor').replace(/[^a-z0-9]+/gi,'_')+'_Labour_Dashboard_'+year+'_'+String(month+1).padStart(2,'0')+'.csv';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);}

async function renderContractorPortal(){
if(!sessionContractor)return;
await syncContractorAssignedEmployees();
const month=Number(document.getElementById('cpAttM').value),year=Number(document.getElementById('cpAttY').value),contractorId=sessionContractor.id;
const days=new Date(year,month+1,0).getDate(),key=`${contractorId}-${month}-${year}`,contractor=db.contractors.find(c=>c.id===contractorId)||sessionContractor;
const totals={mason:0,helper:0,carpenter:0,plumber:0,painter:0,mason_ot:0,helper_ot:0,carpenter_ot:0,plumber_ot:0,painter_ot:0};
for(let day=1;day<=days;day++){const c=ctDayCounts(key,day);Object.keys(totals).forEach(k=>{totals[k]+=c[k];});}
const cost=ctCost(contractor,totals);
renderContractorFullDashboard(key,month,year,contractor,totals,cost);
renderWeeklyPayment('cpWeeklyPayment',key,month,year,contractor);
}
async function adminStorageRefresh(){
const box=document.getElementById('adminStorageStatus');if(!box)return;
const r=await server('admin_storage_status',{});
if(r.status!=='success'){box.textContent='Could not read status.';return;}
if(!r.mysql){box.innerHTML='<span style="color:#b91c1c;font-weight:800">MySQL not connected.</span> Check db_config.php.';return;}
const rows=Object.entries(r.stores||{}).map(([k,v])=>k+': '+v).join(' \u00b7 ');
box.innerHTML='<span style="color:#059669;font-weight:800">\u25cf MySQL connected</span><br>Rows &mdash; '+escapeHTML(rows)+'<br>'+(r.legacy&&r.legacy.length?'Old JSON files still on server: <strong>'+escapeHTML(r.legacy.join(', '))+'</strong>':'No old JSON files on the server.');
}
async function adminJsonImport(){
const inp=document.getElementById('adminJsonFiles'),out=document.getElementById('adminJsonResult');
if(!inp||!inp.files.length){alert('Choose database.json (and/or biometrics.json) first.');return;}
if(!confirm('This REPLACES the data in MySQL with the uploaded file(s). Continue?'))return;
const log=[];const show=m=>{out.textContent=log.concat(m?[m]:[]).join('\n');};
const post=async(action,data)=>{const ac=new AbortController(),t=setTimeout(()=>ac.abort(),90000);try{
 const resp=await fetch(location.pathname+'?action='+encodeURIComponent(action),{method:'POST',signal:ac.signal,headers:{'Content-Type':'application/json','X-Tab':(function(){try{return localStorage.getItem('swTab')||''}catch(e){return ''}})()},body:JSON.stringify(data)});
 const text=await resp.text();let r;try{r=JSON.parse(text)}catch(e){return{status:'error',message:'Server sent an unexpected reply (HTTP '+resp.status+'): '+text.replace(/<[^>]*>/g,' ').trim().slice(0,200)}}
 if(r&&r.session_expired){return{status:'error',message:r.message}}return r;
}catch(e){return{status:'error',message:e.name==='AbortError'?'Server did not answer within 90 seconds.':'Cannot connect: '+e.message}}finally{clearTimeout(t)}};
let imported=false;
try{
for(const f of inp.files){
 show('Reading '+f.name+'\u2026');
 let text=await new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.onerror=()=>rej(new Error('cannot read file'));fr.readAsText(f);});
 text=String(text).replace(/^\uFEFF/,'');
 let data;try{data=JSON.parse(text)}catch(e){log.push(f.name+': not valid JSON ('+e.message+') - skipped');continue}
 if(!data||typeof data!=='object'||Array.isArray(data)){log.push(f.name+': not an object - skipped');continue}
 if(!('company' in data)&&!data.database&&(data.contractors||data.contractor_attendance||data.contractor_payments)){
  show('Adding records from '+f.name+'\u2026');
  const mr=await post('admin_merge_records',{data});
  if(mr.status==='success'){imported=true;const x=mr.report;log.push(f.name+': added '+x.contractors_added+' contractor(s), '+x.attendance_days_added+' attendance day(s), '+x.payments_added+' payment(s); already present and kept: '+x.contractors_existing+' contractor(s), '+x.attendance_days_existing+' day(s), '+x.payments_existing+' payment(s)');}
  else log.push(f.name+': '+(mr.message||'failed'));
  continue;
 }
 let sections;
 if(data.database&&typeof data.database==='object')sections={database:data.database,biometrics:data.biometrics};
 else if('company' in data&&'employees' in data)sections={database:data};
 else if(/biometric/i.test(f.name)||(Object.keys(data).length&&Object.values(data).every(v=>v&&typeof v==='object'&&v.pem)))sections={biometrics:data};
 else{log.push(f.name+': not recognised (needs "company" and "employees") - skipped');continue}
 for(const [store,obj] of Object.entries(sections)){
  if(!obj||typeof obj!=='object'||Array.isArray(obj))continue;
  const keys=Object.keys(obj);let r=await post('admin_import_begin',{store});
  if(r.status!=='success'){log.push(f.name+' ('+store+'): '+(r.message||'failed')+' - nothing changed');continue}
  let ok=true,n=0;
  for(const k of keys){n++;show(f.name+' ('+store+'): sending '+n+'/'+keys.length+' \u2013 '+k+'\u2026');
   r=await post('admin_import_chunk',{store,key:k,value:JSON.stringify(obj[k])});
   if(r.status!=='success'){log.push(f.name+' ('+store+'): failed at "'+k+'": '+(r.message||'error')+' - nothing changed');ok=false;break}}
  if(!ok)continue;
  r=await post('admin_import_finish',{store,keys});
  if(r.status==='success'){imported=true;log.push(f.name+' ('+store+'): imported and verified, '+r.rows+' rows'+(r.deleted&&r.deleted.length?'; deleted old files: '+r.deleted.join(', '):''));}
  else log.push(f.name+' ('+store+'): '+(r.message||'failed'));
 }
}
}catch(e){log.push('Error: '+e.message)}
show(imported?'Reloading\u2026':'Nothing was imported.');
if(imported)setTimeout(()=>location.reload(),1800);
}
async function cpManualRefresh(btn){
if(btn){btn.disabled=true;btn.textContent='Refreshing…';}
try{if(await refreshPortalDatabase()){const latest=(db.contractors||[]).find(c=>sessionContractor&&String(c.id)===String(sessionContractor.id));if(latest)sessionContractor=latest;await renderContractorPortal();}}catch(e){}
if(btn){btn.disabled=false;btn.textContent='↻ Refresh';}
}
function downloadWeeklyStatement(){
if(!sessionContractor)return;
const month=Number(document.getElementById('cpAttM').value),year=Number(document.getElementById('cpAttY').value),key=`${sessionContractor.id}-${month}-${year}`,contractor=db.contractors.find(c=>c.id===sessionContractor.id)||sessionContractor;
const weeks=computeWeeklyBreakdown(key,month,year);
if(!weeks.length){alert('No attendance recorded for this month yet.');return}
let csv='Week,Mason,Helper,Carpenter,Plumber,Painter,OT Hours,Total Amount (Rs)\n',grandTotal=0;
weeks.forEach(wk=>{
const cost=ctCost(contractor,wk),otHours=wk.mason_ot+wk.helper_ot+wk.carpenter_ot+wk.plumber_ot+wk.painter_ot;
grandTotal+=cost;
csv+=`"${wk.label}",${wk.mason},${wk.helper},${wk.carpenter},${wk.plumber},${wk.painter},${otHours},${cost.toFixed(2)}\n`;
});
csv+=`,,,,,,Grand Total,${grandTotal.toFixed(2)}\n`;
const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'}),url=URL.createObjectURL(blob),a=document.createElement('a');
a.href=url;a.download=`${contractor.name.replace(/[^a-z0-9]+/gi,'_')}_Weekly_Statement_${months[month]}_${year}.csv`;
document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);
}
/* Calendars run Monday -> Sunday: on day 1 add the Mon..Sun header row and blank cells up to the weekday of the 1st. */
function calAppend(box,cell,year,month,day){
if(day===1){
['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].forEach((n,i)=>{const h=document.createElement('div');h.className='cal-wd';h.style.cssText='text-align:center;font-size:11px;font-weight:700;padding:2px 0;color:'+(i===6?'#dc2626':'#475569');h.textContent=n;box.appendChild(h)});
const lead=(new Date(year,month,1).getDay()+6)%7;
for(let i=0;i<lead;i++){const b=document.createElement('div');b.className='cal-blank';box.appendChild(b)}
}
box.appendChild(cell);
}
function ctDowTag(y,m,d){const n=new Date(y,m,d).getDay();return `<em class="ct-dow" style="display:block;font-size:10px;font-style:normal;font-weight:700;line-height:1.1;color:${n===0?'#dc2626':'#64748b'}">${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][n]}</em>`}
function showContractorOTPopup(event,key,day){
if(event){event.stopPropagation();event.preventDefault();}
const c=ctDayCounts(key,day), raw=(db.contractor_attendance[key]||{})[day]||{};
const isTargetDate=String(key).endsWith('-9-2026') && Number(day)===22;
// Requested initial entry for 22 Oct 2026, used only when that contractor/date has no saved record.
if(isTargetDate && !Object.keys(raw).length){c.mason=2;c.helper=2;c.mason_ot=0;c.helper_ot=0;}
const trades=[['Mason','mason','mason_ot'],['Helper','helper','helper_ot'],['Carpenter','carpenter','carpenter_ot'],['Plumber','plumber','plumber_ot'],['Painter','painter','painter_ot']];
const old=document.getElementById('contractorOTPopup');if(old)old.remove();
const overlay=document.createElement('div');overlay.id='contractorOTPopup';
overlay.style.cssText='position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:99999;display:flex;align-items:center;justify-content:center;padding:12px;';
const panel=document.createElement('div');panel.style.cssText='background:#fff;color:#0f172a;width:min(520px,100%);border-radius:16px;padding:18px;box-shadow:0 20px 60px rgba(0,0,0,.25);max-height:90vh;overflow:auto;';
const title=document.createElement('h3');title.textContent=`Worker-wise OT — ${String(day).padStart(2,'0')} ${months[Number(String(key).split('-').slice(-2,-1)[0])]||''} ${String(key).split('-').pop()}`;title.style.cssText='margin:0 0 6px;font-size:18px;';
const subtitle=document.createElement('p');subtitle.textContent='Enter overtime separately for each worker. Changes are saved to contractor attendance.';subtitle.style.cssText='margin:0 0 14px;color:#64748b;font-size:12px;';
const inputs={};const content=document.createElement('div');
trades.forEach(([label,trade,otField])=>{const count=Math.max(0,Math.floor(Number(c[trade])||0));if(!count)return;
const heading=document.createElement('div');heading.textContent=`${label} (${count} worker${count===1?'':'s'})`;heading.style.cssText='font-weight:800;margin:14px 0 6px;color:#334155;';content.appendChild(heading);inputs[trade]=[];
const existing=Array.isArray(raw.worker_ot?.[trade])?raw.worker_ot[trade]:null;
for(let i=0;i<count;i++){const row=document.createElement('div');row.style.cssText='display:grid;grid-template-columns:1fr 120px;gap:10px;align-items:center;padding:6px 0;border-bottom:1px solid #e2e8f0;';const labelEl=document.createElement('label');labelEl.textContent=`${label} ${String(i+1).padStart(2,'0')}`;labelEl.style.cssText='margin:0;padding:0;text-transform:none;letter-spacing:0;font-size:13px;color:#475569;';const input=document.createElement('input');input.type='number';input.min='0';input.max='24';input.step='0.5';input.inputMode='decimal';input.setAttribute('aria-label',`${label} ${i+1} overtime hours`);input.style.cssText='width:100%;padding:9px;border:1px solid #cbd5e1;border-radius:9px;font-size:14px;';input.value=existing?Number(existing[i]||0):(isTargetDate&&!Object.keys(raw).length&&trade==='mason'?[4,2][i]??0:isTargetDate&&!Object.keys(raw).length&&trade==='helper'?[4,3][i]??0:Number(c[otField]||0));inputs[trade].push(input);row.append(labelEl,input);content.appendChild(row);}
});
const totalBox=document.createElement('div');totalBox.style.cssText='margin-top:14px;padding:12px;background:#f1f5f9;border-radius:10px;display:flex;justify-content:space-between;font-weight:800;';
const totalValue=document.createElement('span');const updateTotal=()=>{let total=0;Object.values(inputs).forEach(arr=>arr.forEach(input=>total+=Math.max(0,Number(input.value)||0)));totalValue.textContent=Number(total.toFixed(2))+' hrs';};Object.values(inputs).forEach(arr=>arr.forEach(input=>input.addEventListener('input',updateTotal)));totalBox.append('Total OT man-hours',totalValue);updateTotal();
const buttons=document.createElement('div');buttons.style.cssText='display:flex;gap:8px;margin-top:14px;';
const close=document.createElement('button');close.className='btn';close.textContent='Cancel';close.style.cssText='flex:1;background:#e2e8f0;color:#0f172a;';close.onclick=()=>overlay.remove();
const save=document.createElement('button');save.className='btn btn-primary';save.textContent='Save OT';save.style.cssText='flex:1;';save.onclick=async()=>{const worker_ot={};trades.forEach(([label,trade,otField])=>{worker_ot[trade]=(inputs[trade]||[]).map(input=>Math.max(0,Math.min(24,Number(input.value)||0)));});save.disabled=true;save.textContent='Saving…';const payload={key,day,mason:c.mason,helper:c.helper,carpenter:c.carpenter,plumber:c.plumber,painter:c.painter,worker_ot};const result=await server('save_contractor_attendance',payload);if(result.status==='success'){if(!db.contractor_attendance[key])db.contractor_attendance[key]={};db.contractor_attendance[key][day]={...raw,...payload,mason_ot:worker_ot.mason.reduce((a,v)=>a+v,0),helper_ot:worker_ot.helper.reduce((a,v)=>a+v,0),carpenter_ot:worker_ot.carpenter.reduce((a,v)=>a+v,0),plumber_ot:worker_ot.plumber.reduce((a,v)=>a+v,0),painter_ot:worker_ot.painter.reduce((a,v)=>a+v,0)};overlay.remove();if(typeof renderContractorCalendar==='function')renderContractorCalendar();if(typeof renderContractorCalendarStaff==='function')renderContractorCalendarStaff();alert('Worker-wise OT saved.');}else{save.disabled=false;save.textContent='Save OT';alert(result.message||'Could not save OT.');}};
buttons.append(close,save);panel.append(title,subtitle,content,totalBox,buttons);overlay.appendChild(panel);overlay.addEventListener('click',e=>{if(e.target===overlay)overlay.remove();});document.body.appendChild(overlay);
}
function renderContractorCalendar(){
const month=Number(document.getElementById('ctAttM').value),year=Number(document.getElementById('ctAttY').value),contractorId=document.getElementById('ctAttE').value,box=document.getElementById('contractorCalendar');box.innerHTML='';document.getElementById('ctPresentCount').innerText='';if(!contractorId)return;
const days=new Date(year,month+1,0).getDate(),key=`${contractorId}-${month}-${year}`;if(!db.contractor_attendance[key])db.contractor_attendance[key]={};
const contractor=db.contractors.find(c=>c.id===contractorId);
const totals={mason:0,helper:0,carpenter:0,plumber:0,painter:0,mason_ot:0,helper_ot:0,carpenter_ot:0,plumber_ot:0,painter_ot:0};
for(let day=1;day<=days;day++){
const c=ctDayCounts(key,day),total=ctDayTotal(c),otTotal=ctDayOTTotal(c);
totals.mason+=c.mason;totals.helper+=c.helper;totals.carpenter+=c.carpenter;totals.plumber+=c.plumber;totals.painter+=c.painter;totals.mason_ot+=c.mason_ot;totals.helper_ot+=c.helper_ot;totals.carpenter_ot+=c.carpenter_ot;totals.plumber_ot+=c.plumber_ot;totals.painter_ot+=c.painter_ot;
const cell=document.createElement('div');cell.className=`day ${total>0?'hascount':''}`;
cell.innerHTML=`<span>${day}</span>${ctDowTag(year,month,day)}<small>${total>0?total+' \ud83d\udc77':'\u2014'}</small>${total>0?`<small class="ot-tag" style="cursor:pointer;text-decoration:underline" title="Click to add or view worker-wise OT" onclick="showContractorOTPopup(event, '${key}', ${day})">+${c.mason*c.mason_ot+c.helper*c.helper_ot+c.carpenter*c.carpenter_ot+c.plumber*c.plumber_ot+c.painter*c.painter_ot} man-hrs OT</small>`:''}`;
cell.onclick=()=>{if(month===9&&year===2026&&day===22)showContractorOTPopup(null,key,day);else selectContractorDay(key,day);};
calAppend(box,cell,year,month,day)}
const cost=ctCost(contractor,totals),otHoursTotal=totals.mason_ot+totals.helper_ot+totals.carpenter_ot+totals.plumber_ot+totals.painter_ot;
document.getElementById('ctPresentCount').innerHTML=`Mason: ${totals.mason} | Helper: ${totals.helper} | Carpenter: ${totals.carpenter} | Plumber: ${totals.plumber} | Painter: ${totals.painter}<br>OT Hours: ${otHoursTotal}  |  Total Labour Cost: \u20b9 ${formatINR(cost)}`;
renderWeeklyPayment('ctWeeklyPayment',key,month,year,contractor);
document.getElementById('ctDayEditor').classList.add('hidden');
}
let ctEditKey=null,ctEditDay=null;
function selectContractorDay(key,day){
ctEditKey=key;ctEditDay=day;const c=ctDayCounts(key,day);
document.getElementById('ctCntMason').value=c.mason;document.getElementById('ctCntHelper').value=c.helper;document.getElementById('ctCntCarpenter').value=c.carpenter;document.getElementById('ctCntPlumber').value=c.plumber;document.getElementById('ctCntPainter').value=c.painter;
document.getElementById('ctCntMasonOT').value=c.mason_ot;document.getElementById('ctCntHelperOT').value=c.helper_ot;document.getElementById('ctCntCarpenterOT').value=c.carpenter_ot;document.getElementById('ctCntPlumberOT').value=c.plumber_ot;document.getElementById('ctCntPainterOT').value=c.painter_ot;
document.getElementById('ctDayEditorTitle').innerText=`Day ${day} \u2014 ${months[Number(document.getElementById('ctAttM').value)]} ${document.getElementById('ctAttY').value}`;
document.getElementById('ctDayEditor').classList.remove('hidden');
}
async function saveDayCount(){
if(!ctEditKey||!ctEditDay){alert('Select a day first.');return}
const payload={key:ctEditKey,day:ctEditDay,mason:Number(document.getElementById('ctCntMason').value)||0,helper:Number(document.getElementById('ctCntHelper').value)||0,carpenter:Number(document.getElementById('ctCntCarpenter').value)||0,plumber:Number(document.getElementById('ctCntPlumber').value)||0,painter:Number(document.getElementById('ctCntPainter').value)||0,mason_ot:Number(document.getElementById('ctCntMasonOT').value)||0,helper_ot:Number(document.getElementById('ctCntHelperOT').value)||0,carpenter_ot:Number(document.getElementById('ctCntCarpenterOT').value)||0,plumber_ot:Number(document.getElementById('ctCntPlumberOT').value)||0,painter_ot:Number(document.getElementById('ctCntPainterOT').value)||0};
const result=await server('save_contractor_attendance',payload);
if(result.status==='success'){if(!db.contractor_attendance[ctEditKey])db.contractor_attendance[ctEditKey]={};db.contractor_attendance[ctEditKey][ctEditDay]=payload;renderContractorCalendar();selectContractorDay(ctEditKey,ctEditDay)}
alert(result.message);
}
function contractorDataStaff(){const id=document.getElementById('sCtID').value.trim();const existing=db.contractors.find(c=>String(c.id)===String(id));return{id,name:document.getElementById('sCtName').value,mason_rate:Number(document.getElementById('sCtMasonRate').value)||0,helper_rate:Number(document.getElementById('sCtHelperRate').value)||0,carpenter_rate:Number(document.getElementById('sCtCarpenterRate').value)||0,plumber_rate:Number(document.getElementById('sCtPlumberRate').value)||0,painter_rate:Number(document.getElementById('sCtPainterRate').value)||0,contact:document.getElementById('sCtContact').value,user:document.getElementById('sCtUser').value.trim(),pass:document.getElementById('sCtPass').value,assigned_employee_ids:existing?.assigned_employee_ids||[]}}
async function saveContractorStaff(){
const contractor=contractorDataStaff();if(!contractor.id){alert('Contractor ID is required.');return}
const result=await server('save_contractor',contractor);
if(result.status==='success'){const saved=result.contractor||contractor;const index=db.contractors.findIndex(c=>String(c.id)===String(contractor.id));if(index>=0)db.contractors[index]=saved;else db.contractors.push(saved);syncContractorsStaff();document.getElementById('sContractorSelector').value=saved.id;loadContractorStaff()}
alert(result.message+(result.details?'\n\n'+result.details:''));
}
function loadContractorStaff(){
const id=document.getElementById('sContractorSelector').value;if(id==='new'){clearContractorStaff();return}
const c=db.contractors.find(x=>x.id===id);if(!c)return;
document.getElementById('sCtID').value=c.id;document.getElementById('sCtName').value=c.name||'';document.getElementById('sCtMasonRate').value=c.mason_rate||'';document.getElementById('sCtHelperRate').value=c.helper_rate||'';document.getElementById('sCtCarpenterRate').value=c.carpenter_rate||'';document.getElementById('sCtPlumberRate').value=c.plumber_rate||'';document.getElementById('sCtPainterRate').value=c.painter_rate||'';document.getElementById('sCtContact').value=c.contact||'';document.getElementById('sCtUser').value=c.user||'';document.getElementById('sCtPass').value='';
}
function clearContractorStaff(){['sCtID','sCtName','sCtMasonRate','sCtHelperRate','sCtCarpenterRate','sCtPlumberRate','sCtPainterRate','sCtContact','sCtUser','sCtPass'].forEach(id=>document.getElementById(id).value='')}
async function deleteContractorStaff(){
const id=document.getElementById('sCtID').value.trim();if(!id){alert('Select contractor first.');return}
if(!confirm('Delete this contractor?'))return;
const result=await server('delete_contractor',{id});
if(result.status==='success'){db.contractors=db.contractors.filter(c=>c.id!==id);syncContractorsStaff();clearContractorStaff()}
alert(result.message);
}
function syncContractorsStaff(){
let staffContractors=db.contractors||[];
if(sessionUser){
const myId=String(sessionUser.id||'');
staffContractors=staffContractors.filter(c=>(c.assigned_employee_ids||[]).map(String).includes(myId));
}
const options=staffContractors.map(c=>`<option value="${escapeHTML(c.id)}">${escapeHTML(c.name||'')} [${escapeHTML(c.id||'')}]</option>`).join('');
const sel=document.getElementById('sContractorSelector');
if(sel){const previous=sel.value;sel.innerHTML='<option value="new">+ New Contractor</option>'+options;if(previous && staffContractors.some(c=>String(c.id)===String(previous)))sel.value=previous;else if(staffContractors.length)sel.value=staffContractors[0].id;}
const access=document.getElementById('staffContractorAccess');
if(access){
const myId=String(sessionUser?.id||'');
access.innerHTML=staffContractors.length?staffContractors.map(c=>{return `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:10px 12px;border:1px solid var(--border);border-radius:12px;margin:6px 0;background:#f8fafc"><div><strong>${escapeHTML(c.name||'')}</strong> <span style="color:#64748b">[${escapeHTML(c.id||'')}]</span></div><span style="font-size:11px;font-weight:800;color:#166534">✓ Admin assigned access — Edit/Update allowed</span></div>`}).join(''):'<div style="padding:10px 12px;border:1px dashed var(--border);border-radius:12px;color:#64748b;font-size:12px">No assigned contractors yet. Admin can give you contractor access from Project Assign.</div>';
}
const att=document.getElementById('sCtAttE');if(att){const previous=att.value;att.innerHTML=options;if(staffContractors.length){att.value=staffContractors.some(c=>String(c.id)===String(previous))?previous:staffContractors[0].id;}else{att.value='';}}
document.getElementById('sCtDayEditor').classList.add('hidden');renderContractorCalendarStaff();
}
function renderContractorCalendarStaff(){
const month=Number(document.getElementById('sCtAttM').value),year=Number(document.getElementById('sCtAttY').value),contractorId=document.getElementById('sCtAttE').value,box=document.getElementById('sContractorCalendar');box.innerHTML='';document.getElementById('sCtPresentCount').innerText='';if(!contractorId)return;
const days=new Date(year,month+1,0).getDate(),key=`${contractorId}-${month}-${year}`;if(!db.contractor_attendance[key])db.contractor_attendance[key]={};
const contractor=db.contractors.find(c=>c.id===contractorId);
const totals={mason:0,helper:0,carpenter:0,plumber:0,painter:0,mason_ot:0,helper_ot:0,carpenter_ot:0,plumber_ot:0,painter_ot:0};
for(let day=1;day<=days;day++){
const c=ctDayCounts(key,day),total=ctDayTotal(c),otTotal=ctDayOTTotal(c);
totals.mason+=c.mason;totals.helper+=c.helper;totals.carpenter+=c.carpenter;totals.plumber+=c.plumber;totals.painter+=c.painter;totals.mason_ot+=c.mason_ot;totals.helper_ot+=c.helper_ot;totals.carpenter_ot+=c.carpenter_ot;totals.plumber_ot+=c.plumber_ot;totals.painter_ot+=c.painter_ot;
const cell=document.createElement('div');cell.className=`day ${total>0?'hascount':''}`;
cell.innerHTML=`<span>${day}</span>${ctDowTag(year,month,day)}<small>${total>0?total+' \ud83d\udc77':'\u2014'}</small>${total>0?`<small class="ot-tag" style="cursor:pointer;text-decoration:underline" title="Click to add or view worker-wise OT" onclick="showContractorOTPopup(event, '${key}', ${day})">+${c.mason*c.mason_ot+c.helper*c.helper_ot+c.carpenter*c.carpenter_ot+c.plumber*c.plumber_ot+c.painter*c.painter_ot} man-hrs OT</small>`:''}`;
cell.onclick=()=>selectContractorDayStaff(key,day);
calAppend(box,cell,year,month,day)}
const cost=ctCost(contractor,totals),otHoursTotal=totals.mason_ot+totals.helper_ot+totals.carpenter_ot+totals.plumber_ot+totals.painter_ot;
document.getElementById('sCtPresentCount').innerHTML=`Mason: ${totals.mason} | Helper: ${totals.helper} | Carpenter: ${totals.carpenter} | Plumber: ${totals.plumber} | Painter: ${totals.painter}<br>OT Hours: ${otHoursTotal}  |  Total Labour Cost: \u20b9 ${formatINR(cost)}`;
renderWeeklyPayment('sCtWeeklyPayment',key,month,year,contractor);
document.getElementById('sCtDayEditor').classList.add('hidden');
}
let sCtEditKey=null,sCtEditDay=null;
function selectContractorDayStaff(key,day){
sCtEditKey=key;sCtEditDay=day;const c=ctDayCounts(key,day);
document.getElementById('sCtCntMason').value=c.mason;document.getElementById('sCtCntHelper').value=c.helper;document.getElementById('sCtCntCarpenter').value=c.carpenter;document.getElementById('sCtCntPlumber').value=c.plumber;document.getElementById('sCtCntPainter').value=c.painter;
document.getElementById('sCtCntMasonOT').value=c.mason_ot;document.getElementById('sCtCntHelperOT').value=c.helper_ot;document.getElementById('sCtCntCarpenterOT').value=c.carpenter_ot;document.getElementById('sCtCntPlumberOT').value=c.plumber_ot;document.getElementById('sCtCntPainterOT').value=c.painter_ot;
document.getElementById('sCtDayEditorTitle').innerText=`Day ${day} \u2014 ${months[Number(document.getElementById('sCtAttM').value)]} ${document.getElementById('sCtAttY').value}`;
document.getElementById('sCtDayEditor').classList.remove('hidden');
}
async function saveDayCountStaff(){
if(!sCtEditKey||!sCtEditDay){alert('Select a day first.');return}
const payload={key:sCtEditKey,day:sCtEditDay,mason:Number(document.getElementById('sCtCntMason').value)||0,helper:Number(document.getElementById('sCtCntHelper').value)||0,carpenter:Number(document.getElementById('sCtCntCarpenter').value)||0,plumber:Number(document.getElementById('sCtCntPlumber').value)||0,painter:Number(document.getElementById('sCtCntPainter').value)||0,mason_ot:Number(document.getElementById('sCtCntMasonOT').value)||0,helper_ot:Number(document.getElementById('sCtCntHelperOT').value)||0,carpenter_ot:Number(document.getElementById('sCtCntCarpenterOT').value)||0,plumber_ot:Number(document.getElementById('sCtCntPlumberOT').value)||0,painter_ot:Number(document.getElementById('sCtCntPainterOT').value)||0};
const result=await server('save_contractor_attendance',payload);
if(result.status==='success'){if(!db.contractor_attendance[sCtEditKey])db.contractor_attendance[sCtEditKey]={};db.contractor_attendance[sCtEditKey][sCtEditDay]=payload;renderContractorCalendarStaff();selectContractorDayStaff(sCtEditKey,sCtEditDay)}
alert(result.message);
}
function renderStaffCalendar(){
if(!sessionUser)return;
const month=Number(document.getElementById('vM').value),year=Number(document.getElementById('vY').value),box=document.getElementById('staffCal');box.innerHTML='';
const days=new Date(year,month+1,0).getDate(),key=`${sessionUser.id}-${month}-${year}`,attendance=db.attendance[key]||{};
for(let day=1;day<=days;day++){const hol=holidayForDate(year,month,day);const sunday=new Date(year,month,day).getDay()===0,status=hol?'HOL':(sunday?'SUN':(attendance[day]||'A')),cell=document.createElement('div');cell.className=`day ${status}`;cell.innerHTML=`${leaveStarMark(status)}<span>${day}</span><small>${status}</small>${punchSummary(key,day)}<button type="button" class="day-view-btn">🕒</button>`;cell.onclick=()=>showPunchModal(key,day,month,year);calAppend(box,cell,year,month,day)}
}
function requestStatusLabel(status){return status==='P'?'Present':(status==='OD'?'On Duty':'Half Day');}
function requestPunchLabel(r){const t=String(r.request_type||'').toUpperCase();return t==='IN'?'🟢 In Time':(t==='OUT'?'🔴 Out Time':`📝 Missed Attendance — ${requestStatusLabel(String(r.attendance_status||'P').toUpperCase())}`);}
function toggleMissedAttendanceFields(){
const type=document.getElementById('reqPunchType')?.value, punchGroup=document.getElementById('reqPunchTimeGroup'), statusGroup=document.getElementById('reqAttendanceStatusGroup'), punch=document.getElementById('reqPunchTime');
const attendance=type==='ATTENDANCE';
punchGroup?.classList.toggle('hidden',attendance);statusGroup?.classList.toggle('hidden',!attendance);
if(punch){punch.required=!attendance;if(attendance)punch.value='';}
}
function updateApprovalsBadge(){
const badge=document.getElementById('approvalsBadge');if(!badge)return;
const count=(db.requests||[]).length+(db.leave_requests||[]).length;
if(count>0){badge.textContent=count;badge.classList.remove('hidden');}else{badge.classList.add('hidden');}
}
function renderRequests(){
const box=document.getElementById('requestQueue');if(!db.requests.length){box.innerHTML='<p style="color:#64748b">No pending requests.</p>';updateApprovalsBadge();return}
box.innerHTML=db.requests.map(r=>`<div style="padding:18px;margin-bottom:12px;border:1px solid #e2e8f0;border-radius:18px"><strong>${escapeHTML(r.emp_name)} (${escapeHTML(r.emp_id)})</strong><br><small>Date: ${escapeHTML(r.date)} | ${requestPunchLabel(r)} | Time: ${escapeHTML(r.punch_time||'')}</small><p>${escapeHTML(r.reason)}</p><button class="btn btn-save" onclick="processRequest('${escapeJS(r.id)}',true)">Approve</button> <button class="btn btn-danger" onclick="processRequest('${escapeJS(r.id)}',false)">Reject</button></div>`).join('');
updateApprovalsBadge();
}
function getMonthlyForgotPunchCount(){
if(!sessionUser)return 0;const ym=new Date().toISOString().slice(0,7);return [...(db.requests||[]),...(db.request_history||[])].filter(r=>String(r.emp_id)===String(sessionUser.id)&&String(r.submitted||'').slice(0,7)===ym).length;
}
function renderForgotPunchLimit(){
const box=document.getElementById('forgotPunchLimit'),btn=document.getElementById('submitForgotPunchBtn');if(!box||!sessionUser)return;const used=Math.min(5,getMonthlyForgotPunchCount()),remaining=Math.max(0,5-used);box.textContent=`Forgot-punch applications this month: ${used}/5 — ${remaining} remaining.`;if(btn)btn.disabled=remaining===0;}
async function processRequest(id,approve){
let reason='';if(!approve){const r=prompt('Reason for rejecting this request (the employee will see it):','');if(r===null)return;reason=r.trim();if(!reason){alert('Please enter a reason to reject.');return;}}
const result=await server('process_request',{req_id:id,approve,reason});if(result.status==='success'){db.requests=db.requests.filter(r=>r.id!==id);renderRequests();if(sessionUser)renderStaffCalendar()}alert(result.message);
}
async function submitAttendanceRequest(){
if(!sessionUser)return;
const date=document.getElementById('reqDate').value,punchType=document.getElementById('reqPunchType').value,punchTime=document.getElementById('reqPunchTime').value,attendanceStatus=document.getElementById('reqAttendanceStatus')?.value||'',reason=document.getElementById('reqReason').value.trim();
const isAttendance=punchType==='ATTENDANCE';
if(!date||!punchType||(!isAttendance&&!punchTime)||(isAttendance&&!attendanceStatus)||!reason){alert(isAttendance?'Please select the date, attendance status, and reason.':'Please select the date, In/Out, actual punch time, and reason.');return}
const used=getMonthlyForgotPunchCount();if(used>=5){alert('Monthly limit reached. You can apply for a maximum of 5 missed-attendance requests per month.');return}
const today=new Date();today.setHours(0,0,0,0);const picked=new Date(date+'T00:00:00');const diffDays=Math.round((today-picked)/86400000);
if(diffDays<0||diffDays>5){alert('Missed attendance can only be applied for a date within the last 5 days.');return}
const result=await server('submit_request',{emp_id:sessionUser.id,emp_name:sessionUser.name,date,request_type:punchType,punch_time:isAttendance?'':punchTime,attendance_status:isAttendance?attendanceStatus:'',reason});
if(result.status==='success'){
document.getElementById('reqDate').value='';document.getElementById('reqPunchTime').value='';if(document.getElementById('reqAttendanceStatus'))document.getElementById('reqAttendanceStatus').value='P';document.getElementById('reqReason').value='';
if(!db.requests)db.requests=[];
db.requests.push({id:result.id||('local_'+Date.now()),emp_id:sessionUser.id,emp_name:sessionUser.name,date,request_type:punchType,punch_time:isAttendance?'':punchTime,attendance_status:isAttendance?attendanceStatus:'',reason,submitted:new Date().toISOString().slice(0,19).replace('T',' ')});
renderMyRequests();renderForgotPunchLimit();
}
alert(result.message);
}
function renderMyRequests(){
const box=document.getElementById('myRequestList');if(!box||!sessionUser)return;
const mine=(db.requests||[]).filter(r=>String(r.emp_id)===String(sessionUser.id));
box.innerHTML=mine.length?mine.map(r=>`<div style="padding:14px;margin-bottom:10px;border:1px solid #e2e8f0;border-radius:14px"><strong>${escapeHTML(r.date)}</strong> — ${requestPunchLabel(r)} @ ${escapeHTML(r.punch_time||'')} <span style="color:#d97706;font-weight:700;margin-left:6px">⏳ Pending</span><p style="margin-top:6px;color:#64748b;font-size:12px">${escapeHTML(r.reason)}</p></div>`).join(''):'<p style="color:#64748b">No pending requests.</p>';renderForgotPunchLimit();
renderMyRequestHistory();
}
function leaveTypeLabel(t){return {CL:'Casual Leave',SL:'Sick Leave',LOP:'Loss of Pay',OD:'On Duty'}[String(t||'').toUpperCase()]||t;}
const LEAVE_ANNUAL_QUOTA={CL:12,SL:12};
function leaveDaysUsedClient(empId,leaveType,year){
let total=0;
const approved=(db.leave_history||[]).filter(r=>r.result==='approved');
const all=[...(db.leave_requests||[]),...approved];
all.forEach(r=>{
if(String(r.emp_id)!==String(empId))return;
if(String(r.leave_type||'').toUpperCase()!==leaveType)return;
const from=new Date(r.date_from+'T00:00:00'),to=new Date(r.date_to+'T00:00:00');
if(isNaN(from)||isNaN(to))return;
for(let d=new Date(from);d<=to;d.setDate(d.getDate()+1)){if(d.getFullYear()===year)total++;}
});
return total;
}
function renderLeaveBalance(){
const box=document.getElementById('leaveBalanceBox');if(!box||!sessionUser)return;
const year=new Date().getFullYear();
const clUsed=leaveDaysUsedClient(sessionUser.id,'CL',year),slUsed=leaveDaysUsedClient(sessionUser.id,'SL',year);
box.innerHTML=`<div style="display:flex;gap:12px;flex-wrap:wrap"><div style="flex:1;min-width:150px;padding:10px 12px;border-radius:10px;background:#f0fdfa;color:#0f766e;font-size:12px;font-weight:800">Casual Leave ${year}: ${clUsed}/${LEAVE_ANNUAL_QUOTA.CL} used (${Math.max(0,LEAVE_ANNUAL_QUOTA.CL-clUsed)} left)</div><div style="flex:1;min-width:150px;padding:10px 12px;border-radius:10px;background:#fef2f2;color:#b91c1c;font-size:12px;font-weight:800">Sick Leave ${year}: ${slUsed}/${LEAVE_ANNUAL_QUOTA.SL} used (${Math.max(0,LEAVE_ANNUAL_QUOTA.SL-slUsed)} left)</div></div>`;
}
async function submitLeaveRequest(){
if(!sessionUser)return;
const leaveType=document.getElementById('lvType').value,dateFrom=document.getElementById('lvFrom').value,dateTo=document.getElementById('lvTo').value,reason=document.getElementById('lvReason').value.trim();
if(!leaveType||!dateFrom||!dateTo||!reason){alert('Please select the leave type, dates, and enter a reason.');return}
if(dateTo<dateFrom){alert('End date cannot be before start date.');return}
const result=await server('submit_leave_request',{emp_id:sessionUser.id,emp_name:sessionUser.name,leave_type:leaveType,date_from:dateFrom,date_to:dateTo,reason});
if(result.status==='success'){
document.getElementById('lvFrom').value='';document.getElementById('lvTo').value='';document.getElementById('lvReason').value='';
if(!db.leave_requests)db.leave_requests=[];
db.leave_requests.push({id:result.id||('local_'+Date.now()),emp_id:sessionUser.id,emp_name:sessionUser.name,leave_type:leaveType,date_from:dateFrom,date_to:dateTo,reason,submitted:new Date().toISOString().slice(0,19).replace('T',' ')});
renderMyLeaveRequests();renderStaffLeaveApprovals();renderLeaveApprovals?.();
}
alert(result.message);
}
function renderMyLeaveRequests(){
const box=document.getElementById('myLeaveRequestList'),hist=document.getElementById('myLeaveHistoryList');if(!box||!sessionUser)return;
renderLeaveBalance();
const mine=(db.leave_requests||[]).filter(r=>String(r.emp_id)===String(sessionUser.id));
box.innerHTML=mine.length?mine.map(r=>`<div style="padding:14px;margin-bottom:10px;border:1px solid #e2e8f0;border-radius:14px"><strong>${escapeHTML(r.date_from)} → ${escapeHTML(r.date_to)}</strong> — ${escapeHTML(leaveTypeLabel(r.leave_type))} <span style="color:#d97706;font-weight:700;margin-left:6px">⏳ Pending</span><p style="margin-top:6px;color:#64748b;font-size:12px">${escapeHTML(r.reason)}</p></div>`).join(''):'<p style="color:#64748b">No pending leave requests.</p>';
if(hist){
const mineHist=(db.leave_history||[]).filter(r=>String(r.emp_id)===String(sessionUser.id)).slice(-10).reverse();
hist.innerHTML=mineHist.length?mineHist.map(r=>{const ok=r.result==='approved';return `<div style="padding:14px;margin-bottom:10px;border:1px solid #e2e8f0;border-radius:14px"><strong>${escapeHTML(r.date_from)} → ${escapeHTML(r.date_to)}</strong> — ${escapeHTML(leaveTypeLabel(r.leave_type))} <span style="font-weight:700;margin-left:6px;color:${ok?'#166534':'#be123c'}">${ok?'✓ Approved':'✗ Rejected'}</span><p style="margin-top:6px;color:#64748b;font-size:12px">${escapeHTML(r.reason)}</p>${(!ok&&r.reject_reason)?`<p style="margin-top:4px;color:#be123c;font-size:12px"><b>Reason for rejection:</b> ${escapeHTML(r.reject_reason)}</p>`:''}</div>`}).join(''):'<p style="color:#64748b">No past leave requests yet.</p>';
}
}
function renderStaffLeaveApprovals(){
const card=document.getElementById('leaveApprovalsCardStaff'),box=document.getElementById('staffLeaveApprovalQueue');if(!card||!box||!sessionUser)return;
const me=(db.employees||[]).find(e=>String(e.id)===String(sessionUser.id));
if(!me||!me.is_manager){card.classList.add('hidden');return}
const myProject=String(me.project||'').trim().toLowerCase();
const queue=(db.leave_requests||[]).filter(r=>{if(String(r.emp_id)===String(sessionUser.id))return false;const emp=(db.employees||[]).find(e=>String(e.id)===String(r.emp_id));return emp&&String(emp.project||'').trim().toLowerCase()===myProject&&myProject!=='';});
card.classList.remove('hidden');
box.innerHTML=queue.length?queue.map(r=>`<div style="padding:18px;margin-bottom:12px;border:1px solid #e2e8f0;border-radius:18px"><strong>${escapeHTML(r.emp_name)} (${escapeHTML(r.emp_id)})</strong><br><small>${escapeHTML(r.date_from)} → ${escapeHTML(r.date_to)} | ${escapeHTML(leaveTypeLabel(r.leave_type))}</small><p>${escapeHTML(r.reason)}</p><button class="btn btn-save" onclick="processLeaveRequest('${escapeJS(r.id)}',true)">Approve</button> <button class="btn btn-danger" onclick="processLeaveRequest('${escapeJS(r.id)}',false)">Reject</button></div>`).join(''):'<p style="color:#64748b">No pending leave requests from your project.</p>';
}
function renderLeaveApprovals(){
const box=document.getElementById('leaveApprovalQueue');if(!box)return;
const queue=db.leave_requests||[];
box.innerHTML=queue.length?queue.map(r=>`<div style="padding:18px;margin-bottom:12px;border:1px solid #e2e8f0;border-radius:18px"><strong>${escapeHTML(r.emp_name)} (${escapeHTML(r.emp_id)})</strong><br><small>${escapeHTML(r.date_from)} → ${escapeHTML(r.date_to)} | ${escapeHTML(leaveTypeLabel(r.leave_type))}</small><p>${escapeHTML(r.reason)}</p><button class="btn btn-save" onclick="processLeaveRequest('${escapeJS(r.id)}',true)">Approve</button> <button class="btn btn-danger" onclick="processLeaveRequest('${escapeJS(r.id)}',false)">Reject</button></div>`).join(''):'<p style="color:#64748b">No pending leave requests.</p>';
updateApprovalsBadge();
}
async function processLeaveRequest(id,approve){
let reason='';if(!approve){const r=prompt('Reason for rejecting this leave (the employee will see it):','');if(r===null)return;reason=r.trim();if(!reason){alert('Please enter a reason to reject.');return;}}
const result=await server('process_leave_request',{req_id:id,approve,reason});
if(result.status==='success'){
db.leave_requests=(db.leave_requests||[]).filter(r=>r.id!==id);
renderStaffLeaveApprovals();renderMyLeaveRequests();renderLeaveApprovals?.();
if(sessionUser)renderStaffCalendar();
}
alert(result.message);
}
function renderMyRequestHistory(){
const sel=document.getElementById('myRequestHistorySelect'),detail=document.getElementById('myRequestHistoryDetail');
if(!sel||!sessionUser)return;
const mine=(db.request_history||[]).filter(h=>String(h.emp_id)===String(sessionUser.id)).sort((a,b)=>String(b.processed||'').localeCompare(String(a.processed||'')));
if(!mine.length){sel.innerHTML='<option value="">No past requests yet</option>';sel.disabled=true;sel.removeAttribute('data-items');if(detail)detail.innerHTML='';return}
sel.disabled=false;sel.dataset.items=JSON.stringify(mine);
sel.innerHTML=mine.map((h,i)=>`<option value="${i}">${escapeHTML(h.date)} — ${requestPunchLabel(h)} @ ${escapeHTML(h.punch_time||'')} — ${h.result==='approved'?'✅ Approved':'❌ Rejected'}</option>`).join('');
showMyRequestHistoryDetail();
}
function showMyRequestHistoryDetail(){
const sel=document.getElementById('myRequestHistorySelect'),detail=document.getElementById('myRequestHistoryDetail');if(!sel||!detail)return;
let items=[];try{items=JSON.parse(sel.dataset.items||'[]');}catch(e){}
const h=items[Number(sel.value)];if(!h){detail.innerHTML='';return}
const badge=h.result==='approved'?'<span style="color:#16a34a;font-weight:700">Approved</span>':'<span style="color:#dc2626;font-weight:700">❌ Rejected</span>';
detail.innerHTML=`<div style="padding:14px;margin-top:10px;border:1px solid #e2e8f0;border-radius:14px"><strong>${escapeHTML(h.date)}</strong> — ${requestPunchLabel(h)} @ ${escapeHTML(h.punch_time||'')} ${badge}<p style="margin-top:6px;color:#64748b;font-size:12px">${escapeHTML(h.reason)}</p>${(h.result!=='approved'&&h.reject_reason)?`<p style="margin-top:4px;color:#be123c;font-size:12px"><b>Reason for rejection:</b> ${escapeHTML(h.reject_reason)}</p>`:''}<small style="color:#94a3b8">Processed: ${escapeHTML(h.processed||'')}</small></div>`;
}
function todaysPunchList(key,day){
return ((db.punches||{})[key]||{})[day]||[];
}
function computeWorkedHours(punches){
/* Worked time = first IN to last OUT of the day (matches the "Working Hours" shown on screen).
   Old logic summed IN→OUT pairs only, so a repeated IN, a missed IN after lunch, or an OUT with no IN
   dropped hours and wrongly produced Half Day. */
const s=punchSorted(punches).filter(p=>p&&Number(p.ts)>0);
const firstIn=s.find(p=>p.type==='IN');
if(!firstIn)return 0;
const outs=s.filter(p=>p.type==='OUT'&&Number(p.ts)>Number(firstIn.ts));
if(!outs.length)return 0;
return (Number(outs[outs.length-1].ts)-Number(firstIn.ts))/3600000;
}
async function selfPunch(type){
if(!sessionUser)return;
if(db.face_ai&&db.face_ai.enabled){const fr=await faceVerifyFlow(sessionUser.id,'self');if(!fr.ok){alert(fr.msg);return}}
const d=new Date(),day=d.getDate(),month=d.getMonth(),year=d.getFullYear(),key=`${sessionUser.id}-${month}-${year}`,timeStr=d.toLocaleTimeString(),ts=d.getTime();
if(!db.punches)db.punches={};if(!db.punches[key])db.punches[key]={};if(!db.punches[key][day])db.punches[key][day]=[];
const result=await server('record_punch',{key,day,type,time:timeStr,site:'Self',ts});
if(result.status!=='success'){alert(result.message);return}
db.punches[key][day].push({time:timeStr,type,site:'Self',ts});
if(type==='OUT'){
const status=computeWorkedHours(todaysPunchList(key,day))<=4?'H':'P';
await applyAttendanceStatus(key,day,status);
}
renderSelfPunchUI();
renderStaffCalendar();
}
async function applyAttendanceStatus(key,day,status){
const result=await server('set_attendance_status',{key,day,status});
if(result.status==='success'){if(!db.attendance[key])db.attendance[key]={};db.attendance[key][day]=status;}
else alert(result.message);
return result;
}
function renderSelfPunchUI(){
const box=document.getElementById('selfPunchBox');if(!box||!sessionUser)return;
const d=new Date(),day=d.getDate(),month=d.getMonth(),year=d.getFullYear(),key=`${sessionUser.id}-${month}-${year}`;
const punches=todaysPunchList(key,day);
const sorted=[...punches].filter(p=>p&&p.type&&p.ts).sort((a,b)=>(Number(a.ts)||0)-(Number(b.ts)||0));
const firstIn=sorted.find(p=>p.type==='IN');
const outs=sorted.filter(p=>p.type==='OUT');
const lastOut=outs.length?outs[outs.length-1]:null;
let workHours=0;
if(firstIn){
const endTs=lastOut?Number(lastOut.ts):Date.now();
workHours=Math.max(0,(endTs-Number(firstIn.ts||0))/3600000);
}
const status=(db.attendance[key]||{})[day];
/* Self-heal: the saved Half Day/Full Day was only set at the moment of punch-out, so a day marked Half Day
   by the old calculation stayed wrong. Re-check it from today's punches whenever this screen is shown. */
if(lastOut&&(status==='H'||status==='P'||!status)){const want=computeWorkedHours(punches)<=4?'H':'P',guard=key+'-'+day+'-'+want;if(want!==status&&window._attHealed!==guard){window._attHealed=guard;applyAttendanceStatus(key,day,want).then(()=>{renderSelfPunchUI();renderStaffCalendar();});}}
const fmtTime=ts=>ts?new Date(Number(ts)).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}):'—';
const firstInLabel=firstIn?fmtTime(firstIn.ts):'—';
const lastOutLabel=lastOut?fmtTime(lastOut.ts):'—';
const history=sorted.map(p=>`${p.type} @ ${p.time||fmtTime(p.ts)}`).join(' → ');
const liveText=firstIn&&!lastOut?' (running)':'';
box.innerHTML=`
<div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-bottom:10px">
<div style="padding:11px 8px;border:1px solid var(--border);border-radius:12px;text-align:center;background:#f8fafc"><div style="font-size:10px;color:#64748b;font-weight:800;text-transform:uppercase">First In</div><strong style="display:block;margin-top:4px;font-size:17px">${firstInLabel}</strong></div>
<div style="padding:11px 8px;border:1px solid var(--border);border-radius:12px;text-align:center;background:#f8fafc"><div style="font-size:10px;color:#64748b;font-weight:800;text-transform:uppercase">Last Out</div><strong style="display:block;margin-top:4px;font-size:17px">${lastOutLabel}</strong></div>
<div style="padding:11px 8px;border:1px solid var(--border);border-radius:12px;text-align:center;background:#f8fafc"><div style="font-size:10px;color:#64748b;font-weight:800;text-transform:uppercase">Working Hours</div><strong style="display:block;margin-top:4px;font-size:17px">${workHours.toFixed(2)} hrs${liveText}</strong></div>
</div>
<div style="color:#64748b;font-size:12px">${history||'No punches yet today.'}</div>
<div style="margin-top:8px;font-weight:800">${status?`Status: ${status==='P'?'Full Day ✅':status==='H'?'Half Day ⚠️':escapeHTML(status)}`:'Attendance will be calculated after the punch-out.'}</div>`;
}
function refreshEmployeeSalaryAdvanceNow(){ if(!sessionUser)return; refreshPortalDatabase().then(ok=>{ if(ok && document.getElementById('stab-advances')?.classList.contains('active')){ renderStaffAdvances(); const live=document.getElementById('salaryAdvanceLiveStatus'); if(live){live.textContent='● Live';live.style.color='#16a34a';} } }); }
function startEmployeeTodayAttendanceLiveRefresh(){
if(window.employeeTodayAttendanceTimer) clearInterval(window.employeeTodayAttendanceTimer);
window.employeeTodayAttendanceTimer=setInterval(async()=>{
if(typeof noAutoRefreshTab==='function'&&noAutoRefreshTab())return;
if(!sessionUser){clearInterval(window.employeeTodayAttendanceTimer);window.employeeTodayAttendanceTimer=null;return;}
const todayTab=document.getElementById('stab-today');
const paySlipTab=document.getElementById('stab-payslip');
const ctAttTab=document.getElementById('stab-contractorAtt');
const applyAttTab=document.getElementById('stab-applyAtt');
const leaveTab=document.getElementById('stab-leave');
const todayActive=!!(todayTab&&todayTab.classList.contains('active'));
const paySlipActive=!!(paySlipTab&&paySlipTab.classList.contains('active'));
const ctAttActive=!!(ctAttTab&&ctAttTab.classList.contains('active'));
const applyAttActive=!!(applyAttTab&&applyAttTab.classList.contains('active'));
const leaveActive=!!(leaveTab&&leaveTab.classList.contains('active')); const advancesTab=document.getElementById('stab-advances'); const advancesActive=!!(advancesTab&&advancesTab.classList.contains('active'));
if(!todayActive&&!paySlipActive&&!ctAttActive&&!applyAttActive&&!leaveActive&&!advancesActive) return;
if(await refreshPortalDatabase()){
const latest=db.employees.find(e=>String(e.id)===String(sessionUser.id));
if(latest)sessionUser=latest;
applyEmployeeRestrictionUI();
if(todayActive) renderSelfPunchUI();
if(paySlipActive) renderStaffCalendar();
if(ctAttActive&&typeof renderContractorCalendarStaff==='function') renderContractorCalendarStaff();
if(applyAttActive){renderMyRequests();renderForgotPunchLimit();}
if(leaveActive){renderMyLeaveRequests();renderStaffLeaveApprovals();} if(advancesActive){renderStaffAdvances(); const live=document.getElementById('salaryAdvanceLiveStatus'); if(live){live.textContent='● Live';live.style.color='#16a34a';}}
}
},3000);
}
function startEmployeePortalLiveRefresh(){
if(window.employeePortalLiveTimer) clearInterval(window.employeePortalLiveTimer);
window.employeePortalLiveTimer=setInterval(async()=>{
if(typeof noAutoRefreshTab==='function'&&noAutoRefreshTab())return;
if(!sessionUser){clearInterval(window.employeePortalLiveTimer);window.employeePortalLiveTimer=null;return;}
const before=JSON.stringify({
project:sessionUser.project||'',
shift:sessionUser.shift||'',
contractor_ids:sessionUser.contractor_ids||((sessionUser.contractor_id||'')?[sessionUser.contractor_id]:[]),
contractor_id:sessionUser.contractor_id||'',
terminated:!!sessionUser.terminated,
termination_date:sessionUser.termination_date||'',
notice_period_end:sessionUser.notice_period_end||''
});
if(!await refreshPortalDatabase()) return;
const latest=db.employees.find(e=>String(e.id)===String(sessionUser.id));
if(!latest)return;
const after=JSON.stringify({
project:latest.project||'',
shift:latest.shift||'',
contractor_ids:latest.contractor_ids||((latest.contractor_id||'')?[latest.contractor_id]:[]),
contractor_id:latest.contractor_id||'',
terminated:!!latest.terminated,
termination_date:latest.termination_date||'',
notice_period_end:latest.notice_period_end||''
});
sessionUser=latest;
applyEmployeeRestrictionUI();
if(before===after)return;
const nameEl=document.getElementById('staffName');
if(nameEl)nameEl.innerText='Portal: '+(latest.name||'Employee');
renderEmployeeProfile(latest);
const active=document.querySelector('#empView .nav-tab-btn.active')?.dataset?.stab||'';
if(active==='today'){renderSelfPunchUI();renderStaffCalendar();}
if(active==='contractor'||active==='contractorAtt'){syncContractorsStaff?.();}
if(active==='idcard'){renderIdCard(latest,false);}
},3000);
}
function startContractorPortalLiveRefresh(){
if(window.contractorPortalLiveTimer) clearInterval(window.contractorPortalLiveTimer);
window.contractorPortalLiveTimer=setInterval(async()=>{
if(!sessionContractor){clearInterval(window.contractorPortalLiveTimer);window.contractorPortalLiveTimer=null;return;}
return; /* No timer-based refresh: contractor portal updates only on open or when Refresh is tapped. */
const before=JSON.stringify(sessionContractor);
if(!await refreshPortalDatabase())return;
const latest=db.contractors.find(c=>String(c.id)===String(sessionContractor.id));
if(!latest)return;
const changed=JSON.stringify(latest)!==before;
sessionContractor=latest;
if(!changed)return;
const title=document.getElementById('cpContractorName');
if(title)title.innerText=(latest.name||'Contractor')+' ['+(latest.id||'')+']';
renderContractorPortal();
},3000);
}
function startAdminLiveCalendarRefresh(){
if(window.adminCalendarTimer) clearInterval(window.adminCalendarTimer);
window.adminCalendarTimer=setInterval(async()=>{
if(typeof noAutoRefreshTab==='function'&&noAutoRefreshTab())return;
const adminView=document.getElementById('adminView');
if(!adminView||adminView.classList.contains('hidden')){clearInterval(window.adminCalendarTimer);window.adminCalendarTimer=null;return;}
const attTab=document.getElementById('tab-attendance');
const ctAttTab=document.getElementById('tab-contractorAtt');
const dashTab=document.getElementById('tab-dashboard');
const attActive=!!(attTab&&attTab.classList.contains('active'));
const ctAttActive=!!(ctAttTab&&ctAttTab.classList.contains('active'));
const dashActive=!!(dashTab&&dashTab.classList.contains('active'));
if(!attActive&&!ctAttActive&&!dashActive){
if(await refreshPortalDatabase()) updateApprovalsBadge();
return;
}
if(await refreshPortalDatabase()){
if(attActive) renderAdminCalendar();
if(ctAttActive) renderContractorCalendar();
if(dashActive){renderRequests();renderLeaveApprovals();renderDashboard();}
}
},4000);
}
function generateMyQR(){
if(!sessionUser)return;
const box=document.getElementById('myQRBox');if(!box)return;
box.innerHTML='';document.getElementById('myQRIdLabel').innerText=sessionUser.id;
if(typeof QRCode==='undefined'){box.innerHTML='<p style="color:#be123c">QR library failed to load. Check your internet connection.</p>';return}
new QRCode(box,{text:sessionUser.id,width:200,height:200});
}
async function testCamera(){
const status=document.getElementById('scanStatus');
status.innerHTML='<span style="color:#4f46e5">Testing camera access…</span>';
if(!window.isSecureContext){status.innerHTML='<span style="color:#be123c">❌ Not a secure context (no https). This alone will block the camera.</span>';return}
if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){status.innerHTML='<span style="color:#be123c">❌ navigator.mediaDevices.getUserMedia is not available in this browser at all.</span>';return}
if(navigator.permissions&&navigator.permissions.query){
try{const p=await navigator.permissions.query({name:'camera'});status.innerHTML=`<span style="color:#4f46e5">Browser permission state: <strong>${p.state}</strong>. Requesting stream…</span>`;}catch(e){}
}
try{
const testStream=await navigator.mediaDevices.getUserMedia({video:true});
testStream.getTracks().forEach(t=>t.stop());
status.innerHTML='<span style="color:#059669">Camera access works! Try In Time / Out Time now.</span>';
}catch(err){
status.innerHTML=`<span style="color:#be123c">❌ ${err.name}: ${err.message||'camera blocked'}. Check your phone's Settings → Browser app → Camera permission.</span>`;
}
}
let scanStream=null,scanRAF=null,scanLastId=null,scanLastTime=0,scanMode='IN';
function updateScanModeUI(){
document.getElementById('scanInBtn').style.opacity=scanMode==='IN'?'1':'0.5';
document.getElementById('scanOutBtn').style.opacity=scanMode==='OUT'?'1':'0.5';
}
/* ===== Object-tracking QR scanner =====
   Each QR card is treated as a tracked object: detected every frame, matched by its ID,
   smoothed, drawn with a box that follows it, and only punched after a stable lock. */
const SCAN_LOCK_HITS=3,SCAN_COAST_MS=450,SCAN_DROP_MS=900,SCAN_PUNCH_COOLDOWN=8000,SCAN_INTERVAL=70,SCAN_MAX_W=720,SCAN_MAX_CODES=4;
let scanTracks=new Map(),scanBusy=false,scanLastDetect=0,scanDetector=null,scanDetectorTried=false;
function scanKnown(id){return !!(db&&db.employees&&db.employees.find(e=>e.id===id))}
function scanEmp(id){return db&&db.employees?db.employees.find(e=>e.id===id):null}
const OTS_CALS=['https://alice.btc.calendar.opentimestamps.org','https://bob.btc.calendar.opentimestamps.org','https://finney.calendar.eternitywall.com'];
const OTS_MAGIC=[0x00,0x4f,0x70,0x65,0x6e,0x54,0x69,0x6d,0x65,0x73,0x74,0x61,0x6d,0x70,0x73,0x00,0x00,0x50,0x72,0x6f,0x6f,0x66,0x00,0xbf,0x89,0xe2,0xe8,0x84,0xe8,0x92,0x94];
function ledgerB64(u8){let s='';for(let i=0;i<u8.length;i+=0x8000)s+=String.fromCharCode.apply(null,u8.subarray(i,i+0x8000));return btoa(s)}
function ledgerB64Bytes(b){const s=atob(b),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u}
async function ledgerSha256(buf){return new Uint8Array(await crypto.subtle.digest('SHA-256',buf))}
function ledgerHex(u8){return Array.from(u8).map(b=>b.toString(16).padStart(2,'0')).join('')}
function ledgerSave(name,blobParts,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(blobParts,{type}));a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1500)}
async function ledgerAnchorNow(auto){
const out=document.getElementById('ledgerResult');
const say=(c,t)=>{if(out&&!auto)out.innerHTML=`<span style="color:${c}">${t}</span>`};
if(!window.isSecureContext||!window.crypto||!crypto.subtle){say('#be123c','Anchoring needs the site to be opened over https://.');return}
say('#4f46e5','Preparing anchor…');
const prep=await server('ledger_anchor_prepare',{});
if(prep.status!=='success'){say('#be123c',escapeHTML(prep.message||'Could not prepare the anchor.'));return}
const digest=await ledgerSha256(new TextEncoder().encode(prep.text));
say('#4f46e5','Sending fingerprint to OpenTimestamps calendars…');
const proofs={};
await Promise.all(OTS_CALS.map(async cal=>{try{
const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),15000);
const r=await fetch(cal+'/digest',{method:'POST',headers:{'Accept':'application/vnd.opentimestamps.v1','Content-Type':'application/octet-stream'},body:digest,signal:ctl.signal});clearTimeout(to);
if(!r.ok)return;const body=new Uint8Array(await r.arrayBuffer());if(!body.length)return;
const L=OTS_MAGIC.length,f=new Uint8Array(L+34+body.length);f.set(OTS_MAGIC,0);f[L]=1;f[L+1]=8;f.set(digest,L+2);f.set(body,L+34);
proofs[cal.replace('https://','').split('.')[0]]=ledgerB64(f);
}catch(e){}}));
if(!Object.keys(proofs).length){
window.__ledgerAnchorText=prep.text;
say('#b45309','Could not reach any OpenTimestamps calendar from this browser. <a href="#" onclick="ledgerSave(\'anchor-'+prep.height+'.txt\',[window.__ledgerAnchorText],\'text/plain\');return false">Download the anchor file</a> and stamp it manually at opentimestamps.org.');
return}
const sv=await server('ledger_anchor_save',{text:prep.text,proofs});
if(sv.status!=='success'){say('#be123c',escapeHTML(sv.message||'Could not save the anchor.'));return}
say('#059669',`✅ Anchored chain height ${prep.height} (${sv.calendars.length} calendar${sv.calendars.length>1?'s':''}). Bitcoin confirmation usually follows within a few hours.`);
ledgerLoadAnchors();
}
async function ledgerAutoAnchor(){
if(window.__ledgerAuto)return;window.__ledgerAuto=true;
try{const st=await server('ledger_anchor_status',{});if(st.status==='success'&&st.due)ledgerAnchorNow(true)}catch(e){}
}
async function ledgerLoadAnchors(){
const box=document.getElementById('ledgerAnchors');if(!box)return;
const r=await server('ledger_anchor_list',{});
if(r.status!=='success'||!r.anchors.length){box.innerHTML='';return}
box.innerHTML='<strong>Recent anchors</strong>'+r.anchors.map(a=>`<div style="padding:6px 0;border-bottom:1px solid var(--border)">${escapeHTML(a.time)} · block #${a.height} · ${a.docs} docs<br>${a.calendars.map(c=>`<a href="#" onclick="ledgerDownloadAnchor(${a.id},'${escapeHTML(c)}');return false" style="color:#4f46e5;font-weight:800">⬇ ${escapeHTML(c)}.ots</a>`).join(' · ')}</div>`).join('')+'<p style="color:#64748b;font-size:11px;margin:6px 0 0">To verify: open opentimestamps.org, drop the .ots file and the .txt file it downloads with. It becomes fully Bitcoin-confirmed after a few hours (the site upgrades it for you).</p>';
}
async function ledgerDownloadAnchor(id,cal){
const r=await server('ledger_anchor_get',{id,cal});
if(r.status!=='success'){alert(r.message||'Download failed.');return}
const base='anchor-'+r.height+'.txt';
ledgerSave(base,[r.text],'text/plain');
setTimeout(()=>ledgerSave(base+'.ots',[ledgerB64Bytes(r.ots)],'application/octet-stream'),400);
}
async function ledgerSelectedFingerprint(){
const f=document.getElementById('ledgerDocFile').files[0];if(!f)throw new Error('Choose a file first.');
if(!window.crypto||!crypto.subtle)throw new Error('Document fingerprinting needs HTTPS.');
return {file:f,sha256:ledgerHex(await ledgerSha256(await f.arrayBuffer()))};
}
async function ledgerCheckDoc(){
const out=document.getElementById('ledgerDocResult');try{
out.innerHTML='<span style="color:#4f46e5">Checking…</span>';
const {file:f,sha256:h}=await ledgerSelectedFingerprint();
const r=await server('ledger_doc_check',{sha256:h});
if(r.status!=='success'){out.innerHTML=`<span style="color:#be123c">${escapeHTML(r.message||'Check failed.')}</span>`;return}
const fp=`<div style="font-weight:600;color:#64748b;font-size:11px;margin-top:4px;word-break:break-all">SHA-256: ${h}</div>`;
if(!r.matches.length){document.getElementById('ledgerDocMeta').style.display='block';document.getElementById('ledgerDocName').value=f.name;out.innerHTML=`<span style="color:#be123c">❌ No stored document matches this file. You can register its fingerprint below.</span>${fp}`;return}
document.getElementById('ledgerDocMeta').style.display='none';out.innerHTML=`<span style="color:#059669">✅ Matches a stored document:</span><ul style="margin:4px 0 0;padding-left:18px;font-weight:600;font-size:12px">${r.matches.map(m=>`<li>${escapeHTML(m.path)} · first recorded ${escapeHTML(m.time)}</li>`).join('')}</ul>${fp}`;
}catch(e){out.innerHTML=`<span style="color:#be123c">${escapeHTML(e.message||'Check failed.')}</span>`}
}
async function ledgerRegisterDoc(){const out=document.getElementById('ledgerDocResult');try{const {file,sha256}=await ledgerSelectedFingerprint();document.getElementById('ledgerDocMeta').style.display='block';if(!document.getElementById('ledgerDocName').value)document.getElementById('ledgerDocName').value=file.name;out.innerHTML=`<span style="color:#4f46e5">Ready to register fingerprint for ${escapeHTML(file.name)}. Confirm the title and project below.</span><div style="font-size:11px;word-break:break-all;color:#64748b">SHA-256: ${sha256}</div>`;}catch(e){out.innerHTML=`<span style="color:#be123c">${escapeHTML(e.message||'Cannot prepare registration.')}</span>`}}
async function ledgerSubmitRegistration(){const out=document.getElementById('ledgerDocResult');try{const {file,sha256}=await ledgerSelectedFingerprint();const name=document.getElementById('ledgerDocName').value.trim(),project=document.getElementById('ledgerDocProject').value.trim();if(!name){out.innerHTML='<span style="color:#be123c">Enter a document title.</span>';return}out.innerHTML='<span style="color:#4f46e5">Registering fingerprint…</span>';const r=await server('ledger_doc_register',{sha256,name,project,size:file.size});if(r.status!=='success'){out.innerHTML=`<span style="color:#be123c">${escapeHTML(r.message||'Registration failed.')}</span>`;return}out.innerHTML=`<span style="color:#059669">✅ ${escapeHTML(r.message||'Registered.')}</span><div style="font-size:11px;color:#64748b">${escapeHTML(r.path||'')} · ${escapeHTML(r.time||'')}<br>SHA-256: ${sha256}</div>`;document.getElementById('ledgerDocMeta').style.display='none';}catch(e){out.innerHTML=`<span style="color:#be123c">${escapeHTML(e.message||'Registration failed.')}</span>`}}
async function verifyLedger(){
const out=document.getElementById('ledgerResult');out.innerHTML='<span style="color:#4f46e5">Verifying…</span>';
const r=await server('ledger_verify',{});
if(r.status!=='success'){out.innerHTML=`<span style="color:#be123c">${escapeHTML(r.message||'Verification failed.')}</span>`;return}
const head=`<div style="font-weight:600;color:#64748b;font-size:11px;margin-top:6px;word-break:break-all">${r.blocks} blocks · last ${escapeHTML(r.head_time||'-')}<br>Head: ${escapeHTML(r.head)}${r.untracked?`<br>${r.untracked} record(s) not yet in the chain (they join on their next save).`:''}<br>${r.docs} document(s) fingerprinted${r.docs_new?`, ${r.docs_new} new`:''}${r.docs_changed?`, ${r.docs_changed} replaced since last check`:''} · ${r.anchors} anchor(s)</div>`;
if(r.ok){out.innerHTML=`<span style="color:#059669">✅ Chain intact. No tampering found.</span>${head}`;ledgerLoadAnchors();return}
out.innerHTML=`<span style="color:#be123c">❌ ${r.issue_count} problem(s) found:</span><ul style="margin:6px 0 0;padding-left:18px;color:#be123c;font-weight:600;font-size:12px">${r.issues.map(i=>`<li>${escapeHTML(i)}</li>`).join('')}</ul>${head}`;
}
async function startScan(mode){
if(db.face_ai&&db.face_ai.enabled){scanMode=mode;updateScanModeUI();return guardFaceScan(mode)}
scanMode=mode;updateScanModeUI();
const video=document.getElementById('scanVideo'),wrap=document.getElementById('scanWrap'),status=document.getElementById('scanStatus');
const msg=(c,t)=>{status.innerHTML=`<span style="color:${c}">${t}</span>`};
const scanning=()=>msg('#4f46e5',`Tracking for <strong>${mode==='IN'?'In Time':'Out Time'}</strong>… hold QR cards in view (several at once is fine)`);
if(scanStream){scanning();return}
if(typeof jsQR==='undefined'&&!('BarcodeDetector' in window)){msg('#be123c','QR scanner library failed to load. Check your internet connection and reload.');return}
if(!window.isSecureContext){msg('#be123c','Camera needs a secure connection. Open this site over <strong>https://</strong> (or localhost) — browsers block the camera on plain http.');return}
if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){msg('#be123c','This browser does not support camera access. Try Chrome or Safari.');return}
msg('#4f46e5','Requesting camera permission…');
const attach=async stream=>{
scanStream=stream;video.srcObject=stream;wrap.style.display='block';
try{await video.play()}catch(e){}
try{const t=stream.getVideoTracks()[0];const caps=t.getCapabilities?t.getCapabilities():{};if(caps.focusMode&&caps.focusMode.includes('continuous'))await t.applyConstraints({advanced:[{focusMode:'continuous'}]})}catch(e){}
document.getElementById('scanStopBtn').classList.remove('hidden');
scanTracks=new Map();scanBusy=false;scanLastDetect=0;
scanning();scanTick();
};
try{
await attach(await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1280},height:{ideal:720}}}));
}catch(err){
let m='Camera error: '+(err.name||err.message||'unknown');
if(err.name==='NotAllowedError')m='Camera permission was denied. Allow camera access for this site in your browser settings, then tap In Time or Out Time again.';
else if(err.name==='NotFoundError')m='No camera was found on this device.';
else if(err.name==='NotReadableError')m='Camera is already in use by another app. Close other camera apps and try again.';
else if(err.name==='OverconstrainedError'){try{await attach(await navigator.mediaDevices.getUserMedia({video:true}));return}catch(e2){m='No usable camera found.'}}
msg('#be123c',m);
}
}
function stopScan(){
if(scanRAF)cancelAnimationFrame(scanRAF);scanRAF=null;
if(scanStream){scanStream.getTracks().forEach(t=>t.stop());scanStream=null}
scanTracks=new Map();scanBusy=false;
const ov=document.getElementById('scanOverlay');if(ov){const c=ov.getContext('2d');c.clearRect(0,0,ov.width,ov.height)}
document.getElementById('scanWrap').style.display='none';
document.getElementById('scanStopBtn').classList.add('hidden');
document.getElementById('scanStatus').innerText='';
}
/* Detect every QR in the frame. Returns [{data, pts:[{x,y}x4]}] in video pixel coordinates. */
async function scanDetectAll(video,canvas){
if(!scanDetectorTried){scanDetectorTried=true;try{if('BarcodeDetector' in window)scanDetector=new BarcodeDetector({formats:['qr_code']})}catch(e){scanDetector=null}}
if(scanDetector){
try{
const r=await scanDetector.detect(video);
return r.filter(c=>c.rawValue&&c.cornerPoints&&c.cornerPoints.length===4).map(c=>({data:c.rawValue.trim(),pts:c.cornerPoints.map(q=>({x:q.x,y:q.y}))}));
}catch(e){scanDetector=null}
}
if(typeof jsQR==='undefined')return [];
const vw=video.videoWidth,vh=video.videoHeight,k=Math.min(1,SCAN_MAX_W/vw),w=Math.round(vw*k),h=Math.round(vh*k);
canvas.width=w;canvas.height=h;
const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(video,0,0,w,h);
const img=ctx.getImageData(0,0,w,h),out=[];
for(let i=0;i<SCAN_MAX_CODES;i++){
const c=jsQR(img.data,w,h,{inversionAttempts:'dontInvert'});
if(!c||!c.data)break;
const L=c.location,pts=[L.topLeftCorner,L.topRightCorner,L.bottomRightCorner,L.bottomLeftCorner].map(q=>({x:q.x/k,y:q.y/k}));
out.push({data:c.data.trim(),pts});
/* blank the found code so the next pass can find another card */
const xs=[L.topLeftCorner.x,L.topRightCorner.x,L.bottomRightCorner.x,L.bottomLeftCorner.x],ys=[L.topLeftCorner.y,L.topRightCorner.y,L.bottomRightCorner.y,L.bottomLeftCorner.y];
const pad=6,x0=Math.max(0,Math.floor(Math.min(...xs))-pad),x1=Math.min(w-1,Math.ceil(Math.max(...xs))+pad),y0=Math.max(0,Math.floor(Math.min(...ys))-pad),y1=Math.min(h-1,Math.ceil(Math.max(...ys))+pad);
for(let y=y0;y<=y1;y++){let o=(y*w+x0)*4;for(let x=x0;x<=x1;x++,o+=4){img.data[o]=img.data[o+1]=img.data[o+2]=128}}
}
return out;
}
/* Fold one frame's detections into the tracker (match by ID, smooth, coast, drop). */
function scanUpdateTracks(dets,now){
const seen=new Set();
for(const d of dets){
seen.add(d.data);
let t=scanTracks.get(d.data);
if(!t){t={id:d.data,pts:d.pts,vel:[0,0,0,0].map(()=>({x:0,y:0})),hits:0,first:now,last:now,punchedAt:0,result:''};scanTracks.set(d.data,t)}
else{
const dt=Math.max(1,now-t.last),A=0.55;
t.pts=t.pts.map((p,i)=>{const nx=p.x+(d.pts[i].x-p.x)*A,ny=p.y+(d.pts[i].y-p.y)*A;t.vel[i]={x:(nx-p.x)/dt,y:(ny-p.y)/dt};return{x:nx,y:ny}});
}
t.hits++;t.last=now;
}
for(const [id,t] of scanTracks){
if(seen.has(id))continue;
const gap=now-t.last;
if(gap>SCAN_DROP_MS){scanTracks.delete(id);continue}
if(gap<=SCAN_COAST_MS){t.pts=t.pts.map((p,i)=>({x:p.x+t.vel[i].x*16,y:p.y+t.vel[i].y*16}))}
t.hits=Math.max(0,t.hits-1);
}
}
function scanDraw(video,now){
const ov=document.getElementById('scanOverlay');if(!ov||!video.videoWidth)return;
const cw=ov.clientWidth,ch=ov.clientHeight;if(!cw||!ch)return;
if(ov.width!==cw||ov.height!==ch){ov.width=cw;ov.height=ch}
const ctx=ov.getContext('2d');ctx.clearRect(0,0,cw,ch);
const sx=cw/video.videoWidth,sy=ch/video.videoHeight;
ctx.lineJoin='round';ctx.font='700 12px Segoe UI,Arial,sans-serif';
for(const t of scanTracks.values()){
const emp=scanEmp(t.id),coasting=(now-t.last)>SCAN_INTERVAL*2.5;
const locked=t.hits>=SCAN_LOCK_HITS,recent=t.punchedAt&&(now-t.punchedAt)<SCAN_PUNCH_COOLDOWN;
let color='#f59e0b',label=emp?emp.name:'Locking…';
if(!emp&&locked){color='#e11d48';label='Unknown ID'}
else if(recent){color='#10b981';label=(emp?emp.name:t.id)+(t.result?' · '+t.result:'')}
else if(locked&&emp){color='#3b82f6'}
ctx.globalAlpha=coasting?0.45:1;
ctx.strokeStyle=color;ctx.lineWidth=3;ctx.shadowColor='rgba(0,0,0,.5)';ctx.shadowBlur=4;
ctx.beginPath();t.pts.forEach((p,i)=>{const x=p.x*sx,y=p.y*sy;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.closePath();ctx.stroke();
ctx.shadowBlur=0;
const minY=Math.min(...t.pts.map(p=>p.y))*sy,minX=Math.min(...t.pts.map(p=>p.x))*sx;
const tw=ctx.measureText(label).width+12,ty=Math.max(0,minY-22),tx=Math.min(Math.max(0,minX),cw-tw);
ctx.fillStyle=color;ctx.fillRect(tx,ty,tw,20);ctx.fillStyle='#fff';ctx.fillText(label,tx+6,ty+14);
ctx.globalAlpha=1;
}
}
function scanTick(){
const video=document.getElementById('scanVideo'),canvas=document.getElementById('scanCanvas');
if(!scanStream)return;
scanRAF=requestAnimationFrame(scanTick);
if(!video||video.readyState!==video.HAVE_ENOUGH_DATA)return;
const now=performance.now();
scanDraw(video,now);
if(scanBusy||now-scanLastDetect<SCAN_INTERVAL)return;
scanBusy=true;scanLastDetect=now;
scanDetectAll(video,canvas).then(dets=>{
if(!scanStream)return;
const t=performance.now();
scanUpdateTracks(dets,t);
for(const tr of scanTracks.values()){
if(tr.hits>=SCAN_LOCK_HITS&&scanKnown(tr.id)&&(t-tr.punchedAt)>SCAN_PUNCH_COOLDOWN){
tr.punchedAt=t;tr.result=scanMode==='IN'?'IN ✓':'OUT ✓';
handleScannedCode(tr.id);
}else if(tr.hits>=SCAN_LOCK_HITS&&!scanKnown(tr.id)&&!tr.warned){
tr.warned=true;handleScannedCode(tr.id);
}
}
}).catch(()=>{}).finally(()=>{scanBusy=false});
}
function manualPunch(type){
const id=document.getElementById('manualEmpId').value.trim();
if(!id){alert('Enter an Employee ID first.');return}
handleScannedCode(id,type);
document.getElementById('manualEmpId').value='';
}
async function guardFaceScan(type){
if(window.__faceBusy)return;window.__faceBusy=true;const status=document.getElementById('scanStatus');
try{if(scanStream)stopScan();status.innerHTML='<span style="color:#4f46e5">Face scan…</span>';const fr=await faceVerifyFlow(null,'guard',true);if(!fr.ok){status.innerHTML=`<span style="color:#be123c">❌ ${escapeHTML(fr.msg)}</span>`;return}
window.__faceBusy=false;await handleScannedCode(fr.emp_id,type,true)}
finally{window.__faceBusy=false}
}
async function handleScannedCode(empId,forcedType,skipFace){
const now=Date.now();
if(!forcedType&&empId===scanLastId&&(now-scanLastTime)<4000)return;
scanLastId=empId;scanLastTime=now;
const employee=db.employees.find(e=>e.id===empId);
const status=document.getElementById('scanStatus'),log=document.getElementById('scanLog');
if(!employee){status.innerHTML=`<span style="color:#be123c">❌ Unknown ID: ${escapeHTML(empId)}</span>`;return}
if(db.face_ai&&db.face_ai.enabled&&!skipFace){
if(window.__faceBusy)return;window.__faceBusy=true;
try{if(scanStream)stopScan();status.innerHTML=`<span style="color:#4f46e5">Face check for ${escapeHTML(employee.name)}…</span>`;const fr=await faceVerifyFlow(empId,'guard');if(!fr.ok){status.innerHTML=`<span style="color:#be123c">❌ ${escapeHTML(fr.msg)}</span>`;return}}
finally{window.__faceBusy=false}
}
const d=new Date(),day=d.getDate(),month=d.getMonth(),year=d.getFullYear(),key=`${employee.id}-${month}-${year}`,timeStr=d.toLocaleTimeString(),type=forcedType||scanMode;
if(!db.punches)db.punches={};if(!db.punches[key])db.punches[key]={};if(!db.punches[key][day])db.punches[key][day]=[];
const todaysPunches=db.punches[key][day];
const result=await server('record_punch',{key,day,type,time:timeStr,site:sessionSite||'',ts:d.getTime()});
if(result.status!=='success'){status.innerHTML=`<span style="color:#b45309">⚠️ ${escapeHTML(result.message)}</span>`;return}
todaysPunches.push({time:timeStr,type,site:sessionSite||'',ts:d.getTime()});
if(type==='OUT'){
const attStatus=computeWorkedHours(todaysPunches)<=4?'H':'P';
if(!db.attendance[key])db.attendance[key]={};
const attResult=await server('set_attendance_status',{key,day,status:attStatus});
if(attResult.status==='success')db.attendance[key][day]=attStatus;
}
const inCount=todaysPunches.filter(p=>p.type==='IN').length,outCount=todaysPunches.filter(p=>p.type==='OUT').length;
status.innerHTML=`<span style="color:#059669">${escapeHTML(employee.name)} punched ${type==='IN'?'In Time':'Out Time'} at ${timeStr}</span>`;
const history=todaysPunches.map(p=>`${p.type} @ ${p.time}`).join(' → ');
const row=document.createElement('div');row.style.cssText='padding:8px 0;border-bottom:1px solid var(--border);font-size:12px';
row.innerHTML=`<strong>${escapeHTML(employee.name)}</strong> [${escapeHTML(employee.id)}] — <strong>${type}</strong> @ ${timeStr} <span style="color:#4f46e5">(${escapeHTML(sessionSite||'')})</span> <span style="color:#64748b">(Punch #${todaysPunches.length} today · IN:${inCount} OUT:${outCount})</span><div style="color:#64748b;margin-top:2px">${history}</div>`;
log.prepend(row);
const attEEl=document.getElementById('attE');
if(attEEl&&attEEl.value===employee.id&&Number(document.getElementById('attM').value)===month&&Number(document.getElementById('attY').value)===year){renderAdminCalendar();}
}
function initPasswordToggles(){document.querySelectorAll('input[type="password"]').forEach(input=>{if(input.dataset.eyeReady)return;input.dataset.eyeReady='1';const wrap=document.createElement('div');wrap.className='password-wrap';input.parentNode.insertBefore(wrap,input);wrap.appendChild(input);const btn=document.createElement('button');btn.type='button';btn.className='password-toggle';btn.setAttribute('aria-label','Show password');btn.innerText='👁';btn.onclick=()=>{const show=input.type==='password';input.type=show?'text':'password';btn.innerText=show?'🙈':'👁';btn.setAttribute('aria-label',show?'Hide password':'Show password')};wrap.appendChild(btn);});}
document.addEventListener('DOMContentLoaded',initPasswordToggles);
(function(){
try{
var isPhone = /Android|iPhone|iPad|iPod|Windows Phone|Mobile/i.test(navigator.userAgent);
if(isPhone){
var lv = document.getElementById('loginView');
if(lv) lv.classList.add('force-mobile-login');
document.documentElement.classList.add('force-mobile-device');
document.body.classList.add('force-mobile-device');
}
}catch(e){}
})();
function toggleLoginPw(){
var pw=document.getElementById('p');
var icon=document.getElementById('pwEyeIcon');
if(!pw||!icon)return;
if(pw.type==='password'){
pw.type='text';
icon.innerHTML='<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"></path><circle cx="12" cy="12" r="3"></circle>';
}else{
pw.type='password';
icon.innerHTML='<path d="M17.9 17.9A10.6 10.6 0 0 1 12 19c-6.5 0-10-7-10-7a18.6 18.6 0 0 1 4.2-5.2M9.5 4.6A10.7 10.7 0 0 1 12 4.3c6.5 0 10 7 10 7a18.6 18.6 0 0 1-2.2 3.1M14.1 14.1a3 3 0 1 1-4.2-4.2"></path><line x1="1" y1="1" x2="23" y2="23"></line>';
}
}
function showForgotPassword(){
const m=document.getElementById('forgotPasswordModal');
const u=document.getElementById('u');
const fu=document.getElementById('forgotUser');
if(fu) fu.value=u?u.value.trim():'';
['forgotDob','forgotNewPass','forgotConfirmPass'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
const r=document.getElementById('forgotResult'); if(r){r.style.display='none';r.innerText='';}
if(m){m.classList.remove('hidden');m.style.display='flex';}
setTimeout(()=>{if(fu)fu.focus();},50);
}
function hideForgotPassword(){
const m=document.getElementById('forgotPasswordModal');
if(m){m.classList.add('hidden');m.style.display='none';}
}
async function submitForgotPassword(){
const username=(document.getElementById('forgotUser')?.value||'').trim();
const dob=(document.getElementById('forgotDob')?.value||'').trim();
const newPass=document.getElementById('forgotNewPass')?.value||'';
const confirmPass=document.getElementById('forgotConfirmPass')?.value||'';
const r=document.getElementById('forgotResult');
const show=(msg,ok=false)=>{if(r){r.style.display='block';r.style.background=ok?'#ecfdf5':'#fef2f2';r.style.color=ok?'#047857':'#b91c1c';r.innerText=msg;}};
if(!username){show('Please enter your username.');return;}
if(!dob){show('Please select your date of birth.');return;}
if(newPass.length<8){show('New password must contain at least 8 characters.');return;}
if(newPass!==confirmPass){show('New password and confirmation do not match.');return;}
if(r){r.style.display='block';r.style.background='#eff6ff';r.style.color='#1d4ed8';r.innerText='Verifying your details...';}
try{
const result=await server('forgot_password_reset',{username,dob,new_password:newPass});
if(result.status==='success'){
show(result.message||'Password reset successfully.',true);
const loginPass=document.getElementById('p'); if(loginPass)loginPass.value=newPass;
setTimeout(()=>hideForgotPassword(),1200);
}else show(result.message||'Unable to reset password.');
}catch(e){show('Unable to connect to the server. Please try again.');}
}

/* ---- Biometric login (fingerprint / face) ---- */
function bioB64uToBuf(x){x=String(x).replace(/-/g,'+').replace(/_/g,'/');while(x.length%4)x+='=';const b=atob(x),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u.buffer;}
function bioBufToB64u(buf){const u=new Uint8Array(buf);let s='';for(let i=0;i<u.length;i++)s+=String.fromCharCode(u[i]);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function bioNative(){try{return !!(window.TejodharBio&&window.TejodharBio.isAvailable());}catch(e){return false;}}
function bioNativeCall(fn,arg){return new Promise(function(resolve){var name='__bioCb'+Date.now().toString(36)+Math.floor(Math.random()*1e6);var done=false;window[name]=function(r){if(done)return;done=true;try{delete window[name];}catch(e){window[name]=undefined;}resolve(r||{ok:false,error:'failed'});};try{if(arg===undefined)window.TejodharBio[fn](name);else window.TejodharBio[fn](arg,name);}catch(e){window[name]({ok:false,error:'failed'});}});}
function bioSupported(){return bioNative()||!!(window.PublicKeyCredential&&navigator.credentials&&window.isSecureContext);}
function bioShowError(m){const el=document.getElementById('loginError');if(el){el.innerText=m;el.style.display='block';}else alert(m);}
async function bioLogin(){
const el=document.getElementById('loginError');if(el){el.style.display='none';el.innerText='';}
if(!bioSupported()){bioShowError('Biometric login is not supported on this browser. Use your password.');return;}
if(bioNative()){
if(!window.TejodharBio.hasToken()){bioShowError('Fingerprint is not set up on this phone. Login with password and enable it first.');return;}
try{
const u=await bioNativeCall('unlock');
if(!u.ok){if(u.error==='not_registered')bioShowError('Fingerprint is not set up on this phone. Login with password and enable it first.');else if(u.error==='cancelled')bioShowError('Biometric check cancelled.');else if(u.error==='locked')bioShowError('Too many wrong attempts. Wait 30 seconds or use your password.');else if(u.error==='busy')bioShowError('Fingerprint prompt is already open.');else if(u.error==='unavailable')bioShowError('Fingerprint / screen lock is not set up on this phone. Use your password.');else bioShowError('Biometric login failed. Use your password.');return;}
const tab=Date.now().toString(36)+Math.random().toString(36).slice(2,12);try{localStorage.setItem('swTab',tab);}catch(e){}
const auth=await server('bio_native_login',{token:u.token,tab});
if(auth.status!=='success'){if(/not registered/i.test(auth.message||'')){try{window.TejodharBio.clear();}catch(e){}var nb=document.getElementById('bioLoginBtn');if(nb)nb.style.display='none';}bioShowError(auth.message||'Biometric login failed.');return;}
await refreshPortalDatabase();
await login({auth,username:auth.username,tab});
}catch(e){bioShowError('Biometric login failed. Use your password.');}
return;
}
let savedId='';try{savedId=localStorage.getItem('bioCredId')||'';}catch(e){}
if(!savedId){bioShowError('Fingerprint is not set up on this phone. Login with password and enable it first.');return;}
try{
const opt=await server('bio_login_options',{});
if(opt.status!=='success'){bioShowError(opt.message||'Could not start biometric login.');return;}
const cred=await navigator.credentials.get({publicKey:{challenge:bioB64uToBuf(opt.challenge),rpId:opt.rpId,allowCredentials:[{type:'public-key',id:bioB64uToBuf(savedId),transports:['internal']}],userVerification:'required',timeout:60000}});
const tab=Date.now().toString(36)+Math.random().toString(36).slice(2,12);try{localStorage.setItem('swTab',tab);}catch(e){}
const r=cred.response;
const auth=await server('bio_login_verify',{id:cred.id,clientDataJSON:bioBufToB64u(r.clientDataJSON),authenticatorData:bioBufToB64u(r.authenticatorData),signature:bioBufToB64u(r.signature),tab});
if(auth.status!=='success'){if(/not registered/i.test(auth.message||'')){try{localStorage.removeItem('bioCredId');}catch(e){}var bb=document.getElementById('bioLoginBtn');if(bb)bb.style.display='none';}bioShowError(auth.message||'Biometric login failed.');return;}
await refreshPortalDatabase();
await login({auth,username:auth.username,tab});
}catch(e){if(e&&e.name==='NotAllowedError')bioShowError('Biometric check cancelled.');else bioShowError('Biometric login failed. Use your password.');}
}
async function bioEnable(){
if(!bioSupported()){alert('Biometric login is not supported on this browser/phone.');return;}
if(bioNative()){
try{
try{localStorage.removeItem('bioOfferNo');}catch(e){}
const reg=await server('bio_native_register',{label:'Android app'});
if(reg.status!=='success'){alert(reg.message||'Setup failed.');return;}
const r=await bioNativeCall('register',reg.token);
if(!r.ok){alert(r.error==='cancelled'?'Biometric setup cancelled.':'Biometric setup failed on this phone.');}
else alert('Fingerprint login enabled on this phone. Next time it will unlock directly with your fingerprint.');
}catch(e){alert('Biometric setup failed on this phone.');}
bioRefreshMenu();return;
}
try{
const opt=await server('bio_reg_options',{});
if(opt.status!=='success'){alert(opt.message||'Could not start setup.');return;}
const cred=await navigator.credentials.create({publicKey:{challenge:bioB64uToBuf(opt.challenge),rp:{name:'Tejodhar',id:opt.rpId},user:{id:bioB64uToBuf(opt.userId),name:opt.userName,displayName:opt.userName},pubKeyCredParams:[{type:'public-key',alg:-7},{type:'public-key',alg:-257}],authenticatorSelection:{authenticatorAttachment:'platform',residentKey:'discouraged',requireResidentKey:false,userVerification:'required'},attestation:'none',timeout:60000}});
const r=cred.response;
const res=await server('bio_reg_verify',{clientDataJSON:bioBufToB64u(r.clientDataJSON),attestationObject:bioBufToB64u(r.attestationObject),label:(navigator.platform||'Phone')});
if(res.status==='success'){try{localStorage.setItem('bioCredId',cred.id);}catch(e){}}
alert(res.status==='success'?'Fingerprint login enabled on this phone. Next time it will unlock directly with your fingerprint.':(res.message||'Setup failed.'));
bioRefreshMenu();
}catch(e){if(e&&e.name==='NotAllowedError')alert('Biometric setup cancelled.');else alert('Biometric setup failed on this phone.');}
}
async function bioOfferEnable(username){
return; /* outer biometric unlock removed */
try{
if(!bioNative()||window.TejodharBio.hasToken())return;
if(localStorage.getItem('bioOfferNo')==='1')return;
if(confirm('Link fingerprint / face unlock to your account ('+username+') on this phone?\n\nNext time you can log in with your fingerprint instead of typing the password.')){await bioEnable();}
else{localStorage.setItem('bioOfferNo','1');}
}catch(e){}
}
async function bioDisable(){
if(!confirm('Remove biometric login from all your phones?'))return;
const res=await server('bio_remove',{});if(res.status==='success'){try{localStorage.removeItem('bioCredId');}catch(e){}try{if(window.TejodharBio)window.TejodharBio.clear();}catch(e){}}alert(res.status==='success'?'Biometric login removed.':(res.message||'Failed.'));bioRefreshMenu();
}
async function bioRefreshMenu(){
const slots=document.querySelectorAll('.bio-settings-slot');if(!slots.length)return;
let thisPhone=false;try{thisPhone=bioNative()?!!window.TejodharBio.hasToken():!!localStorage.getItem('bioCredId');}catch(e){}
let body='';
if(!bioSupported()){
if(window.TejodharBio){body='<p style="color:#b45309;font-size:13px;margin:0">This phone has no fingerprint / face / screen lock set up. Open the phone Settings &rarr; Security, set a screen lock or add a fingerprint, then reopen this page.</p>';}
else{body='<p style="color:#b45309;font-size:13px;margin:0">Biometric login is not available here. Open the site in Chrome on your phone over https:// and make sure a screen lock / fingerprint is set on the phone. (If you are using the Tejodhar app, install the latest app version.)</p>';}
}else{
const st=await server('bio_status',{});
if(st.status!=='success'){body='<p style="color:#64748b;font-size:13px;margin:0">Biometric settings are not available for this account right now.</p>';}
else{
const on=st.count>0;
body='<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px"><div><div style="font-size:12px;color:#64748b">Account</div><strong style="color:'+(on?'#059669':'#64748b')+'">'+(on?'Enabled':'Not enabled')+'</strong></div><div><div style="font-size:12px;color:#64748b">This phone</div><strong style="color:'+(thisPhone?'#059669':'#64748b')+'">'+(thisPhone?'Fingerprint ready':'Not set up')+'</strong></div></div>'
+'<p style="color:#64748b;font-size:12px;margin:0 0 12px">Unlock the portal directly with your fingerprint or face instead of typing the password. Your fingerprint never leaves the phone.</p>'
+'<div style="display:flex;gap:10px;flex-wrap:wrap">'
+'<button type="button" class="btn btn-primary" onclick="bioEnable()">'+(thisPhone?'Set up again on this phone':'Enable on this phone')+'</button>'
+(on?'<button type="button" class="btn btn-danger" onclick="bioDisable()">Turn off on all phones</button>':'')
+'</div>';
}}
slots.forEach(function(el){el.innerHTML='<div style="border:1px solid #c7d2fe;background:#f8faff;border-radius:16px;padding:14px"><strong style="display:block;margin-bottom:10px">&#128274; Biometric login</strong>'+body+'</div>';});
}
async function login(pre){
const username=pre?pre.username:document.getElementById('u').value.trim(),password=pre?'':document.getElementById('p').value;
const loginError=document.getElementById('loginError');
if(loginError){loginError.style.display='none';loginError.innerText='';}
const tab=pre?pre.tab:Date.now().toString(36)+Math.random().toString(36).slice(2,12);try{localStorage.setItem('swTab',tab);}catch(e){}
const auth=pre?pre.auth:await server('login',{username,password,tab});
if(auth.status!=='success'){
if(loginError){loginError.innerText=(auth.duplicate||auth.locked)?auth.message:'Wrong password';loginError.style.display='block';}
return;
}
try{window.__swBroadcastLogin&&window.__swBroadcastLogin(tab);}catch(e){}
setTimeout(bioRefreshMenu,900);
if(!pre)setTimeout(function(){bioOfferEnable(username);},1600);
const detectedRole=auth.role;
if(detectedRole==='admin'&&true){document.getElementById('loginView').classList.add('hidden');document.body.classList.remove('login-active');document.documentElement.classList.remove('login-active');document.getElementById('siteNav').classList.remove('hidden');document.getElementById('adminView').classList.remove('hidden');document.getElementById('logoutBtn').classList.remove('hidden');syncEmployees();syncContractors();renderContractorAssignments(null);showAdminTab('dashboard');renderRequests();renderLeaveApprovals();syncShiftLabels();renderDashboard();startAdminLiveCalendarRefresh();return}
if(detectedRole==='emp'){const employee=db.employees.find(e=>e.user===username);if(employee){sessionUser=employee;sessionRestricted=!!auth.restricted;sessionTerminationDate=auth.termination_date||employee.termination_date||employee.notice_period_end||'';sessionRestrictionReason=auth.restriction_reason||'';document.getElementById('loginView').classList.add('hidden');document.body.classList.remove('login-active');document.documentElement.classList.remove('login-active');document.getElementById('siteNav').classList.remove('hidden');document.getElementById('empView').classList.remove('hidden');document.getElementById('logoutBtn').classList.remove('hidden');document.getElementById('staffName').innerText='Portal: '+employee.name;renderEmployeeProfile(employee);syncContractorsStaff?.();applyEmployeeRestrictionUI();showStaffTab(sessionRestricted?'payslip':'today');renderSelfPunchUI();renderStaffCalendar();startEmployeeTodayAttendanceLiveRefresh();startEmployeePortalLiveRefresh();startUniversalLiveSync();return}}
if(detectedRole==='security'){const siteAccount=(db.security||[]).find(s=>s.user===username);if(siteAccount){sessionSite=siteAccount.site;document.getElementById('loginView').classList.add('hidden');document.body.classList.remove('login-active');document.documentElement.classList.remove('login-active');document.getElementById('siteNav').classList.remove('hidden');document.getElementById('securityView').classList.remove('hidden');document.getElementById('logoutBtn').classList.remove('hidden');document.getElementById('securitySiteLabel').innerText=siteAccount.site;updateScanModeUI();return}}
if(detectedRole==='contractor'){const contractor=db.contractors.find(c=>c.user&&c.user===username);if(contractor){sessionContractor=contractor;document.getElementById('loginView').classList.add('hidden');document.body.classList.remove('login-active');document.documentElement.classList.remove('login-active');document.getElementById('siteNav').classList.remove('hidden');document.getElementById('contractorPortalView').classList.remove('hidden');document.getElementById('logoutBtn').classList.remove('hidden');document.getElementById('cpContractorName').innerText=contractor.name+' ['+contractor.id+']';{const bn=document.getElementById('cpBillName');if(bn)bn.innerText=contractor.name+' ['+contractor.id+']';}const now=new Date();document.getElementById('cpAttM').value=now.getMonth();document.getElementById('cpAttY').value=now.getFullYear();renderContractorPortal();startContractorPortalLiveRefresh();return}}
if(loginError){loginError.innerText='Wrong password';loginError.style.display='block';}
}
function contractorAssignedEmployees(){
if(!sessionContractor)return[];
const latest=db.contractors.find(c=>String(c.id)===String(sessionContractor.id))||sessionContractor;
sessionContractor=latest;
const ids=new Set((latest.assigned_employee_ids||[]).map(String));
return db.employees.filter(e=>!e.terminated&&(ids.has(String(e.id)) || (Array.isArray(e.contractor_ids) && e.contractor_ids.map(String).includes(String(latest.id))) || String(e.contractor_id||'')===String(latest.id)));
}
async function refreshPortalDatabase(){
try{
const result=await server('refresh_portal_data',{});
if(result.status==='success'&&result.db){db=result.db;
if(sessionContractor){const latest=db.contractors.find(c=>String(c.id)===String(sessionContractor.id));if(latest)sessionContractor=latest;}
if(sessionUser){const latest=db.employees.find(e=>String(e.id)===String(sessionUser.id));if(latest)sessionUser=latest;}
return true;
}
}catch(e){}
return false;
}
/* =========================================================
UNIVERSAL LIVE SYNC
Keeps Admin, Employee, Contractor and Security data synced
in both directions without manual page refresh.
========================================================= */
let universalLiveSyncTimer = null;
let universalLiveSyncBusy = false;
async function universalLiveSync(){
if(universalLiveSyncBusy) return;
if(typeof noAutoRefreshTab==='function'&&noAutoRefreshTab()) return;
if(!sessionUser && !sessionContractor && !sessionSite) return;
universalLiveSyncBusy = true;
try{
const ok = await refreshPortalDatabase();
if(!ok) return;
const adminView=document.getElementById('adminView');
if(adminView && !adminView.classList.contains('hidden')){
const active=document.querySelector('#adminView .admin-tab.active');
const name=active ? (active.id||'').replace(/^tab-/,'') : '';
if(name==='dashboard'){
renderRequests?.(); renderLeaveApprovals?.(); renderDashboard?.();
}else if(name==='attendance'){
renderAdminCalendar?.();
}else if(name==='advance'){
renderAdvanceList?.();
}else if(name==='contractor'){
renderContractorList?.();
}else if(name==='contractorAtt'){
renderContractorCalendar?.();
}else if(name==='employee'){
syncEmployees?.();
}else if(name==='idcard'){
syncIdCardEmployees?.();
}else if(name==='projectAssign'){
syncEmployees?.();
filterProjectEmployees?.();
if(document.getElementById('paEmployeeSelector')?.value) loadProjectAssignment?.();
}else if(name==='cashbookReport'){
initAdminCashbookReport?.();
}else if(name==='holiday'){
renderHolidayList?.();
}
updateApprovalsBadge?.();
}
const empView=document.getElementById('empView');
if(empView && !empView.classList.contains('hidden') && sessionUser){
const latest=db.employees?.find(e=>String(e.id)===String(sessionUser.id));
if(latest) sessionUser=latest;
applyEmployeeRestrictionUI?.();
const active=document.querySelector('#empView .admin-tab.active');
const name=active ? (active.id||'').replace(/^stab-/,'') : '';
if(name==='today'){
renderSelfPunchUI?.(); renderStaffCalendar?.();
}else if(name==='applyAtt'){
renderMyRequests?.(); renderForgotPunchLimit?.();
}else if(name==='leave'){
renderMyLeaveRequests?.(); renderStaffLeaveApprovals?.();
}else if(name==='payslip'){
renderStaffPayslip?.();
}else if(name==='advances'){
renderStaffAdvances?.();
renderEmployeeAdvanceList?.();
}else if(name==='cashbook'){
renderStaffCashbook?.();
}else if(name==='contractor' || name==='contractorAtt'){
syncContractorsStaff?.();
}else if(name==='idcard'){
renderEmployeeProfile?.(sessionUser);
renderIdCard?.(sessionUser,false);
}
}
const cpView=document.getElementById('contractorPortalView');
if(cpView && !cpView.classList.contains('hidden') && sessionContractor){
const latest=(db.contractors||[]).find(c=>String(c.id)===String(sessionContractor.id));
if(latest) sessionContractor=latest;
/* contractor portal: no auto re-render (manual Refresh only) */
}
/* Security portal uses the shared database directly for punches.
No visual re-render is necessary while the scanner is active. */
} finally {
universalLiveSyncBusy=false;
}
}
function startUniversalLiveSync(){
if(universalLiveSyncTimer) clearInterval(universalLiveSyncTimer);
universalLiveSyncTimer=setInterval(universalLiveSync,3000);
document.addEventListener('visibilitychange',()=>{
if(!document.hidden) universalLiveSync();
});
window.addEventListener('focus',()=>universalLiveSync());
}
let employeeIdCardLiveTimer=null;
let employeeIdCardFingerprint='';
function employeeCardFingerprint(e){
if(!e)return '';
return JSON.stringify({id:e.id,name:e.name,des:e.des,project:e.project,doj:e.doj,photo:e.photo||'',company:db.company||{}});
}
function startEmployeeIdCardLiveRefresh(){
if(employeeIdCardLiveTimer) clearInterval(employeeIdCardLiveTimer);
employeeIdCardFingerprint=employeeCardFingerprint(sessionUser);
employeeIdCardLiveTimer=setInterval(async()=>{
if(!sessionUser){clearInterval(employeeIdCardLiveTimer);employeeIdCardLiveTimer=null;return;}
const oldFp=employeeIdCardFingerprint;
if(!await refreshPortalDatabase()) return;
const latest=db.employees.find(e=>String(e.id)===String(sessionUser.id));
if(!latest)return;
const newFp=employeeCardFingerprint(latest);
if(newFp!==oldFp){
sessionUser=latest;
employeeIdCardFingerprint=newFp;
const status=document.getElementById('idCardLiveStatus');
if(status){status.textContent='● Updated live';status.style.color='#16a34a';}
const tab=document.getElementById('stab-idcard');
if(tab && tab.classList.contains('active')) renderIdCard(sessionUser,false);
}
},3000);
}
async function syncContractorAssignedEmployees(){
const box=document.getElementById('cpEmpAttE');if(!box)return;
await refreshPortalDatabase();
const emps=contractorAssignedEmployees();
box.innerHTML=emps.length?emps.map(e=>`<option value="${escapeHTML(e.id)}">${escapeHTML(e.name||'')} [${escapeHTML(e.id||'')}] — ${escapeHTML(e.des||'Employee')}</option>`).join(''):'<option value="">No employees assigned</option>';
const detail=document.getElementById('cpEmpDetails');
if(detail){detail.innerHTML=emps.length?`<div class="grid">${emps.map(e=>`<div class="card" style="margin:0;padding:12px"><strong>${escapeHTML(e.name||'')}</strong><div style="font-size:12px;color:#64748b;margin-top:4px">ID: ${escapeHTML(e.id||'')}</div><div style="font-size:12px;color:#64748b">Designation: ${escapeHTML(e.des||'-')}</div><div style="font-size:12px;color:#64748b">Project: ${escapeHTML(e.project||'-')}</div></div>`).join('')}</div>`:'<div style="padding:12px;border:1px dashed var(--border);border-radius:12px;color:#64748b">No employees are assigned to this contractor.</div>';}
if(emps.length)renderContractorEmployeeAttendance();else{const cal=document.getElementById('cpEmpAttCalendar');if(cal)cal.innerHTML='';const n=document.getElementById('cpEmpAttNote');if(n)n.innerText='No employees assigned to this contractor yet. Ask Admin to assign an employee.';}
}
function renderContractorEmployeeAttendance(){
if(!sessionContractor)return;
const empId=document.getElementById('cpEmpAttE')?.value;if(!empId)return;
if(!contractorAssignedEmployees().some(e=>String(e.id)===String(empId)))return;
const month=Number(document.getElementById('cpAttM').value),year=Number(document.getElementById('cpAttY').value),key=`${empId}-${month}-${year}`,box=document.getElementById('cpEmpAttCalendar');box.innerHTML='';
const days=new Date(year,month+1,0).getDate();
for(let day=1;day<=days;day++){
const hol=holidayForDate(year,month,day);
const sunday=new Date(year,month,day).getDay()===0,status=hol?'HOL':(sunday?'SUN':(db.attendance[key]?.[day]||'A'));
const cell=document.createElement('div');cell.className=`day ${status}`;cell.innerHTML=`<span>${day}</span><small>${status}</small>`;
if(!sunday)cell.onclick=async()=>{if(isEmpAttendanceLocked(key)){alert('This employee is terminated. Attendance is permanently locked.');return}const current=db.attendance[key]?.[day]||'A',next=current==='P'?'H':current==='H'?'A':'P';const old=db.attendance[key]?.[day];if(!db.attendance[key])db.attendance[key]={};db.attendance[key][day]=next;renderContractorEmployeeAttendance();const result=await server('save_attendance',{key,day,status:next});if(result.status!=='success'){if(old===undefined)delete db.attendance[key][day];else db.attendance[key][day]=old;renderContractorEmployeeAttendance();alert(result.message)}};
calAppend(box,cell,year,month,day);
}
const n=document.getElementById('cpEmpAttNote');if(n)n.innerText='Tap a working day to cycle: Present (P) → Half Day (H) → Absent (A). Sundays are locked.';
}
async function logout(){if(window.employeeTodayAttendanceTimer){clearInterval(window.employeeTodayAttendanceTimer);window.employeeTodayAttendanceTimer=null;}if(window.employeePortalLiveTimer){clearInterval(window.employeePortalLiveTimer);window.employeePortalLiveTimer=null;}if(window.contractorPortalLiveTimer){clearInterval(window.contractorPortalLiveTimer);window.contractorPortalLiveTimer=null;}if(window.adminCalendarTimer){clearInterval(window.adminCalendarTimer);window.adminCalendarTimer=null;}try{await Promise.race([server('logout',{push_token:(window.__tjPushToken||'')}),new Promise(function(r){setTimeout(r,4000)})]);}catch(e){}try{sessionStorage.clear();sessionStorage.setItem('bioAutoTried','1');}catch(e){}location.reload();}
function formatINR(number){return Number(number||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}
function words(number){
number=Math.round(Number(number)||0);if(number===0)return'Zero Only.';const one=['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'],ten=['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];function two(n){return n<20?one[n]:ten[Math.floor(n/10)]+(n%10?' '+one[n%10]:'')}let result='',n=number;if(n>=10000000){result+=two(Math.floor(n/10000000))+' Crore ';n%=10000000}if(n>=100000){result+=two(Math.floor(n/100000))+' Lakh ';n%=100000}if(n>=1000){result+=two(Math.floor(n/1000))+' Thousand ';n%=1000}if(n>=100){result+=one[Math.floor(n/100)]+' Hundred ';n%=100}if(n>0)result+=(result?'And ':'')+two(n);return result.trim()+' Only.';
}
function getAttStatusForDay(empId,year,month,day){
let y=year,m=month,d=day;const dim=new Date(y,m+1,0).getDate();
if(d<1){m-=1;if(m<0){m=11;y-=1;}d=new Date(y,m+1,0).getDate()+d;}
else if(d>dim){d=d-dim;m+=1;if(m>11){m=0;y+=1;}}
const att=db.attendance[`${empId}-${m}-${y}`]||{};
return att[d]||'A';
}
function formatAddressOneLine(address){return escapeHTML(String(address||'').replace(/\s*\n\s*/g,' ').replace(/\s+/g,' ').trim()); } async function viewPayslipFresh(){try{await refreshPortalDatabase();}catch(e){}generatePayslip();}
function computeSalaryFor(e,month,year,cutoffDay=null){
const key=`${e.id}-${month}-${year}`,attendance=db.attendance[key]||{},monthDays=new Date(year,month+1,0).getDate(),totalDays=Math.max(1,Math.min(monthDays,Number(cutoffDay)||monthDays));
let payableDays=0,halfDays=0,lateCount=0,holidayBonusUnits=0,curStreak=0,maxAbsentStreak=0;
const shiftCfg=(db.shifts&&db.shifts[e.shift||'shift1'])||(db.shifts&&db.shifts.shift1)||{start:'08:00'};
const sp=(shiftCfg.start||'08:00').split(':'),shiftStartMins=Number(sp[0])*60+Number(sp[1]);
for(let d=1;d<=totalDays;d++){const date=new Date(year,month,d);const hol=holidayForDate(year,month,d);
if(hol){if(holidayPayableFor(e,year,month,d)){payableDays++;const st=attendance[d];if(hol.double_pay&&(st==='P'||st==='H'))holidayBonusUnits+=(st==='P'?1:.5);}curStreak=0;}
else if(date.getDay()===0){
const satStatus=getAttStatusForDay(e.id,year,month,d-1),monStatus=getAttStatusForDay(e.id,year,month,d+1);
if(!(satStatus==='A'&&monStatus==='A'))payableDays++;
curStreak=0;
}else{const status=attendance[d]||'A';
if(status==='P'){payableDays++;curStreak=0;
const dayPunches=((db.punches||{})[key]||{})[d]||[],ins=dayPunches.filter(p=>p.type==='IN');
if(ins.length){const m=(ins[0].time||'').match(/(\d+):(\d+)\s*(AM|PM)/i);if(m){const h=Number(m[1])%12+(m[3].toUpperCase()==='PM'?12:0),mins=h*60+Number(m[2]);if(mins>shiftStartMins+10)lateCount++;}}
}else if(status==='H'){payableDays+=.5;halfDays++;curStreak=0;}
else if(status==='CL'||status==='SL'||status==='OD'){payableDays++;curStreak=0;}
else{curStreak++;if(curStreak>maxAbsentStreak)maxAbsentStreak=curStreak;}
}}
const halfDayPairPenalty=Math.floor(halfDays/2)*1,latePenalty=Math.floor(lateCount/3)*.5;
payableDays=Math.max(0,payableDays-halfDayPairPenalty-latePenalty);
let prevMonth=month-1,prevYear=year;if(prevMonth<0){prevMonth=11;prevYear=year-1;}
const advStart=`${year}-${String(month+1).padStart(2,'0')}-01`,advEnd=`${year}-${String(month+1).padStart(2,'0')}-31`;
const monthlyAdvance=(db.salary_advances||[]).filter(a=>a.employee_id===e.id&&advMonthKey(a)===advStart.slice(0,7)).reduce((s,a)=>s+Number(a.amount||0),0);
const ratio=payableDays/totalDays,basic=Math.round((e.basic_rate||0)*ratio),hra=Math.round((e.hra_rate||0)*ratio),lta=Math.round((e.lta_rate||0)*ratio),special=Math.round((e.special_rate||0)*ratio),mobile=Math.round((e.mobile_rate||0)*ratio),masterTotal=(e.basic_rate||0)+(e.hra_rate||0)+(e.lta_rate||0)+(e.special_rate||0)+(e.mobile_rate||0),holidayBonus=Math.round((totalDays?masterTotal/totalDays:0)*holidayBonusUnits),earnedTotal=basic+hra+lta+special+mobile+holidayBonus,pf=e.pf_ded||0,pt=e.pt_ded||0,employerPF=e.emp_pf_ded||0,deductions=pf+pt+employerPF+monthlyAdvance,netPay=earnedTotal-deductions;
return {payableDays,totalDays,earnedTotal,deductions,monthlyAdvance,netPay,pf,pt,employerPF};
}
function renderSalaryCalculation(){
 const dateEl=document.getElementById('salaryCalcDate');if(!dateEl)return;
 const raw=dateEl.value||'2026-10-24',parts=raw.split('-').map(Number);if(parts.length!==3||!parts[0]||!parts[1]||!parts[2])return;
 const year=parts[0],month=parts[1]-1,day=parts[2],today=new Date();
 const cutoff=(year===today.getFullYear()&&month===today.getMonth())?Math.min(day,today.getDate()):day;
 const empSel=document.getElementById('salaryCalcEmployee'),active=(db.employees||[]).filter(e=>!e.terminated);
 if(empSel){const old=empSel.value;empSel.innerHTML='<option value="all">All Active Employees</option>'+active.map(e=>`<option value="${escapeHTML(e.id)}">${escapeHTML(e.name)} (${escapeHTML(e.id)})</option>`).join('');if([...empSel.options].some(o=>o.value===old))empSel.value=old;}
 const selected=empSel&&empSel.value!=='all'?active.filter(e=>String(e.id)===empSel.value):active;
 const rows=selected.map(e=>{const r=computeSalaryFor(e,month,year,cutoff);const key=`${e.id}-${month}-${year}`,paid=(!Array.isArray(db.salary_paid)&&db.salary_paid||{})[key];return {e,r,paid};});
 const sum=key=>rows.reduce((a,x)=>a+Number(x.r[key]||0),0),fmt=n=>'₹ '+formatINR(Math.round(n));
 const cards=[['Employees',rows.length],['Gross Earned',fmt(sum('earnedTotal'))],['Deductions',fmt(sum('deductions'))],['Net Payable',fmt(sum('netPay'))]];
 document.getElementById('salaryCalcSummary').innerHTML=cards.map((c,i)=>`<div style="padding:16px;border:1px solid #e2e8f0;border-radius:14px;background:${i===3?'#ecfdf5':'#f8fafc'}"><div style="font-size:11px;color:#64748b;font-weight:800;text-transform:uppercase">${c[0]}</div><div style="font-size:20px;font-weight:900;color:${i===3?'#047857':'#0f172a'};margin-top:5px">${c[1]}</div></div>`).join('');
 const body=rows.map(({e,r,paid})=>`<tr><td>${escapeHTML(e.id)}</td><td>${escapeHTML(e.name)}</td><td>${r.payableDays}</td><td>${fmt(r.earnedTotal)}</td><td>${fmt(r.pf+r.pt+r.employerPF)}</td><td>${fmt(r.monthlyAdvance)}</td><td><strong>${fmt(r.netPay)}</strong></td><td>${paid?'<span style="color:#047857;font-weight:800">PAID</span>':'<span style="color:#b45309;font-weight:800">Pending</span>'}</td></tr>`).join('');
 document.getElementById('salaryCalcTable').innerHTML=`<table id="salaryCalcDataTable" style="width:100%;border-collapse:collapse;min-width:760px;font-size:13px"><thead><tr style="background:#0f2f55;color:#fff"><th style="padding:11px;text-align:left">Employee ID</th><th style="padding:11px;text-align:left">Employee Name</th><th style="padding:11px;text-align:right">Payable Days</th><th style="padding:11px;text-align:right">Gross Earned</th><th style="padding:11px;text-align:right">PF/PT & Employer PF</th><th style="padding:11px;text-align:right">Advance</th><th style="padding:11px;text-align:right">Net Payable</th><th style="padding:11px;text-align:left">Status</th></tr></thead><tbody>${body||'<tr><td colspan="8" style="padding:18px;text-align:center">No active employees found.</td></tr>'}</tbody><tfoot><tr style="background:#f1f5f9;font-weight:900"><td colspan="3" style="padding:11px">TOTAL</td><td style="padding:11px;text-align:right">${fmt(sum('earnedTotal'))}</td><td style="padding:11px;text-align:right">${fmt(rows.reduce((a,x)=>a+x.r.pf+x.r.pt+x.r.employerPF,0))}</td><td style="padding:11px;text-align:right">${fmt(sum('monthlyAdvance'))}</td><td style="padding:11px;text-align:right">${fmt(sum('netPay'))}</td><td></td></tr></tfoot></table>`;
}
function printSalaryCalculation(){const table=document.getElementById('salaryCalcTable');if(!table)return;const title='Tejodhar Constructions — Employee Salary Calculation';const w=window.open('','_blank');if(!w){alert('Allow pop-ups to print or save as PDF.');return;}w.document.write('<!doctype html><html><head><title>'+title+'</title><style>body{font-family:Arial,sans-serif;padding:20px;color:#111827}h2{margin-bottom:4px}p{color:#475569;font-size:12px}table{width:100%;border-collapse:collapse;font-size:10px}th,td{border:1px solid #cbd5e1;padding:7px;text-align:left}th{background:#0f2f55;color:white}td:nth-child(n+3){text-align:right}@media print{body{padding:0}}</style></head><body><h2>'+title+'</h2><p>Calculated up to '+document.getElementById('salaryCalcDate').value+'</p>'+document.getElementById('salaryCalcSummary').outerHTML+table.innerHTML+'</body></html>');w.document.close();w.focus();w.print();}
function exportSalaryCalculationCSV(){const table=document.getElementById('salaryCalcDataTable');if(!table)return;const csv=[...table.querySelectorAll('tr')].map(tr=>[...tr.querySelectorAll('th,td')].map(td=>'"'+td.innerText.replace(/"/g,'""').replace(/\s+/g,' ').trim()+'"').join(',')).join('\r\n');const blob=new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8;'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Tejodhar_Salary_Calculation_'+(document.getElementById('salaryCalcDate').value||'report')+'.csv';a.click();URL.revokeObjectURL(url);}
function generatePayslip(){
const e=sessionUser;if(!e)return;{const _n=new Date(),_m=Number(document.getElementById('psM').value),_y=Number(document.getElementById('psY').value);if(_y*12+_m>=_n.getFullYear()*12+_n.getMonth()){alert('Payslip for the current month cannot be generated. It will be available after the month ends.');return;}}const month=Number(document.getElementById('psM').value),year=Number(document.getElementById('psY').value),key=`${e.id}-${month}-${year}`,attendance=db.attendance[key]||{},totalDays=new Date(year,month+1,0).getDate();
let payableDays=0,halfDays=0,lateCount=0,holidayBonusUnits=0,curStreak=0,maxAbsentStreak=0;
const shiftCfg=(db.shifts&&db.shifts[e.shift||'shift1'])||(db.shifts&&db.shifts.shift1)||{start:'08:00'};
const sp=(shiftCfg.start||'08:00').split(':'),shiftStartMins=Number(sp[0])*60+Number(sp[1]);
for(let d=1;d<=totalDays;d++){const date=new Date(year,month,d);const hol=holidayForDate(year,month,d);
if(hol){if(holidayPayableFor(e,year,month,d)){payableDays++;const st=attendance[d];if(hol.double_pay&&(st==='P'||st==='H'))holidayBonusUnits+=(st==='P'?1:.5);}curStreak=0;}
else if(date.getDay()===0){
const satStatus=getAttStatusForDay(e.id,year,month,d-1),monStatus=getAttStatusForDay(e.id,year,month,d+1);
if(!(satStatus==='A'&&monStatus==='A'))payableDays++;
curStreak=0;
}else{const status=attendance[d]||'A';
if(status==='P'){payableDays++;curStreak=0;
const dayPunches=((db.punches||{})[key]||{})[d]||[],ins=dayPunches.filter(p=>p.type==='IN');
if(ins.length){const m=(ins[0].time||'').match(/(\d+):(\d+)\s*(AM|PM)/i);if(m){const h=Number(m[1])%12+(m[3].toUpperCase()==='PM'?12:0),mins=h*60+Number(m[2]);if(mins>shiftStartMins+10)lateCount++;}}
}else if(status==='H'){payableDays+=.5;halfDays++;curStreak=0;}
else if(status==='CL'||status==='SL'||status==='OD'){payableDays++;curStreak=0;}
else{curStreak++;if(curStreak>maxAbsentStreak)maxAbsentStreak=curStreak;}
}}
const halfDayPairPenalty=Math.floor(halfDays/2)*1,latePenalty=Math.floor(lateCount/3)*.5;
payableDays=Math.max(0,payableDays-halfDayPairPenalty-latePenalty);
let prevMonth=month-1,prevYear=year;if(prevMonth<0){prevMonth=11;prevYear=year-1;}
const advStart=`${year}-${String(month+1).padStart(2,'0')}-01`,advEnd=`${year}-${String(month+1).padStart(2,'0')}-31`;
const monthlyAdvance=(db.salary_advances||[]).filter(a=>a.employee_id===e.id&&advMonthKey(a)===advStart.slice(0,7)).reduce((s,a)=>s+Number(a.amount||0),0);
const ratio=payableDays/totalDays,basic=Math.round((e.basic_rate||0)*ratio),hra=Math.round((e.hra_rate||0)*ratio),lta=Math.round((e.lta_rate||0)*ratio),special=Math.round((e.special_rate||0)*ratio),mobile=Math.round((e.mobile_rate||0)*ratio),masterTotal=(e.basic_rate||0)+(e.hra_rate||0)+(e.lta_rate||0)+(e.special_rate||0)+(e.mobile_rate||0),holidayBonus=Math.round((totalDays?masterTotal/totalDays:0)*holidayBonusUnits),earnedTotal=basic+hra+lta+special+mobile+holidayBonus,pf=e.pf_ded||0,pt=e.pt_ded||0,employerPF=e.emp_pf_ded||0,deductions=pf+pt+employerPF+monthlyAdvance,netPay=earnedTotal-deductions;
const warnings=[];
if(maxAbsentStreak>3)warnings.push(`⚠ ${maxAbsentStreak} consecutive days absent recorded this month.`);
if(halfDayPairPenalty>0)warnings.push(`ℹ ${halfDays} half-day(s) recorded — every 2 half-days count as 1 absent, so ${halfDayPairPenalty} day(s) were deducted.`);
if(latePenalty>0)warnings.push(`ℹ ${lateCount} late arrival(s) recorded — every 3 lates deduct half a day, so ${latePenalty} day(s) were deducted.`);
const warningHTML=warnings.length?`<div style="margin-top:10px;padding:10px 14px;background:#fffbeb;border:1px solid #fde68a;border-radius:10px;font-size:11px;color:#92400e">${warnings.map(w=>escapeHTML(w)).join('<br>')}</div>`:'';
const logo=db.company.logo?`<img class="pay-logo" style="width:${Number(db.company.size||80)}px;height:auto" src="${db.company.logo}">`:'';const seal=db.company.seal?`<img src="${db.company.seal}">`:'';const paidRec=(!Array.isArray(db.salary_paid)&&db.salary_paid||{})[key];
document.getElementById('payslipTarget').innerHTML=`<div class="payslip">
<div class="pay-header">
<div class="company-brand">
<div class="brand-logo">${logo}</div>
<div class="company-text">
<div class="company-address">${formatAddressOneLine(db.company.addr||'')}</div>
</div>
</div>
</div>
<div class="pay-title"><span>PAY SLIP — ${months[month]} ${year}</span></div>
<div class="summary"><div class="summary-box"><div class="summary-label">Employee No</div><div class="summary-value">${escapeHTML(e.id)}</div></div><div class="summary-box"><div class="summary-label">Employee Name</div><div class="summary-value">${escapeHTML(e.name)}</div></div><div class="summary-box"><div class="summary-label">Payable Days</div><div class="summary-value">${payableDays}</div></div><div class="summary-box"><div class="summary-label">Half Days (Paid @ 50%)</div><div class="summary-value">${halfDays}</div></div><div class="summary-box"><div class="summary-label">Grade</div><div class="summary-value">${escapeHTML(e.grade||'')}</div></div></div>
<table class="details"><tr><td class="label">Designation</td><td class="value">${escapeHTML(e.des||'')}</td><td class="label">Project / Office</td><td class="value">${escapeHTML(e.project||'')}</td></tr><tr><td class="label">Date of Joining</td><td class="value">${escapeHTML(e.doj||'')}</td><td class="label">Bank</td><td class="value">${escapeHTML(e.bank||'')}</td></tr><tr><td class="label">Bank Account</td><td class="value">${escapeHTML(e.acc||'')}</td><td class="label">PAN</td><td class="value">${escapeHTML(e.pan||'')}</td></tr><tr><td class="label">UAN</td><td class="value">${escapeHTML(e.uan||'')}</td><td class="label">PF No</td><td class="value">${escapeHTML(e.pf_no||'')}</td></tr><tr><td class="label">ESI No</td><td class="value">${escapeHTML(e.esi_no||'')}</td><td class="label">CTC</td><td class="value">₹ ${formatINR(e.ctc)}</td></tr></table>
<table class="salary"><thead><tr><th>Earnings</th><th>Master Rate</th><th>Current Month</th><th>Deductions</th><th>Current Month</th></tr></thead><tbody>
<tr><td>Basic</td><td class="amount">₹ ${formatINR(e.basic_rate)}</td><td class="amount">₹ ${formatINR(basic)}</td><td>Provident Fund</td><td class="amount">₹ ${formatINR(pf)}</td></tr>
<tr><td>HRA</td><td class="amount">₹ ${formatINR(e.hra_rate)}</td><td class="amount">₹ ${formatINR(hra)}</td><td>Professional Tax</td><td class="amount">₹ ${formatINR(pt)}</td></tr>
<tr><td>LTA</td><td class="amount">₹ ${formatINR(e.lta_rate)}</td><td class="amount">₹ ${formatINR(lta)}</td><td>Employer PF</td><td class="amount">₹ ${formatINR(employerPF)}</td></tr>
<tr><td>Special Allowance</td><td class="amount">₹ ${formatINR(e.special_rate)}</td><td class="amount">₹ ${formatINR(special)}</td><td>Salary Advance</td><td class="amount">₹ ${formatINR(monthlyAdvance)}</td></tr>
<tr><td>Mobile Allowance</td><td class="amount">₹ ${formatINR(e.mobile_rate)}</td><td class="amount">₹ ${formatINR(mobile)}</td><td></td><td></td></tr>
${holidayBonus>0?`<tr><td>Holiday Bonus</td><td class="amount">—</td><td class="amount">₹ ${formatINR(holidayBonus)}</td><td></td><td></td></tr>`:''}
<tr class="total"><td>TOTAL</td><td class="amount">₹ ${formatINR(masterTotal)}</td><td class="amount">₹ ${formatINR(earnedTotal)}</td><td>TOTAL DEDUCTIONS</td><td class="amount">₹ ${formatINR(deductions)}</td></tr>
</tbody></table>
${warningHTML}
<div class="net"><div><div class="net-label">Net Pay</div><div class="net-value">₹ ${formatINR(netPay)}</div><div class="words">Rupees ${words(netPay)}</div></div><div style="text-align:right;font-size:9px;color:#64748b">Payable Days <strong>${payableDays}</strong> / ${totalDays}</div></div>
<div class="pay-footer-wrap" style="position:relative;display:flow-root;${paidRec?'min-height:92px;':''}">${paidRec?`<img class="paid-stamp" src="https://res.cloudinary.com/wpizqa3u/image/upload/q_auto/app_icons/paid_stamp.png" onerror="this.onerror=null;this.src='assets/paid_stamp.png?v=1'" alt="PAID" style="position:absolute;left:0;bottom:-8px;width:150px;height:auto;pointer-events:none;opacity:.92">`:''}<div class="pay-footer"><div class="seal">${seal}</div><div class="signature"><div class="signature-line"></div><strong>Authorized Signatory</strong><small>For ${escapeHTML(db.company.name||'')}</small></div></div></div>
<div class="note">This is a system-generated pay slip issued with company authorization. Physical signature is not required when electronically authorized.</div>
<div class="no-print" style="display:flex;gap:10px;margin-top:25px;flex-wrap:wrap">
<button class="btn btn-primary payslip-download-btn" style="flex:1;min-width:180px" onclick="downloadPayslipPDF()">⬇ Download Payslip PDF</button>
<button class="btn btn-primary payslip-print-btn" style="flex:1;min-width:180px" onclick="printPayslipA4()">🖨 Print Payslip — A4</button>
</div>
</div>`;
document.getElementById('fullPageDisplay').classList.remove('hidden');window.scrollTo(0,document.body.scrollHeight);
}
function printPayslipA4(){
const area=document.querySelector('#payslipTarget .payslip');
if(!area){alert('Please generate the payslip first.');return}
const printWin=window.open('', '_blank', 'width=900,height=1200');
if(!printWin){alert('Please allow pop-ups to print the payslip.');return}
const clone=area.cloneNode(true);
clone.querySelectorAll('.no-print').forEach(el=>el.remove());
const styles=Array.from(document.querySelectorAll('style')).map(s=>s.outerHTML).join('\n');
const links=Array.from(document.querySelectorAll('link[rel="stylesheet"]')).map(l=>l.outerHTML).join('\n');
printWin.document.open();
printWin.document.write(`<!doctype html><html><head><meta charset="utf-8">${links}${styles}<style>@page{size:A4 portrait;margin:0}html,body{margin:0!important;padding:0!important;background:#fff!important;width:210mm;min-height:297mm}.print-sheet{position:relative;width:210mm;min-height:297mm;box-sizing:border-box;padding:10mm 10mm 16mm;page-break-after:always;break-after:page;overflow:visible}.print-sheet:last-child{page-break-after:auto;break-after:auto}.payslip{box-sizing:border-box;width:190mm!important;max-width:190mm!important;min-height:0!important;height:auto!important;margin:0 auto!important;padding:10mm!important;background:#fff!important;box-shadow:none!important;border:0!important;border-radius:0!important;overflow:visible!important}.payslip *{box-sizing:border-box}@media print{.no-print{display:none!important}.payslip table,.payslip tr,.payslip td,.payslip th,.payslip .summary,.payslip .net,.payslip .pay-footer,.payslip .note{break-inside:avoid;page-break-inside:avoid}.payslip thead{display:table-header-group}.payslip tr{break-inside:avoid;page-break-inside:avoid}}.page-number{display:none!important}</style>
<style>html, body{width: 100%;min-width: 100%;height: 100%;min-height: 100%;margin: 0 !important;padding: 0 !important;overflow: hidden;}body{min-height: 100dvh;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-container, .auth-wrapper{box-sizing: border-box;min-height: 100dvh;}@media (max-width: 600px){html, body{height: 100dvh !important;min-height: 100dvh !important;width: 100vw !important;min-width: 100vw !important;overflow: hidden !important;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-container, .auth-wrapper{width: 100vw !important;max-width: none !important;min-height: 100dvh !important;height: 100dvh !important;margin: 0 !important;border-radius: 0 !important;box-sizing: border-box !important;}.login-card, .login-box, .login-form, .auth-card{width: min(92vw, 430px) !important;max-width: 92vw !important;box-sizing: border-box !important;margin-left: auto !important;margin-right: auto !important;}}</style>
<style>html,body,.login-page,.login-container,.login-portal,.portal{background-image:none!important;}</style><style>html, body{width:100% !important;height:100% !important;min-width:100% !important;min-height:100% !important;margin:0 !important;padding:0 !important;overflow:hidden !important;background:none !important;background-image:none !important;}body > *{box-sizing:border-box;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{width:100vw !important;height:100dvh !important;min-height:100dvh !important;max-width:none !important;margin:0 !important;padding:0 !important;background:none !important;background-image:none !important;border-radius:0 !important;box-sizing:border-box !important;position:relative !important;inset:auto !important;}@media (max-width:600px){.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{width:100vw !important;height:100dvh !important;min-height:100dvh !important;}.login-card, .login-box, .login-form, .auth-card{width:92vw !important;max-width:430px !important;margin-left:auto !important;margin-right:auto !important;box-sizing:border-box !important;}}</style><style>html{width:100%;min-height:100%;overflow-x:hidden !important;overflow-y:auto !important;}body{width:100%;min-height:100dvh;height:auto !important;margin:0 !important;overflow-x:hidden !important;overflow-y:auto !important;-webkit-overflow-scrolling:touch;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{width:100vw !important;min-height:100dvh !important;height:auto !important;overflow-x:hidden !important;overflow-y:visible !important;box-sizing:border-box !important;}@media (max-width:600px){html, body{overflow-x:hidden !important;overflow-y:auto !important;-webkit-overflow-scrolling:touch !important;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{min-height:100dvh !important;height:auto !important;overflow:visible !important;}.login-card, .login-box, .login-form, .auth-card{max-height:none !important;overflow:visible !important;}}</style><style>html, body{scroll-behavior: auto !important;overscroll-behavior-y: auto !important;-webkit-overflow-scrolling: touch !important;}body{touch-action: pan-y !important;}.login-page, .login-container, .login-portal, .portal, .login-wrapper, .auth-wrapper, .auth-container{scroll-behavior: auto !important;overscroll-behavior-y: auto !important;-webkit-overflow-scrolling: touch !important;touch-action: pan-y !important;}@media (max-width:600px){html, body{scroll-behavior: auto !important;overflow-x: hidden !important;overflow-y: auto !important;-webkit-overflow-scrolling: touch !important;touch-action: pan-y !important;}*{scroll-behavior: auto !important;}}#loginView.login-wrap .login-card::before, #loginView.login-wrap .login-card::after, #loginView.login-wrap .login-panel::before, #loginView.login-wrap .login-panel::after, #loginView.login-wrap .login-wrap::before, #loginView.login-wrap .login-wrap::after{content:none !important;display:none !important;background:none !important;background-image:none !important;box-shadow:none !important;border:0 !important;}#loginView.login-wrap .login-panel{background:#fff !important;background-image:none !important;}#loginView.login-wrap .login-card{background:#fff !important;background-image:none !important;}#loginView.login-wrap .login-visual, #loginView.login-wrap .login-visual-overlay, #loginView.login-wrap .login-city-art, #loginView.login-wrap .login-curve{display:none !important;}html.login-active, body.login-active{background:#0b1f3a !important;background-image:url("assets/login_background.jpg") !important;background-repeat:no-repeat !important;background-size:cover !important;background-position:center center !important;background-attachment:fixed !important;}#loginView.login-wrap, #loginView.login-wrap.force-mobile-login{position:relative !important;width:100vw !important;min-width:100vw !important;min-height:100dvh !important;height:100dvh !important;margin:0 !important;padding:0 !important;box-sizing:border-box !important;display:flex !important;align-items:center !important;justify-content:flex-end !important;overflow:hidden !important;background-color:#0b1f3a !important;background-image:url("assets/login_background.jpg") !important;background-repeat:no-repeat !important;background-size:cover !important;background-position:center center !important;background-attachment:fixed !important;}#loginView.login-wrap::before, #loginView.login-wrap::after, #loginView.login-wrap .login-panel::before, #loginView.login-wrap .login-panel::after, #loginView.login-wrap .login-card::before, #loginView.login-wrap .login-card::after{content:none !important;display:none !important;background:none !important;background-image:none !important;box-shadow:none !important;}#loginView.login-wrap .login-visual, #loginView.login-wrap .login-visual-overlay, #loginView.login-wrap .login-city-art, #loginView.login-wrap .login-curve{display:none !important;}#loginView.login-wrap .login-card{position:relative !important;z-index:20 !important;width:min(520px,42vw) !important;max-width:520px !important;min-height:0 !important;height:auto !important;margin:0 5vw 0 0 !important;padding:0 !important;border-radius:26px !important;overflow:hidden !important;background:#fff !important;background-image:none !important;box-shadow:0 24px 70px rgba(0,0,0,.28) !important;}#loginView.login-wrap .login-panel{width:100% !important;min-height:0 !important;height:auto !important;box-sizing:border-box !important;padding:42px 52px 34px !important;background:#fff !important;background-image:none !important;overflow:hidden !important;justify-content:center !important;}#loginView.login-wrap .login-logo-row{margin:0 0 20px !important;padding:0 !important;justify-content:center !important;text-align:center !important;}#loginView.login-wrap .login-portal-logo{width:auto !important;max-width:260px !important;max-height:78px !important;margin:0 auto !important;object-position:center !important;}#loginView.login-wrap .login-heading, #loginView.login-wrap .login-subheading{text-align:left !important;}#loginView.login-wrap .login-heading{margin:0 0 7px !important;}#loginView.login-wrap .login-subheading{margin:0 0 22px !important;}#loginView.login-wrap .login-card .form-group{margin-bottom:14px !important;}#loginView.login-wrap .login-forgot-link{margin:-1px 2px 18px !important;}#loginView.login-wrap .login-footer{margin-top:22px !important;}@media (max-width:800px){html.login-active, body.login-active{background-attachment:scroll !important;background-position:72% center !important;}#loginView.login-wrap, #loginView.login-wrap.force-mobile-login{min-height:100dvh !important;height:100dvh !important;align-items:center !important;justify-content:center !important;background-position:72% center !important;background-size:cover !important;overflow-y:auto !important;}#loginView.login-wrap .login-card{width:min(520px,calc(100vw - 32px)) !important;max-width:520px !important;margin:0 auto !important;border-radius:24px !important;background:#fff !important;box-shadow:0 18px 55px rgba(0,0,0,.25) !important;}#loginView.login-wrap .login-panel{min-height:0 !important;height:auto !important;padding:30px 24px 28px !important;}#loginView.login-wrap .login-logo-row{margin-bottom:16px !important;}#loginView.login-wrap .login-portal-logo{max-width:210px !important;max-height:65px !important;}#loginView.login-wrap .login-heading{margin:0 0 5px !important;font-size:27px !important;}#loginView.login-wrap .login-subheading{margin:0 0 20px !important;}}@media (max-width:380px){#loginView.login-wrap .login-card{width:calc(100vw - 24px) !important;}#loginView.login-wrap .login-panel{padding:24px 20px 24px !important;}}</style></head><body><div class="print-sheet">${clone.outerHTML}</div><script>
(function(){
function fit(){
var sheet=document.querySelector('.print-sheet'), pay=document.querySelector('.payslip');
if(!sheet||!pay)return;
var available=sheet.clientHeight-26*3.779527559;
if(pay.scrollHeight>available){
pay.style.fontSize='9px';
pay.style.lineHeight='1.2';
}
setTimeout(function(){
window.focus();
var closed=false;
function closePrintWindow(){
if(closed)return;
closed=true;
try{window.close();}catch(e){}
}
window.onafterprint=closePrintWindow;
window.print();
setTimeout(closePrintWindow,1500);
},300);
}
if(document.fonts&&document.fonts.ready){
document.fonts.ready.then(function(){requestAnimationFrame(function(){requestAnimationFrame(fit);});});
}else{window.onload=fit;}
})();
<\/script></body></html>`);
printWin.document.close();
}
async function downloadPayslipPDF(){
const area=document.querySelector('#payslipTarget .payslip');
if(!area){alert('Please generate the payslip first.');return}
if(typeof html2canvas==='undefined' || !window.jspdf){alert('PDF download library failed to load. Please try again.');return}
const btn=area.querySelector('.payslip-download-btn');
if(btn){btn.disabled=true;btn.textContent='Generating PDF…';}
let clone=null;
try{
clone=area.cloneNode(true);
const cloneControls=clone.querySelector('.no-print');
if(cloneControls) cloneControls.remove();
clone.style.cssText += ';position:fixed;left:-10000px;top:0;width:210mm;min-height:0;height:auto;margin:0;padding:10mm;box-sizing:border-box;background:#fff;box-shadow:none;border:0;border-radius:0;overflow:visible;transform:none;';
clone.querySelectorAll('*').forEach(el=>{el.style.breakInside='avoid';el.style.pageBreakInside='avoid';});
document.body.appendChild(clone);
await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
const canvas=await html2canvas(clone,{
scale:2,
useCORS:true,
backgroundColor:'#ffffff',
logging:false,
width:clone.scrollWidth,
height:clone.scrollHeight,
windowWidth:clone.scrollWidth,
windowHeight:clone.scrollHeight
});
const {jsPDF}=window.jspdf;
const pdf=new jsPDF({orientation:'portrait',unit:'mm',format:'a4',compress:true});
const pageW=210,pageH=297,margin=0;
const ratio=Math.min((pageW-2*margin)/canvas.width,(pageH-2*margin)/canvas.height);
const imgW=canvas.width*ratio,imgH=canvas.height*ratio;
const x=(pageW-imgW)/2,y=(pageH-imgH)/2;
pdf.addImage(canvas.toDataURL('image/jpeg',0.95),'JPEG',x,y,imgW,imgH,undefined,'FAST');
const employee=(typeof sessionUser==='object' && sessionUser)?(sessionUser.name||sessionUser.id||'Employee'):'Payslip';
const title=area.querySelector('.pay-title span')?.textContent||'';
const monthLabel=title.replace(/^PAY SLIP\s*[—-]\s*/i,'').trim().replace(/\s+/g,'-');
const safe=String(employee+'_'+monthLabel+'_Payslip').replace(/[^a-z0-9_-]+/gi,'_');
pdf.save(safe+'.pdf');
}catch(err){console.error(err);alert('Unable to download the payslip PDF. Please try again.');}
finally{
if(clone && clone.parentNode) clone.parentNode.removeChild(clone);
if(btn){btn.disabled=false;btn.textContent='⬇ Download Payslip PDF';}
}
}
function escapeHTML(value){return String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;')}
function escapeJS(value){return String(value??'').replace(/\\/g,'\\\\').replace(/'/g,"\\'")}
function setupPasswordToggles(){
document.querySelectorAll('input[type=\"password\"]').forEach(function(input){
if(input.dataset.passwordToggleReady==='1')return;
input.dataset.passwordToggleReady='1';
const wrap=document.createElement('div');wrap.className='password-wrap';
input.parentNode.insertBefore(wrap,input);wrap.appendChild(input);
const btn=document.createElement('button');btn.type='button';btn.className='password-toggle';btn.setAttribute('aria-label','Show password');btn.title='Show password';btn.innerHTML='👁';
btn.addEventListener('click',function(){
const showing=input.type==='text';input.type=showing?'password':'text';
btn.innerHTML=showing?'👁':'🙈';btn.setAttribute('aria-label',showing?'Show password':'Hide password');btn.title=showing?'Show password':'Hide password';
});
wrap.appendChild(btn);
});
}
window.onload=function(){
setupPasswordToggles();
const now=new Date();document.getElementById('attM').innerHTML=months.map((n,i)=>`<option value="${i}">${n}</option>`).join('');document.getElementById('vM').innerHTML=months.map((n,i)=>`<option value="${i}">${n}</option>`).join('');
document.getElementById('advM').innerHTML=months.map((n,i)=>`<option value="${i}">${n}</option>`).join('');
document.getElementById('stAdvM').innerHTML=months.map((n,i)=>`<option value="${i}">${n}</option>`).join('');
document.getElementById('ctAttM').innerHTML=months.map((n,i)=>`<option value="${i}">${n}</option>`).join('');
document.getElementById('sCtAttM').innerHTML=months.map((n,i)=>`<option value="${i}">${n}</option>`).join('');
document.getElementById('cpAttM').innerHTML=months.map((n,i)=>`<option value="${i}">${n}</option>`).join('');
document.getElementById('psM').innerHTML=months.map((n,i)=>`<option value="${i}">${n}</option>`).join('');
const reqDateEl=document.getElementById('reqDate');if(reqDateEl)reqDateEl.max=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0')+'-'+String(now.getDate()).padStart(2,'0');
document.getElementById('attM').value=now.getMonth();document.getElementById('vM').value=now.getMonth();document.getElementById('ctAttM').value=9;document.getElementById('sCtAttM').value=9;document.getElementById('cpAttM').value=now.getMonth();document.getElementById('psM').value=(now.getMonth()+11)%12;document.getElementById('advM').value=now.getMonth();document.getElementById('attY').value=now.getFullYear();document.getElementById('vY').value=now.getFullYear();document.getElementById('ctAttY').value=2026;document.getElementById('sCtAttY').value=2026;document.getElementById('cpAttY').value=now.getFullYear();document.getElementById('psY').value=now.getMonth()===0?now.getFullYear()-1:now.getFullYear();document.getElementById('advY').value=now.getFullYear();document.getElementById('stAdvM').value=now.getMonth();document.getElementById('stAdvY').value=now.getFullYear();updateBranding();
};
</script>

<script>(function(){
const ICONS={
dashboard:'<path fill="currentColor" d="M3 11.5 12 3l9 8.5v8.8a1.7 1.7 0 0 1-1.7 1.7H4.7A1.7 1.7 0 0 1 3 20.3z"/><path fill="#fff" d="M9 21v-6h6v6z"/>',
security:'<path fill="currentColor" d="M12 2 20 5v6.2c0 5.2-3.1 9-8 10.8-4.9-1.8-8-5.6-8-10.8V5z"/><path fill="#fff" d="m9.2 12.2 1.8 1.8 4.2-4.4 1.3 1.3-5.5 5.7-3.1-3.1z"/>',
company:'<path fill="currentColor" d="M4 21V6l8-4 8 4v15z"/><path fill="#fff" d="M8 9h2v2H8zm6 0h2v2h-2zM8 13h2v2H8zm6 0h2v2h-2zM10 17h4v4h-4z"/>',
employee:'<circle fill="currentColor" cx="12" cy="7" r="4"/><path fill="currentColor" d="M4 21a8 8 0 0 1 16 0z"/><circle fill="#fff" cx="7" cy="8" r="2.2" opacity=".9"/><circle fill="#fff" cx="17" cy="8" r="2.2" opacity=".9"/>',
idcard:'<rect fill="currentColor" x="2.5" y="5" width="19" height="14" rx="2.5"/><circle fill="#fff" cx="8" cy="10.5" r="2.3"/><path fill="#fff" d="M5 16a3.5 3.5 0 0 1 6 0zM13 9h5v1.7h-5zm0 3.2h5v1.7h-5zm0 3.2h3.5v1.7H13z"/>',
projectAssign:'<path fill="currentColor" d="M2.5 6.5A2.5 2.5 0 0 1 5 4h5l2 2h7.5A2.5 2.5 0 0 1 22 8.5v9A2.5 2.5 0 0 1 19.5 20h-15A2.5 2.5 0 0 1 2 17.5z"/><path fill="#fff" d="M12 9h2v3h3v2h-3v3h-2v-3H9v-2h3z"/>',
attendance:'<rect fill="currentColor" x="3" y="4" width="18" height="17" rx="3"/><path fill="#fff" d="M7 2h2v4H7zm8 0h2v4h-2zM5 9h14v2H5zm2 4h3v3H7zm5 0h3v3h-3z"/><circle fill="#fff" cx="17.5" cy="17.5" r="3"/><path fill="currentColor" d="M17.5 15.8h1v2.1l1.4.8-.5.9-1.9-1.2z"/>',
advance:'<circle fill="currentColor" cx="12" cy="12" r="10"/><path fill="#fff" d="M12 5v14h2V5zm4 3.2c-.8-.9-2.1-1.5-3.7-1.5-2.3 0-4 1.3-4 3.2 0 2.2 1.8 3.1 4.1 3.7 1.5.4 2.2.8 2.2 1.7 0 .8-.8 1.3-2 1.3-1.4 0-2.5-.5-3.3-1.4l-1.4 1.5c1 1.1 2.5 1.8 4.2 2v1h2v-1c2.1-.4 3.5-1.6 3.5-3.6 0-2.1-1.6-3.1-4-3.8-1.7-.5-2.3-.9-2.3-1.6 0-.6.6-1 1.6-1 1 0 1.8.3 2.5 1z"/>',
contractor:'<circle fill="currentColor" cx="9" cy="8" r="3.5"/><circle fill="currentColor" cx="17" cy="9" r="2.8"/><path fill="currentColor" d="M2.5 21a6.5 6.5 0 0 1 13 0zm12 0a5.3 5.3 0 0 1 7 0z"/><path fill="#fff" d="M7.7 5.8h2.6v1.7H7.7z"/>',
contractorAtt:'<rect fill="currentColor" x="3" y="4" width="18" height="17" rx="3"/><path fill="#fff" d="M7 2h2v4H7zm8 0h2v4h-2zM5 9h14v2H5zm2 4h3v3H7zm5 0h3v3h-3z"/>',
cashbookReport:'<path fill="currentColor" d="M4 3h13l3 3v15H4z"/><path fill="#fff" d="M7 16h2v2H7zm4-4h2v6h-2zm4-3h2v9h-2zM7 6h7v2H7z"/>',
today:'<circle fill="currentColor" cx="12" cy="12" r="10"/><path fill="#fff" d="M11 6h2v6l4 2-1 1.7-5-2.7z"/>',
applyAtt:'<rect fill="currentColor" x="3" y="3" width="18" height="18" rx="3"/><path fill="#fff" d="M7 7h10v2H7zm0 4h7v2H7zm0 4h4v2H7z"/><path fill="#fff" d="m15 15 1.6 1.6 3.1-3.3 1.3 1.2-4.4 4.6-2.9-2.9z"/>',
leave:'<path fill="currentColor" d="M5 21h14V8H5z"/><path fill="#fff" d="M8 5h8v3H8zM10 2h4v3h-4zm0 10h4v2h-4zm0 4h4v2h-4z"/>',
payslip:'<path fill="currentColor" d="M5 2h10l4 4v16H5z"/><path fill="#fff" d="M14 2v6h5M8 11h8v2H8zm0 4h8v2H8zm0 4h5v2H8z"/><circle fill="#ffb52e" cx="17.5" cy="17.5" r="3.2"/><path fill="#fff" d="M17 15.8h1v3.4h-1z"/>',
advances:'<circle fill="currentColor" cx="12" cy="12" r="10"/><path fill="#fff" d="M12 5v14h2V5zm4 3.2c-.8-.9-2.1-1.5-3.7-1.5-2.3 0-4 1.3-4 3.2 0 2.2 1.8 3.1 4.1 3.7 1.5.4 2.2.8 2.2 1.7 0 .8-.8 1.3-2 1.3-1.4 0-2.5-.5-3.3-1.4l-1.4 1.5c1 1.1 2.5 1.8 4.2 2v1h2v-1c2.1-.4 3.5-1.6 3.5-3.6 0-2.1-1.6-3.1-4-3.8-1.7-.5-2.3-.9-2.3-1.6 0-.6.6-1 1.6-1 1 0 1.8.3 2.5 1z"/>',
cashbook:'<path fill="currentColor" d="M4 4h12a4 4 0 0 1 4 4v13H8a4 4 0 0 1-4-4z"/><path fill="#fff" d="M8 9h8v2H8zm0 4h8v2H8zm0 4h5v2H8z"/>',
contractorAtt2:'<rect fill="currentColor" x="3" y="4" width="18" height="17" rx="3"/><path fill="#fff" d="M7 2h2v4H7zm8 0h2v4h-2zM5 9h14v2H5z"/><path fill="#fff" d="m7 15 2 2 4-4 1.4 1.4-5.4 5.3L5.6 16.4z"/>',
default:'<circle fill="currentColor" cx="12" cy="12" r="9"/><circle fill="#fff" cx="12" cy="12" r="2.5"/>'
};
const ICON_FILES={dashboard:'home',security:'users-roles',company:'clients',employee:'employees',idcard:'id-card',projectAssign:'projects',attendance:'attendance',advance:'advances',contractor:'contractors',contractorAtt:'calendar',contractorBill:'salary',faceSec:'users-roles',cashbookReport:'reports',spending:'expense',today:'attendance',applyAtt:'documents',leave:'leave',payslip:'payslip',advances:'salary',cashbook:'cash-book',measurement:'measurement-book',contractorAtt2:'calendar',default:'settings'};
function makeIcon(key){const f=ICON_FILES[key]||ICON_FILES.default;return '<span class="portal-nav-icon" aria-hidden="true"><img src="https://res.cloudinary.com/wpizqa3u/image/upload/q_auto/app_icons/'+f+'.png" onerror="this.onerror=null;this.src=\'assets/icons/'+f+'.png?v=1\'" alt="" width="48" height="48" decoding="async"></span>';}
function install(){
document.querySelectorAll('.nav-tab-btn[data-tab],.nav-tab-btn[data-stab]').forEach(function(btn){
if(btn.querySelector('.portal-nav-icon')) return;
const key=btn.getAttribute('data-tab')||btn.getAttribute('data-stab')||'default';
const badge=btn.querySelector('#approvalsBadge');
const textNodes=[...btn.childNodes].filter(n=>n.nodeType===3);
let label=textNodes.map(n=>n.nodeValue).join('').trim();
textNodes.forEach(n=>n.remove());
const labelEl=document.createElement('span'); labelEl.className='nav-label'; labelEl.textContent=label;
btn.insertBefore(labelEl,badge||null); btn.insertBefore(document.createRange().createContextualFragment(makeIcon(key)),labelEl);
});
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',install); else install();
setTimeout(install,500);
/* Auto-upload icons to Cloudinary once: runs when an Admin is logged in and the icons were not uploaded yet. */
(function(){var done=false;try{done=localStorage.getItem('iconsCloudV1')==='1';}catch(e){}
if(done)return;var tries=0;
var t=setInterval(function(){tries++;if(tries>200){clearInterval(t);return;}
var a=document.getElementById('adminView');if(!a||a.offsetParent===null)return;
clearInterval(t);
fetch('index.php?tool=migrate_icons&run=1',{credentials:'same-origin'}).then(function(r){return r.text();}).then(function(x){
if(/uploaded: [1-9]/.test(x)&&/problems: 0/.test(x)){try{localStorage.setItem('iconsCloudV1','1');}catch(e){}}
}).catch(function(){});
},3000);})();
})();
</script>

<!-- ===== Face recognition security (admin on/off in "Face Security" tab). face-api.js is loaded lazily, only when a face scan is needed. ===== -->
<style id="face-security-css">
.face-switch{display:inline-flex;align-items:center;gap:10px;cursor:pointer;font-weight:900;font-size:14px;user-select:none}
.face-switch input{position:absolute;opacity:0;width:0;height:0}
.face-slider{position:relative;width:58px;height:32px;border-radius:32px;background:#cbd5e1;transition:.2s;flex-shrink:0}
.face-slider:after{content:"";position:absolute;top:3px;left:3px;width:26px;height:26px;border-radius:50%;background:#fff;box-shadow:0 2px 6px rgba(15,23,42,.3);transition:.2s}
.face-switch input:checked+.face-slider{background:#059669}
.face-switch input:checked+.face-slider:after{left:29px}
.face-switch input:focus-visible+.face-slider{outline:3px solid #a5b4fc}
.face-opt{display:flex;align-items:flex-start;gap:10px;padding:10px 12px;border:1px solid #e2e8f0;border-radius:14px;background:#f8fafc;font-size:13px;font-weight:700;text-transform:none;letter-spacing:0;margin:0;color:#0f172a}.face-opt span{flex:1;min-width:0}.face-opt small{text-transform:none;letter-spacing:0;font-size:11px}
.face-opt input{margin-top:3px;width:18px;height:18px;flex-shrink:0}
.face-opt small{display:block;color:#64748b;font-weight:600;margin-top:2px;line-height:1.35}
.face-badge{display:inline-block;padding:2px 9px;border-radius:999px;font-size:11px;font-weight:900;white-space:nowrap}
.face-ok{background:#d1fae5;color:#047857}.face-bad{background:#ffe4e6;color:#be123c}.face-warn{background:#fef3c7;color:#b45309}.face-neu{background:#e2e8f0;color:#475569}
.face-tbl{width:100%;border-collapse:collapse;font-size:13px}.face-tbl th,.face-tbl td{padding:8px 10px;border-bottom:1px solid #e2e8f0;text-align:left;vertical-align:middle}.face-tbl th{font-size:12px;color:#64748b}
.face-tblwrap{overflow-x:auto;max-height:420px;overflow-y:auto}
#faceModal{position:fixed;inset:0;z-index:99999;background:rgba(15,23,42,.78);display:flex;align-items:center;justify-content:center;padding:14px}
#faceModal .fm-card{background:#fff;border-radius:24px;padding:20px;width:100%;max-width:420px;text-align:center;box-shadow:0 30px 80px rgba(0,0,0,.5)}
#faceModal .fm-wrap{position:relative;width:100%;aspect-ratio:4/3;border-radius:18px;overflow:hidden;background:#0f172a;line-height:0}
#faceModal video,#faceModal canvas{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transform:scaleX(-1)}#faceModal.fm-back video,#faceModal.fm-back canvas{transform:none}#faceModal .fm-flip{position:absolute;right:10px;top:10px;z-index:3;line-height:1;padding:9px 12px;border-radius:999px;border:0;background:rgba(15,23,42,.65);color:#fff;font-weight:800;font-size:13px;cursor:pointer}
#faceModal .fm-say{margin:14px 0 4px;min-height:44px;font-weight:800;font-size:15px}
</style>
<script id="face-security-js">
(function(){
const FA_BASE='https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.12';
let faLoading=null,faBusy=false;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const esc=v=>escapeHTML(v);
function faLoad(){
 if(faLoading)return faLoading;
 faLoading=new Promise((res,rej)=>{
  const go=async()=>{try{
   const n=faceapi.nets;
   await Promise.all([n.tinyFaceDetector.loadFromUri(FA_BASE+'/model'),n.faceLandmark68Net.loadFromUri(FA_BASE+'/model'),n.faceRecognitionNet.loadFromUri(FA_BASE+'/model')]);
   res();}catch(e){rej(e)}};
  if(window.faceapi)return go();
  const sc=document.createElement('script');sc.src=FA_BASE+'/dist/face-api.js';sc.onload=go;
  sc.onerror=()=>rej(new Error('The face recognition library could not be loaded. Check the internet connection.'));
  document.head.appendChild(sc);
 }).catch(e=>{faLoading=null;throw e});
 return faLoading;
}
function faModal(title){
 const el=document.createElement('div');el.id='faceModal';
 el.innerHTML='<div class="fm-card"><h3 style="margin:0 0 12px">'+esc(title)+'</h3><div class="fm-wrap"><video playsinline muted autoplay></video><canvas></canvas><button type="button" class="fm-flip" title="Switch between front and back camera">🔄 Front / Back</button></div><div class="fm-say"></div><button type="button" class="btn" style="width:100%;background:#64748b;color:#fff">Cancel</button></div>';
 document.body.appendChild(el);
 const m={el,video:el.querySelector('video'),canvas:el.querySelector('canvas'),say:el.querySelector('.fm-say'),cancelled:false,stream:null};
 m.msg=(t,c)=>{m.say.style.color=c||'#4f46e5';m.say.textContent=t};
 m.close=()=>{m.cancelled=true;try{m.stream&&m.stream.getTracks().forEach(t=>t.stop())}catch(e){}el.remove()};
 el.querySelector('.fm-flip').onclick=async()=>{if(m.switching)return;m.switching=true;try{m.facing=m.facing==='environment'?'user':'environment';try{localStorage.setItem('faceCam',m.facing)}catch(e){}m.stream&&m.stream.getTracks().forEach(t=>t.stop());await faCam(m)}catch(e){m.msg(errText(e),'#be123c')}m.switching=false};
 el.querySelector('.fm-card>button').onclick=()=>{m.cancelled=true};
 return m;
}
async function faCam(m){
 if(!window.isSecureContext)throw new Error('Camera needs a secure connection (https://).');
 if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)throw new Error('This browser does not support camera access.');
  if(!m.facing){try{m.facing=localStorage.getItem('faceCam')==='environment'?'environment':'user'}catch(e){m.facing='user'}}
 m.el.classList.toggle('fm-back',m.facing==='environment');m.mirror=m.facing!=='environment';
 try{m.stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:m.facing},width:{ideal:640},height:{ideal:480}},audio:false});}
 catch(err){
  if(err.name==='NotAllowedError')throw new Error('Camera permission was denied. Allow camera access for this site and try again.');
  if(err.name==='NotFoundError')throw new Error('No camera was found on this device.');
  if(err.name==='NotReadableError')throw new Error('The camera is in use by another app.');
  m.stream=await navigator.mediaDevices.getUserMedia({video:true,audio:false});
 }
 m.video.srcObject=m.stream;try{await m.video.play()}catch(e){}
 for(let i=0;i<50&&!m.video.videoWidth;i++)await sleep(100);
 m.canvas.width=m.video.videoWidth||640;m.canvas.height=m.video.videoHeight||480;
}
const TFO=()=>new faceapi.TinyFaceDetectorOptions({inputSize:224,scoreThreshold:0.5});
async function faDetect(m){if(m.switching){await sleep(120);return[]}return faceapi.detectAllFaces(m.video,TFO()).withFaceLandmarks();}
function faDraw(m,dets,color,label){
 const c=m.canvas.getContext('2d');c.clearRect(0,0,m.canvas.width,m.canvas.height);
 dets.forEach(d=>{const b=d.detection.box,L=Math.max(14,b.width*.18);
  c.strokeStyle=color;c.lineWidth=3;c.beginPath();
  [[b.x,b.y,1,1],[b.x+b.width,b.y,-1,1],[b.x,b.y+b.height,1,-1],[b.x+b.width,b.y+b.height,-1,-1]].forEach(k=>{c.moveTo(k[0]+k[2]*L,k[1]);c.lineTo(k[0],k[1]);c.lineTo(k[0],k[1]+k[3]*L)});
  c.stroke();
  /* label is drawn un-mirrored (canvas itself is mirrored by CSS) */
  c.save();if(m.mirror!==false){c.translate(b.x+b.width,b.y-6);c.scale(-1,1)}else c.translate(b.x,b.y-6);c.fillStyle=color;c.font='bold 16px sans-serif';c.fillText(label,0,0);c.restore();
 });
}
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
function ear(p){return (dist(p[1],p[5])+dist(p[2],p[4]))/(2*dist(p[0],p[3])||1)}
function eyeAR(lm){return (ear(lm.getLeftEye())+ear(lm.getRightEye()))/2}
function yawRatio(lm){const p=lm.positions;return (p[30].x-p[0].x)/((p[16].x-p[0].x)||1)}
function snapshot(m){try{const c=document.createElement('canvas');c.width=160;c.height=120;c.getContext('2d').drawImage(m.video,0,0,160,120);return c.toDataURL('image/jpeg',0.55)}catch(e){return ''}}
const errText=e=>(e&&e.message)||'Face scan failed.';

/* ---- Verify: tracking + liveness challenge + server-side match.  Resolves {ok,msg,bypass}. ---- */
window.faceVerifyFlow=async function(empId,purpose,useQR){
 if(faBusy)return{ok:false,msg:'A face scan is already in progress.'};
 const ident=(empId===null);
 const st=ident?{status:'success',required:true,enrolled:true,liveness:!!(db.face_ai&&db.face_ai.liveness),snapshots:!!(db.face_ai&&db.face_ai.snapshots)}:await server('face_status',{emp_id:empId});
 if(st.status!=='success')return{ok:false,msg:st.message||'Face check is unavailable right now.'};
 if(!st.required)return{ok:true};
 if(!st.enrolled)return st.allow_unenrolled?{ok:true,bypass:true}:{ok:false,msg:'Your face is not enrolled yet. Please ask Admin to enrol it.'};
 faBusy=true;const m=faModal('Face verification');
 try{
  m.msg('Loading face recognition…');await faLoad();
  m.msg('Starting camera…');await faCam(m);
  let live=!st.liveness,chal=Math.random()<.5?'blink':'turn',chalAt=Date.now(),openSeen=false,centre=false,stable=0;const t0=Date.now();
  const hint=ident&&useQR?'Show the QR card and look at the camera. ':'';
  let qrId=null,qrAt=0,qrName='',qrTry=0;
  if(st.liveness)m.msg(hint+(chal==='blink'?'Please blink once':'Please slowly turn your head'));
  while(!m.cancelled){
   if(Date.now()-t0>30000)throw new Error('Face scan timed out. Please try again.');
   if(ident&&useQR&&Date.now()-qrTry>350&&!m.switching){qrTry=Date.now();try{const cs=await scanDetectAll(m.video,document.getElementById('scanCanvas'));const hit=cs.map(c=>(db.employees||[]).find(e=>String(e.id)===c.data&&!e.terminated)).find(Boolean);if(hit){if(qrId!==hit.id)m.msg('QR card read: '+hit.name+' - now look at the camera','#059669');qrId=hit.id;qrAt=Date.now();qrName=hit.name}}catch(e){}}
   const dets=await faDetect(m);
   if(m.cancelled)break;
   if(dets.length===0){faDraw(m,[],'#f59e0b','');stable=0;m.msg('No face found - look at the camera','#b45309');await sleep(80);continue}
   if(dets.length>1){faDraw(m,dets,'#e11d48','Multiple faces');stable=0;m.msg('Only one person should be in view','#be123c');await sleep(80);continue}
   const d=dets[0],bw=d.detection.box.width/(m.video.videoWidth||640);
   if(bw<0.22){faDraw(m,dets,'#f59e0b','Move closer');stable=0;m.msg('Move a little closer','#b45309');await sleep(80);continue}
   faDraw(m,dets,live?'#10b981':'#4f46e5',live?'Tracking':'Tracking');stable++;
   if(!live){
    if(chal==='blink'){const e=eyeAR(d.landmarks);if(e>0.27)openSeen=true;else if(e<0.22&&openSeen)live=true;}
    else{const r=yawRatio(d.landmarks);if(Math.abs(r-.5)<.1)centre=true;else if(Math.abs(r-.5)>.18&&centre)live=true;}
    if(!live&&Date.now()-chalAt>9000){chal=chal==='blink'?'turn':'blink';chalAt=Date.now();openSeen=false;centre=false;m.msg(chal==='blink'?'Please blink once':'Please slowly turn your head left or right','#4f46e5');}
    if(live){stable=0;m.msg('Liveness confirmed - hold still…','#059669');}
    await sleep(30);continue;
   }
   if(stable<4){await sleep(60);continue}
   const qrOk=qrId&&Date.now()-qrAt<20000;
   if(ident&&!qrOk&&!(db.face_ai&&db.face_ai.guard_identify)){stable=0;m.msg('Show the QR card to the camera','#b45309');await sleep(150);continue}
   m.msg('Verifying…');
   const full=await faceapi.detectSingleFace(m.video,TFO()).withFaceLandmarks().withFaceDescriptor();
   if(!full){stable=0;continue}
   const snap=st.snapshots?snapshot(m):'';
   const r=(ident&&qrOk)?await server('face_verify',{emp_id:qrId,descriptor:Array.from(full.descriptor),live:true,snap,purpose:'guard'}):ident?await server('face_identify',{descriptor:Array.from(full.descriptor),live:true,snap}):await server('face_verify',{emp_id:empId,descriptor:Array.from(full.descriptor),live:true,snap,purpose:purpose||''});
   if(r.status==='success'){m.msg('✔ '+(r.message||'Face verified'),'#059669');faDraw(m,[full],'#10b981','Verified');await sleep(700);m.close();faBusy=false;return{ok:true,bypass:!!r.bypass,emp_id:r.emp_id||(ident&&qrOk?qrId:undefined),name:r.name||qrName};}
   m.close();faBusy=false;return{ok:false,msg:r.message||'Face did not match.'};
  }
  m.close();faBusy=false;return{ok:false,msg:'Face scan cancelled.'};
 }catch(e){m.close();faBusy=false;return{ok:false,msg:errText(e)};}
};

/* ---- Enrol (admin): several samples at different angles ---- */
window.faceEnrollFlow=async function(empId,name){
 if(faBusy)return;
 if(!confirm('Enrol the face of '+name+'?\n\nOnly continue if this employee has agreed to their face data being stored for attendance security. Only a numeric face template is saved (not a photo), and you can remove it at any time.'))return;
 faBusy=true;const m=faModal('Enrol face: '+name);let ok=false;
 try{
  m.msg('Loading face recognition…');await faLoad();
  m.msg('Starting camera…');await faCam(m);
  const steps=['Look straight at the camera','Turn your head slightly LEFT','Turn your head slightly RIGHT','Look straight again','Tilt your chin slightly UP'];
  const samples=[];
  for(let i=0;i<steps.length&&!m.cancelled;i++){
   m.msg((i+1)+'/'+steps.length+'  '+steps[i]);
   const until=Date.now()+1400;while(Date.now()<until&&!m.cancelled){const ds=await faDetect(m);faDraw(m,ds,'#4f46e5','Tracking');await sleep(40)}
   let got=null;const lim=Date.now()+8000;
   while(!got&&Date.now()<lim&&!m.cancelled){
    const ds=await faDetect(m);
    if(ds.length!==1){faDraw(m,ds,'#e11d48',ds.length?'Multiple faces':'');m.msg(ds.length?'Only one person should be in view':'No face found','#be123c');await sleep(80);continue}
    faDraw(m,ds,'#10b981','Capturing');
    const f=await faceapi.detectSingleFace(m.video,TFO()).withFaceLandmarks().withFaceDescriptor();
    if(f&&f.detection.score>0.6)got=Array.from(f.descriptor);
   }
   if(!got&&!m.cancelled)throw new Error('Could not capture a clear face. Try again with better light.');
   if(got)samples.push(got);
  }
  if(m.cancelled)throw new Error('Enrolment cancelled.');
  m.msg('Saving…');
  const r=await server('face_enroll',{emp_id:empId,descriptors:samples});
  if(r.status!=='success')throw new Error(r.message||'Could not save.');
  ok=true;m.msg('✔ '+r.message,'#059669');await sleep(900);
 }catch(e){m.msg(errText(e),'#be123c');await sleep(1800);}
 m.close();faBusy=false;
 if(ok){try{faceAdminInit()}catch(e){}}
};

/* ---- Admin tab ---- */
const RES={match:['face-ok','Verified'],no_match:['face-bad','Not matched'],liveness_fail:['face-warn','Liveness failed'],not_enrolled:['face-neu','Not enrolled (allowed)'],enrolled:['face-neu','Face enrolled'],removed:['face-neu','Face removed'],feature_on:['face-ok','Feature turned ON'],feature_off:['face-bad','Feature turned OFF']};
const cb=id=>document.getElementById(id);
function faceApplySettings(){
 const c=db.face_ai||{};
 cb('faEnabled').checked=!!c.enabled;cb('faEnabledLbl').textContent=c.enabled?'ON':'OFF';cb('faEnabledLbl').style.color=c.enabled?'#047857':'#64748b';
 ['require_emp','require_guard','guard_identify','liveness','allow_unenrolled','snapshots'].forEach(k=>{cb('fa_'+k).checked=!!c[k]});
 cb('fa_threshold').value=String(c.threshold||0.5);
 cb('faOptions').style.opacity=c.enabled?'1':'.55';
}
window.faceSaveSettings=async function(fromToggle){
 const s={enabled:cb('faEnabled').checked,threshold:parseFloat(cb('fa_threshold').value)||0.5};
 ['require_emp','require_guard','guard_identify','liveness','allow_unenrolled','snapshots'].forEach(k=>{s[k]=cb('fa_'+k).checked});
 const r=await server('save_face_settings',{settings:s});
 if(r.status==='success'){db.face_ai=r.settings;faceApplySettings();faceAdminInit();if(!fromToggle)alert(r.message)}
 else{alert(r.message||'Could not save.');faceApplySettings();}
};
window.faceAdminInit=async function(){
 if(!cb('faEnabled'))return;
 faceApplySettings();
 const r=await server('face_admin_data',{});
 if(r.status!=='success'){cb('faEmpBody').innerHTML='<tr><td colspan="4">'+esc(r.message||'Could not load.')+'</td></tr>';return}
 const en=r.enrolled||{},emps=(db.employees||[]).filter(e=>!e.terminated);
 const n=emps.filter(e=>en[e.id]).length;
 cb('faSummary').textContent=n+' of '+emps.length+' active employees enrolled';
 cb('faEmpBody').innerHTML=emps.map(e=>{const x=en[e.id];
  return '<tr><td><strong>'+esc(e.name)+'</strong><br><span style="color:#64748b;font-size:11px">'+esc(e.id)+'</span></td>'
  +'<td>'+(x?'<span class="face-badge face-ok">Enrolled</span><br><span style="color:#64748b;font-size:11px">'+esc(x.at)+'</span>':'<span class="face-badge face-warn">Not enrolled</span>')+'</td>'
  +'<td style="white-space:nowrap"><button class="btn btn-save" style="padding:6px 12px;font-size:12px" data-fe="'+esc(e.id)+'">'+(x?'Re-enrol':'Enrol face')+'</button> '
  +(x?'<button class="btn btn-danger" style="padding:6px 12px;font-size:12px" data-fr="'+esc(e.id)+'">Remove</button>':'')+'</td></tr>'}).join('')||'<tr><td colspan="3">No employees.</td></tr>';
 cb('faEmpBody').querySelectorAll('[data-fe]').forEach(b=>b.onclick=()=>{const e=emps.find(x=>x.id===b.dataset.fe);faceEnrollFlow(e.id,e.name)});
 cb('faEmpBody').querySelectorAll('[data-fr]').forEach(b=>b.onclick=async()=>{const e=emps.find(x=>x.id===b.dataset.fr);if(!confirm('Remove the stored face data of '+e.name+'?'))return;const q=await server('face_remove',{emp_id:e.id});alert(q.message);faceAdminInit()});
 const L=r.log||[];
 cb('faLogBody').innerHTML=L.map(x=>{const t=RES[x.result]||['face-neu',x.result];
  const when=new Date(x.ts*1000).toLocaleString('en-IN',{timeZone:'Asia/Kolkata',day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit',second:'2-digit'});
  const who=x.emp_name?esc(x.emp_name)+' <span style="color:#64748b;font-size:11px">'+esc(x.emp_id||'')+'</span>':'-';
  const via=x.role==='security'?'Guard'+(x.site?' @ '+esc(x.site):''):(x.role==='emp'?'Self punch':esc(x.role||''))+(x.by&&x.role!=='emp'?' ('+esc(x.by)+')':'');
  return '<tr><td style="white-space:nowrap">'+when+'</td><td>'+who+'</td><td><span class="face-badge '+t[0]+'">'+esc(t[1])+'</span></td><td>'+(x.score!=null?x.score:'')+'</td><td>'+via+'</td><td>'+(x.snap?'<button class="btn" style="padding:4px 10px;font-size:12px" data-fs="'+esc(x.id)+'">View</button>':'')+'</td></tr>'}).join('')||'<tr><td colspan="6" style="color:#64748b">No face scans yet.</td></tr>';
 cb('faLogBody').querySelectorAll('[data-fs]').forEach(b=>b.onclick=async()=>{const q=await server('face_snap',{id:b.dataset.fs});if(q.status!=='success'){alert(q.message);return}
  const o=document.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(15,23,42,.8);display:flex;align-items:center;justify-content:center';o.onclick=()=>o.remove();
  const i=new Image();i.src=q.img;i.style.cssText='width:min(90vw,480px);border-radius:16px;background:#000';o.appendChild(i);document.body.appendChild(o)});
};
window.faceClearLog=async function(){if(!confirm('Delete the whole face scan log and its snapshots?'))return;const r=await server('face_clear_log',{});alert(r.message);faceAdminInit()};
})();
</script>
<style id="tejodhar-circular-icon-reference">.portal-nav-icon{width:52px!important;height:52px!important;min-width:52px!important;border-radius:50%!important;border:0!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;margin:0 auto 7px!important;position:relative!important;overflow:hidden!important;color:#fff!important;box-shadow:0 7px 16px rgba(15,23,42,.16),inset 0 1px 0 rgba(255,255,255,.28)!important;background:linear-gradient(145deg,#2f80ed,#1261d6)!important;transition:transform .18s ease,box-shadow .18s ease!important;}.portal-nav-icon:before{content:"";position:absolute;inset:3px;border-radius:50%;border:1px solid rgba(255,255,255,.22);pointer-events:none}.portal-nav-icon:after{content:"";position:absolute;inset:0!important;background:linear-gradient(135deg,rgba(255,255,255,.22),transparent 42%,rgba(255,255,255,.08));transform:none!important;pointer-events:none}.portal-nav-icon svg{width:27px!important;height:27px!important;display:block!important;position:relative;z-index:2;stroke:none!important;fill:currentColor!important;stroke-width:0!important}.nav-tab-btn{background:#fff!important;border:1px solid #edf0f5!important;border-radius:16px!important;min-height:92px!important;padding:8px 4px!important;box-shadow:0 4px 12px rgba(15,23,42,.055)!important}.nav-tab-btn:hover{transform:translateY(-2px)!important;box-shadow:0 9px 20px rgba(15,23,42,.12)!important}.nav-tab-btn.active{background:#fff!important;color:#0f172a!important;border-color:#e7ebf2!important;box-shadow:0 9px 22px rgba(15,23,42,.11)!important}.nav-tab-btn.active .portal-nav-icon{box-shadow:0 8px 18px rgba(15,23,42,.18),inset 0 1px 0 rgba(255,255,255,.28)!important}.nav-tab-btn .nav-label{display:block!important;max-width:100%!important;color:#10264b!important;font-size:10px!important;line-height:1.18!important;font-weight:850!important;letter-spacing:0!important;text-align:center!important}.portal-nav-icon.ci-blue{background:linear-gradient(145deg,#2f80ed,#1261d6)!important}.portal-nav-icon.ci-orange{background:linear-gradient(145deg,#ffb52e,#f47b20)!important}.portal-nav-icon.ci-purple{background:linear-gradient(145deg,#a66cff,#6841d9)!important}.portal-nav-icon.ci-green{background:linear-gradient(145deg,#35d58a,#0b9b68)!important}.portal-nav-icon.ci-cyan{background:linear-gradient(145deg,#28dbe7,#1595d4)!important}.portal-nav-icon.ci-pink{background:linear-gradient(145deg,#ff6f9c,#e83c72)!important}.portal-nav-icon.ci-teal{background:linear-gradient(145deg,#42d8c2,#16a99a)!important}.portal-nav-icon.ci-indigo{background:linear-gradient(145deg,#7186ff,#4657d9)!important}.portal-nav-icon.ci-red{background:linear-gradient(145deg,#ff6680,#df3655)!important}.portal-nav-icon.ci-lime{background:linear-gradient(145deg,#65d85b,#2cae4d)!important}@media(max-width:800px){.nav-tab-btn{min-height:76px!important;padding:6px 3px!important;border-radius:14px!important}.portal-nav-icon{width:42px!important;height:42px!important;min-width:42px!important;margin-bottom:5px!important}.portal-nav-icon svg{width:22px!important;height:22px!important}.nav-tab-btn .nav-label{font-size:8.5px!important}}@media(max-width:480px){.nav-tab-btn{min-height:72px!important;padding:5px 2px!important;border-radius:13px!important}.portal-nav-icon{width:38px!important;height:38px!important;min-width:38px!important}.portal-nav-icon svg{width:20px!important;height:20px!important}.nav-tab-btn .nav-label{font-size:8px!important}}</style>
<script id="tejodhar-circular-icon-colors">(function(){
const colorMap={
dashboard:'ci-blue',faceSec:'ci-purple',security:'ci-orange',company:'ci-cyan',employee:'ci-orange',idcard:'ci-pink',projectAssign:'ci-cyan',
attendance:'ci-purple',advance:'ci-green',contractor:'ci-orange',contractorAtt:'ci-blue',cashbookReport:'ci-purple',spending:'ci-orange',today:'ci-green',
applyAtt:'ci-blue',leave:'ci-green',payslip:'ci-blue',advances:'ci-pink',cashbook:'ci-orange',contractorAtt2:'ci-cyan'
};
function applyCircularColors(){
document.querySelectorAll('.nav-tab-btn').forEach(function(btn){
const icon=btn.querySelector('.portal-nav-icon');
if(!icon) return;
Object.keys(colorMap).forEach(k=>icon.classList.remove(colorMap[k]));
const key=btn.getAttribute('data-tab')||btn.getAttribute('data-stab')||'';
icon.classList.add(colorMap[key]||'ci-blue');
});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',applyCircularColors);else applyCircularColors();
setTimeout(applyCircularColors,100);setTimeout(applyCircularColors,600);
})();
</script>
<style id="tejodhar-image-icons">:is(#adminView,#empView) .nav-tab-btn .portal-nav-icon, :is(#adminView,#empView) .nav-tab-btn .portal-nav-icon[class*="ci-"]{background:none!important;box-shadow:none!important;overflow:visible!important}:is(#adminView,#empView) .nav-tab-btn .portal-nav-icon:before, :is(#adminView,#empView) .nav-tab-btn .portal-nav-icon:after{display:none!important}:is(#adminView,#empView) .nav-tab-btn .portal-nav-icon img{width:100%;height:100%;display:block;object-fit:contain;position:relative;z-index:2;filter:drop-shadow(0 4px 6px rgba(15,23,42,.18))}</style>


<style id="oneplus-style-menu">#siteNav{margin:0!important;padding:0 8px 0 16px!important;border-radius:0!important;box-shadow:none!important;border-bottom:1px solid #e5e7eb;background:#fff!important;min-height:60px!important;top:0!important;width:100%!important;position:sticky}#siteNav .nav-centered-logo{position:static!important;transform:none!important;height:var(--nav-logo-h,34px)!important;width:auto!important;max-width:60vw!important;max-height:none!important;border-radius:0!important;object-fit:contain}#siteNav>div:first-child{order:0}#siteNav .employee-profile-wrap{order:2;margin:0 4px 0 auto!important}#siteNav .employee-profile-btn{width:38px;height:38px}#siteNav #logoutBtn{display:none!important}#siteNav>div:first-child{display:contents!important}#siteNav .employee-profile-wrap{margin:0 4px 0 auto!important}#siteNav .employee-profile-popup{left:auto!important;right:-52px;top:52px;width:min(290px,calc(100vw - 24px));max-height:calc(100vh - 90px);overflow-y:auto;z-index:4000}#siteNav .employee-profile-popup .profile-close{position:absolute;top:8px;right:10px;width:32px;height:32px;border:0;border-radius:50%;background:#f1f5f9;color:#0f172a;cursor:pointer}#siteNav .profile-info-row strong{text-align:right;word-break:break-word}#opMenuBtn{order:3;flex-shrink:0;width:44px;height:44px;border:0;background:transparent;color:#0f172a;display:flex;align-items:center;justify-content:center;cursor:pointer;border-radius:50%}#opMenuBtn:focus-visible,#opMenuClose:focus-visible,.op-row:focus-visible{outline:2px solid #f97316;outline-offset:2px}:is(#adminView,#empView) .admin-layout{display:block!important}:is(#adminView,#empView) .admin-nav{display:none!important}#opMenu{position:fixed;inset:0;z-index:5000;background:#fff;display:flex;flex-direction:column;visibility:hidden;opacity:0;transform:translateY(-12px);transition:opacity .2s ease,transform .2s ease,visibility 0s .2s}#opMenu.open{visibility:visible;opacity:1;transform:none;transition:opacity .2s ease,transform .2s ease}#opMenu .op-top{display:flex;align-items:center;justify-content:space-between;min-height:60px;padding:0 8px 0 16px;border-bottom:1px solid #e5e7eb;flex-shrink:0}#opMenu .op-top img{height:34px;width:auto;max-width:60vw;object-fit:contain}#opMenuClose{width:44px;height:44px;border:0;background:transparent;color:#0f172a;display:flex;align-items:center;justify-content:center;cursor:pointer;border-radius:50%}#opMenu .op-scroll{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding-bottom:env(safe-area-inset-bottom,0)}#opMenu .op-list{padding:8px 0 24px}.op-row{display:flex;align-items:center;gap:14px;width:100%;min-height:56px;padding:8px 16px;border:0;background:transparent;font:inherit;font-size:17px;color:#0f172a;text-align:left;cursor:pointer;border-left:4px solid transparent}.op-row img{width:32px;height:32px;flex-shrink:0;object-fit:contain}.op-row span.op-label{flex:1;min-width:0}.op-row svg{flex-shrink:0;color:#0f172a}.op-row.active{border-left-color:#f97316;background:#fff7ed;font-weight:700}.op-badge{background:#be123c;color:#fff;border-radius:999px;padding:1px 8px;font-size:12px;font-weight:800}#opMenu .op-account{background:#f3f4f6;padding:16px}#opMenu .op-card{background:#fff;padding:6px 0}#opMenu .op-row.op-logout{justify-content:flex-start;gap:14px;min-height:56px;padding:8px 16px;border-left:0;color:#0f172a;font-weight:500;font-size:17px;background:transparent}#opMenu .op-row.op-logout span.op-label{flex:1;min-width:0;color:#0f172a}#opMenu .op-row.op-logout .op-lico{width:40px;height:40px;border-radius:50%;background:#eef0f6;display:flex;align-items:center;justify-content:center;flex-shrink:0}#opMenu .op-row.op-logout .op-lico svg{color:#475569}#opMenu .op-row.op-logout > svg:last-child{color:#94a3b8}#opMenu .op-hello{padding:12px 16px;font-size:15px;color:#475569}#opMenu .op-hello strong{display:block;font-size:17px;color:#0f172a}.op-profile{display:flex;align-items:center;gap:14px;padding:14px 16px 6px}#opMenu .op-avatar{width:56px;height:56px;border-radius:50%;background:#eef2ff;color:#4338ca;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:20px;overflow:hidden;flex-shrink:0}#opMenu .op-avatar img{width:100%;height:100%;object-fit:cover}#opMenu .op-pname{min-width:0}#opMenu .op-pname strong{display:block;font-size:18px;color:#0f172a;word-break:break-word}#opMenu .op-pname small{display:block;font-size:12px;color:#64748b}#opMenu .op-details{margin:0;padding:6px 16px 10px}#opMenu .op-details div{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px solid #eef2f7;font-size:14px}#opMenu .op-details dt{color:#64748b}#opMenu .op-details dd{margin:0;font-weight:700;color:#0f172a;text-align:right;word-break:break-word}body.op-lock{overflow:hidden}@media(prefers-reduced-motion:reduce){#opMenu,#opMenu.open{transition:none;transform:none}}</style>
<style id="oneplus-menu-v2">#opMenu .op-scroll{background:#fff}#opMenu .op-nav{background:#fff;padding:2px 0 44px}#opMenu .op-nav .op-row{min-height:56px;padding:8px 16px;font-size:17px;font-weight:400;color:#111}#opMenu .op-nav .op-row{gap:14px}#opMenu .op-nav .op-row img{display:block;width:32px;height:32px;flex-shrink:0;object-fit:contain}#opMenu .op-nav .op-row.active{font-weight:700;border-left-color:#f97316;background:#fff7ed}#opMenu .op-account{background:#f7f7f7;padding:16px 12px 32px}#opMenu .op-card{background:#fff;padding:8px 0 10px;border-radius:0}#opMenu .op-welcome{display:flex;align-items:center;gap:14px;padding:16px 16px 12px}#opMenu .op-welcome .op-wav{width:56px;height:56px;border-radius:50%;background:#cfe3ff;color:#1a73e8;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0}#opMenu .op-welcome .op-wav img{width:100%;height:100%;object-fit:cover;display:block}#opMenu .op-welcome .op-wt{min-width:0;font-size:16px;color:#111;line-height:1.35}#opMenu .op-welcome .op-wt strong{display:block;font-size:16px;font-weight:700;word-break:break-word}#opMenu .op-welcome .op-wt small{display:block;font-size:13px;color:#6b7280;word-break:break-word}#opMenu .op-pdetails{margin:0;padding:2px 16px 10px}#opMenu .op-pdetails div{display:flex;justify-content:space-between;align-items:baseline;gap:16px;padding:11px 0;border-bottom:1px solid #eef0f3;font-size:15px}#opMenu .op-pdetails div:last-child{border-bottom:0}#opMenu .op-pdetails dt{color:#6b7280;flex-shrink:0}#opMenu .op-pdetails dd{margin:0;color:#111;font-weight:600;text-align:right;word-break:break-word}#opMenu .op-card .op-row{min-height:58px;padding:8px 16px;gap:16px;font-size:16px;font-weight:400;border-left:0;color:#111;background:transparent}#opMenu .op-card .op-row .op-lico, #opMenu .op-card .op-row.op-logout .op-lico{width:24px;height:24px;border-radius:0;background:none;display:flex;align-items:center;justify-content:center;flex-shrink:0}#opMenu .op-card .op-row .op-lico svg, #opMenu .op-card .op-row.op-logout .op-lico svg{color:#111;width:24px;height:24px}#opMenu .op-card .op-row.op-logout > svg:last-child, #opMenu .op-card .op-row > svg:last-child{color:#111}</style>
<script id="oneplus-style-menu-js">(function(){
var CHEV='<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg>';
var BURGER='<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M3 6h18M3 12h18M3 18h18"/></svg>';
var CLOSE='<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M5 5l14 14M19 5 5 19"/></svg>';
var nav,btn,menu,list,lastFocus;
function esc(s){var d=document.createElement('div');d.textContent=s==null?'':s;return d.innerHTML;}
function activeView(){return document.querySelector('#adminView:not(.hidden)')||document.querySelector('#empView:not(.hidden)');}
function logoSrc(){var l=document.getElementById('navLogo');return l&&l.getAttribute('src')||'';}
function fmtDate(v){
v=String(v==null?'':v).trim();if(!v)return '—';
if(/^\d{4}-\d{2}-\d{2}$/.test(v)){var d=new Date(v+'T00:00:00');if(!isNaN(d))return d.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});}
var m=v.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/);
if(m){var d2=new Date(+m[3],+m[2]-1,+m[1]);if(!isNaN(d2))return d2.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});}
return v;
}
function profileHTML(co){
var rows=[],name='',photo='';
var e=(typeof sessionUser!=='undefined')?sessionUser:null;
var c=(typeof sessionContractor!=='undefined')?sessionContractor:null;
var g=(typeof sessionSite!=='undefined')?sessionSite:null;
if(e){
name=e.name||e.user||'Employee';photo=e.photo||'';
rows=[['Name',e.name||'—'],['Date of Birth',fmtDate(e.dob)],['Employee ID',e.id||'—'],['Date of Joining',fmtDate(e.doj)]];
}else if(c){
name=c.name||'Contractor';rows=[['Name',c.name||'—'],['Contractor ID',c.id||'—']];
}else if(g){
name='Security';rows=[['Role','Security guard'],['Site',g]];
}else{
name='Administrator';rows=[['Role','Admin']];
}
var ini=String(name).trim().split(/\s+/).slice(0,2).map(function(x){return x.charAt(0).toUpperCase();}).join('')||'U';
var av=photo?'<img src="'+esc(photo)+'" alt="">':'<span>'+esc(ini)+'</span>';
return '<div class="op-profile"><div class="op-avatar">'+av+'</div><div class="op-pname"><small>Signed in</small><strong>'+esc(name)+'</strong><small>'+esc(co)+'</small></div></div>'
+'<dl class="op-details">'+rows.map(function(r){return '<div><dt>'+esc(r[0])+'</dt><dd>'+esc(r[1])+'</dd></div>';}).join('')+'</dl>';
}
function whoAmI(){
var e=(typeof sessionUser!=='undefined')?sessionUser:null;
var c=(typeof sessionContractor!=='undefined')?sessionContractor:null;
var g=(typeof sessionSite!=='undefined')?sessionSite:null;
if(e)return {name:e.name||e.user||'Employee',photo:e.photo||'',rows:[
['Employee ID',e.id||'—'],['Designation',e.des||e.designation||'—'],
['Date of Joining',fmtDate(e.doj)],['Date of Birth',fmtDate(e.dob)]]};
if(c)return {name:c.name||'Contractor',photo:'',rows:[['Contractor ID',c.id||'—']]};
if(g)return {name:'Security',photo:'',rows:[['Role','Security guard'],['Site',g]]};
return {name:'Administrator',photo:'',rows:[['Role','Admin']]};
}
function build(){
var v=activeView(),html='';
if(v){
v.querySelectorAll('.nav-tab-btn').forEach(function(b,i){
if(b.style.display==='none')return;
var lab=b.querySelector('.nav-label'),img=b.querySelector('.portal-nav-icon img'),bd=b.querySelector('#approvalsBadge');
var text=(lab?lab.textContent:b.textContent).trim();
var badge=bd&&!bd.classList.contains('hidden')&&bd.textContent.trim()?'<span class="op-badge">'+esc(bd.textContent.trim())+'</span>':'';
html+='<button type="button" class="op-row'+(b.classList.contains('active')?' active':'')+'" data-i="'+i+'">'+(img?'<img src="'+esc(img.getAttribute('src'))+'" alt="">':'')+'<span class="op-label">'+esc(text)+'</span>'+badge+CHEV+'</button>';
});
}
var co=(typeof db!=='undefined'&&db.company&&db.company.name)||'Tejodhar Constructions';
var who=whoAmI();
var ICO_USER='<span class="op-lico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><circle cx="12" cy="10" r="3.2"/><path d="M5.8 18.4c1.5-2.4 3.7-3.4 6.2-3.4s4.7 1 6.2 3.4"/></svg></span>';
var ICO_OUT='<span class="op-lico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h4"/><path d="M9 12h11"/><path d="m16 8 4 4-4 4"/></svg></span>';
var GLYPH='<svg width="34" height="34" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="12" cy="8" r="4.2"/><path d="M3.5 21c0-4.6 3.8-7.4 8.5-7.4s8.5 2.8 8.5 7.4z"/></svg>';
var av=who.photo?'<img src="'+esc(who.photo)+'" alt="">':GLYPH;
var welcome='<div class="op-welcome"><div class="op-wav">'+av+'</div><div class="op-wt">Welcome to '+esc(co)+'<strong>'+esc(who.name)+'</strong></div></div>'
+'<dl class="op-pdetails">'+who.rows.map(function(r){return '<div><dt>'+esc(r[0])+'</dt><dd>'+esc(r[1])+'</dd></div>';}).join('')+'</dl>';
var profileRow='';
var logoutRow='<button type="button" class="op-row op-logout" data-exit="1" aria-label="Log out">'+ICO_OUT+'<span class="op-label">Log out</span>'+CHEV+'</button>';
list.innerHTML='<div class="op-nav">'+html+'</div><section class="op-theme-section"><label for="opThemeSelect">Colour theme</label><select id="opThemeSelect" aria-label="Choose portal colour theme"><option value="navy">Navy &amp; Orange</option><option value="purple">Purple Gradient</option><option value="teal">Teal / Green</option><option value="red">Red / Dark</option><option value="gold">Gold / Royal</option><option value="blue">Light Blue</option><option value="dark">Dark Glass</option><option value="sunset">Sunset</option></select><small>Choose a theme for this device</small></section><div class="op-account"><div class="op-card">'+welcome+profileRow+logoutRow+'</div></div>';var themeSelect=list.querySelector('#opThemeSelect');if(themeSelect){var savedTheme='navy';try{savedTheme=localStorage.getItem('tejodharLoginTheme')||'navy'}catch(e){}themeSelect.value=savedTheme;}
menu.querySelector('.op-top img').src=logoSrc();
}
function open(){
if(typeof closeEmployeeProfile==='function')closeEmployeeProfile();
build();lastFocus=document.activeElement;
menu.classList.add('open');menu.setAttribute('aria-hidden','false');btn.setAttribute('aria-expanded','true');
document.body.classList.add('op-lock');
var a=list.querySelector('.op-row.active')||list.querySelector('.op-row');
if(a&&a.scrollIntoView)a.scrollIntoView({block:'center'});
document.getElementById('opMenuClose').focus({preventScroll:true});
}
function close(){
menu.classList.remove('open');menu.setAttribute('aria-hidden','true');btn.setAttribute('aria-expanded','false');
document.body.classList.remove('op-lock');
if(lastFocus&&lastFocus.focus)lastFocus.focus({preventScroll:true});
}
function init(){
nav=document.getElementById('siteNav');if(!nav||document.getElementById('opMenuBtn'))return;
btn=document.createElement('button');btn.type='button';btn.id='opMenuBtn';btn.setAttribute('aria-label','Open menu');btn.setAttribute('aria-expanded','false');btn.innerHTML=BURGER;
nav.appendChild(btn);
menu=document.createElement('div');menu.id='opMenu';menu.setAttribute('role','dialog');menu.setAttribute('aria-modal','true');menu.setAttribute('aria-label','Menu');menu.setAttribute('aria-hidden','true');
menu.innerHTML='<div class="op-top"><img alt="Logo"><button type="button" id="opMenuClose" aria-label="Close menu">'+CLOSE+'</button></div><div class="op-scroll"></div>';
document.body.appendChild(menu);list=menu.querySelector('.op-scroll');
btn.addEventListener('click',open);
document.getElementById('opMenuClose').addEventListener('click',close);
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&menu.classList.contains('open'))close();});
list.addEventListener('change',function(e){var sel=e.target.closest('#opThemeSelect');if(!sel)return;var themes={navy:['#f97316','#fb923c','#08264b'],purple:['#7c3aed','#c026d3','#321064'],teal:['#0d9488','#10b981','#064e4a'],red:['#e11d48','#fb7185','#4c0519'],gold:['#b8860b','#eab308','#33250b'],blue:['#2563eb','#38bdf8','#12356b'],dark:['#6366f1','#a855f7','#0b1538'],sunset:['#ea580c','#f59e0b','#7c2d12']};var t=themes[sel.value]||themes.navy;var root=document.documentElement;root.style.setProperty('--login-accent',t[0]);root.style.setProperty('--login-secondary',t[1]);root.style.setProperty('--login-deep',t[2]);try{localStorage.setItem('tejodharLoginTheme',sel.value)}catch(err){}var picker=document.getElementById('tejodharThemePicker');if(picker){var b=picker.querySelector('button[data-theme="'+sel.value+'"]');if(b)b.click();}});
list.addEventListener('click',function(e){
var r=e.target.closest('.op-row');if(!r)return;
if(r.dataset.exit){close();if(typeof logout==='function')logout();return;}
if(r.dataset.profile){close();setTimeout(function(){if(typeof toggleEmployeeProfile==='function')toggleEmployeeProfile();},60);return;}
var v=activeView(),tabs=v?v.querySelectorAll('.nav-tab-btn'):[],t=tabs[+r.dataset.i];
close();if(t)t.click();window.scrollTo({top:0});
});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
</script>
<style>#navLogo,#opMenu .op-top img{cursor:pointer}#navLogo:focus-visible,#opMenu .op-top img:focus-visible{outline:2px solid #f97316;outline-offset:3px}</style>
<script id="logo-home-js">(function(){
function goHome(){
var v=document.querySelector('#adminView:not(.hidden)')||document.querySelector('#empView:not(.hidden)');
var m=document.getElementById('opMenu');
if(m&&m.classList.contains('open')){var c=document.getElementById('opMenuClose');if(c)c.click();}
if(v){
var tabs=[].slice.call(v.querySelectorAll('.nav-tab-btn')).filter(function(b){return b.style.display!=='none';});
if(tabs[0])tabs[0].click();
}
window.scrollTo({top:0,behavior:'smooth'});
}
function bind(el){
if(!el||el.dataset.homeBound)return;el.dataset.homeBound='1';
el.setAttribute('role','link');el.setAttribute('tabindex','0');el.setAttribute('aria-label','Go to home page');
el.addEventListener('click',goHome);
el.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();goHome();}});
}
function init(){bind(document.getElementById('navLogo'));bind(document.querySelector('#opMenu .op-top img'));}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
setTimeout(init,600);
})();
</script>
<style id="strong-pass-style">.sp-box{margin:6px 0 10px;font-size:12px;color:#475569}.sp-bar{height:5px;border-radius:99px;background:#e2e8f0;overflow:hidden}.sp-bar i{display:block;height:100%;width:0;border-radius:99px;transition:width .2s,background .2s}.sp-row{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:5px;flex-wrap:wrap}.sp-btn{border:1px solid #cbd5e1;background:#fff;color:#0f172a;border-radius:8px;padding:5px 10px;font-size:12px;font-weight:700;cursor:pointer}.sp-btn:focus-visible{outline:2px solid #f97316;outline-offset:2px}.sp-tip{margin-top:4px;color:#64748b}</style>
<script id="strong-pass-js">(function(){
var IDS=['forgotNewPass','aPass','paPass','ctPass','sCtPass'];
var U='ABCDEFGHJKLMNPQRSTUVWXYZ',L='abcdefghijkmnpqrstuvwxyz',D='23456789',S='@#$%&*!?';
function rnd(n){var a=new Uint32Array(1),lim=Math.floor(4294967296/n)*n,x;do{crypto.getRandomValues(a);x=a[0];}while(x>=lim);return x%n;}
function pick(s){return s.charAt(rnd(s.length));}
function generate(){
var c=[pick(U),pick(U),pick(L),pick(L),pick(L),pick(L),pick(D),pick(D),pick(S)],all=U+L+D+S;
while(c.length<14)c.push(pick(all));
for(var i=c.length-1;i>0;i--){var j=rnd(i+1),t=c[i];c[i]=c[j];c[j]=t;}
return c.join('');
}
function score(p){
if(!p)return 0;var s=0;
if(p.length>=8)s++;if(p.length>=12)s++;
if(/[a-z]/.test(p)&&/[A-Z]/.test(p))s++;
if(/\d/.test(p))s++;if(/[^A-Za-z0-9]/.test(p))s++;
if(/^(.)\1+$/.test(p)||/^(123456|password|qwerty|abc123|111111|000000)/i.test(p))s=Math.min(s,1);
return Math.min(s,5);
}
var LV=[['','#e2e8f0','0%'],['Too weak','#e11d48','20%'],['Weak','#f97316','40%'],['Fair','#eab308','60%'],['Strong','#22c55e','80%'],['Very strong','#059669','100%']];
function set(inp,val){
var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');d.set.call(inp,val);
inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}));
}
function attach(id){
var inp=document.getElementById(id);if(!inp||inp.dataset.spReady)return;inp.dataset.spReady='1';
var box=document.createElement('div');box.className='sp-box';
box.innerHTML='<div class="sp-bar"><i></i></div><div class="sp-row"><span class="sp-lbl" aria-live="polite"></span><span><button type="button" class="sp-btn sp-copy" style="display:none">Copy</button> <button type="button" class="sp-btn sp-gen">Suggest strong password</button></span></div><div class="sp-tip">Use 12+ characters with upper and lower case letters, numbers and symbols.</div>';
var anchor=inp.closest('.password-wrap')||inp;anchor.insertAdjacentElement('afterend',box);
var bar=box.querySelector('i'),lbl=box.querySelector('.sp-lbl'),copy=box.querySelector('.sp-copy');
function paint(){var v=LV[score(inp.value)];bar.style.width=v[2];bar.style.background=v[1];lbl.textContent=v[0]?'Strength: '+v[0]:'';copy.style.display=inp.value?'':'none';}
inp.addEventListener('input',paint);paint();
box.querySelector('.sp-gen').addEventListener('click',function(){
var p=generate();set(inp,p);
if(id==='forgotNewPass'){var cf=document.getElementById('forgotConfirmPass');if(cf)set(cf,p);}
inp.type='text';var eye=(inp.closest('.password-wrap')||document).querySelector('.password-toggle');if(eye){eye.innerHTML='🙈';eye.setAttribute('aria-label','Hide password');eye.title='Hide password';}
paint();
});
copy.addEventListener('click',function(){
var v=inp.value;function done(){copy.textContent='Copied';setTimeout(function(){copy.textContent='Copy';},1500);}
if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(v).then(done,function(){inp.select();document.execCommand('copy');done();});
else{inp.select();document.execCommand('copy');done();}
});
}
function init(){IDS.forEach(attach);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(init,300);});else setTimeout(init,300);
setTimeout(init,1200);
})();
</script>
<style id="spending-dash-style">#tab-spending .sd-filters{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;margin-bottom:16px}#tab-spending .sd-filters .form-group{margin:0;min-width:130px;flex:1}#tab-spending .sd-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:18px}#tab-spending .sd-kpi{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:14px 16px;border-top:4px solid var(--c,#0f3f7a)}#tab-spending .sd-kpi span{display:block;font-size:11px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:#64748b}#tab-spending .sd-kpi strong{display:block;font-size:20px;margin-top:4px;color:var(--c,#0f3f7a);word-break:break-word}#tab-spending .sd-stack{display:flex;height:14px;border-radius:99px;overflow:hidden;background:#e2e8f0;margin:8px 0 10px}#tab-spending .sd-stack i{display:block;height:100%}#tab-spending .sd-legend{display:flex;flex-wrap:wrap;gap:6px 14px;font-size:12px;color:#334155}#tab-spending .sd-legend b{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px}#tab-spending .sd-sites{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}#tab-spending .sd-site{background:#fff;border:1px solid #e5e7eb;border-radius:20px;padding:16px}#tab-spending .sd-site h4{margin:0;font-size:16px;word-break:break-word}#tab-spending .sd-site .sd-total{font-size:22px;font-weight:900;color:#0f3f7a;margin:4px 0 2px}#tab-spending .sd-share{font-size:12px;color:#64748b}#tab-spending .sd-line{display:flex;justify-content:space-between;gap:10px;font-size:13px;margin-top:10px}#tab-spending .sd-line em{font-style:normal;font-weight:800}#tab-spending .sd-bar{height:6px;border-radius:99px;background:#eef2f7;margin-top:4px;overflow:hidden}#tab-spending .sd-bar i{display:block;height:100%;border-radius:99px}#tab-spending details{margin-top:12px;border-top:1px solid #eef2f7;padding-top:8px}#tab-spending summary{cursor:pointer;font-size:12px;font-weight:800;color:#4338ca;padding:6px 0}#tab-spending .sd-det{font-size:12px;color:#334155}#tab-spending .sd-det h5{margin:10px 0 4px;font-size:11px;letter-spacing:.5px;text-transform:uppercase;color:#64748b}#tab-spending .sd-det div{display:flex;justify-content:space-between;gap:10px;padding:3px 0;border-bottom:1px dashed #eef2f7}#tab-spending .sd-table-wrap{overflow-x:auto}#tab-spending table.sd-t{width:100%;border-collapse:collapse;font-size:13px;min-width:520px}#tab-spending .sd-t th,#tab-spending .sd-t td{padding:9px 8px;border-bottom:1px solid #eef2f7;text-align:right}#tab-spending .sd-t th:first-child,#tab-spending .sd-t td:first-child{text-align:left}#tab-spending .sd-t th{font-size:11px;text-transform:uppercase;letter-spacing:.4px;color:#64748b}#tab-spending .sd-t tfoot td{font-weight:900;border-top:2px solid #cbd5e1}#tab-spending .sd-note{font-size:12px;color:#64748b;margin:8px 0 0}</style>
<script id="spending-dash-js">(function(){
var MN=['January','February','March','April','May','June','July','August','September','October','November','December'];
var COL={salary:'#4338ca',labour:'#ea580c',cash:'#dc2626',owner:'#7c3aed'};
var LAB={salary:'Employee salary',labour:'Labour payment',cash:'Cash book expenses',owner:'Owner direct payments'};
function money(n){return '₹ '+Number(n||0).toLocaleString('en-IN',{maximumFractionDigits:0});}
function nm(s){s=String(s==null?'':s).trim();return s||'Unassigned';}
function salaryEarned(e,month,year){
var key=e.id+'-'+month+'-'+year,att=(db.attendance||{})[key]||{};
if(!Object.keys(att).length)return 0;
var total=new Date(year,month+1,0).getDate(),pay=0,half=0,late=0,bonus=0;
var cfg=(db.shifts&&db.shifts[e.shift||'shift1'])||(db.shifts&&db.shifts.shift1)||{start:'08:00'};
var sp=(cfg.start||'08:00').split(':'),sm=Number(sp[0])*60+Number(sp[1]);
for(var d=1;d<=total;d++){
var date=new Date(year,month,d),hol=holidayForDate(year,month,d);
if(hol){if(holidayPayableFor(e,year,month,d)){pay++;var st=att[d];if(hol.double_pay&&(st==='P'||st==='H'))bonus+=(st==='P'?1:.5);}}
else if(date.getDay()===0){var a=getAttStatusForDay(e.id,year,month,d-1),b=getAttStatusForDay(e.id,year,month,d+1);if(!(a==='A'&&b==='A'))pay++;}
else{
var s=att[d]||'A';
if(s==='P'){pay++;var ps=(((db.punches||{})[key]||{})[d]||[]).filter(function(p){return p.type==='IN';});
if(ps.length){var m=(ps[0].time||'').match(/(\d+):(\d+)\s*(AM|PM)/i);if(m){var h=Number(m[1])%12+(m[3].toUpperCase()==='PM'?12:0);if(h*60+Number(m[2])>sm+10)late++;}}}
else if(s==='H'){pay+=.5;half++;}
else if(s==='CL'||s==='SL'||s==='OD'){pay++;}
}
}
pay=Math.max(0,pay-Math.floor(half/2)-Math.floor(late/3)*.5);
var r=pay/total,R=function(v){return Math.round((Number(v)||0)*r);};
var master=(+e.basic_rate||0)+(+e.hra_rate||0)+(+e.lta_rate||0)+(+e.special_rate||0)+(+e.mobile_rate||0);
return R(e.basic_rate)+R(e.hra_rate)+R(e.lta_rate)+R(e.special_rate)+R(e.mobile_rate)+Math.round((total?master/total:0)*bonus);
}
function compute(year,month){
var months=month==='all'?[0,1,2,3,4,5,6,7,8,9,10,11]:[Number(month)];
var sites={},emps=[],tot={salary:0,labour:0,cash:0,owner:0};
function S(n){n=nm(n);return sites[n]||(sites[n]={name:n,salary:0,labour:0,cash:0,owner:0,emps:{},cts:{},cats:{}});}
(db.employees||[]).forEach(function(e){
var amt=0,tdm=String(e.termination_date||'').match(/^(\d{4})-(\d{2})/),tdi=(e.terminated&&tdm)?Number(tdm[1])*12+Number(tdm[2])-1:null;months.forEach(function(m){if(tdi!==null&&year*12+m>=tdi)return;amt+=salaryEarned(e,m,year);});
if(!amt)return;
var s=S(e.project);s.salary+=amt;s.emps[e.id]={name:e.name||e.id,amt:amt};tot.salary+=amt;
emps.push({id:e.id,name:e.name||e.id,site:s.name,amt:amt});
});
(db.contractors||[]).forEach(function(c){
var amt=0,days=0;
months.forEach(function(m){
var key=c.id+'-'+m+'-'+year,obj=(db.contractor_attendance||{})[key]||{};
Object.keys(obj).forEach(function(d){var cc=ctDayCounts(key,d);amt+=ctCost(c,cc);days+=ctDayTotal(cc);});
});
if(!amt)return;
var projs=[];
(db.employees||[]).forEach(function(e){
var ids=(e.contractor_ids||[]).map(String),asg=(c.assigned_employee_ids||[]).map(String);
if(ids.indexOf(String(c.id))>-1||asg.indexOf(String(e.id))>-1){var p=nm(e.project);if(projs.indexOf(p)<0)projs.push(p);}
});
if(!projs.length)projs=['Unassigned'];
projs.forEach(function(p){var part=amt/projs.length,s=S(p);s.labour+=part;s.cts[c.id]={name:c.name||c.id,amt:(s.cts[c.id]?s.cts[c.id].amt:0)+part,days:days/projs.length};});
tot.labour+=amt;
});
function inRange(dt){var m=String(dt||'').match(/^(\d{4})-(\d{2})/);return m&&Number(m[1])===year&&(month==='all'||Number(m[2])-1===Number(month));}
(db.cashbook||[]).forEach(function(c){
var x=Number(c.expense)||0;if(x<=0||!inRange(c.date))return;
var s=S(c.project);s.cash+=x;tot.cash+=x;var k=c.category||'Other';s.cats[k]=(s.cats[k]||0)+x;
});
(db.owner_payments||[]).forEach(function(o){
var x=Number(o.amount)||0;if(x<=0||!inRange(o.date))return;
var s=S(o.project);s.owner+=x;tot.owner+=x;
});
var list=Object.keys(sites).map(function(k){var s=sites[k];s.total=s.salary+s.labour+s.cash+s.owner;return s;}).sort(function(a,b){return b.total-a.total;});
return {list:list,tot:tot,grand:tot.salary+tot.labour+tot.cash+tot.owner,emps:emps.sort(function(a,b){return b.amt-a.amt;})};
}
function years(){
var ys={},cy=new Date().getFullYear();ys[cy]=1;
Object.keys(db.attendance||{}).concat(Object.keys(db.contractor_attendance||{})).forEach(function(k){var m=k.match(/-(\d{4})$/);if(m)ys[m[1]]=1;});
(db.cashbook||[]).concat(db.owner_payments||[]).forEach(function(r){var m=String(r.date||'').match(/^(\d{4})/);if(m)ys[m[1]]=1;});
return Object.keys(ys).sort().reverse();
}
var selSite='';
function render(){
var box=document.getElementById('spendingBody');if(!box)return;
var year=Number(document.getElementById('spYear').value),month=document.getElementById('spMonth').value;
var r=compute(year,month),g=r.grand||0;
var pct=function(v,t){return t>0?Math.round(v/t*100):0;};
var kp=[['Total spending',g,'#0f3f7a'],[LAB.salary,r.tot.salary,COL.salary],[LAB.labour,r.tot.labour,COL.labour],[LAB.cash,r.tot.cash,COL.cash],[LAB.owner,r.tot.owner,COL.owner]];
var h='<div class="sd-kpis">'+kp.map(function(k){return '<div class="sd-kpi" style="--c:'+k[2]+'"><span>'+k[0]+'</span><strong>'+money(k[1])+'</strong></div>';}).join('')+'</div>';
h+='<div class="card" style="padding:18px"><strong>Where the money went</strong><div class="sd-stack">'+['salary','labour','cash','owner'].map(function(k){return '<i style="width:'+pct(r.tot[k],g)+'%;background:'+COL[k]+'"></i>';}).join('')+'</div><div class="sd-legend">'+['salary','labour','cash','owner'].map(function(k){return '<span><b style="background:'+COL[k]+'"></b>'+LAB[k]+' '+pct(r.tot[k],g)+'%</span>';}).join('')+'</div></div>';
h+='<h3 style="margin:22px 0 10px">Site-wise dashboard</h3>';
if(!r.list.length)h+='<p style="color:#64748b">No spending recorded for this period.</p>';
else{
var names=r.list.map(function(x){return x.name;});
if(names.indexOf(selSite)<0)selSite=names[0];
h+='<div class="form-group" style="max-width:420px"><label for="spSite">Select site</label><select id="spSite" onchange="spPickSite(this.value)">'+r.list.map(function(x){return '<option value="'+escapeHTML(x.name)+'"'+(x.name===selSite?' selected':'')+'>'+escapeHTML(x.name)+' — '+money(x.total)+'</option>';}).join('')+'</select></div>';
var s=r.list.filter(function(x){return x.name===selSite;})[0];
h+='<div class="sd-sites">'+(function(s){
var lines=['salary','labour','cash','owner'].map(function(k){return '<div><div class="sd-line"><span>'+LAB[k]+'</span><em>'+money(s[k])+'</em></div><div class="sd-bar"><i style="width:'+pct(s[k],s.total)+'%;background:'+COL[k]+'"></i></div></div>';}).join('');
var det='';
var ek=Object.keys(s.emps);if(ek.length)det+='<h5>Salary</h5>'+ek.map(function(i){return '<div><span>'+escapeHTML(s.emps[i].name)+' ['+escapeHTML(i)+']</span><b>'+money(s.emps[i].amt)+'</b></div>';}).join('');
var ck=Object.keys(s.cts);if(ck.length)det+='<h5>Labour</h5>'+ck.map(function(i){return '<div><span>'+escapeHTML(s.cts[i].name)+' · '+Math.round(s.cts[i].days*10)/10+' worker-days</span><b>'+money(s.cts[i].amt)+'</b></div>';}).join('');
var ct=Object.keys(s.cats);if(ct.length)det+='<h5>Cash book by category</h5>'+ct.sort(function(a,b){return s.cats[b]-s.cats[a];}).map(function(i){return '<div><span>'+escapeHTML(i)+'</span><b>'+money(s.cats[i])+'</b></div>';}).join('');
return '<div class="sd-site"><h4>'+escapeHTML(s.name)+'</h4><div class="sd-total">'+money(s.total)+'</div><div class="sd-share">'+pct(s.total,g)+'% of total spending</div>'+lines+(det?'<details open><summary>Details</summary><div class="sd-det">'+det+'</div></details>':'')+'</div>';
})(s)+'</div>';
}
if(r.emps.length){
h+='<div class="card" style="margin-top:18px;padding:18px"><strong>Employee salary</strong><div class="sd-table-wrap"><table class="sd-t"><thead><tr><th>Employee</th><th>Site</th><th>Salary earned</th></tr></thead><tbody>'
+r.emps.map(function(e){return '<tr><td>'+escapeHTML(e.name)+' ['+escapeHTML(e.id)+']</td><td style="text-align:right">'+escapeHTML(e.site)+'</td><td>'+money(e.amt)+'</td></tr>';}).join('')+'</tbody></table></div></div>';
}
h+='<p class="sd-note">Salary = gross earned per the payslip rules (attendance, holidays, half-day and late adjustments), counted only for months with attendance recorded, and charged to the employee\'s current project. Employees are not counted from their termination month onward. Labour = contractor attendance × rates, split across the sites of the employees linked to that contractor (Unassigned if none). Cash book counts expenses only, not cash received.</p>';
box.innerHTML=h;
}
window.initSpendingDashboard=function(){
var y=document.getElementById('spYear'),m=document.getElementById('spMonth');if(!y||!m)return;
var keepY=y.value,keepM=m.value,now=new Date();
y.innerHTML=years().map(function(v){return '<option value="'+v+'">'+v+'</option>';}).join('');
m.innerHTML='<option value="all">Full year</option>'+MN.map(function(n,i){return '<option value="'+i+'">'+n+'</option>';}).join('');
y.value=keepY&&[].some.call(y.options,function(o){return o.value===keepY;})?keepY:String(now.getFullYear());
m.value=keepM||String(now.getMonth());
render();
};
window.renderSpendingDashboard=render;
window.spPickSite=function(v){selSite=v;render();};
})();
</script>
<style id="labour-bill-style">
.bill-modal-body iframe{min-height:60vh}
.lb-tiles{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:12px 0}
.lb-tile{border-radius:14px;padding:10px 10px;background:#f8fafc;border:1px solid var(--border);min-width:0}
.lb-tile small{display:block;font-size:10px;font-weight:800;color:#64748b;text-transform:uppercase;letter-spacing:.3px}
.lb-tile b{display:block;font-size:15px;margin-top:3px;word-break:break-word}
.lb-tile.paid b{color:#059669}.lb-tile.bal b{color:#e11d48}.lb-tile.adv b{color:#4f46e5}
.lb-week{border:1px solid var(--border);border-radius:16px;padding:12px;margin:12px 0;background:#fff}
.lb-week-head{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;font-weight:800;font-size:13px}
.lb-badge{font-size:10px;font-weight:800;border-radius:999px;padding:3px 9px;white-space:nowrap}
.lb-b-paid{background:#d1fae5;color:#047857}.lb-b-part{background:#fef3c7;color:#b45309}.lb-b-unpaid{background:#ffe4e6;color:#be123c}.lb-b-adv{background:#e0e7ff;color:#4338ca}.lb-b-none{background:#f1f5f9;color:#64748b}
.lb-rows{margin-top:8px;font-size:12px}
.lb-rows div{display:flex;justify-content:space-between;gap:10px;padding:4px 0;border-bottom:1px dashed #e2e8f0}
.lb-rows div:last-child{border-bottom:0}
.lb-rows .tot{font-weight:800}.lb-rows .carry{font-weight:800;color:#be123c}.lb-rows .carry.ok{color:#059669}
.lb-note{font-size:11px;color:#64748b;margin-top:6px}
.lb-pay{margin-top:8px;padding:8px 10px;border-radius:12px;background:#f0fdf4;border:1px solid #bbf7d0;font-size:12px}
.lb-pay-top{display:flex;justify-content:space-between;gap:8px;font-weight:800}
.lb-pay-meta{color:#64748b;font-size:11px;margin-top:2px;word-break:break-word}
.lb-pay-act{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.lb-link{border:1px solid #cbd5e1;background:#fff;border-radius:9px;padding:5px 9px;font-size:11px;font-weight:800;cursor:pointer;color:#0f172a}
.lb-link.danger{color:#be123c;border-color:#fecdd3}
.lb-form{border:2px dashed #c7d2fe;border-radius:16px;padding:14px;margin:12px 0}
.lb-muted{color:#64748b;font-size:12px}
.lb-pane-tabs{display:flex;gap:8px;margin:0 0 14px}
.lb-pane-tabs button{flex:1;border:1px solid #cbd5e1;background:#fff;border-radius:12px;padding:10px;font-weight:800;font-size:13px;cursor:pointer}
.lb-pane-tabs button.active{background:var(--primary);color:#fff;border-color:var(--primary)}
</style>
<script id="labour-bill-js">
(function(){
const MODES=['Cash','UPI','Bank Transfer','Cheque','Other'];
const r2=n=>Math.round((Number(n)||0)*100)/100;
const money=n=>'₹ '+formatINR(Math.abs(n));
const pad=n=>String(n).padStart(2,'0');
const ds=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const pd=s=>{const a=String(s).split('-').map(Number);return new Date(a[0],a[1]-1,a[2]);};
const mondayOf=d=>{const x=new Date(d.getFullYear(),d.getMonth(),d.getDate());x.setDate(x.getDate()-((x.getDay()+6)%7));return x;};
const addDays=(d,n)=>new Date(d.getFullYear(),d.getMonth(),d.getDate()+n);
const short=d=>pad(d.getDate())+'/'+pad(d.getMonth()+1);
function weekLabel(mon){const m=pd(mon),e=addDays(m,6);return short(m)+' – '+short(e)+'/'+e.getFullYear();}
const limits={lb:8,slb:8,clb:8};
function payments(){return Array.isArray(db.contractor_payments)?db.contractor_payments:[];}

function weekBill(c,mon){
let t=0;const m=pd(mon);
for(let i=0;i<7;i++){const d=addDays(m,i);t+=ctCost(c,ctDayCounts(c.id+'-'+d.getMonth()+'-'+d.getFullYear(),d.getDate()));}
return r2(t);
}
/* Builds the running weekly ledger: each week = brought-forward + this week's bill - paid; the remainder is
   carried into the next week automatically. */
function ledger(c){
const set=new Set(),prefix=c.id+'-',att=db.contractor_attendance||{};
Object.keys(att).forEach(k=>{
if(k.indexOf(prefix)!==0)return;
const rest=k.slice(prefix.length).split('-');if(rest.length!==2)return;
const m=Number(rest[0]),y=Number(rest[1]);if(isNaN(m)||isNaN(y))return;
Object.keys(att[k]||{}).forEach(dn=>{const d=Number(dn),cc=ctDayCounts(k,d);if(ctDayTotal(cc)>0||ctDayOTTotal(cc)>0)set.add(ds(mondayOf(new Date(y,m,d))));});
});
const mine=payments().filter(x=>String(x.contractor_id)===String(c.id));
mine.forEach(x=>{if(x.week_start)set.add(x.week_start);});
const cur=mondayOf(new Date());set.add(ds(cur));
const sorted=[...set].sort();
let a=pd(sorted[0]);const z=pd(sorted[sorted.length-1]);
const rows=[];let carry=0,totalBill=0,totalPaid=0;
for(let guard=0;a<=z&&guard<1500;guard++,a=addDays(a,7)){
const wk=ds(a),bill=weekBill(c,wk),pays=mine.filter(x=>x.week_start===wk).sort((x,y)=>String(x.paid_date).localeCompare(String(y.paid_date))||String(x.created_at).localeCompare(String(y.created_at)));
const paid=r2(pays.reduce((s,x)=>s+(Number(x.amount)||0),0)),opening=r2(carry),payable=r2(opening+bill),closing=r2(payable-paid);
rows.push({week:wk,label:weekLabel(wk),opening,bill,payable,paid,closing,pays});
carry=closing;totalBill+=bill;totalPaid+=paid;
}
return{rows,totalBill:r2(totalBill),totalPaid:r2(totalPaid),balance:r2(totalBill-totalPaid)};
}
function status(w){
if(w.closing<-0.005)return['Advance paid','lb-b-adv'];
if(w.payable<=0.005&&w.paid<=0.005)return['No dues','lb-b-none'];
if(w.closing<=0.005)return['Paid in full','lb-b-paid'];
if(w.paid>0.005)return['Part paid','lb-b-part'];
return['Unpaid','lb-b-unpaid'];
}
function myContractors(p){
const all=db.contractors||[];
if(p==='lb')return all;
if(p==='slb'){const id=String(sessionUser&&sessionUser.id||''),u=String(sessionUser&&sessionUser.user||'');return all.filter(c=>(c.assigned_employee_ids||[]).map(String).includes(id)||(u&&String(c.created_by||'')===u));}
return sessionContractor?all.filter(c=>String(c.id)===String(sessionContractor.id)):[];
}
function current(p){
if(p==='clb')return sessionContractor?((db.contractors||[]).find(c=>String(c.id)===String(sessionContractor.id))||sessionContractor):null;
const sel=document.getElementById(p+'Sel');const id=sel?sel.value:'';
return myContractors(p).find(c=>String(c.id)===String(id))||null;
}
function fillSelector(p){
const sel=document.getElementById(p+'Sel');if(!sel)return;
const list=myContractors(p),prev=sel.value;
sel.innerHTML=list.map(c=>'<option value="'+escapeHTML(c.id)+'">'+escapeHTML(c.name||'')+' ['+escapeHTML(c.id||'')+']</option>').join('');
if(prev&&list.some(c=>String(c.id)===String(prev)))sel.value=prev;
}
function tilesHTML(L){
const bal=L.balance;
return '<div class="lb-tiles"><div class="lb-tile"><small>Total Bill</small><b>'+money(L.totalBill)+'</b></div>'
+'<div class="lb-tile paid"><small>Paid</small><b>'+money(L.totalPaid)+'</b></div>'
+'<div class="lb-tile '+(bal<-0.005?'adv':'bal')+'"><small>'+(bal<-0.005?'Advance':'Balance')+'</small><b>'+money(bal)+'</b></div></div>';
}
function imgButtons(x,p,editable){
let h='';
if(x.image_url)h+='<button class="lb-link" type="button" onclick="labourViewImage(\''+escapeHTML(x.id)+'\')">📎 View image</button>';
if(editable){
h+='<button class="lb-link" type="button" onclick="labourPickImage(\''+escapeHTML(x.id)+'\',\''+p+'\')">'+(x.image_url?'♻ Replace image':'📷 Add image')+'</button>';
if(x.image_url)h+='<button class="lb-link danger" type="button" onclick="labourRemoveImage(\''+escapeHTML(x.id)+'\',\''+p+'\')">Remove image</button>';
h+='<button class="lb-link danger" type="button" onclick="labourDeletePayment(\''+escapeHTML(x.id)+'\',\''+p+'\')">🗑 Delete</button>';
}
return h?'<div class="lb-pay-act">'+h+'</div>':'';
}
function weekHTML(w,p,editable){
const st=status(w);
let h='<div class="lb-week"><div class="lb-week-head"><span>📅 '+escapeHTML(w.label)+'</span><span class="lb-badge '+st[1]+'">'+st[0]+'</span></div><div class="lb-rows">';
h+='<div><span>Balance brought forward</span><span>'+(w.opening<-0.005?'- ':'')+money(w.opening)+'</span></div>';
h+='<div><span>This week labour bill</span><span>'+money(w.bill)+'</span></div>';
h+='<div class="tot"><span>Total payable</span><span>'+(w.payable<-0.005?'- ':'')+money(w.payable)+'</span></div>';
h+='<div><span>Paid this week</span><span style="color:#059669;font-weight:800">'+money(w.paid)+'</span></div>';
h+='<div class="carry '+(w.closing<=0.005?'ok':'')+'"><span>'+(w.closing<-0.005?'Advance carried to next week':'Balance carried to next week')+'</span><span>'+money(w.closing)+'</span></div></div>';
w.pays.forEach(x=>{
h+='<div class="lb-pay"><div class="lb-pay-top"><span>'+money(x.amount)+'</span><span>'+escapeHTML(String(x.paid_date||'').split('-').reverse().join('/'))+'</span></div>'
+'<div class="lb-pay-meta">'+escapeHTML(x.mode||'Cash')+(x.note?' • '+escapeHTML(x.note):'')+'</div>'+imgButtons(x,p,editable)+'</div>';
});
return h+'</div>';
}
function formHTML(p,L){
const def=[...L.rows].reverse().find(w=>w.closing>0.005)||L.rows[L.rows.length-1];
const opts=[...L.rows].reverse().map(w=>'<option value="'+w.week+'"'+(w.week===def.week?' selected':'')+'>'+escapeHTML(w.label)+'  •  due ₹ '+formatINR(Math.max(0,r2(w.payable-w.paid)))+'</option>').join('');
return '<div class="lb-form"><h4 style="margin:0 0 4px">➕ Record Payment</h4><div class="lb-note" style="margin:0 0 10px">If only part is paid, the remaining balance is added to the next week automatically.</div><div class="grid">'
+'<div class="form-group"><label>Week</label><select id="'+p+'Week" onchange="labourWeekChanged(\''+p+'\')">'+opts+'</select></div>'
+'<div class="form-group"><label>Amount Paid (₹)</label><input id="'+p+'Amt" type="number" min="0" step="0.01" inputmode="decimal"></div>'
+'<div class="form-group"><label>Paid On</label><input id="'+p+'Date" type="date" value="'+ds(new Date())+'"></div>'
+'<div class="form-group"><label>Mode</label><select id="'+p+'Mode">'+MODES.map(m=>'<option>'+m+'</option>').join('')+'</select></div>'
+'<div class="form-group"><label>Note / Reference</label><input id="'+p+'Note" maxlength="300" placeholder="UTR / cheque no. / remarks"></div>'
+'<div class="form-group"><label>Reference Image (optional)</label><input id="'+p+'File" type="file" accept="image/jpeg,image/png,image/webp,application/pdf"></div>'
+'</div><div id="'+p+'Due" class="lb-note"></div><button id="'+p+'SaveBtn" class="btn btn-save" type="button" style="width:100%;margin-top:10px" onclick="labourSave(\''+p+'\')">Save Payment</button></div>';
}
function render(p){
const body=document.getElementById(p+'Body');if(!body)return;
const c=current(p);
if(!c){body.innerHTML='<p class="lb-muted">No contractor available.</p>';if(p==='clb')renderBanner(null);return;}
const L=ledger(c),editable=p!=='clb';
let h=tilesHTML(L);
if(editable)h+=formHTML(p,L);
h+='<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h4 style="margin:6px 0">Week-wise Bill &amp; Payments</h4><span style="display:flex;gap:6px"><button class="lb-link" type="button" onclick="labourPDF(\''+p+'\')">⬇ PDF</button><button class="lb-link" type="button" onclick="labourDownload(\''+p+'\')">⬇ CSV</button></span></div>';
const rev=[...L.rows].reverse(),lim=limits[p]||8;
h+=rev.slice(0,lim).map(w=>weekHTML(w,p,editable)).join('');
if(rev.length>lim)h+='<button class="btn" type="button" style="width:100%" onclick="labourMore(\''+p+'\')">Show older weeks ('+(rev.length-lim)+' more)</button>';
body.innerHTML=h;
if(editable)labourWeekChanged(p);
if(p==='clb')renderBanner(L);
}
function renderBanner(L){
const b=document.getElementById('cpPayBanner');if(!b)return;
b.innerHTML=L?'<div class="card" style="padding:14px"><div style="font-weight:800;font-size:13px">💰 Labour Payment Summary</div>'+tilesHTML(L)+'</div>':'';
}
window.renderLabourBill=async function(p,fresh){
if(fresh&&typeof refreshPortalDatabase==='function')await refreshPortalDatabase();
if(p!=='clb')fillSelector(p);
render(p);
};
window.labourMore=function(p){limits[p]=(limits[p]||8)+8;render(p);};
window.labourWeekChanged=function(p){
const c=current(p);if(!c)return;
const L=ledger(c),sel=document.getElementById(p+'Week');if(!sel)return;
const w=L.rows.find(x=>x.week===sel.value);if(!w)return;
const due=Math.max(0,r2(w.payable-w.paid));
const amt=document.getElementById(p+'Amt');if(amt)amt.value=due>0?due:'';
const d=document.getElementById(p+'Due');
if(d)d.textContent='Payable this week ₹ '+formatINR(w.payable)+'  |  Already paid ₹ '+formatINR(w.paid)+'  |  Still due ₹ '+formatINR(due);
};
window.labourSave=async function(p){
const c=current(p);if(!c)return;
const week=document.getElementById(p+'Week').value,amount=r2(document.getElementById(p+'Amt').value),date=document.getElementById(p+'Date').value;
if(!(amount>0)){alert('Enter the amount paid.');return;}
if(!date){alert('Select the payment date.');return;}
const w=ledger(c).rows.find(x=>x.week===week);
if(w){const due=Math.max(0,r2(w.payable-w.paid));
if(amount>due+0.005&&!confirm('Amount ₹ '+formatINR(amount)+' is more than the ₹ '+formatINR(due)+' due for this week. The extra will be carried to the next week as an advance. Continue?'))return;}
const btn=document.getElementById(p+'SaveBtn');
const fileEl=document.getElementById(p+'File');let bill=null;
if(fileEl&&fileEl.files&&fileEl.files[0]){bill=await readCashBillFile(fileEl.files[0]);if(!bill)return;}
if(btn){btn.disabled=true;btn.textContent='Saving…';}
const r=await server('save_contractor_payment',{contractor_id:c.id,week_start:week,amount,paid_date:date,mode:document.getElementById(p+'Mode').value,note:document.getElementById(p+'Note').value.trim(),bill_data:bill?bill.data:'',bill_name:bill?bill.name:''});
if(btn){btn.disabled=false;btn.textContent='Save Payment';}
if(r.status==='success'&&r.record){if(!Array.isArray(db.contractor_payments))db.contractor_payments=[];db.contractor_payments.push(r.record);render(p);}
alert(r.message);
};
window.labourDeletePayment=async function(id,p){
if(!confirm('Delete this payment? Its reference image will also be deleted and the balance will be recalculated.'))return;
const r=await server('delete_contractor_payment',{id});
if(r.status==='success'){db.contractor_payments=payments().filter(x=>String(x.id)!==String(id));render(p);}
alert(r.message);
};
window.labourRemoveImage=async function(id,p){
if(!confirm('Remove the reference image from this payment? It will be permanently deleted.'))return;
const r=await server('update_contractor_payment_image',{id,remove:true});
if(r.status==='success'&&r.record){const i=payments().findIndex(x=>String(x.id)===String(id));if(i>=0)db.contractor_payments[i]=r.record;render(p);}
alert(r.message);
};
window.labourPickImage=function(id,p){
let inp=document.getElementById('lbImgPicker');
if(!inp){inp=document.createElement('input');inp.type='file';inp.id='lbImgPicker';inp.accept='image/jpeg,image/png,image/webp,application/pdf';inp.style.display='none';document.body.appendChild(inp);}
inp.value='';
inp.onchange=async()=>{
const f=inp.files&&inp.files[0];if(!f)return;
const x=payments().find(y=>String(y.id)===String(id));
if(x&&x.image_url&&!confirm('Replace the existing image? The old image will be permanently deleted.')){inp.value='';return;}
const bill=await readCashBillFile(f);if(!bill){inp.value='';return;}
const r=await server('update_contractor_payment_image',{id,bill_data:bill.data,bill_name:bill.name});
inp.value='';
if(r.status==='success'&&r.record){const i=payments().findIndex(y=>String(y.id)===String(id));if(i>=0)db.contractor_payments[i]=r.record;render(p);}
alert(r.message);
};
inp.click();
};

/* PDF bills: phones / the Android app cannot show a PDF inside an iframe, and Cloudinary may block raw PDF delivery.
   So a Cloudinary PDF is shown as page images (page 1 first, with Prev / Next) plus an "Open PDF" button; any other PDF
   falls back to the normal embedded viewer plus the same button. */
window.pdfViewerHTML=function(src,title){
const safe=escapeHTML(src),m=String(src).match(/^(https?:\/\/res\.cloudinary\.com\/[^\/]+\/(?:image|raw)\/upload\/)(.+?)(\.pdf)?(\?.*)?$/i);
const open='<a class="lb-link" style="display:inline-block;text-decoration:none" href="'+safe+'" target="_blank" rel="noopener">⬇ Open / Download PDF</a>';
if(!m||/\/raw\/upload\//i.test(src))return '<iframe src="'+safe+'" title="'+escapeHTML(title)+'"></iframe><div style="padding:10px;text-align:center">'+open+'</div>';
const id='pdfv'+Math.random().toString(36).slice(2,8);
window.__pdfv=window.__pdfv||{};window.__pdfv[id]={base:m[1],rest:m[2],page:1};
setTimeout(function(){const im=document.getElementById(id+'Img');if(im)im.src=window.pdfPageUrl(id);},0);
return '<div style="text-align:center;padding:6px"><img id="'+id+'Img" alt="'+escapeHTML(title)+'" style="max-width:100%;background:#fff" onerror="pdfPageFail(\''+id+'\')">'
+'<div style="display:flex;gap:8px;justify-content:center;align-items:center;flex-wrap:wrap;margin:10px 0"><button type="button" class="lb-link" onclick="pdfPage(\''+id+'\',-1)">◀ Prev</button><b id="'+id+'Pg" style="font-size:12px">Page 1</b><button type="button" class="lb-link" onclick="pdfPage(\''+id+'\',1)">Next ▶</button>'+open+'</div></div>';
};
window.pdfPageUrl=function(id){const v=window.__pdfv[id];return v.base+'pg_'+v.page+',f_jpg,w_1400/'+v.rest+'.jpg';};
window.pdfPage=function(id,d){const v=window.__pdfv[id];if(!v)return;const n=v.page+d;if(n<1)return;v.prev=v.page;v.page=n;document.getElementById(id+'Pg').textContent='Page '+n;document.getElementById(id+'Img').src=window.pdfPageUrl(id);};
window.pdfPageFail=function(id){const v=window.__pdfv[id];if(!v)return;if(v.page>1&&v.prev){v.page=v.prev;v.prev=0;document.getElementById(id+'Pg').textContent='Page '+v.page+' (last page)';document.getElementById(id+'Img').src=window.pdfPageUrl(id);}else{const im=document.getElementById(id+'Img');if(im)im.outerHTML='<p style="padding:20px;font-size:13px">Preview not available — use Open / Download PDF.</p>';}};
window.labourViewImage=function(id){
const x=payments().find(y=>String(y.id)===String(id));
if(!x||!x.image_url){alert('No image was uploaded for this payment.');return;}
const old=document.querySelector('.bill-modal');if(old)old.remove();
const src=String(x.image_url),isPdf=(String(x.image_type||'').toLowerCase()==='application/pdf'||/\.pdf($|[?#])/i.test(src));
const body=isPdf?window.pdfViewerHTML(src,'Payment reference'):'<img src="'+escapeHTML(src)+'" alt="Payment reference">';
const m=document.createElement('div');m.className='bill-modal';
m.innerHTML='<div class="bill-modal-box"><div class="bill-modal-head"><div class="bill-modal-title">'+escapeHTML(x.image_name||'Payment reference')+'</div><button class="bill-modal-close" type="button" aria-label="Close">×</button></div><div class="bill-modal-body">'+body+'</div></div>';
m.querySelector('.bill-modal-close').onclick=()=>m.remove();
m.addEventListener('click',e=>{if(e.target===m)m.remove();});
document.body.appendChild(m);
};
window.labourPDF=function(p){
const c=current(p);if(!c)return;
if(!window.jspdf||!window.jspdf.jsPDF){alert('PDF library failed to load. Please check your internet connection and try again.');return;}
const L=ledger(c),doc=new window.jspdf.jsPDF({orientation:'portrait',unit:'mm',format:'a4',compress:true});
const DAYS=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const dmy=str=>{const a=String(str||'').split('-').map(Number);if(a.length!==3||a.some(isNaN))return String(str||'');const d=new Date(a[0],a[1]-1,a[2]);return pad(a[2])+'/'+pad(a[1])+'/'+a[0]+' ('+DAYS[d.getDay()]+')';};
const inr=n=>'Rs. '+(n<-0.005?'-':'')+formatINR(Math.abs(n));
const fm=n=>(n<-0.005?'-':'')+formatINR(Math.abs(n));
const W=210,M=12,R=W-M;let y=0;
const co=(db.company&&db.company.name)||'',addr=(db.company&&db.company.addr)||'';
function header(){
doc.setFont('helvetica','bold');doc.setFontSize(14);doc.setTextColor(15,23,42);doc.text(co||'Contractor Payment Statement',W/2,14,{align:'center'});
doc.setFont('helvetica','normal');doc.setFontSize(8);doc.setTextColor(100,116,139);if(addr)doc.text(String(addr),W/2,19,{align:'center',maxWidth:W-2*M});
doc.setDrawColor(203,213,225);doc.line(M,22,R,22);y=28;
}
function newPage(){doc.addPage();header();}
function need(h){if(y+h>285){newPage();return true;}return false;}
header();
doc.setFont('helvetica','bold');doc.setFontSize(13);doc.setTextColor(15,23,42);doc.text('CONTRACTOR PAYMENT DETAILS',M,y);y+=7;
const now=new Date();
doc.setFont('helvetica','normal');doc.setFontSize(10);doc.setTextColor(30,41,59);
doc.text('Contractor: '+String(c.name||'')+'  ['+String(c.id||'')+']',M,y);
doc.text('Generated: '+dmy(ds(now)),R,y,{align:'right'});y+=6;
// summary boxes
const bw=(R-M-8)/3,bal=L.balance,boxes=[['Total Bill',inr(L.totalBill),[241,245,249],[15,23,42]],['Total Paid',inr(L.totalPaid),[236,253,245],[5,150,105]],[bal<-0.005?'Advance':'Balance',inr(bal),bal<-0.005?[239,246,255]:[254,242,242],bal<-0.005?[37,99,235]:[190,18,60]]];
boxes.forEach((b,i)=>{const x=M+i*(bw+4);doc.setFillColor.apply(doc,b[2]);doc.roundedRect(x,y,bw,15,2,2,'F');doc.setFontSize(8);doc.setFont('helvetica','normal');doc.setTextColor(100,116,139);doc.text(b[0],x+3,y+5.5);doc.setFontSize(12);doc.setFont('helvetica','bold');doc.setTextColor.apply(doc,b[3]||[15,23,42]);doc.text(b[1],x+3,y+12);});
y+=22;
// week table
const cols=[['Week (Mon - Sun)',M,0,'left'],['B/F',90,0,'right'],['Week Bill',115,0,'right'],['Payable',140,0,'right'],['Paid',162,0,'right'],['C/F',R,0,'right']];
function tHead(){doc.setFillColor(30,41,59);doc.rect(M,y-4.5,R-M,7,'F');doc.setFont('helvetica','bold');doc.setFontSize(8.5);doc.setTextColor(255,255,255);cols.forEach(c2=>doc.text(c2[0],c2[3]==='left'?c2[1]+1.5:c2[1],y,{align:c2[3]}));y+=6;}
doc.setFont('helvetica','bold');doc.setFontSize(10);doc.setTextColor(15,23,42);doc.text('Week-wise Bill & Payments',M,y);y+=6;
tHead();
const rows=L.rows.filter(w=>w.bill>0.005||w.paid>0.005||Math.abs(w.opening)>0.005||Math.abs(w.closing)>0.005);
rows.forEach((w,i)=>{
const pays=w.pays||[];
const h=7+pays.length*4.6+(pays.some(x=>x.note)?0:0);
if(need(h+2)){tHead();}
if(i%2===0){doc.setFillColor(248,250,252);doc.rect(M,y-4.5,R-M,h-1,'F');}
doc.setFont('helvetica','normal');doc.setFontSize(8.5);doc.setTextColor(30,41,59);
doc.text(w.label,M+1.5,y);
doc.text(fm(w.opening),90,y,{align:'right'});doc.text(fm(w.bill),115,y,{align:'right'});doc.text(fm(w.payable),140,y,{align:'right'});
doc.setTextColor(5,150,105);doc.text(fm(w.paid),162,y,{align:'right'});
doc.setTextColor(w.closing>0.005?190:(w.closing<-0.005?37:30),w.closing>0.005?18:(w.closing<-0.005?99:41),w.closing>0.005?60:(w.closing<-0.005?235:59));doc.setFont('helvetica','bold');doc.text(fm(w.closing),R,y,{align:'right'});
y+=4.6;
doc.setFont('helvetica','normal');doc.setFontSize(7.5);
pays.forEach(x=>{
doc.setTextColor(100,116,139);
doc.text('Paid '+dmy(x.paid_date)+'  |  '+(x.mode||'Cash')+(x.note?'  |  '+String(x.note):''),M+5,y,{maxWidth:130});
doc.setTextColor(5,150,105);doc.text(fm(Number(x.amount)||0),162,y,{align:'right'});
y+=4.6;
});
y+=2.4;
});
need(12);
doc.setDrawColor(15,23,42);doc.line(M,y-3,R,y-3);
doc.setFont('helvetica','bold');doc.setFontSize(9);doc.setTextColor(15,23,42);
doc.text('TOTAL',M+1.5,y+1);doc.text(fm(L.totalBill),115,y+1,{align:'right'});doc.text(fm(L.totalPaid),162,y+1,{align:'right'});doc.text(fm(L.balance),R,y+1,{align:'right'});
y+=8;
doc.setFont('helvetica','italic');doc.setFontSize(7.5);doc.setTextColor(100,116,139);
doc.text('All amounts in Indian Rupees (Rs.). B/F = balance brought forward, C/F = balance carried forward (negative = advance paid).',M,y,{maxWidth:R-M});
// page numbers
const n=doc.getNumberOfPages();
for(let i=1;i<=n;i++){doc.setPage(i);doc.setFont('helvetica','normal');doc.setFontSize(7.5);doc.setTextColor(100,116,139);doc.text('Page '+i+' of '+n,R,291,{align:'right'});}
doc.save(String(c.name||c.id).replace(/[^a-z0-9]+/gi,'_')+'_Payment_Details_'+ds(now)+'.pdf');
};
window.labourDownload=function(p){
const c=current(p);if(!c)return;
const L=ledger(c);
let csv='Week,Balance B/F (Rs),Week Bill (Rs),Total Payable (Rs),Paid (Rs),Balance C/F (Rs),Status\n';
L.rows.forEach(w=>{csv+='"'+w.label+'",'+w.opening.toFixed(2)+','+w.bill.toFixed(2)+','+w.payable.toFixed(2)+','+w.paid.toFixed(2)+','+w.closing.toFixed(2)+','+status(w)[0]+'\n';});
csv+=',,'+L.totalBill.toFixed(2)+',,'+L.totalPaid.toFixed(2)+','+L.balance.toFixed(2)+',TOTAL\n';
const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'})),a=document.createElement('a');
a.href=url;a.download=String(c.name||c.id).replace(/[^a-z0-9]+/gi,'_')+'_Labour_Payment_Statement.csv';
document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);
};
window.cpShowTab=function(which){
const a=document.getElementById('cpAttCard'),b=document.getElementById('cpBillCard');
if(!a||!b)return;
a.classList.toggle('hidden',which!=='att');b.classList.toggle('hidden',which!=='bill');
document.querySelectorAll('#cpPaneTabs button').forEach(x=>x.classList.toggle('active',x.dataset.pane===which));
if(which==='bill')renderLabourBill('clb',true);
};
/* Contractor portal: keep the paid / balance summary fresh whenever the portal redraws. */
if(typeof renderContractorPortal==='function'){
const orig=renderContractorPortal;
renderContractorPortal=async function(){await orig.apply(this,arguments);try{render('clb');}catch(e){}};
}
})();
</script>

<style id="no-auto-refresh-style">.manual-refresh-bar{display:flex;justify-content:flex-end;margin:0 0 10px}.manual-refresh-bar button{border:1px solid #cbd5e1;background:#fff;color:#0f172a;border-radius:10px;padding:8px 14px;font-weight:800;font-size:13px;cursor:pointer}.manual-refresh-bar button:disabled{opacity:.6}@media print{.manual-refresh-bar{display:none!important}}.manual-refresh-bar button:focus-visible{outline:2px solid #f97316;outline-offset:2px}</style>
<script id="no-auto-refresh-js">/* Cash Book Report and Contractor Attendance no longer refresh on a timer.
The other tabs keep their live sync; these two update only when opened or when Refresh is tapped. */
(function(){
var PAUSED={'tab-cashbookReport':function(){return typeof initAdminCashbookReport==='function'&&initAdminCashbookReport();},
'tab-contractorAtt':function(){return typeof renderContractorCalendar==='function'&&renderContractorCalendar();},
'stab-cashbook':function(){return typeof renderStaffCashbook==='function'&&renderStaffCashbook();},
'stab-contractorAtt':function(){return typeof syncContractorsStaff==='function'&&syncContractorsStaff();},
'tab-contractorBill':function(){return typeof renderLabourBill==='function'&&renderLabourBill('lb');},
'stab-contractorBill':function(){return typeof renderLabourBill==='function'&&renderLabourBill('slb');}};
window.noAutoRefreshTab=function(){
for(var id in PAUSED){var el=document.getElementById(id);if(el&&el.classList.contains('active'))return true;}
return false;
};
function addButtons(){
Object.keys(PAUSED).forEach(function(id){
var tab=document.getElementById(id);if(!tab||tab.querySelector('.manual-refresh-bar'))return;
var bar=document.createElement('div');bar.className='manual-refresh-bar';
var b=document.createElement('button');b.type='button';b.textContent='↻ Refresh';
b.addEventListener('click',async function(){
b.disabled=true;b.textContent='Refreshing…';
try{if(typeof refreshPortalDatabase==='function')await refreshPortalDatabase();PAUSED[id]();}catch(e){}
b.disabled=false;b.textContent='↻ Refresh';
});
bar.appendChild(b);tab.insertBefore(bar,tab.firstChild);
});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',addButtons);else addButtons();
})();
</script>


<script>(function(){
var PING=30*1000,last=Date.now(),lastPing=0,fired=false; /* keep authenticated session alive while the app is open */
function loggedIn(){var b=document.getElementById('logoutBtn');return !!b&&!b.classList.contains('hidden');}
function act(){last=Date.now();}
['mousemove','mousedown','keydown','touchstart','scroll','click','wheel'].forEach(function(ev){window.addEventListener(ev,act,{passive:true,capture:true});});
setInterval(function(){
if(!loggedIn()){fired=false;last=Date.now();return;}
var now=Date.now();
if(now-lastPing>=PING){lastPing=now;if(typeof server==='function')server('idle_ping',{});}
},5000);
var checking=false;
function check(){
if(checking||window.__swExpiring||!loggedIn()||typeof server!=='function')return;
checking=true;
Promise.resolve(server('session_check',{})).then(function(){checking=false;},function(){checking=false;});
}
/* Was every 0.7 s per open tab, which got the site throttled by the host with several tabs open. Now every 10 s,
   skipped while the tab is hidden, and run immediately when the tab becomes visible again. */
setInterval(function(){if(!document.hidden)check();},10000);
document.addEventListener('visibilitychange',function(){if(!document.hidden)check();});
try{
var bc=new BroadcastChannel('sw_login');
bc.onmessage=function(e){var mine='';try{mine=localStorage.getItem('swTab')||''}catch(x){}if(e&&e.data&&e.data.tab!==mine)check();};
window.__swBroadcastLogin=function(tab){try{bc.postMessage({tab:tab});}catch(x){}};
}catch(x){}
})();
</script>
<script id="tejodhar-multicolour-login-script">
(function(){
 var themes=[
  {id:'navy',name:'Navy & Orange',accent:'#f97316',secondary:'#fb923c',deep:'#08264b'},
  {id:'purple',name:'Purple Gradient',accent:'#7c3aed',secondary:'#c026d3',deep:'#321064'},
  {id:'teal',name:'Teal Green',accent:'#0d9488',secondary:'#10b981',deep:'#064e4a'},
  {id:'red',name:'Red Bold',accent:'#e11d48',secondary:'#fb7185',deep:'#4c0519'},
  {id:'gold',name:'Royal Gold',accent:'#b8860b',secondary:'#eab308',deep:'#33250b'},
  {id:'blue',name:'Light Blue',accent:'#2563eb',secondary:'#38bdf8',deep:'#12356b'},
  {id:'dark',name:'Dark Glass',accent:'#6366f1',secondary:'#a855f7',deep:'#0b1538'},
  {id:'sunset',name:'Sunset',accent:'#ea580c',secondary:'#f59e0b',deep:'#7c2d12'}
 ];
 function apply(t){
  var r=document.documentElement;
  r.style.setProperty('--login-accent',t.accent);r.style.setProperty('--login-secondary',t.secondary);r.style.setProperty('--login-deep',t.deep);
  try{localStorage.setItem('tejodharLoginTheme',t.id)}catch(e){}
  var p=document.getElementById('tejodharLoginThemeDropdown');
  if(p)p.querySelectorAll('button[data-theme]').forEach(function(b){b.setAttribute('aria-pressed',b.dataset.theme===t.id?'true':'false')});
 }
 function init(){
  var login=document.getElementById('loginView');if(!login)return;
  var old=document.getElementById('tejodharThemePicker');if(old)old.remove();
  var menu=document.getElementById('tejodharLoginThemeMenu');
  if(!menu){
   menu=document.createElement('div');menu.id='tejodharLoginThemeMenu';
   var toggle=document.createElement('button');toggle.type='button';toggle.innerHTML='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2.1-2.5 1.5-2.5H17a4 4 0 0 0 4-4c0-5-4-9.5-9-9.5z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="14.5" cy="7" r="1"/></svg><span>Theme</span><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';toggle.setAttribute('aria-label','Open colour theme menu');toggle.setAttribute('aria-expanded','false');
   var panel=document.createElement('div');panel.id='tejodharLoginThemeDropdown';panel.setAttribute('aria-label','Colour theme options');
   var title=document.createElement('div');title.className='theme-menu-title';title.textContent='Choose colour theme';panel.appendChild(title);
   var grid=document.createElement('div');grid.className='theme-menu-grid';
   themes.forEach(function(t){
    var b=document.createElement('button');b.type='button';b.dataset.theme=t.id;b.setAttribute('aria-pressed','false');
    var sw=document.createElement('span');sw.className='theme-swatch';sw.style.background='linear-gradient(135deg,'+t.accent+','+t.secondary+')';
    var label=document.createElement('span');label.textContent=t.name;b.appendChild(sw);b.appendChild(label);
    b.addEventListener('click',function(){apply(t);panel.classList.remove('open');toggle.setAttribute('aria-expanded','false')});grid.appendChild(b);
   });
   panel.appendChild(grid);toggle.addEventListener('click',function(){var open=panel.classList.toggle('open');toggle.setAttribute('aria-expanded',open?'true':'false')});
   document.addEventListener('click',function(e){if(!menu.contains(e.target)){panel.classList.remove('open');toggle.setAttribute('aria-expanded','false')}});
   menu.appendChild(toggle);menu.appendChild(panel);document.body.appendChild(menu);
  }
  var saved='';try{saved=localStorage.getItem('tejodharLoginTheme')||''}catch(e){}
  apply(themes.find(function(t){return t.id===saved})||themes.find(function(t){return t.id==='purple'})||themes[0]);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
 setTimeout(init,500);setTimeout(init,1500);
})();
</script><script id="tejodhar-login-busy-js">
/* Instant feedback on Login: the button shows "Signing in..." right away and ignores repeat clicks while the server answers. */
(function(){function wrap(){if(typeof window.login!=='function'||window.login.__lx)return;var orig=window.login;
var f=async function(pre){var b=document.querySelector('#loginView .lx-login-btn');if(b&&b.dataset.busy)return;if(b){b.dataset.busy='1';b.classList.add('lx-busy');}
try{return await orig.apply(this,arguments);}finally{if(b){delete b.dataset.busy;b.classList.remove('lx-busy');}}};f.__lx=1;window.login=f;}
wrap();document.addEventListener('DOMContentLoaded',wrap);window.addEventListener('load',wrap);})();
</script>
<script id="tejodhar-login-standalone-js">
(function(){
function sync(){
 var lv=document.getElementById('loginView');if(!lv)return;
 var b=document.body,h=document.documentElement;
 /* Logged in = Exit button visible (set by login()). If so, the login screen is always hidden. */
 var lo=document.getElementById('logoutBtn');
 var loggedIn=!!lo&&!lo.classList.contains('hidden');
 if(loggedIn&&!lv.classList.contains('hidden'))lv.classList.add('hidden');
 var showing=!lv.classList.contains('hidden');
 if(showing){b.classList.add('login-active');h.classList.add('login-active');
  var n=document.getElementById('siteNav');if(n)n.classList.add('hidden');}
 else{b.classList.remove('login-active');h.classList.remove('login-active');}
}
function init(){var lv=document.getElementById('loginView');if(!lv)return;sync();
 new MutationObserver(sync).observe(lv,{attributes:true,attributeFilter:['class']});
 var lo=document.getElementById('logoutBtn');
 if(lo)new MutationObserver(sync).observe(lo,{attributes:true,attributeFilter:['class']});}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
</script>
<script>(function(){
/* Biometric unlock on the login page: show "Login with fingerprint" when this phone is registered, and
   prompt automatically once when the app opens (not after a manual logout). */
function loginShowing(){var v=document.getElementById('loginView');return !!v&&!v.classList.contains('hidden');}
function ready(){
 try{
  if(typeof bioSupported!=='function'||!bioSupported())return false;
  if(window.TejodharBio)return !!window.TejodharBio.hasToken();
  return !!localStorage.getItem('bioCredId');
 }catch(e){return false;}
}
function sync(){
 var b=document.getElementById('bioLoginBtn');if(!b)return;
 b.style.display=(loginShowing()&&ready())?'flex':'none';
}
function auto(){
 try{
  if(!loginShowing()||!window.TejodharBio||!ready())return;
  if(sessionStorage.getItem('bioAutoTried')==='1')return;
  sessionStorage.setItem('bioAutoTried','1');
  setTimeout(function(){if(loginShowing()&&typeof bioLogin==='function')bioLogin();},500);
 }catch(e){}
}
function start(){sync();auto();var v=document.getElementById('loginView');if(v)new MutationObserver(sync).observe(v,{attributes:true,attributeFilter:['class']});}
if(document.readyState==='complete')setTimeout(start,300);else window.addEventListener('load',function(){setTimeout(start,300)});
})();</script>
<style id="tjChatStyle">
#tjChatFab{position:fixed;right:16px;bottom:calc(16px + env(safe-area-inset-bottom,0px));width:56px;height:56px;border-radius:50%;border:0;padding:0;background:#0b4f9e;color:#fff;box-shadow:0 6px 18px rgba(11,79,158,.38);display:none;align-items:center;justify-content:center;cursor:pointer;z-index:9000;-webkit-tap-highlight-color:transparent}
#tjChatFab.on{display:flex}
#tjChatBadge{position:absolute;top:-4px;right:-4px;min-width:20px;height:20px;padding:0 5px;border-radius:10px;background:#dc2626;color:#fff;font:700 11px/20px system-ui,Arial,sans-serif;text-align:center;display:none;box-sizing:border-box}
#tjChatPanel{position:fixed;z-index:9001;display:none;flex-direction:column;background:#fff;color:#111827;overflow:hidden;right:16px;bottom:calc(84px + env(safe-area-inset-bottom,0px));width:380px;max-width:calc(100vw - 24px);height:min(560px,calc(100vh - 110px));border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.25);border:1px solid #e5e7eb;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}
#tjChatPanel.on{display:flex}
@media(max-width:640px){#tjChatPanel{top:0;left:0;right:0;bottom:0;width:auto;max-width:none;height:auto;border-radius:0;border:0;padding-top:env(safe-area-inset-top,0px)}}
#tjChatHead{background:#0b4f9e;color:#fff;padding:12px 14px;display:flex;align-items:center;gap:10px;flex-shrink:0}
#tjChatHead .t{flex:1;min-width:0}
#tjChatHead .t b{display:block;font-size:16px;line-height:1.2}
#tjChatHead .t span{display:block;font-size:12px;opacity:.85;margin-top:2px}
#tjChatClose{background:transparent;border:0;color:#fff;font-size:26px;line-height:1;cursor:pointer;padding:2px 8px}
#tjChatList{flex:1;overflow-y:auto;background:#eef2f7;padding:10px 10px 6px;-webkit-overflow-scrolling:touch;overscroll-behavior:contain}
#tjChatEmpty{text-align:center;color:#64748b;font-size:13px;margin:30px 12px}
.tjDay{text-align:center;margin:10px 0 6px}
.tjDay span{background:#dbe3ee;color:#475569;font-size:11px;font-weight:600;padding:3px 10px;border-radius:10px}
.tjM{display:flex;flex-direction:column;align-items:flex-start;margin:4px 0;max-width:100%}
.tjM.me{align-items:flex-end}
.tjB{max-width:84%;background:#fff;border-radius:14px 14px 14px 4px;padding:7px 11px 6px;box-shadow:0 1px 1px rgba(0,0,0,.08);font-size:14px;line-height:1.4;word-break:break-word}
.tjM.me .tjB{background:#d6e8ff;border-radius:14px 14px 4px 14px}
.tjN{font-size:12px;font-weight:700;color:#0b4f9e;margin-bottom:2px}
.tjM.me .tjN{color:#047857}
.tjN i{font-style:normal;font-weight:600;font-size:10px;color:#fff;background:#64748b;border-radius:8px;padding:1px 6px;margin-left:5px;vertical-align:1px}
.tjN i.adm{background:#b45309}
.tjTx{white-space:pre-wrap}
.tjImg{display:block;max-width:100%;max-height:230px;border-radius:10px;margin:2px 0 4px;cursor:pointer;background:#e2e8f0}
.tjDoc{display:flex;align-items:center;gap:8px;background:#f1f5f9;border:1px solid #dbe3ee;border-radius:10px;padding:8px 10px;margin:2px 0 4px;color:#0b4f9e;text-decoration:none;font-size:13px;font-weight:600}
.tjDoc .nm{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:200px}
.tjMeta{font-size:10.5px;color:#64748b;margin-top:3px;text-align:right}
.tjMeta a{color:#b91c1c;margin-left:8px;cursor:pointer;text-decoration:underline}
.tjMeta .sn{margin-left:8px;color:#64748b}
.tjMeta .sn.ok{color:#0b7a4b;font-weight:700;cursor:pointer;text-decoration:underline}
#tjChatErr{color:#b91c1c;font-size:12px;padding:4px 12px 0;background:#fff;display:none}
#tjChatPrev{display:none;align-items:center;gap:10px;padding:8px 12px;background:#f8fafc;border-top:1px solid #e5e7eb;flex-shrink:0;font-size:13px}
#tjChatPrev img{width:44px;height:44px;object-fit:cover;border-radius:8px}
#tjChatPrev .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#tjChatPrev button{background:transparent;border:0;font-size:22px;color:#64748b;cursor:pointer;padding:0 6px}
#tjChatBar{display:flex;align-items:flex-end;gap:6px;padding:8px 10px calc(8px + env(safe-area-inset-bottom,0px));background:#fff;border-top:1px solid #e5e7eb;flex-shrink:0}
.tjAtt{width:38px;height:42px;border:0;background:transparent;color:#475569;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;padding:0}
#tjChatInput{flex:1;min-width:0;resize:none;border:1px solid #cbd5e1;border-radius:18px;padding:9px 13px;font:inherit;font-size:14px;max-height:110px;outline:none;line-height:1.35;background:#fff;color:#111827}
#tjChatInput:focus{border-color:#0b4f9e}
#tjChatSend{width:42px;height:42px;border-radius:50%;border:0;background:#0b4f9e;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;padding:0}
#tjChatSend:disabled{opacity:.5}
#tjSeenSheet{position:absolute;left:0;right:0;bottom:0;max-height:60%;overflow:auto;background:#fff;border-top:1px solid #cbd5e1;box-shadow:0 -8px 24px rgba(0,0,0,.18);padding:12px 14px calc(12px + env(safe-area-inset-bottom,0px));display:none;z-index:2}
#tjSeenSheet b{display:block;margin-bottom:8px;font-size:14px}
#tjSeenSheet div.r{padding:6px 0;border-top:1px solid #eef2f7;font-size:14px}
#tjSeenSheet div.r i{font-style:normal;font-size:11px;color:#64748b;margin-left:6px}
#tjSeenSheet button{position:absolute;top:6px;right:8px;background:transparent;border:0;font-size:24px;color:#64748b;cursor:pointer}
#tjLight{position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:9100;display:none;flex-direction:column;align-items:center;justify-content:center}
#tjLight .stage{position:absolute;top:0;left:0;right:0;bottom:0;display:flex;align-items:center;justify-content:center;touch-action:none;overflow:hidden}
#tjLight img{max-width:96vw;max-height:84vh;object-fit:contain;-webkit-user-select:none;user-select:none;-webkit-user-drag:none;will-change:transform}
#tjLight .bar{z-index:2;position:absolute;top:calc(10px + env(safe-area-inset-top,0px));right:12px;display:flex;gap:14px;align-items:center}
#tjLight a,#tjLight button{color:#fff;font-size:14px;background:transparent;border:0;cursor:pointer;text-decoration:underline}
#tjLight button{font-size:30px;text-decoration:none;line-height:1}
body.login-active #tjChatFab,body.login-active #tjChatPanel{display:none!important}
</style>
<script>(function(){
/* Team Chat: one common room for the admin and every logged-in user. Text, photos and documents.
   Server: chat_poll / chat_send / chat_delete / chat_seen. */
var OPEN_MS=5000,CLOSED_MS=20000,DOC_MAX=4*1024*1024,last=0,open=false,busy=false,on=false,dead=false,unread=0,nextAt=0,meAdmin=false,meKey='',lastDay='',firstLoad=true,pending=null;
var fab,badge,panel,list,input,sendBtn,errBox,prev,fImg,fDoc,sheet,light;
function loggedIn(){var b=document.getElementById('logoutBtn');return !!b&&!b.classList.contains('hidden');}
function restricted(){try{return typeof sessionRestricted!=='undefined'&&!!sessionRestricted}catch(e){return false}}
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e;}
function fine(){return !!(window.matchMedia&&matchMedia('(pointer:fine)').matches);}
function seenKey(){return 'tjChatSeen:'+meKey;}
function getSeen(){try{return parseInt(localStorage.getItem(seenKey())||'0',10)||0}catch(e){return 0}}
function setSeen(v){try{localStorage.setItem(seenKey(),String(v))}catch(e){}}
function icon(path,w){return '<svg width="'+(w||24)+'" height="'+(w||24)+'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+path+'</svg>';}
function build(){
 if(fab)return;
 fab=el('button');fab.id='tjChatFab';fab.type='button';fab.setAttribute('aria-label','Open team chat');
 fab.innerHTML=icon('<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',28);
 badge=el('span');badge.id='tjChatBadge';fab.appendChild(badge);
 fab.addEventListener('click',function(){toggle(!open)});
 panel=el('div');panel.id='tjChatPanel';
 var head=el('div');head.id='tjChatHead';
 var t=el('div','t');t.appendChild(el('b',null,'Team Chat'));t.appendChild(el('span',null,'\uD83D\uDD12 End-to-end encrypted \u00b7 Admin & all users'));
 var cl=el('button',null,'\u00d7');cl.id='tjChatClose';cl.type='button';cl.setAttribute('aria-label','Close chat');cl.addEventListener('click',function(){toggle(false)});
 head.appendChild(t);head.appendChild(cl);
 list=el('div');list.id='tjChatList';
 errBox=el('div');errBox.id='tjChatErr';
 prev=el('div');prev.id='tjChatPrev';
 var bar=el('div');bar.id='tjChatBar';
 fImg=el('input');fImg.type='file';fImg.accept='image/*';fImg.style.display='none';
 fDoc=el('input');fDoc.type='file';fDoc.accept='.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv';fDoc.style.display='none';
 fImg.addEventListener('change',function(){pick(fImg.files&&fImg.files[0],'img');fImg.value='';});
 fDoc.addEventListener('change',function(){pick(fDoc.files&&fDoc.files[0],'doc');fDoc.value='';});
 var bImg=el('button','tjAtt');bImg.type='button';bImg.setAttribute('aria-label','Send photo');
 bImg.innerHTML=icon('<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-8 9"/>');
 bImg.addEventListener('click',function(){fImg.click()});
 var bDoc=el('button','tjAtt');bDoc.type='button';bDoc.setAttribute('aria-label','Send document');
 bDoc.innerHTML=icon('<path d="M21 11l-9 9a5 5 0 0 1-7-7l9-9a3.5 3.5 0 0 1 5 5l-9 9a2 2 0 0 1-3-3l8-8"/>');
 bDoc.addEventListener('click',function(){fDoc.click()});
 input=el('textarea');input.id='tjChatInput';input.rows=1;input.maxLength=1000;input.placeholder='Type a message\u2026';
 input.addEventListener('input',function(){input.style.height='auto';input.style.height=Math.min(input.scrollHeight,110)+'px'});
 input.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey&&fine()){e.preventDefault();send();}});
 sendBtn=el('button');sendBtn.id='tjChatSend';sendBtn.type='button';sendBtn.setAttribute('aria-label','Send');
 sendBtn.innerHTML='<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M2 21l21-9L2 3v7l15 2-15 2z"/></svg>';
 sendBtn.addEventListener('click',send);
 [bImg,bDoc,input,sendBtn,fImg,fDoc].forEach(function(n){bar.appendChild(n)});
 sheet=el('div');sheet.id='tjSeenSheet';
 panel.appendChild(head);panel.appendChild(list);panel.appendChild(errBox);panel.appendChild(prev);panel.appendChild(bar);panel.appendChild(sheet);
 light=el('div');light.id='tjLight';
 document.body.appendChild(panel);document.body.appendChild(fab);document.body.appendChild(light);
 document.addEventListener('keydown',function(e){if(e.key==='Escape'){if(light.style.display==='flex')closeLight();else if(open)toggle(false);}});
}
/* ---- End-to-end encryption (Web Crypto). One shared AES-256-GCM room key; each device has an ECDH P-256 key pair.
   An admin device wraps the room key for every other device (ECDH + HKDF + AES-GCM). The server stores only ciphertext,
   public keys and wrapped keys. The private key never leaves this phone/browser (IndexedDB, non-extractable). ---- */
var CR=(window.crypto&&window.crypto.subtle&&window.isSecureContext!==false)?window.crypto.subtle:null,TE=new TextEncoder(),TD=new TextDecoder();
var K=null,rawK=null,ident=null,keyNote=null,lastServe=0,filePlain={};
function b64u(buf){var b=new Uint8Array(buf),s='';for(var i=0;i<b.length;i+=0x8000)s+=String.fromCharCode.apply(null,b.subarray(i,i+0x8000));return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function unb64u(s){s=String(s).replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';var x=atob(s),b=new Uint8Array(x.length);for(var i=0;i<x.length;i++)b[i]=x.charCodeAt(i);return b;}
function b64std(buf){var b=new Uint8Array(buf),s='';for(var i=0;i<b.length;i+=0x8000)s+=String.fromCharCode.apply(null,b.subarray(i,i+0x8000));return btoa(s);}
function rnd(n){return crypto.getRandomValues(new Uint8Array(n));}
function idb(){return new Promise(function(res,rej){var r=indexedDB.open('tjchat',1);r.onupgradeneeded=function(){r.result.createObjectStore('kv');};r.onsuccess=function(){res(r.result)};r.onerror=function(){rej(r.error)};});}
function idbGet(k){return idb().then(function(d){return new Promise(function(res,rej){var q=d.transaction('kv').objectStore('kv').get(k);q.onsuccess=function(){res(q.result)};q.onerror=function(){rej(q.error)};});});}
function idbPut(k,v){return idb().then(function(d){return new Promise(function(res,rej){var t=d.transaction('kv','readwrite');t.objectStore('kv').put(v,k);t.oncomplete=function(){res()};t.onerror=function(){rej(t.error)};});});}
async function loadIdentity(){
 var k='id:'+meKey,x=null;try{x=await idbGet(k);}catch(e){}
 if(x&&x.priv&&x.pub&&x.dev)return x;
 var kp=await CR.generateKey({name:'ECDH',namedCurve:'P-256'},false,['deriveBits']);
 var pj=await CR.exportKey('jwk',kp.publicKey);
 x={dev:b64u(rnd(18)),priv:kp.privateKey,pub:{kty:'EC',crv:'P-256',x:pj.x,y:pj.y}};
 await idbPut(k,x);return x;
}
async function wrapKeyFor(theirPubJson,raw){
 var their=await CR.importKey('jwk',JSON.parse(theirPubJson),{name:'ECDH',namedCurve:'P-256'},false,[]);
 var aes=await wrapAes(ident.priv,their),iv=rnd(12);
 var ct=await CR.encrypt({name:'AES-GCM',iv:iv},aes,raw);
 return {wrapped:JSON.stringify({iv:b64u(iv),ct:b64u(ct)}),wpub:JSON.stringify(ident.pub)};
}
async function wrapAes(priv,pub){
 var bits=await CR.deriveBits({name:'ECDH',public:pub},priv,256);
 var hk=await CR.importKey('raw',bits,'HKDF',false,['deriveKey']);
 return CR.deriveKey({name:'HKDF',hash:'SHA-256',salt:new Uint8Array(0),info:TE.encode('tejodhar-chat-wrap-v1')},hk,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
async function setRoomKey(raw){rawK=meAdmin?raw:null;K=await CR.importKey('raw',raw,{name:'AES-GCM'},false,['encrypt','decrypt']);}
function noteKey(t){
 if(!keyNote){keyNote=el('div');keyNote.id='tjKeyNote';keyNote.style.cssText='padding:10px 14px;background:#fef3c7;color:#92400e;font-size:12px;display:none';if(panel&&list)panel.insertBefore(keyNote,list);}
 if(keyNote){keyNote.textContent=t||'';keyNote.style.display=t?'block':'none';}
}
async function ensureKeys(){
 if(K)return true;
 if(!CR){noteKey('🔒 Encrypted chat needs a secure (https) connection and a newer browser / WebView.');return false;}
 try{
  if(!ident)ident=await loadIdentity();
  var r=await server('chat_key_pub',{dev:ident.dev,pub:JSON.stringify(ident.pub)});
  if(!r||r.status!=='success')return false;
  if(r.wrapped&&r.wpub){
   var w=JSON.parse(r.wrapped),their=await CR.importKey('jwk',JSON.parse(r.wpub),{name:'ECDH',namedCurve:'P-256'},false,[]);
   var aes=await wrapAes(ident.priv,their);
   var raw=await CR.decrypt({name:'AES-GCM',iv:unb64u(w.iv)},aes,unb64u(w.ct));
   await setRoomKey(raw);noteKey('');return true;
  }
  if(r.empty&&meAdmin){ /* very first admin device creates the room key */
   var raw2=rnd(32),me=await wrapKeyFor(JSON.stringify(ident.pub),raw2);
   var p=await server('chat_key_put',{init:true,items:[{skey:meKey,dev:ident.dev,wrapped:me.wrapped,wpub:me.wpub}]});
   if(p&&p.status==='success'&&p.stored>0){await setRoomKey(raw2);noteKey('');return true;}
  }
  noteKey('🔒 Setting up secure chat on this device… an admin must open the app once to approve it. This happens automatically.');
 }catch(e){noteKey('🔒 Could not set up the secure chat key on this device.');}
 return false;
}
/* admin devices: hand the room key to every device that is still waiting */
async function serveKeys(){
 if(!K||!rawK||!meAdmin||Date.now()-lastServe<10000)return;lastServe=Date.now();
 try{
  var r=await server('chat_key_pending',{});if(!r||r.status!=='success'||!r.pending.length)return;
  var items=[];
  for(var i=0;i<r.pending.length;i++){var d=r.pending[i];try{var w=await wrapKeyFor(d.pub,rawK);items.push({skey:d.skey,dev:d.dev,wrapped:w.wrapped,wpub:w.wpub});}catch(e){}}
  if(items.length)await server('chat_key_put',{items:items});
 }catch(e){}
}
async function encPayload(obj){var iv=rnd(12),ct=await CR.encrypt({name:'AES-GCM',iv:iv},K,TE.encode(JSON.stringify(obj)));return JSON.stringify({v:1,iv:b64u(iv),ct:b64u(ct)});}
async function decPayload(s){var j=JSON.parse(s),pt=await CR.decrypt({name:'AES-GCM',iv:unb64u(j.iv)},K,unb64u(j.ct));return JSON.parse(TD.decode(pt));}
async function prepare(m){
 if(!m.enc)return m;
 try{
  var p=await decPayload(m.enc);m.text=typeof p.t==='string'?p.t:'';
  if(p.f&&m.file&&m.file.url){var mime=String(p.f.m||'');m.cf={url:m.file.url,name:String(p.f.n||'').slice(0,150),kind:(p.f.k==='img'&&/^image\/(jpeg|png|webp|gif)$/.test(mime))?'img':'doc',mime:mime};}
 }catch(e){m.text='🔒 This message could not be decrypted.';}
 return m;
}
function fetchPlain(cf){
 if(filePlain[cf.url])return filePlain[cf.url];
 return filePlain[cf.url]=fetch(cf.url).then(function(r){if(!r.ok)throw new Error('dl');return r.arrayBuffer();}).then(function(buf){
  var b=new Uint8Array(buf);return CR.decrypt({name:'AES-GCM',iv:b.slice(0,12)},K,b.slice(12));
 }).then(function(pt){return URL.createObjectURL(new Blob([pt],{type:cf.kind==='img'?cf.mime:'application/octet-stream'}));});
}
function showErr(m){errBox.textContent=m||'';errBox.style.display=m?'block':'none';if(m)setTimeout(function(){if(errBox.textContent===m)showErr('')},5000);}
function updBadge(){if(!badge)return;if(unread>0&&!open){badge.textContent=unread>99?'99+':String(unread);badge.style.display='block';}else badge.style.display='none';}
function nearBottom(){return list.scrollHeight-list.scrollTop-list.clientHeight<80;}
function toBottom(){list.scrollTop=list.scrollHeight;}
function dayLabel(d){var n=new Date(),y=new Date(Date.now()-864e5);
 if(d.toDateString()===n.toDateString())return 'Today';if(d.toDateString()===y.toDateString())return 'Yesterday';
 return d.toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'});}
function closeLight(){light.style.display='none';light.innerHTML='';}
function lightbox(url){
 light.innerHTML='';
 var bar=el('div','bar'),a=el('a',null,'Open'),mi=el('button',null,'\u2212'),pl=el('button',null,'+'),x=el('button',null,'\u00d7');
 a.href=url;a.target='_blank';a.rel='noopener';
 mi.setAttribute('aria-label','Zoom out');pl.setAttribute('aria-label','Zoom in');x.setAttribute('aria-label','Close');
 [a,mi,pl,x].forEach(function(n){bar.appendChild(n)});
 var st=el('div','stage'),im=el('img');im.src=url;im.draggable=false;st.appendChild(im);
 light.appendChild(st);light.appendChild(bar);light.style.display='flex';
 var s=1,tx=0,ty=0,pts={},d0=0,moved=false,lastTap=0;
 function apply(){if(s<=1.001){s=1;tx=0;ty=0;}im.style.transform='translate('+tx+'px,'+ty+'px) scale('+s+')';}
 function zoomAt(f,cx,cy){
  var ns=Math.min(6,Math.max(1,s*f));if(ns===s)return;
  var r=st.getBoundingClientRect(),ox=cx-(r.left+r.width/2),oy=cy-(r.top+r.height/2);
  tx=ox-(ox-tx)*(ns/s);ty=oy-(oy-ty)*(ns/s);s=ns;apply();
 }
 function centre(){var r=st.getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2};}
 function dist(){var k=Object.keys(pts);if(k.length<2)return 0;var p=pts[k[0]],q=pts[k[1]];return Math.hypot(p.x-q.x,p.y-q.y);}
 mi.addEventListener('click',function(){var c=centre();zoomAt(1/1.5,c.x,c.y)});
 pl.addEventListener('click',function(){var c=centre();zoomAt(1.5,c.x,c.y)});
 x.addEventListener('click',closeLight);
 st.addEventListener('wheel',function(e){e.preventDefault();zoomAt(e.deltaY<0?1.2:1/1.2,e.clientX,e.clientY);},{passive:false});
 st.addEventListener('pointerdown',function(e){
  pts[e.pointerId]={x:e.clientX,y:e.clientY};moved=false;
  try{st.setPointerCapture(e.pointerId)}catch(x){}
  if(Object.keys(pts).length===2)d0=dist();
 });
 st.addEventListener('pointermove',function(e){
  var p=pts[e.pointerId];if(!p)return;
  var n=Object.keys(pts).length;
  if(n>=2){
   var nx={x:e.clientX,y:e.clientY},k=Object.keys(pts),o=pts[k[0]]===p?pts[k[1]]:pts[k[0]];
   pts[e.pointerId]=nx;var d1=dist();
   if(d0>0&&d1>0){zoomAt(d1/d0,(nx.x+o.x)/2,(nx.y+o.y)/2);d0=d1;}
   moved=true;
  }else{
   var dx=e.clientX-p.x,dy=e.clientY-p.y;
   if(Math.abs(dx)+Math.abs(dy)>2)moved=true;
   p.x=e.clientX;p.y=e.clientY;
   if(s>1){tx+=dx;ty+=dy;apply();}
  }
 });
 function up(e){
  var had=!!pts[e.pointerId],single=Object.keys(pts).length===1;delete pts[e.pointerId];d0=0;
  if(!had||!single||moved||e.type==='pointercancel')return;
  var now=Date.now();
  if(now-lastTap<320){lastTap=0;if(s>1){s=1;apply();}else zoomAt(2.5,e.clientX,e.clientY);return;}
  lastTap=now;
  if(e.target===st&&s===1)setTimeout(function(){if(lastTap===now)closeLight();},330); /* tap on the dark area closes */
 }
 st.addEventListener('pointerup',up);st.addEventListener('pointercancel',up);
 apply();
}
function setSeenText(id,n){
 var s=document.getElementById('tjs-'+id);if(!s)return;
 if(n>0){s.textContent='\u2713\u2713 Seen by '+n;s.className='sn ok';}else{s.textContent='\u2713 Sent';s.className='sn';}
}
function showSeen(id){
 sheet.innerHTML='';sheet.style.display='block';
 var x=el('button',null,'\u00d7');x.addEventListener('click',function(){sheet.style.display='none'});
 sheet.appendChild(x);sheet.appendChild(el('b',null,'Seen by'));
 var ld=el('div','r','Loading\u2026');sheet.appendChild(ld);
 server('chat_seen',{id:id}).then(function(r){
  ld.remove();
  if(!r||r.status!=='success'){sheet.appendChild(el('div','r',(r&&r.message)||'Could not load.'));return;}
  if(!r.seen.length){sheet.appendChild(el('div','r','No one has seen this yet.'));return;}
  r.seen.forEach(function(p){var row=el('div','r',p.name||'User');if(p.label)row.appendChild(el('i',null,p.label));sheet.appendChild(row);});
 });
}
function addMsg(m){
 if(document.getElementById('tjm-'+m.id))return;
 var empty=document.getElementById('tjChatEmpty');if(empty)empty.remove();
 var d=new Date(m.ts*1000),key=d.toDateString();
 if(key!==lastDay){lastDay=key;var dv=el('div','tjDay');dv.appendChild(el('span',null,dayLabel(d)));list.appendChild(dv);}
 var w=el('div','tjM'+(m.mine?' me':''));w.id='tjm-'+m.id;
 var b=el('div','tjB');
 var n=el('div','tjN',m.name||'User');if(m.label){n.appendChild(el('i',m.role==='admin'?'adm':'',m.label));}b.appendChild(n);
 var f=m.file;
 if(m.cf){
  var cf=m.cf;
  if(cf.kind==='img'){
   var im2=el('img','tjImg');im2.alt=cf.name||'Photo';im2.style.minHeight='60px';b.appendChild(im2);
   fetchPlain(cf).then(function(u){im2.style.minHeight='';im2.src=u;im2.addEventListener('click',function(){lightbox(u)});}).catch(function(){im2.replaceWith(el('div','tjTx','\uD83D\uDD12 This photo could not be decrypted.'));});
  }else{
   var a2=el('a','tjDoc');a2.href='#';a2.appendChild(el('span',null,'\uD83D\uDCC4'));a2.appendChild(el('span','nm',cf.name||'Document'));
   a2.addEventListener('click',function(e){e.preventDefault();fetchPlain(cf).then(function(u){var d=document.createElement('a');d.href=u;d.download=cf.name||'document';document.body.appendChild(d);d.click();d.remove();}).catch(function(){showErr('Could not decrypt this file.');});});
   b.appendChild(a2);
  }
 }else if(f&&f.kind!=='enc'&&typeof f.url==='string'&&f.url.indexOf('https://')===0){
  if(f.kind==='img'){var im=el('img','tjImg');im.src=f.url;im.loading='lazy';im.alt=f.name||'Photo';im.addEventListener('click',function(){lightbox(f.url)});b.appendChild(im);}
  else{var a=el('a','tjDoc');a.href=f.url;a.target='_blank';a.rel='noopener';a.appendChild(el('span',null,'\uD83D\uDCC4'));a.appendChild(el('span','nm',f.name||'Document'));b.appendChild(a);}
 }
 if(m.text)b.appendChild(el('div','tjTx',m.text));
 var meta=el('div','tjMeta',d.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}));
 if(m.mine){var sn=el('span','sn','\u2713 Sent');sn.id='tjs-'+m.id;sn.addEventListener('click',function(){if(sn.className.indexOf('ok')>=0)showSeen(m.id)});meta.appendChild(sn);}
 if(m.mine){var del=el('a',null,'Delete');del.addEventListener('click',function(){delMsg(m.id)});meta.appendChild(del);}
 b.appendChild(meta);w.appendChild(b);list.appendChild(w);
}
function showEmpty(){if(!list.children.length){var e=el('div',null,'No messages yet. Say hello to the team!');e.id='tjChatEmpty';list.appendChild(e);}}
function toggle(v){
 build();open=v;panel.classList.toggle('on',v);
 if(v){unread=0;setSeen(last);toBottom();showErr('');if(fine())setTimeout(function(){input.focus()},50);nextAt=0;}
 else sheet.style.display='none';
 updBadge();
}
/* ---- attachments ---- */
function readAsDataUrl(file){return new Promise(function(res,rej){var fr=new FileReader();fr.onload=function(){res(fr.result)};fr.onerror=function(){rej(new Error('read'))};fr.readAsDataURL(file);});}
function shrinkPhoto(file){
 return new Promise(function(res,rej){
  var url=URL.createObjectURL(file),im=new Image();
  im.onload=function(){
   try{
    var max=1600,w=im.naturalWidth,h=im.naturalHeight,k=Math.min(1,max/Math.max(w,h));
    var c=document.createElement('canvas');c.width=Math.max(1,Math.round(w*k));c.height=Math.max(1,Math.round(h*k));
    var g=c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);g.drawImage(im,0,0,c.width,c.height);
    URL.revokeObjectURL(url);res(c.toDataURL('image/jpeg',0.82));
   }catch(e){URL.revokeObjectURL(url);rej(e);}
  };
  im.onerror=function(){URL.revokeObjectURL(url);rej(new Error('decode'));};
  im.src=url;
 });
}
function renderPrev(){
 prev.innerHTML='';
 if(!pending){prev.style.display='none';return;}
 prev.style.display='flex';
 if(pending.kind==='img'){var im=el('img');im.src=pending.data;prev.appendChild(im);}else prev.appendChild(el('span',null,'\uD83D\uDCC4'));
 prev.appendChild(el('span','nm',pending.name));
 var x=el('button',null,'\u00d7');x.setAttribute('aria-label','Remove attachment');x.addEventListener('click',function(){pending=null;renderPrev();});
 prev.appendChild(x);
}
async function pick(file,kind){
 if(!file)return;showErr('');
 try{
  if(kind==='img'){
   if(!/^image\//.test(file.type||'')){showErr('Please choose a photo.');return;}
   var data;
   if(file.type==='image/gif'&&file.size<=3*1024*1024)data=await readAsDataUrl(file);else data=await shrinkPhoto(file);
   var nm=file.type==='image/gif'?(file.name||'photo.gif'):((file.name||'photo').replace(/\.[^.]*$/,'')+'.jpg');
   pending={kind:'img',name:nm,data:data};
  }else{
   var ext=(file.name.split('.').pop()||'').toLowerCase();
   if(['pdf','doc','docx','xls','xlsx','ppt','pptx','txt','csv'].indexOf(ext)<0){showErr('Allowed: PDF, Word, Excel, PowerPoint, text, CSV.');return;}
   if(file.size>DOC_MAX){showErr('Document is too large (max 4 MB).');return;}
   pending={kind:'doc',name:file.name,data:await readAsDataUrl(file)};
  }
  renderPrev();
 }catch(e){showErr('Could not read this file. Try another.');}
}
async function poll(){
 if(busy||dead)return;busy=true;
 try{
  var r=await server('chat_poll',{after:last,seen:open?last:0});
  if(!r||r.status!=='success'){if(!on)dead=true;return;}
  build();
  meAdmin=!!(r.me&&r.me.admin);
  if(firstLoad){meKey=(r.me&&r.me.role||'')+'|'+(r.me&&r.me.usr||'');}
  on=true;fab.classList.add('on');
  var hasKey=await ensureKeys();
  if(hasKey)serveKeys();
  else{ /* cannot read anything yet: do not advance, try again next cycle */ return; }
  var stick=nearBottom()||firstLoad;
  (r.deleted||[]).forEach(function(id){var n=document.getElementById('tjm-'+id);if(n)n.remove();});
  var seen=getSeen();
  var msgs=r.messages||[];
  for(var mi=0;mi<msgs.length;mi++){
   var m=msgs[mi];
   if(m.id<=last&&!firstLoad)continue;
   await prepare(m);
   addMsg(m);if(m.id>last)last=m.id;
   if(!m.mine&&(firstLoad?m.id>seen:true)&&!open)unread++;
  }
  var sm=r.seen||{};Object.keys(sm).forEach(function(id){setSeenText(id,sm[id]);});
  if(firstLoad){firstLoad=false;showEmpty();toBottom();}
  else if(stick&&(r.messages||[]).length)toBottom();
  if(open){setSeen(last);unread=0;}
  updBadge();
 }catch(e){}finally{busy=false;nextAt=Date.now()+(open?OPEN_MS:CLOSED_MS);}
}
async function send(){
 var text=input.value.trim();if((!text&&!pending)||sendBtn.disabled)return;
 if(!K){showErr('Secure chat key is not ready yet. Please wait a moment.');return;}
 sendBtn.disabled=true;showErr('');
 var hadFile=!!pending;if(hadFile)showErr('Encrypting & uploading\u2026');
 try{
  var body={},payload={t:text,f:null};
  if(pending){
   var fbuf=await (await fetch(pending.data)).arrayBuffer(),mm=(pending.data.match(/^data:([^;,]+)[;,]/)||[])[1]||'application/octet-stream';
   var fiv=rnd(12),fct=new Uint8Array(await CR.encrypt({name:'AES-GCM',iv:fiv},K,fbuf)),all=new Uint8Array(12+fct.length);all.set(fiv,0);all.set(fct,12);
   body.file={enc:b64std(all)};payload.f={n:pending.name,k:pending.kind,m:mm};
  }
  body.enc=await encPayload(payload);
  var r=await server('chat_send',body);
  if(r&&r.status==='success'&&r.message){
   var e=document.getElementById('tjChatEmpty');if(e)e.remove();
   await prepare(r.message);
   addMsg(r.message);
   input.value='';input.style.height='auto';pending=null;renderPrev();showErr('');toBottom();
   nextAt=Date.now()+1500;
  }else showErr((r&&r.message)||'Could not send. Try again.');
 }catch(e){showErr('Could not send. Try again.');}
 sendBtn.disabled=false;
 if(fine())input.focus();
}
async function delMsg(id){
 if(!confirm('Delete this message for everyone?'))return;
 var r=await server('chat_delete',{id:id});
 if(r&&r.status==='success'){var n=document.getElementById('tjm-'+id);if(n)n.remove();}
 else showErr((r&&r.message)||'Could not delete.');
}
function reset(){
 on=false;dead=false;last=0;unread=0;firstLoad=true;lastDay='';open=false;meAdmin=false;nextAt=0;pending=null;
 K=null;rawK=null;ident=null;lastServe=0;filePlain={};try{noteKey('');}catch(e){}
 if(fab){fab.classList.remove('on');panel.classList.remove('on');list.innerHTML='';input.value='';renderPrev();sheet.style.display='none';light.style.display='none';showErr('');updBadge();}
}
setInterval(function(){
 if(!loggedIn()||restricted()){if(on||dead||last)reset();return;}
 if(dead||document.hidden)return;
 if(Date.now()>=nextAt)poll();
},1000);
document.addEventListener('visibilitychange',function(){if(!document.hidden&&on)nextAt=0;});
})();</script>
<script>(function(){
/* Push notifications (Android app only). The native bridge window.TejodharPush gives us this phone's FCM token;
   we register it with the server after login, and open the right screen when a notification is tapped. */
var done='',asked=false,busy=false;
function P(){try{return window.TejodharPush||null}catch(e){return null}}
function loggedIn(){var b=document.getElementById('logoutBtn');return !!b&&!b.classList.contains('hidden');}
function isAdmin(){var a=document.getElementById('adminView');return !!a&&!a.classList.contains('hidden');}
function go(tab){
 try{
  if(tab==='chat'){var f=document.getElementById('tjChatFab');var pn=document.getElementById('tjChatPanel');if(f&&!(pn&&pn.classList.contains('on')))f.click();return;}
  if(tab==='approvals'){if(isAdmin()){showAdminTab('dashboard');}else{showStaffTab('leave');}return;}
  if(tab==='myleave'){showStaffTab('leave');return;}
  if(tab==='myreq'){showStaffTab('applyAtt');return;}
 }catch(e){}
}
async function tick(){
 var p=P(); if(!p||!loggedIn()||busy)return;
 busy=true;
 try{
  if(!asked){asked=true;try{p.requestPermission();}catch(e){}}
  var t='';try{t=String(p.getToken()||'');}catch(e){}
  if(t&&t!==done){
   window.__tjPushToken=t;
   var r=await server('push_register',{token:t});
   if(r&&r.status==='success')done=t;
  }
  var l='';try{l=String(p.takeLaunch()||'');}catch(e){}
  if(l)go(l);
 }catch(e){}
 busy=false;
}
setInterval(tick,4000);document.addEventListener('visibilitychange',function(){if(!document.hidden)setTimeout(tick,300);});
setTimeout(tick,1500);
})();</script>
</body>
</html>



<script>document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshEmployeeSalaryAdvanceNow();});
startUniversalLiveSync();
</script>
