# Tejodhar AndroidForge — White Screen Diagnostic Fix

This revision updates the Android WebView wrapper for the live portal:
- https://tejodhar.in/
- https://www.tejodhar.in/

## Changes
- Better WebView initialization, DOM storage, responsive viewport and cookies.
- Removes the Android WebView `; wv` user-agent marker to improve compatibility with hosting/WAF rules that reject embedded browsers.
- Adds a loading progress indicator.
- Adds alternate-host retry when the primary host fails.
- Displays a readable error panel instead of leaving a blank white screen.
- Logs JavaScript console messages under `TejodharWeb`.
- Keeps SSL certificate validation strict; it does not ignore certificate errors.
- Preserves file chooser, download, camera and microphone support.

## Build
Open/import this folder in AndroidForge, build a new APK, uninstall the old APK, install the new APK and test on mobile data and Wi-Fi.

## Important
The previous log ZIP available in this conversation was from the earlier compilation failure, not a runtime WebView white-screen trace. This source update addresses common WebView blank-screen causes and adds diagnostics, but the exact runtime cause cannot be confirmed until the new APK is tested or a fresh runtime log/screenshot is supplied.


## Biometric login, camera and microphone update
- Adds AndroidX BiometricPrompt for fingerprint / strong biometric and device screen-lock fallback.
- Login credentials are saved only after the user explicitly confirms and authenticates; they are encrypted with an AES-GCM key held by Android Keystore.
- On a later launch, biometric authentication decrypts and attempts to fill the portal login form.
- Login-field detection is generic (username/email plus password input). If the portal uses custom non-standard login controls, its exact field selectors may need adjustment.
- Adds biometric manifest permissions and optional camera/microphone hardware declarations.
- WebRTC camera/microphone requests from the trusted `tejodhar.in` origins trigger Android runtime permission prompts. Other origins are denied/opened externally.
- Android permissions do not by themselves create voice/video calling; the website's calling implementation must request the matching WebRTC media devices.
- Requires an internet connection and AndroidX dependency resolution during build. Build the APK in AndroidForge, install it, then test on a real phone with fingerprint enrolled.
