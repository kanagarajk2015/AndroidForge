from pathlib import Path
required = [
    "settings.gradle.kts", "build.gradle.kts", "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/pockethost/server/MainActivity.kt",
    "app/src/main/java/com/pockethost/server/HostingService.kt",
    "app/src/main/java/com/pockethost/server/PhpRuntimeManager.kt",
    ".github/workflows/android.yml",
]
missing = [f for f in required if not Path(f).is_file()]
assert not missing, f"Missing project files: {missing}"
manifest = Path(required[3]).read_text()
main = Path(required[4]).read_text()
service = Path(required[5]).read_text()
php = Path(required[6]).read_text()
workflow = Path(required[7]).read_text()
gradle = Path("app/build.gradle.kts").read_text()
assert 'android:extractNativeLibs="true"' in manifest
assert '0.0.0.0", 8080' in service
assert "nativeLibraryDir" in php and "libphp.so" in php
assert "diagnostic()" in php and "phpManager.diagnostic()" in main
assert "chmod 755" in workflow
assert "Verify PHP binary is inside the APK" in workflow
assert "lib/arm64-v8a/libphp\\.so" in workflow
assert "sha256sum -c -" in workflow
assert "arm64-v8a" in gradle and "useLegacyPackaging = true" in gradle
for feature in ["Create website", "Upload file", "File manager", "Preview", "Edit"]:
    assert feature in main, f"Missing UI feature: {feature}"
print("PocketHost v5.2.4 source/workflow smoke checks: PASS")
