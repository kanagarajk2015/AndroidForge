package com.example.colourlauncher.data

/** Shape used to clip app icons. */
enum class IconShape { Rounded, Circle, Square }

/** Light/dark behaviour of the launcher's own surfaces (drawer, dock, sheets). */
enum class ThemeMode { System, Light, Dark }

/** Where the accent colour comes from. [Wallpaper] needs Android 12+; older versions use Blue. */
enum class Accent { Wallpaper, Blue, Green, Pink, Orange, Fluent }

/**
 * Overall layout: [Windows11] a taskbar with a Start button and a Start-menu panel, [OxygenOS] a
 * large clock, a soft rounded dock and an app drawer with its search bar at the bottom.
 *
 * [themed] styles draw their own artwork behind the home screen, in place of the wallpaper:
 * [MidnightCircles] a navy glow with a left-aligned clock and a floating dock.
 */
enum class LauncherStyle(val themed: Boolean = false) {
    Windows11,
    OxygenOS,
    MidnightCircles(themed = true),
}

/**
 * Clock shown at the top of the home screen. [Default] keeps each launcher style's own clock.
 * The Windows 11 style shows its clock in the taskbar, so these do not apply there.
 */
enum class ClockStyle(val label: String) {
    Default("Style default"),
    Dual("Dual clock"),
    MultiTimezone("Multi-timezone"),
    CalendarClock("Calendar clock"),
    DateTime("Date & time"),
    Vertical("Vertical"),
    Horizontal("Horizontal"),
    BigNumber("Big number"),
    Small("Small"),
    Circular("Circular"),
    Square("Square"),
    Gradient("Gradient"),
    Amoled("AMOLED"),
    Retro("Retro"),
    Vintage("Vintage"),
    Futuristic("Futuristic"),
    Animated("Animated"),
    Floating("Floating"),
    Battery("Battery + clock"),
    Binary("Binary"),
    Word("Word"),
    Matrix("Matrix"),
    Typographic("Typographic"),
    FlipCalendar("Digital flip calendar"),
    MinimalDate("Minimal date"),
}

/** True when the style draws its own artwork over the wallpaper, so the wallpaper is hidden. */
val LauncherSettings.drawsArtwork: Boolean
    get() = (style.themed || style == LauncherStyle.Windows11) && showArtwork

/** User-adjustable look of the launcher. [iconPack] is a package name, or empty for system icons. */
data class LauncherSettings(
    val columns: Int = 4,
    val iconShape: IconShape = IconShape.Rounded,
    val iconSizeDp: Int = 56,
    val showLabels: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.System,
    val accent: Accent = Accent.Wallpaper,
    val iconPack: String = "",
    val style: LauncherStyle = LauncherStyle.OxygenOS,
    val clockStyle: ClockStyle = ClockStyle.Default,
    /** When set, home screen icons can't be moved, added or removed. */
    val lockHome: Boolean = false,
    /** When set, icons show a count of their notifications. Needs notification access. */
    val showBadges: Boolean = false,
    /**
     * Themed styles draw their own artwork behind the icons. Turn this off to see the system
     * wallpaper instead. Picking a wallpaper in settings turns it off.
     */
    val showArtwork: Boolean = true,
    /** Black layer over the wallpaper, 0 to 0.6, so labels stay readable on bright images. */
    val wallpaperDim: Float = 0f,
)
