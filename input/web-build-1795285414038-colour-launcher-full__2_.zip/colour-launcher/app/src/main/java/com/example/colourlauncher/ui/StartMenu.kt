package com.example.colourlauncher.ui

import androidx.compose.ui.graphics.FilterQuality
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherApp

private const val PinnedLimit = 16
private const val RecentLimit = 6

/**
 * The Windows 11 Start menu: a search box, the Pinned apps with an "All apps" button, the
 * Recommended apps (the ones installed most recently), and a footer with the account and a
 * settings button. Typing in the search box lists matching apps. "All apps" shows every app A to Z.
 *
 * [pinnedPackages] are the apps on the home screen, which stand in for the pinned apps.
 */
@Composable
fun StartMenu(
    apps: List<LauncherApp>,
    pinnedPackages: List<String?>,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val shape = RoundedCornerShape(8.dp)
    val ink = winInk()
    val columns = 4
    var query by remember { mutableStateOf("") }
    var showAll by remember { mutableStateOf(false) }

    val byPackage = remember(apps) { apps.associateBy { it.packageName } }
    val pinned = remember(apps, pinnedPackages) {
        val chosen = pinnedPackages.filterNotNull().mapNotNull { byPackage[it] }
        (if (chosen.isEmpty()) apps else chosen).take(PinnedLimit)
    }
    // Most recently installed first, skipping the pinned apps and the launcher itself.
    val recent = remember(apps, pinned) {
        val pinnedSet = pinned.map { it.packageName }.toSet()
        apps.filter { it.packageName !in pinnedSet && it.packageName != context.packageName }
            .sortedByDescending { installTime(context, it.packageName) }
            .take(RecentLimit)
    }
    val sorted = remember(apps) { apps.sortedBy { it.label.lowercase() } }

    Column(
        modifier = modifier
            .shadow(16.dp, shape)
            .clip(shape)
            .background(winAcrylic())
            .border(1.dp, winStroke(), shape),
    ) {
        SearchBox(query = query, onChange = { query = it })

        Column(modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
            when {
                query.isNotBlank() -> {
                    Heading(stringResource(R.string.start_apps))
                    val hits = apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
                    hits.forEach { AppRow(it, onLaunch, onLongPress) }
                }
                showAll -> {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = stringResource(R.string.all_apps),
                            color = ink,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f),
                        )
                        SmallButton(stringResource(R.string.start_back), chevron = false) { showAll = false }
                    }
                    var letter = ' '
                    sorted.forEach { app ->
                        val first = letterOf(app.label)
                        if (first != letter) {
                            letter = first
                            Text(
                                text = first.toString(),
                                color = WinBlue,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(start = 24.dp, top = 8.dp, bottom = 2.dp),
                            )
                        }
                        AppRow(app, onLaunch, onLongPress)
                    }
                }
                else -> {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 24.dp, end = 16.dp, top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = stringResource(R.string.start_pinned),
                            color = ink,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f),
                        )
                        SmallButton(stringResource(R.string.all_apps), chevron = true) { showAll = true }
                    }
                    Spacer(Modifier.height(8.dp))
                    pinned.chunked(columns).forEach { rowApps ->
                        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                            rowApps.forEach { app -> PinnedTile(app, onLaunch, onLongPress, Modifier.weight(1f)) }
                            repeat(columns - rowApps.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    if (recent.isNotEmpty()) {
                        Heading(stringResource(R.string.start_recommended))
                        recent.chunked(2).forEach { pair ->
                            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                                pair.forEach { app -> RecommendedItem(app, onLaunch, onLongPress, Modifier.weight(1f)) }
                                if (pair.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }

        // Footer band: the account on the left, settings on the right.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ink.copy(alpha = 0.05f))
                .padding(horizontal = 24.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier.size(28.dp).background(ink.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Person, contentDescription = null, tint = ink, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(12.dp))
            Text(
                text = Build.MODEL,
                color = ink,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .winButton(onClick = onOpenSettings, onClickLabel = stringResource(R.string.settings_open)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Settings, contentDescription = null, tint = ink, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun SearchBox(query: String, onChange: (String) -> Unit) {
    val ink = winInk()
    val shape = RoundedCornerShape(4.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 12.dp)
            .height(40.dp)
            .background(winControl(), shape)
            .border(1.dp, winStroke(), shape)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = winSubInk(), modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (query.isEmpty()) {
                Text(stringResource(R.string.start_search_hint), color = winSubInk(), fontSize = 13.sp, maxLines = 1)
            }
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = ink, fontSize = 13.sp),
                cursorBrush = SolidColor(WinBlue),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun Heading(text: String) {
    Text(
        text = text,
        color = winInk(),
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 24.dp, top = 16.dp, bottom = 8.dp),
    )
}

@Composable
private fun SmallButton(text: String, chevron: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(4.dp)
    Row(
        modifier = Modifier
            .background(winControl(), shape)
            .border(1.dp, winStroke(), shape)
            .winButton(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, color = winInk(), fontSize = 12.sp)
        if (chevron) {
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = winInk(), modifier = Modifier.size(14.dp))
        }
    }
}

/** A pinned app: icon over a label of up to two lines. */
@Composable
private fun PinnedTile(
    app: LauncherApp,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    modifier: Modifier,
) {
    Column(
        modifier = modifier
            .padding(2.dp)
            .winButton(onClick = { onLaunch(app.packageName) }, onLongClick = { onLongPress(app) })
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(bitmap = app.icon,
 filterQuality = FilterQuality.High, contentDescription = null, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(6.dp))
        Text(
            text = app.label,
            color = winInk(),
            fontSize = 12.sp,
            lineHeight = 14.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** A recommended app: small icon, name, and why it is listed. */
@Composable
private fun RecommendedItem(
    app: LauncherApp,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    modifier: Modifier,
) {
    Row(
        modifier = modifier
            .padding(2.dp)
            .winButton(onClick = { onLaunch(app.packageName) }, onLongClick = { onLongPress(app) })
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(bitmap = app.icon,
 filterQuality = FilterQuality.High, contentDescription = null, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(app.label, color = winInk(), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(stringResource(R.string.start_recently_added), color = winSubInk(), fontSize = 11.sp, maxLines = 1)
        }
    }
}

/** A row in a list of apps: small icon and the name. */
@Composable
private fun AppRow(app: LauncherApp, onLaunch: (String) -> Unit, onLongPress: (LauncherApp) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 1.dp)
            .winButton(onClick = { onLaunch(app.packageName) }, onLongClick = { onLongPress(app) })
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(bitmap = app.icon,
 filterQuality = FilterQuality.High, contentDescription = null, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(14.dp))
        Text(app.label, color = winInk(), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

private fun installTime(context: android.content.Context, packageName: String): Long =
    runCatching { context.packageManager.getPackageInfo(packageName, 0).firstInstallTime }.getOrDefault(0L)

private fun letterOf(label: String): Char {
    val c = label.trim().firstOrNull()?.uppercaseChar() ?: return '#'
    return if (c.isLetter()) c else '#'
}
