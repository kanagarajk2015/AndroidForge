package com.example.colourlauncher.ui

import androidx.compose.ui.draw.alpha
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.data.LauncherStyle
import com.example.colourlauncher.data.drawsArtwork
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.colourlauncher.DOCK_CAPACITY
import com.example.colourlauncher.LauncherViewModel
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.service.BadgeCounts
import com.example.colourlauncher.util.launchPackage
import com.example.colourlauncher.util.openAppInfo
import com.example.colourlauncher.util.setWallpaperFromUri
import com.example.colourlauncher.util.uninstallPackage
import kotlinx.coroutines.launch

/** Windows 11 flyouts grow out of the taskbar on a spring and shrink back quickly. */
private val PanelOrigin = TransformOrigin(0.5f, 1f)
private val PanelEnter = fadeIn(tween(160)) +
    slideInVertically(spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)) { it / 6 } +
    scaleIn(spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow), initialScale = 0.92f, transformOrigin = PanelOrigin)
private val PanelExit = fadeOut(tween(120)) +
    slideOutVertically(tween(180)) { it / 8 } +
    scaleOut(tween(180), targetScale = 0.95f, transformOrigin = PanelOrigin)

/**
 * Root of the launcher: the home screen, with the app drawer slid up on top of it.
 *
 * [homeSignal] changes whenever the system sends HOME again while the launcher is
 * already open. That closes the drawer.
 */
@Composable
fun LauncherScreen(viewModel: LauncherViewModel, homeSignal: Int) {
    val context = LocalContext.current
    val apps by viewModel.apps.collectAsStateWithLifecycle()
    val pages by viewModel.pages.collectAsStateWithLifecycle()
    val folders by viewModel.folders.collectAsStateWithLifecycle()
    val dockPackages by viewModel.dock.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val iconPacks by viewModel.iconPacks.collectAsStateWithLifecycle()
    val notificationCounts by BadgeCounts.counts.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = context.setWallpaperFromUri(uri)
                // Themed styles cover the wallpaper with artwork, so show the wallpaper instead.
                if (ok) viewModel.updateSettings { it.copy(showArtwork = false) }
                Toast.makeText(
                    context,
                    if (ok) R.string.wallpaper_set else R.string.wallpaper_failed,
                    Toast.LENGTH_SHORT,
                ).show()
            }
        }
    }

    var drawerOpen by rememberSaveable { mutableStateOf(false) }
    var actionTarget by remember { mutableStateOf<LauncherApp?>(null) }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }
    var controlsOpen by rememberSaveable { mutableStateOf(false) }
    // Arrange mode: icons on the home screen can be dragged to new positions.
    var arranging by rememberSaveable { mutableStateOf(false) }
    // The folder open in its sheet, and the app waiting for a folder to be picked for it.
    var openFolderId by rememberSaveable { mutableStateOf<String?>(null) }
    var folderPickFor by remember { mutableStateOf<String?>(null) }

    // Back closes the drawer. On the home screen it is consumed, so the launcher never exits.
    BackHandler {
        drawerOpen = false
        controlsOpen = false
        arranging = false
    }
    LaunchedEffect(homeSignal) {
        drawerOpen = false
        controlsOpen = false
        arranging = false
        openFolderId = null
        folderPickFor = null
    }
    // Locking the layout ends any arranging in progress.
    LaunchedEffect(settings.lockHome) {
        if (settings.lockHome) arranging = false
    }

    // Apps opened from here this session, shown with the running-app bar on the Windows 11 taskbar.
    val launched = remember { mutableStateListOf<String>() }
    val launch: (String) -> Unit = { packageName ->
        drawerOpen = false
        if (packageName !in launched) launched.add(packageName)
        context.launchPackage(packageName)
    }
    val openActions: (LauncherApp) -> Unit = { actionTarget = it }

    // Badges show only when the setting is on. Counts stay empty until notification access is granted.
    val badges = if (settings.showBadges) notificationCounts else emptyMap<String, Int>()
    val appsByPackage = remember(apps) { apps.associateBy { it.packageName } }
    // Every app placed on a home page. The action sheet uses it to offer the home-screen actions.
    val homeApps = pages.flatten().filterNotNull().toSet()

    // The locals are provided around everything that draws icons or reads settings, including the
    // sheets. A composition local only reaches content inside the provider that sets it.
    CompositionLocalProvider(
        LocalLauncherSettings provides settings,
        LocalBadgeCounts provides badges,
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Themed styles bring their own artwork, which takes the place of the wallpaper.
            if (settings.style.themed && settings.showArtwork) ThemedBackdrop()
            if (settings.style == LauncherStyle.Windows11 && settings.showArtwork) WindowsBloomBackdrop()
            // Dim layer, only where the wallpaper itself is showing.
            if (!settings.drawsArtwork && settings.wallpaperDim > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(androidx.compose.ui.graphics.Color.Black.copy(alpha = settings.wallpaperDim)),
                )
            }
            // Hidden while the full-screen drawer is open, so the drawer's dark scrim shows only the wallpaper.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(if (drawerOpen && settings.style != LauncherStyle.Windows11) 0f else 1f),
            ) {
                HomeScreen(
                    apps = apps,
                    pages = pages,
                    folders = folders,
                    dockPackages = dockPackages,
                    onLaunch = launch,
                    onLongPress = openActions,
                    onOpenFolder = { openFolderId = it },
                    onOpenDrawer = { drawerOpen = true },
                    onOpenSettings = { settingsOpen = true },
                    onOpenControls = { controlsOpen = true },
                    onAddPage = viewModel::addPage,
                    arranging = arranging,
                    onDrop = viewModel::dropHome,
                    onDoneArranging = { arranging = false },
                    runningPackages = launched.toSet(),
                )
            }

            if (settings.style == LauncherStyle.Windows11) {
                // Quick-settings flyout above the taskbar's clock. Tapping outside closes it.
                AnimatedVisibility(
                    visible = controlsOpen,
                    modifier = Modifier.fillMaxSize(),
                    enter = PanelEnter,
                    exit = PanelExit,
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { controlsOpen = false },
                    ) {
                        Surface(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .navigationBarsPadding()
                                .padding(end = 12.dp, bottom = TaskbarHeight + 12.dp)
                                .widthIn(max = 380.dp)
                                .fillMaxWidth()
                                .heightIn(max = 560.dp)
                                .pointerInput(Unit) { detectTapGestures { } },
                            shape = RoundedCornerShape(8.dp),
                            color = winAcrylic(),
                            border = BorderStroke(1.dp, winStroke()),
                            shadowElevation = 12.dp,
                        ) {
                            ControlContent(onClose = { controlsOpen = false })
                        }
                    }
                }

                // Start menu: a floating panel above the taskbar. Tapping outside it closes it.
                AnimatedVisibility(
                    visible = drawerOpen,
                    modifier = Modifier.fillMaxSize(),
                    enter = PanelEnter,
                    exit = PanelExit,
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { drawerOpen = false },
                    ) {
                        StartMenu(
                            apps = apps,
                            pinnedPackages = pages.flatten(),
                            onLaunch = launch,
                            onLongPress = openActions,
                            onOpenSettings = {
                                drawerOpen = false
                                settingsOpen = true
                            },
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .navigationBarsPadding()
                                .padding(start = 12.dp, end = 12.dp, bottom = TaskbarHeight + 12.dp)
                                .fillMaxWidth()
                                .widthIn(max = 600.dp)
                                .fillMaxHeight(0.78f)
                                // Swallow taps so only the area outside the menu closes it.
                                .pointerInput(Unit) { detectTapGestures { } },
                        )
                    }
                }
            } else {
                AnimatedVisibility(
                    visible = drawerOpen,
                    modifier = Modifier.fillMaxSize(),
                    enter = slideInVertically(initialOffsetY = { it }),
                    exit = slideOutVertically(targetOffsetY = { it }),
                ) {
                    AppDrawer(
                        apps = apps,
                        onLaunch = launch,
                        onLongPress = openActions,
                        onClose = { drawerOpen = false },
                    )
                }
            }
        }

        if (controlsOpen && settings.style != LauncherStyle.Windows11) {
            ControlSheet(onDismiss = { controlsOpen = false })
        }

        // An open folder, with its apps. It is shown only while the folder still exists.
        openFolderId?.let { id ->
            folders[id]?.let { folder ->
                FolderSheet(
                    folder = folder,
                    appsByPackage = appsByPackage,
                    onLaunch = { packageName ->
                        openFolderId = null
                        launch(packageName)
                    },
                    onLongPress = { app ->
                        openFolderId = null
                        actionTarget = app
                    },
                    onRename = { viewModel.renameFolder(id, it) },
                    onDelete = {
                        viewModel.deleteFolder(id)
                        openFolderId = null
                    },
                    onDismiss = { openFolderId = null },
                )
            }
        }

        folderPickFor?.let { packageName ->
            FolderPickerSheet(
                folders = folders.values.toList(),
                onPick = { folderId ->
                    viewModel.addToFolder(packageName, folderId)
                    folderPickFor = null
                },
                onNewFolder = {
                    viewModel.createFolder(packageName)
                    folderPickFor = null
                },
                onDismiss = { folderPickFor = null },
            )
        }

        if (settingsOpen) {
            SettingsSheet(
                settings = settings,
                iconPacks = iconPacks,
                apps = apps,
                onChange = viewModel::updateSettings,
                onPickWallpaper = { wallpaperPicker.launch("image/*") },
                onAutoArrange = { viewModel.autoArrangeHome() },
                onResetDock = { viewModel.resetDock() },
                onFreeArrange = {
                    settingsOpen = false
                    arranging = true
                },
                onDismiss = { settingsOpen = false },
            )
        }

        actionTarget?.let { app ->
            val pkg = app.packageName
            val addHomeLabel = stringResource(R.string.action_add_to_home)
            val removeHomeLabel = stringResource(R.string.action_remove_from_home)
            val addDockLabel = stringResource(R.string.action_add_to_dock)
            val removeDockLabel = stringResource(R.string.action_remove_from_dock)
            val appInfoLabel = stringResource(R.string.action_app_info)
            val uninstallLabel = stringResource(R.string.action_uninstall)

            val moveLabel = stringResource(R.string.action_move_icons)
            val addFolderLabel = stringResource(R.string.action_add_to_folder)
            val removeFolderLabel = stringResource(R.string.action_remove_from_folder)
            val prevPageLabel = stringResource(R.string.action_move_prev_page)
            val nextPageLabel = stringResource(R.string.action_move_next_page)

            // Whether the app sits in a folder, and which home page it is on (-1 if none).
            val inFolder = folders.values.any { pkg in it.packages }
            val homePage = pages.indexOfFirst { pkg in it }

            val actions = buildList<MenuAction> {
                // With the home screen locked, nothing that changes the layout is offered.
                if (!settings.lockHome) {
                    when {
                        pkg in homeApps -> {
                            add(MenuAction(moveLabel) {
                                drawerOpen = false
                                arranging = true
                            })
                            add(MenuAction(addFolderLabel) { folderPickFor = pkg })
                            if (homePage > 0) add(MenuAction(prevPageLabel) { viewModel.moveToPage(pkg, -1) })
                            add(MenuAction(nextPageLabel) { viewModel.moveToPage(pkg, 1) })
                            add(MenuAction(removeHomeLabel) { viewModel.removeFromHome(pkg) })
                        }
                        inFolder -> add(MenuAction(removeFolderLabel) { viewModel.removeFromFolder(pkg) })
                        else -> {
                            add(MenuAction(addHomeLabel) { viewModel.addToHome(pkg) })
                            add(MenuAction(addFolderLabel) { folderPickFor = pkg })
                        }
                    }
                    if (pkg in dockPackages) {
                        add(MenuAction(removeDockLabel) { viewModel.removeFromDock(pkg) })
                    } else if (dockPackages.size < DOCK_CAPACITY) {
                        add(MenuAction(addDockLabel) { viewModel.addToDock(pkg) })
                    }
                }
                add(MenuAction(appInfoLabel) { context.openAppInfo(pkg) })
                add(MenuAction(uninstallLabel) { context.uninstallPackage(pkg) })
            }

            AppActionSheet(app = app, actions = actions, onDismiss = { actionTarget = null })
        }
    }
}
