package com.example.colourlauncher.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Reads the apps that have a launcher entry on this device. */
class AppRepository(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager

    /** Every launchable app except this launcher, sorted by label. Runs off the main thread. */
    suspend fun loadLauncherApps(iconPackName: String = ""): List<LauncherApp> = withContext(Dispatchers.IO) {
        val iconPack = iconPackName.takeIf { it.isNotEmpty() }?.let { IconPackRepository(context).load(it) }
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        packageManager.queryIntentActivities(query, 0)
            .asSequence()
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { info ->
                LauncherApp(
                    packageName = info.activityInfo.packageName,
                    label = info.loadLabel(packageManager).toString(),
                    icon = iconPack?.iconFor(info.activityInfo.packageName, ICON_SIZE_PX)
                        ?: info.loadIcon(packageManager)
                            .toSharpBitmap(ICON_SIZE_PX)
                            .asImageBitmap(),
                )
            }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    private companion object {
        /** Icons are drawn at up to 64dp, so 256px stays sharp even on 4x screens. */
        const val ICON_SIZE_PX = 256
    }
}

/**
 * Draws an icon [px] pixels square. An adaptive icon is drawn as its two layers on the full
 * 108dp canvas and only the central 72dp (the part any mask shows) is kept. That fills the icon
 * plate instead of leaving the artwork small in the middle, and it is rendered at full size
 * rather than scaled up afterwards, so edges stay crisp.
 */
internal fun Drawable.toSharpBitmap(px: Int): Bitmap {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && this is AdaptiveIconDrawable) {
        val full = (px * 108f / 72f).roundToInt()
        val canvasBitmap = Bitmap.createBitmap(full, full, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(canvasBitmap)
        background?.apply { setBounds(0, 0, full, full); draw(canvas) }
        foreground?.apply { setBounds(0, 0, full, full); draw(canvas) }
        val offset = (full - px) / 2
        return Bitmap.createBitmap(canvasBitmap, offset, offset, px, px)
    }
    return toBitmap(px, px)
}
