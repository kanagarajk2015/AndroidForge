package com.example.colourlauncher.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.ClockStyle
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle as DateTextStyle
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private val HmFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val HmsFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
private val LongDate: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM")
private val ShortDate: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE d MMM")

/**
 * The home screen clock for every [ClockStyle] except [ClockStyle.Default]. All of them work
 * offline and need no permission. [ink] is the main text colour for the launcher style behind it.
 */
@Composable
fun StyledClockHeader(style: ClockStyle, ink: Color, onOpenSettings: () -> Unit) {
    val now by produceState(initialValue = LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(1000L - System.currentTimeMillis() % 1000L)
        }
    }
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 8.dp, top = 24.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(modifier = Modifier.weight(1f)) { ClockBody(style, now, ink) }
        IconButton(onClick = onOpenSettings) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = stringResource(R.string.settings_open),
                tint = ink,
            )
        }
    }
}

@Composable
private fun ClockBody(style: ClockStyle, now: LocalDateTime, ink: Color) {
    when (style) {
        ClockStyle.Default, ClockStyle.Horizontal -> HorizontalClock(now, ink)
        ClockStyle.Dual -> DualClock(now, ink)
        ClockStyle.MultiTimezone -> MultiClock(now, ink)
        ClockStyle.CalendarClock -> CalendarClock(now, ink)
        ClockStyle.DateTime -> DateTimeClock(now, ink)
        ClockStyle.Vertical -> VerticalClock(now, ink)
        ClockStyle.BigNumber -> BigNumberClock(now, ink)
        ClockStyle.Small -> SmallClock(now, ink)
        ClockStyle.Circular -> CircularClock(now, ink)
        ClockStyle.Square -> SquareClock(now, ink)
        ClockStyle.Gradient -> GradientClock(now)
        ClockStyle.Amoled -> AmoledClock(now)
        ClockStyle.Retro -> RetroClock(now)
        ClockStyle.Vintage -> VintageClock(now)
        ClockStyle.Futuristic -> FuturisticClock(now)
        ClockStyle.Animated -> AnimatedClock(now, ink)
        ClockStyle.Floating -> FloatingClock(now, ink)
        ClockStyle.Battery -> BatteryClock(now, ink)
        ClockStyle.Binary -> BinaryClock(now, ink)
        ClockStyle.Word -> WordClock(now, ink)
        ClockStyle.Matrix -> MatrixClock(now)
        ClockStyle.Typographic -> TypographicClock(now, ink)
        ClockStyle.FlipCalendar -> FlipCalendarClock(now, ink)
        ClockStyle.MinimalDate -> MinimalDateClock(now, ink)
    }
}

/** Soft shadow so white text stays readable on bright wallpapers. */
private fun shadowed(base: TextStyle): TextStyle = base.copy(shadow = LauncherTextShadow)

@Composable
private fun HorizontalClock(now: LocalDateTime, ink: Color) {
    Column {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = now.format(HmFormat),
                style = shadowed(MaterialTheme.typography.displayLarge),
                color = ink,
                fontWeight = FontWeight.Light,
            )
            Text(
                text = now.format(DateTimeFormatter.ofPattern(":ss")),
                style = shadowed(MaterialTheme.typography.titleLarge),
                color = ink.copy(alpha = 0.7f),
                modifier = Modifier.padding(start = 4.dp, bottom = 12.dp),
            )
        }
        Text(
            text = now.format(LongDate),
            style = shadowed(MaterialTheme.typography.titleMedium),
            color = ink,
        )
    }
}

@Composable
private fun ZoneBlock(label: String, time: String, ink: Color) {
    Column {
        Text(
            text = time,
            style = shadowed(MaterialTheme.typography.displayMedium),
            color = ink,
            fontWeight = FontWeight.Light,
        )
        Text(text = label, style = shadowed(MaterialTheme.typography.labelLarge), color = ink.copy(alpha = 0.8f))
    }
}

private fun timeIn(zone: String): String =
    ZonedDateTime.now(ZoneId.of(zone)).format(HmFormat)

@Composable
private fun DualClock(now: LocalDateTime, ink: Color) {
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            ZoneBlock("Local", now.format(HmFormat), ink)
            ZoneBlock("UTC", timeIn("UTC"), ink)
        }
        Text(
            text = now.format(LongDate),
            style = shadowed(MaterialTheme.typography.titleMedium),
            color = ink,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

private val WorldZones = listOf(
    "London" to "Europe/London",
    "New York" to "America/New_York",
    "Dubai" to "Asia/Dubai",
    "Tokyo" to "Asia/Tokyo",
)

@Composable
private fun MultiClock(now: LocalDateTime, ink: Color) {
    Column {
        Text(
            text = now.format(HmFormat),
            style = shadowed(MaterialTheme.typography.displayMedium),
            color = ink,
            fontWeight = FontWeight.Light,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(top = 4.dp)) {
            WorldZones.forEach { (city, zone) ->
                Column {
                    Text(
                        text = timeIn(zone),
                        style = shadowed(MaterialTheme.typography.titleMedium),
                        color = ink,
                        fontWeight = FontWeight.Medium,
                    )
                    Text(text = city, style = shadowed(MaterialTheme.typography.labelSmall), color = ink.copy(alpha = 0.8f))
                }
            }
        }
    }
}

@Composable
private fun CalendarClock(now: LocalDateTime, ink: Color) {
    val today = now.toLocalDate()
    val monday = today.minusDays((today.dayOfWeek.value - 1).toLong())
    Column {
        Text(
            text = now.format(HmFormat),
            style = shadowed(MaterialTheme.typography.displayLarge),
            color = ink,
            fontWeight = FontWeight.Light,
        )
        Text(
            text = now.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
            style = shadowed(MaterialTheme.typography.titleMedium),
            color = ink,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            for (i in 0..6) {
                val day = monday.plusDays(i.toLong())
                val isToday = day == today
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isToday) ink else Color.Transparent)
                        .padding(horizontal = 7.dp, vertical = 6.dp),
                ) {
                    val textColor = if (isToday) Color.Black else ink
                    Text(
                        text = day.dayOfWeek.getDisplayName(DateTextStyle.NARROW, Locale.getDefault()),
                        style = MaterialTheme.typography.labelSmall,
                        color = textColor.copy(alpha = 0.8f),
                    )
                    Text(
                        text = day.dayOfMonth.toString(),
                        style = MaterialTheme.typography.labelLarge,
                        color = textColor,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }
}

@Composable
private fun DateTimeClock(now: LocalDateTime, ink: Color) {
    Column {
        Text(
            text = now.format(DateTimeFormatter.ofPattern("d MMMM")),
            style = shadowed(MaterialTheme.typography.displaySmall),
            color = ink,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = now.format(DateTimeFormatter.ofPattern("EEEE")) + "  " + now.format(HmFormat),
            style = shadowed(MaterialTheme.typography.titleLarge),
            color = ink,
        )
    }
}

@Composable
private fun VerticalClock(now: LocalDateTime, ink: Color) {
    Column {
        Text(
            text = now.format(DateTimeFormatter.ofPattern("HH")),
            style = shadowed(TextStyle(fontSize = 84.sp, lineHeight = 78.sp, fontWeight = FontWeight.Bold)),
            color = ink,
        )
        Text(
            text = now.format(DateTimeFormatter.ofPattern("mm")),
            style = shadowed(TextStyle(fontSize = 84.sp, lineHeight = 78.sp, fontWeight = FontWeight.Light)),
            color = ink,
        )
        Text(text = now.format(ShortDate), style = shadowed(MaterialTheme.typography.titleSmall), color = ink)
    }
}

@Composable
private fun BigNumberClock(now: LocalDateTime, ink: Color) {
    Column {
        Text(
            text = now.format(HmFormat),
            style = shadowed(TextStyle(fontSize = 104.sp, fontWeight = FontWeight.Black, letterSpacing = (-4).sp)),
            color = ink,
        )
        Text(text = now.format(LongDate), style = shadowed(MaterialTheme.typography.titleMedium), color = ink)
    }
}

@Composable
private fun SmallClock(now: LocalDateTime, ink: Color) {
    Text(
        text = now.format(HmFormat) + "  ·  " + now.format(ShortDate),
        style = shadowed(MaterialTheme.typography.titleMedium),
        color = ink,
        modifier = Modifier.padding(top = 6.dp),
    )
}

@Composable
private fun CircularClock(now: LocalDateTime, ink: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(modifier = Modifier.size(132.dp)) {
            val r = size.minDimension / 2f
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(color = ink.copy(alpha = 0.18f), radius = r, center = c)
            drawCircle(color = ink, radius = r, center = c, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
            for (i in 0 until 12) {
                val a = i * PI / 6.0
                val inner = r * if (i % 3 == 0) 0.80f else 0.88f
                drawLine(
                    color = ink,
                    start = Offset(c.x + (inner * sin(a)).toFloat(), c.y - (inner * cos(a)).toFloat()),
                    end = Offset(c.x + (r * 0.95f * sin(a)).toFloat(), c.y - (r * 0.95f * cos(a)).toFloat()),
                    strokeWidth = if (i % 3 == 0) 4f else 2f,
                    cap = StrokeCap.Round,
                )
            }
            fun hand(fraction: Double, length: Float, width: Float, color: Color) {
                val a = fraction * 2.0 * PI
                drawLine(
                    color = color,
                    start = c,
                    end = Offset(c.x + (r * length * sin(a)).toFloat(), c.y - (r * length * cos(a)).toFloat()),
                    strokeWidth = width,
                    cap = StrokeCap.Round,
                )
            }
            val sec = now.second.toDouble()
            val min = now.minute + sec / 60.0
            val hour = (now.hour % 12) + min / 60.0
            hand(hour / 12.0, 0.5f, 8f, ink)
            hand(min / 60.0, 0.75f, 5f, ink)
            hand(sec / 60.0, 0.85f, 2f, Color(0xFFFF5252))
            drawCircle(color = ink, radius = 6f, center = c)
        }
        Column(modifier = Modifier.padding(start = 16.dp)) {
            Text(text = now.format(HmFormat), style = shadowed(MaterialTheme.typography.headlineMedium), color = ink)
            Text(text = now.format(ShortDate), style = shadowed(MaterialTheme.typography.titleSmall), color = ink)
        }
    }
}

@Composable
private fun SquareClock(now: LocalDateTime, ink: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(128.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color.Black.copy(alpha = 0.35f))
                .border(2.dp, ink, RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = now.format(DateTimeFormatter.ofPattern("HH")),
                    style = TextStyle(fontSize = 46.sp, lineHeight = 46.sp, fontWeight = FontWeight.Bold),
                    color = ink,
                )
                Text(
                    text = now.format(DateTimeFormatter.ofPattern("mm")),
                    style = TextStyle(fontSize = 46.sp, lineHeight = 46.sp, fontWeight = FontWeight.Light),
                    color = ink,
                )
            }
        }
        Text(
            text = now.format(DateTimeFormatter.ofPattern("EEE\nd MMM")),
            style = shadowed(MaterialTheme.typography.titleMedium),
            color = ink,
            modifier = Modifier.padding(start = 16.dp),
        )
    }
}

@Composable
private fun GradientClock(now: LocalDateTime) {
    val brush = Brush.linearGradient(listOf(Color(0xFFFF6EC7), Color(0xFF8E7CFF), Color(0xFF4ADEDE)))
    Column {
        Text(
            text = now.format(HmFormat),
            style = TextStyle(brush = brush, fontSize = 88.sp, fontWeight = FontWeight.Bold),
        )
        Text(
            text = now.format(LongDate),
            style = TextStyle(brush = brush, fontSize = 18.sp, fontWeight = FontWeight.Medium),
        )
    }
}

@Composable
private fun AmoledClock(now: LocalDateTime) {
    Surface(shape = RoundedCornerShape(28.dp), color = Color.Black, border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A2A2A))) {
        Column(modifier = Modifier.padding(horizontal = 24.dp, vertical = 14.dp)) {
            Text(
                text = now.format(HmFormat),
                style = TextStyle(fontSize = 64.sp, fontWeight = FontWeight.ExtraLight),
                color = Color.White,
            )
            Text(text = now.format(LongDate), style = MaterialTheme.typography.labelLarge, color = Color(0xFF9E9E9E))
        }
    }
}

@Composable
private fun RetroClock(now: LocalDateTime) {
    val amber = Color(0xFFFFB000)
    Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFF1C1208), border = androidx.compose.foundation.BorderStroke(3.dp, Color(0xFF5A3B14))) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            Text(
                text = now.format(HmsFormat),
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold,
                    shadow = Shadow(color = amber.copy(alpha = 0.8f), blurRadius = 14f),
                ),
                color = amber,
            )
            Text(
                text = now.format(DateTimeFormatter.ofPattern("EEE dd.MM.yy")).uppercase(),
                style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                color = amber.copy(alpha = 0.75f),
            )
        }
    }
}

@Composable
private fun VintageClock(now: LocalDateTime) {
    val brown = Color(0xFF3E2A18)
    Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFFF3E5C8), border = androidx.compose.foundation.BorderStroke(2.dp, brown)) {
        Column(modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp)) {
            Text(
                text = now.format(HmFormat),
                style = TextStyle(fontFamily = FontFamily.Serif, fontSize = 56.sp, fontWeight = FontWeight.Bold),
                color = brown,
            )
            Text(
                text = now.format(LongDate),
                style = TextStyle(fontFamily = FontFamily.Serif, fontSize = 16.sp, fontStyle = FontStyle.Italic),
                color = brown,
            )
        }
    }
}

@Composable
private fun FuturisticClock(now: LocalDateTime) {
    val cyan = Color(0xFF00E5FF)
    Column {
        Text(
            text = now.format(HmFormat),
            style = TextStyle(
                fontSize = 72.sp,
                fontWeight = FontWeight.Thin,
                letterSpacing = 8.sp,
                shadow = Shadow(color = cyan, blurRadius = 28f),
            ),
            color = cyan,
        )
        Box(modifier = Modifier.width(220.dp).height(2.dp).background(Brush.horizontalGradient(listOf(cyan, Color.Transparent))))
        Text(
            text = now.format(DateTimeFormatter.ofPattern("EEE · dd · MMM")).uppercase(),
            style = TextStyle(fontSize = 14.sp, letterSpacing = 4.sp),
            color = cyan.copy(alpha = 0.85f),
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
private fun AnimatedClock(now: LocalDateTime, ink: Color) {
    val transition = rememberInfiniteTransition(label = "colon")
    val colonAlpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.15f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 900, easing = LinearEasing), RepeatMode.Reverse),
        label = "colonAlpha",
    )
    val progress = (now.second + 0f) / 60f
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = now.format(DateTimeFormatter.ofPattern("HH")),
                style = shadowed(MaterialTheme.typography.displayLarge),
                color = ink,
                fontWeight = FontWeight.Light,
            )
            Text(
                text = ":",
                style = shadowed(MaterialTheme.typography.displayLarge),
                color = ink.copy(alpha = colonAlpha),
                fontWeight = FontWeight.Light,
            )
            Text(
                text = now.format(DateTimeFormatter.ofPattern("mm")),
                style = shadowed(MaterialTheme.typography.displayLarge),
                color = ink,
                fontWeight = FontWeight.Light,
            )
        }
        Box(
            modifier = Modifier
                .width(200.dp)
                .height(4.dp)
                .clip(CircleShape)
                .background(ink.copy(alpha = 0.25f)),
        ) {
            Box(modifier = Modifier.fillMaxWidth(progress).height(4.dp).background(ink))
        }
    }
}

@Composable
private fun FloatingClock(now: LocalDateTime, ink: Color) {
    Surface(
        shape = RoundedCornerShape(32.dp),
        color = Color.White.copy(alpha = 0.16f),
        shadowElevation = 14.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
        modifier = Modifier.padding(4.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp),
        ) {
            Text(
                text = now.format(HmFormat),
                style = shadowed(MaterialTheme.typography.displaySmall),
                color = ink,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = now.format(DateTimeFormatter.ofPattern("EEE\nd MMM")),
                style = shadowed(MaterialTheme.typography.labelLarge),
                color = ink,
                modifier = Modifier.padding(start = 14.dp),
            )
        }
    }
}

private fun batteryPercent(context: Context): Int {
    val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
    return if (level >= 0 && scale > 0) level * 100 / scale else -1
}

@Composable
private fun BatteryClock(now: LocalDateTime, ink: Color) {
    val context = LocalContext.current
    // Reading the battery is cheap, and `now` changes every second, so just read it each time.
    val percent = remember(now.minute) { batteryPercent(context) }
    Column {
        Text(
            text = now.format(HmFormat),
            style = shadowed(MaterialTheme.typography.displayLarge),
            color = ink,
            fontWeight = FontWeight.Light,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .width(64.dp)
                    .height(12.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .border(1.5.dp, ink, RoundedCornerShape(4.dp)),
            ) {
                if (percent >= 0) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(percent / 100f)
                            .height(12.dp)
                            .background(if (percent <= 15) Color(0xFFFF5252) else ink),
                    )
                }
            }
            Text(
                text = (if (percent >= 0) "$percent%" else "--") + "  ·  " + now.format(ShortDate),
                style = shadowed(MaterialTheme.typography.titleMedium),
                color = ink,
                modifier = Modifier.padding(start = 10.dp),
            )
        }
    }
}

@Composable
private fun BinaryColumn(value: Int, bits: Int, ink: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (bit in 3 downTo 0) {
            val used = bit < bits
            val on = used && (((value shr bit) and 1) == 1)
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            !used -> Color.Transparent
                            on -> ink
                            else -> ink.copy(alpha = 0.22f)
                        },
                    ),
            )
        }
    }
}

@Composable
private fun BinaryClock(now: LocalDateTime, ink: Color) {
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BinaryColumn(now.hour / 10, 2, ink)
            BinaryColumn(now.hour % 10, 4, ink)
            Spacer(Modifier.width(8.dp))
            BinaryColumn(now.minute / 10, 3, ink)
            BinaryColumn(now.minute % 10, 4, ink)
            Spacer(Modifier.width(8.dp))
            BinaryColumn(now.second / 10, 3, ink)
            BinaryColumn(now.second % 10, 4, ink)
        }
        Text(
            text = now.format(HmsFormat),
            style = shadowed(MaterialTheme.typography.labelLarge),
            color = ink.copy(alpha = 0.8f),
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

private val HourWords = listOf(
    "twelve", "one", "two", "three", "four", "five", "six",
    "seven", "eight", "nine", "ten", "eleven",
)

/** "It is" plus the time to the nearest five minutes, in words. */
private fun wordTime(now: LocalDateTime): String {
    val rounded = ((now.minute + 2) / 5) * 5
    var hour = now.hour
    var minutes = rounded
    if (minutes == 60) {
        minutes = 0
        hour += 1
    }
    val past = minutes <= 30
    val shownHour = if (past) hour else hour + 1
    val h = HourWords[shownHour % 12]
    val m = if (past) minutes else 60 - minutes
    val minuteWords = when (m) {
        0 -> ""
        5 -> "five"
        10 -> "ten"
        15 -> "a quarter"
        20 -> "twenty"
        25 -> "twenty five"
        else -> "half"
    }
    return when {
        m == 0 -> "$h o'clock"
        m == 30 -> "half past $h"
        past -> "$minuteWords past $h"
        else -> "$minuteWords to $h"
    }
}

@Composable
private fun WordClock(now: LocalDateTime, ink: Color) {
    Column {
        Text(text = "IT IS", style = shadowed(MaterialTheme.typography.labelLarge), color = ink.copy(alpha = 0.7f))
        Text(
            text = wordTime(now).uppercase(),
            style = shadowed(TextStyle(fontSize = 30.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold)),
            color = ink,
        )
        Text(text = now.format(LongDate), style = shadowed(MaterialTheme.typography.titleSmall), color = ink.copy(alpha = 0.85f))
    }
}

@Composable
private fun MatrixClock(now: LocalDateTime) {
    val green = Color(0xFF00FF66)
    val glyphs = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿ0123456789"
    fun noise(seed: Int): String {
        val rnd = Random(seed)
        return String(CharArray(18) { glyphs[rnd.nextInt(glyphs.length)] })
    }
    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF021208).copy(alpha = 0.92f)) {
        Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
            val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            Text(noise(now.second), style = mono, color = green.copy(alpha = 0.25f))
            Text(noise(now.second + 100), style = mono, color = green.copy(alpha = 0.45f))
            Text(
                text = now.format(HmsFormat),
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold,
                    shadow = Shadow(color = green, blurRadius = 16f),
                ),
                color = green,
            )
            Text(noise(now.second + 200), style = mono, color = green.copy(alpha = 0.45f))
            Text(noise(now.second + 300), style = mono, color = green.copy(alpha = 0.25f))
        }
    }
}

@Composable
private fun TypographicClock(now: LocalDateTime, ink: Color) {
    Column {
        Text(
            text = now.format(DateTimeFormatter.ofPattern("HH")),
            style = shadowed(TextStyle(fontSize = 96.sp, lineHeight = 84.sp, fontWeight = FontWeight.Black)),
            color = ink,
        )
        Text(
            text = now.format(DateTimeFormatter.ofPattern("mm")),
            style = shadowed(TextStyle(fontSize = 96.sp, lineHeight = 84.sp, fontWeight = FontWeight.Thin)),
            color = ink,
        )
        Text(
            text = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM")).uppercase(),
            style = shadowed(TextStyle(fontSize = 12.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Medium)),
            color = ink,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

@Composable
private fun FlipCard(text: String, width: Int, height: Int, fontSize: Int) {
    Box(
        modifier = Modifier
            .size(width = width.dp, height = height.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF1E1E1E)),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            style = TextStyle(fontSize = fontSize.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center),
            color = Color(0xFFF2F2F2),
        )
        // The hinge line across the middle of the card.
        Box(modifier = Modifier.fillMaxWidth().height(2.dp).background(Color.Black))
    }
}

@Composable
private fun FlipCalendarClock(now: LocalDateTime, ink: Color) {
    val day = now.format(DateTimeFormatter.ofPattern("dd"))
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FlipCard(day.substring(0, 1), 52, 76, 46)
        FlipCard(day.substring(1, 2), 52, 76, 46)
        Column(modifier = Modifier.padding(start = 8.dp)) {
            Text(
                text = now.format(DateTimeFormatter.ofPattern("MMM")).uppercase(),
                style = shadowed(MaterialTheme.typography.titleLarge),
                color = ink,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = now.format(DateTimeFormatter.ofPattern("EEEE")),
                style = shadowed(MaterialTheme.typography.titleSmall),
                color = ink,
            )
            Text(
                text = now.format(HmFormat),
                style = shadowed(MaterialTheme.typography.titleMedium),
                color = ink.copy(alpha = 0.85f),
            )
        }
    }
}

@Composable
private fun MinimalDateClock(now: LocalDateTime, ink: Color) {
    Column {
        Text(
            text = now.format(DateTimeFormatter.ofPattern("d")),
            style = shadowed(TextStyle(fontSize = 64.sp, lineHeight = 64.sp, fontWeight = FontWeight.Light)),
            color = ink,
        )
        Text(
            text = now.format(DateTimeFormatter.ofPattern("EEEE · MMMM")).uppercase() + "  " + now.format(HmFormat),
            style = shadowed(TextStyle(fontSize = 12.sp, letterSpacing = 2.sp)),
            color = ink,
        )
    }
}
