package com.example.colourlauncher.data

/** Shape used to clip app icons. */
enum class IconShape { Rounded, Circle, Square }

/** Light/dark behaviour of the launcher's own surfaces (drawer, dock, sheets). */
enum class ThemeMode { System, Light, Dark }

/** Where the accent colour comes from. [Wallpaper] needs Android 12+; older versions use Blue. */
enum class Accent { Wallpaper, Blue, Green, Pink, Orange, Fluent }

/**
 * Overall layout: [Classic] is the original dock + handle, [Android17] a floating pill dock with a
 * search pill, [Windows11] a taskbar with a Start button and a Start-menu panel, [OxygenOS] a large
 * clock, a soft rounded dock and an app drawer with its search bar at the bottom.
 *
 * [themed] styles draw their own artwork behind the home screen, in place of the wallpaper:
 * [Aurora] violet waves, [SunsetGold] a gradient with gold lines, [GlassBlue] blue glass slabs and
 * [SkyBlue] a bright sky.
 */
enum class LauncherStyle(val themed: Boolean = false) {
    Classic,
    Android17,
    Windows11,
    OxygenOS,
    Aurora(themed = true),
    SunsetGold(themed = true),
    GlassBlue(themed = true),
    SkyBlue(themed = true),
}

/** User-adjustable look of the launcher. [iconPack] is a package name, or empty for system icons. */
data class LauncherSettings(
    val columns: Int = 4,
    val iconShape: IconShape = IconShape.Rounded,
    val iconSizeDp: Int = 56,
    val showLabels: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.System,
    val accent: Accent = Accent.Wallpaper,
    val iconPack: String = "",
    val style: LauncherStyle = LauncherStyle.Classic,
    /** When set, home screen icons can't be moved, added or removed. */
    val lockHome: Boolean = false,
)
