package com.example.colourlauncher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherStyle
import com.example.colourlauncher.ui.theme.aquaGlass
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay

// The themed styles are original artwork in the spirit of the wave, glass and gold looks.
// They use fixed colours, so the accent setting does not change them.

private val GoldAccent = Color(0xFFFFC93C)
private val DayFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("dd")
private val MonthFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("MMMM yyyy")
private val WeekdayFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE")
private val TimeOnlyFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val LongDateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM")

/**
 * Panel behind the dock. Each themed style has its own. The other styles keep the frosted glass
 * panel. OxygenOS has no panel, and [DockBar] does not call this for it.
 */
@Composable
fun Modifier.themedDockPanel(style: LauncherStyle, shape: Shape): Modifier = when (style) {
    LauncherStyle.Aurora -> this
        .background(Color.White.copy(alpha = 0.14f), shape)
        .border(1.dp, Color.White.copy(alpha = 0.3f), shape)
    LauncherStyle.SunsetGold -> this.border(1.5.dp, GoldAccent, shape)
    LauncherStyle.SkyBlue -> this
        .background(Color.White.copy(alpha = 0.24f), shape)
        .border(1.dp, Color.White.copy(alpha = 0.5f), shape)
    else -> this.aquaGlass(shape)
}

/** Artwork drawn behind the home screen for the themed styles. It replaces the wallpaper there. */
@Composable
fun ThemedBackdrop(style: LauncherStyle) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        when (style) {
            LauncherStyle.Aurora -> drawAurora()
            LauncherStyle.SunsetGold -> drawSunsetGold()
            LauncherStyle.GlassBlue -> drawGlassBlue()
            else -> drawSkyBlue()
        }
    }
}

/** Clock, date and settings button for the themed styles. Each style lays them out differently. */
@Composable
fun ThemedHeader(style: LauncherStyle, onOpenSettings: () -> Unit) {
    val now by produceState(initialValue = LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(10_000L)
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 8.dp, top = 24.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        when (style) {
            LauncherStyle.Aurora -> AuroraClock(now, Modifier.weight(1f))
            LauncherStyle.SunsetGold -> SunsetClock(now, Modifier.weight(1f))
            LauncherStyle.GlassBlue -> GlassClock(now, Modifier.weight(1f))
            else -> SkyClock(now, Modifier.weight(1f))
        }
        IconButton(onClick = onOpenSettings) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = stringResource(R.string.settings_open),
                tint = Color.White,
            )
        }
    }
}

/** Aurora: an analog clock beside a large day number, as on a wave-lock design. */
@Composable
private fun AuroraClock(now: LocalDateTime, modifier: Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        AnalogClock(now = now, modifier = Modifier.size(92.dp))
        Spacer(Modifier.width(20.dp))
        Column {
            Text(
                text = now.format(DayFormat),
                style = MaterialTheme.typography.displayLarge.copy(shadow = LauncherTextShadow),
                color = Color.White,
                fontWeight = FontWeight.Light,
            )
            Text(
                text = now.format(MonthFormat),
                style = MaterialTheme.typography.titleMedium.copy(shadow = LauncherTextShadow),
                color = Color.White,
            )
            Text(
                text = now.format(WeekdayFormat),
                style = MaterialTheme.typography.titleSmall.copy(shadow = LauncherTextShadow),
                color = Color.White,
            )
        }
    }
}

/** Sunset Gold: a digital time inside a gold outline, with the date in gold underneath. */
@Composable
private fun SunsetClock(now: LocalDateTime, modifier: Modifier) {
    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .padding(horizontal = 20.dp, vertical = 6.dp)
                .border(1.5.dp, GoldAccent, RoundedCornerShape(24.dp)),
        ) {
            Text(
                text = now.format(TimeOnlyFormat),
                style = MaterialTheme.typography.displayLarge,
                color = GoldAccent,
                fontWeight = FontWeight.Light,
            )
        }
        Text(
            text = now.format(LongDateFormat),
            style = MaterialTheme.typography.titleMedium.copy(shadow = LauncherTextShadow),
            color = GoldAccent,
            modifier = Modifier.padding(start = 8.dp, top = 8.dp),
        )
    }
}

/** Glass Blue: the clock and date on a frosted glass card. Text follows the theme so it stays readable. */
@Composable
private fun GlassClock(now: LocalDateTime, modifier: Modifier) {
    Box(
        modifier = modifier.aquaGlass(RoundedCornerShape(28.dp)),
    ) {
        Column(modifier = Modifier.padding(horizontal = 22.dp, vertical = 16.dp)) {
            Text(
                text = now.format(TimeOnlyFormat),
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = now.format(LongDateFormat),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Sky Blue: a centred, light clock on a bright sky. */
@Composable
private fun SkyClock(now: LocalDateTime, modifier: Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = now.format(TimeOnlyFormat),
            style = MaterialTheme.typography.displayLarge.copy(shadow = LauncherTextShadow),
            color = Color.White,
            fontWeight = FontWeight.Thin,
        )
        Text(
            text = now.format(LongDateFormat),
            style = MaterialTheme.typography.titleMedium.copy(shadow = LauncherTextShadow),
            color = Color.White,
        )
    }
}

/** Analog clock face: a ring, an hour hand and a minute hand. */
@Composable
private fun AnalogClock(now: LocalDateTime, modifier: Modifier) {
    Canvas(modifier = modifier) {
        val centre = center
        val radius = size.minDimension / 2f
        drawCircle(
            color = Color.White,
            radius = radius - 2.dp.toPx(),
            center = centre,
            style = Stroke(width = 2.dp.toPx()),
        )
        val minute = now.minute + now.second / 60f
        val hour = (now.hour % 12) + minute / 60f
        drawHand(centre, angle = hour / 12f * 360f, length = radius * 0.5f, width = 4.dp.toPx())
        drawHand(centre, angle = minute / 60f * 360f, length = radius * 0.82f, width = 2.dp.toPx())
    }
}

/** A hand from [centre] at [angle] degrees, where 0 is twelve o'clock. */
private fun DrawScope.drawHand(centre: Offset, angle: Float, length: Float, width: Float) {
    val radians = Math.toRadians((angle - 90f).toDouble())
    val end = Offset(
        centre.x + length * cos(radians).toFloat(),
        centre.y + length * sin(radians).toFloat(),
    )
    drawLine(color = Color.White, start = centre, end = end, strokeWidth = width, cap = StrokeCap.Round)
}

private fun DrawScope.drawAurora() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF4A12B0), Color(0xFF1A0A5C), Color(0xFF0A0524))))
    drawPath(wavePath(0.50f, 0.16f, flip = false, closed = true), Color(0xFFE040FF).copy(alpha = 0.45f))
    drawPath(wavePath(0.62f, 0.12f, flip = true, closed = true), Color(0xFF9B2BFF).copy(alpha = 0.55f))
    drawPath(wavePath(0.76f, 0.10f, flip = false, closed = true), Color(0xFF5A3BFF).copy(alpha = 0.6f))
}

private fun DrawScope.drawSunsetGold() {
    drawRect(
        Brush.linearGradient(
            colors = listOf(Color(0xFFFF2E7E), Color(0xFF7B2FE0), Color(0xFF2452FF)),
            start = Offset.Zero,
            end = Offset(size.width, size.height),
        ),
    )
    val gold = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
    drawPath(wavePath(0.56f, 0.07f, flip = false, closed = false), GoldAccent, style = gold)
    drawPath(wavePath(0.70f, 0.07f, flip = true, closed = false), GoldAccent, style = gold)
}

private fun DrawScope.drawGlassBlue() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF17456F), Color(0xFF0A2440), Color(0xFF040E1E))))
    drawPath(slabPath(0.42f, 0.12f, 0.60f, 0.30f), Color(0xFF8FD3FF).copy(alpha = 0.16f))
    drawPath(slabPath(0.66f, 0.44f, 0.72f, 0.50f), Color(0xFF5FB8FF).copy(alpha = 0.12f))
}

private fun DrawScope.drawSkyBlue() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFFBFE6FF), Color(0xFF5AAEFF), Color(0xFF2C6FE0))))
    drawPath(wavePath(0.82f, 0.05f, flip = false, closed = true), Color.White.copy(alpha = 0.22f))
    drawPath(wavePath(0.90f, 0.04f, flip = true, closed = true), Color.White.copy(alpha = 0.14f))
}

/**
 * A wave across the full width. [baseFraction] and [amplitudeFraction] are fractions of the height.
 * A closed wave is filled down to the bottom edge. An open wave is only a line, for stroking.
 */
private fun DrawScope.wavePath(
    baseFraction: Float,
    amplitudeFraction: Float,
    flip: Boolean,
    closed: Boolean,
): Path {
    val w = size.width
    val h = size.height
    val baseY = h * baseFraction
    val amplitude = h * amplitudeFraction
    val segment = w / 4f
    return Path().apply {
        moveTo(0f, baseY)
        for (i in 0 until 4) {
            val up = (i % 2 == 0) != flip
            quadraticBezierTo(
                segment * i + segment / 2f,
                baseY + (if (up) -amplitude else amplitude),
                segment * (i + 1),
                baseY,
            )
        }
        if (closed) {
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
    }
}

/** A slanted band across the screen. Each argument is a height fraction at the left or right edge. */
private fun DrawScope.slabPath(leftTop: Float, rightTop: Float, leftBottom: Float, rightBottom: Float): Path {
    val w = size.width
    val h = size.height
    return Path().apply {
        moveTo(0f, h * leftTop)
        lineTo(w, h * rightTop)
        lineTo(w, h * rightBottom)
        lineTo(0f, h * leftBottom)
        close()
    }
}
