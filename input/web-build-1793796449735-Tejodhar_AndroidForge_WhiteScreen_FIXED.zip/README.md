# Tejodhar AndroidForge — White Screen Diagnostic Fix

This revision updates the Android WebView wrapper for the live portal:
- https://tejodhar.in/
- https://www.tejodhar.in/

## Changes
- Better WebView initialization, DOM storage, responsive viewport and cookies.
- Removes the Android WebView `; wv` user-agent marker to improve compatibility with hosting/WAF rules that reject embedded browsers.
- Adds a loading progress indicator.
- Adds alternate-host retry when the primary host fails.
- Displays a readable error panel instead of leaving a blank white screen.
- Logs JavaScript console messages under `TejodharWeb`.
- Keeps SSL certificate validation strict; it does not ignore certificate errors.
- Preserves file chooser, download, camera and microphone support.

## Build
Open/import this folder in AndroidForge, build a new APK, uninstall the old APK, install the new APK and test on mobile data and Wi-Fi.

## Important
The previous log ZIP available in this conversation was from the earlier compilation failure, not a runtime WebView white-screen trace. This source update addresses common WebView blank-screen causes and adds diagnostics, but the exact runtime cause cannot be confirmed until the new APK is tested or a fresh runtime log/screenshot is supplied.
