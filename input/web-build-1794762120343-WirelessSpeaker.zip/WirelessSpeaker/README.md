# Wireless Speaker (Android)

Turns an Android phone into a Wi-Fi audio receiver. Other devices stream audio
to it; the phone plays it through its speaker or a connected output.

## Features

| Requested | Status |
|---|---|
| Receive audio wirelessly | Yes, over Wi-Fi (TCP), advertised with mDNS/NSD |
| Play music from another phone | Yes, if that phone runs a sender (see `tools/` and "Sending audio") |
| Connect to laptop | Yes, with `tools/send_wav.py` or any app that speaks the protocol |
| Connect to TV or other phone | Only if the sender speaks the protocol. Most TVs do not |
| Volume control | Yes (in-app slider) |
| Play / Pause / Stop | Yes (app and notification buttons) |
| Automatic reconnection | Yes. A new sender replaces the old one; the receiver re-listens and re-advertises when Wi-Fi drops or returns |
| Simple, attractive UI | Jetpack Compose, dark gradient, pulsing play button |
| Low-latency audio | AudioTrack in `PERFORMANCE_MODE_LOW_LATENCY`, about 60 ms buffer |

## Important limitation: not Bluetooth

A regular app cannot make a phone act as a Bluetooth speaker. Android does not
give third-party apps the Bluetooth audio sink role, and iOS does not allow it.
This app uses the same Wi-Fi network instead, so both devices must be on the
same network.

## Build

1. Open the `WirelessSpeaker` folder in Android Studio (Ladybug or newer).
   It will create the Gradle wrapper on first sync.
2. Let Gradle sync, then run the `app` configuration on a phone running
   Android 8.0 (API 26) or newer.
3. Accept the notification permission on first launch. The foreground service
   needs it to show play/pause and stop controls.

## Using it

1. Open the app on the receiving phone. It shows an address such as
   `192.168.1.20:47820`.
2. Start a sender on another device on the same Wi-Fi.
3. Audio plays automatically when the sender connects. Use Play/Pause, Stop,
   and the volume slider on the phone, or the notification buttons.
4. Stop disconnects the sender. The phone keeps listening, so the sender can
   reconnect at any time.

## Sending audio

Laptop (Python 3, no installs needed):

    python3 tools/send_wav.py 192.168.1.20 song.wav

The script streams 16-bit WAV files in real time.

## Protocol

Senders connect over TCP to port 47820 (or the port shown in the app) and send:

- A 12-byte header, big-endian: `WSPK` magic, version `1`, channels (1 or 2),
  bits per sample (`16`), a reserved byte, then the sample rate as a 32-bit integer.
- Raw signed 16-bit little-endian interleaved PCM, continuously, until the
  connection closes.

Keep sending data, even silence. The receiver drops a sender that is quiet for
15 seconds.

## Project layout

    app/src/main/java/com/example/wirelessspeaker/
      MainActivity.kt        Compose entry point; sends commands to the service
      service/SpeakerService.kt   Foreground service, notification, Wi-Fi/wake locks, network callback
      engine/SpeakerEngine.kt     TCP listener, sender sessions, pause/stop/volume
      engine/SpeakerState.kt      Shared UI state (StateFlow)
      audio/PcmPlayer.kt          Low-latency AudioTrack wrapper
      net/Protocol.kt             Header format and constants
      net/NsdAdvertiser.kt        Network service discovery registration
      net/LocalAddress.kt         Finds the phone's Wi-Fi IPv4 address
      ui/SpeakerScreen.kt         Main screen
      ui/Theme.kt                 Colors
    tools/send_wav.py             Laptop sender

## Known gaps / next steps

- No launcher icon yet. Add one with Android Studio's Image Asset tool.
- Volume here is the app's own gain. Hardware volume keys still control the
  media stream volume.
- Phone-to-phone sending needs a sender screen (file picker plus decoding with
  MediaCodec, or MediaProjection to capture system audio on Android 10+).
- TVs need a casting protocol (Chromecast, AirPlay, or DLNA) or an Android TV
  sender app. A custom protocol will not appear on most TVs.
- The code has not been compiled or run on a device in this environment.
