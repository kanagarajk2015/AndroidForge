#!/usr/bin/env python3
"""Stream a 16-bit WAV file to the Wireless Speaker app over Wi-Fi.

    python3 send_wav.py 192.168.1.20 song.wav
    python3 send_wav.py 192.168.1.20:47820 song.wav

The phone's address is shown on the app's main screen. Use this from a
laptop on the same Wi-Fi network as the phone. Only the Python standard
library is needed.
"""
import socket
import struct
import sys
import time
import wave

DEFAULT_PORT = 47820
FRAMES_PER_WRITE = 240   # about 5 ms at 48 kHz
AHEAD_LIMIT = 0.1        # keep at most ~100 ms queued ahead of real time


def main() -> None:
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)

    host, _, port_text = sys.argv[1].partition(":")
    port = int(port_text) if port_text else DEFAULT_PORT

    with wave.open(sys.argv[2], "rb") as wav:
        if wav.getsampwidth() != 2:
            sys.exit("Only 16-bit WAV files are supported")
        channels = wav.getnchannels()
        rate = wav.getframerate()
        if channels not in (1, 2):
            sys.exit("Only mono or stereo files are supported")

        # Header: magic, version, channels, bits per sample, reserved, sample rate.
        header = b"WSPK" + struct.pack(">BBBBI", 1, channels, 16, 0, rate)
        frame_bytes = channels * 2

        with socket.create_connection((host, port), timeout=10) as sock:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            sock.sendall(header)
            print(f"Streaming {rate} Hz, {channels} ch to {host}:{port}. Ctrl+C to stop.")

            start = time.monotonic()
            sent_frames = 0
            try:
                while True:
                    data = wav.readframes(FRAMES_PER_WRITE)
                    if not data:
                        break
                    sock.sendall(data)
                    sent_frames += len(data) // frame_bytes

                    # Pace to real time so the phone is never flooded.
                    ahead = sent_frames / rate - (time.monotonic() - start)
                    if ahead > AHEAD_LIMIT:
                        time.sleep(ahead - AHEAD_LIMIT)
            except KeyboardInterrupt:
                print("\nStopped.")
                return

    print("Finished.")


if __name__ == "__main__":
    main()
