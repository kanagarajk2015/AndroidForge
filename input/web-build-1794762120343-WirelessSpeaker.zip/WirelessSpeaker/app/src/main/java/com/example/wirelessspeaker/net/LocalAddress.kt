package com.example.wirelessspeaker.net

import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object LocalAddress {

    /**
     * The phone's IPv4 address on the local network, or null if it has none.
     * Wi-Fi interfaces are preferred over mobile data.
     */
    fun ipv4(): String? = runCatching {
        Collections.list(NetworkInterface.getNetworkInterfaces())
            .filter { it.isUp && !it.isLoopback }
            .sortedBy { if (it.name.startsWith("wlan")) 0 else 1 }
            .flatMap { Collections.list(it.inetAddresses) }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
            ?.hostAddress
    }.getOrNull()
}
