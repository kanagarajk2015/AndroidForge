package com.example.wirelessspeaker.net

import java.io.DataInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Wire format spoken by senders (laptops, other phones).
 *
 * 12-byte header, big-endian:
 *   0..3   magic "WSPK"
 *   4      version (1)
 *   5      channels (1 or 2)
 *   6      bits per sample (16)
 *   7      reserved (0)
 *   8..11  sample rate in Hz, e.g. 44100 or 48000
 *
 * Then raw signed 16-bit little-endian interleaved PCM until the sender
 * closes the connection. Senders should keep the stream flowing (silence is
 * fine): the receiver drops a sender that stays quiet for 15 seconds.
 */
object Protocol {
    const val DEFAULT_PORT = 47820
    const val SERVICE_TYPE = "_wspeaker._tcp"
    const val VERSION = 1
    const val HEADER_SIZE = 12

    /** Bytes per read. Divisible by 2 (mono frames) and 4 (stereo frames): 5 ms at 48 kHz stereo. */
    const val CHUNK_BYTES = 960
    const val READ_TIMEOUT_MS = 15_000

    private val MAGIC = "WSPK".toByteArray(Charsets.US_ASCII)

    data class Format(val sampleRate: Int, val channels: Int)

    fun readHeader(input: DataInputStream): Format {
        val header = ByteArray(HEADER_SIZE)
        input.readFully(header)

        if (!header.copyOfRange(0, 4).contentEquals(MAGIC)) {
            throw ProtocolException("Not a WSPK audio stream")
        }
        val version = header[4].toInt() and 0xFF
        if (version != VERSION) throw ProtocolException("Unsupported protocol version $version")

        val channels = header[5].toInt() and 0xFF
        if (channels !in 1..2) throw ProtocolException("Unsupported channel count $channels")

        val bits = header[6].toInt() and 0xFF
        if (bits != 16) throw ProtocolException("Only 16-bit PCM is supported")

        val rate = ByteBuffer.wrap(header, 8, 4).order(ByteOrder.BIG_ENDIAN).int
        if (rate !in 8_000..192_000) throw ProtocolException("Unsupported sample rate $rate")

        return Format(sampleRate = rate, channels = channels)
    }
}

class ProtocolException(message: String) : IOException(message)
