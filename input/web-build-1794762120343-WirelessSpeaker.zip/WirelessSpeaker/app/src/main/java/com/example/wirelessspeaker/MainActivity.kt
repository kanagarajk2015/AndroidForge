package com.example.wirelessspeaker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import com.example.wirelessspeaker.engine.SpeakerState
import com.example.wirelessspeaker.service.SpeakerService
import com.example.wirelessspeaker.ui.SpeakerScreen
import com.example.wirelessspeaker.ui.WirelessSpeakerTheme

class MainActivity : ComponentActivity() {

    // Notifications are optional, but without them the foreground-service controls are hidden.
    private val requestNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            sendCommand(SpeakerService.ACTION_START)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            WirelessSpeakerTheme {
                val state by SpeakerState.state.collectAsState()
                SpeakerScreen(
                    state = state,
                    onTogglePlay = { sendCommand(SpeakerService.ACTION_TOGGLE_PLAY) },
                    onStop = { sendCommand(SpeakerService.ACTION_STOP) },
                    onVolume = { sendCommand(SpeakerService.ACTION_VOLUME, it) },
                    onPowerOn = { sendCommand(SpeakerService.ACTION_START) },
                    onPowerOff = { sendCommand(SpeakerService.ACTION_POWER_OFF) },
                )
            }
        }

        val needsNotificationPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED

        if (needsNotificationPermission) {
            requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            sendCommand(SpeakerService.ACTION_START)
        }
    }

    private fun sendCommand(action: String, volume: Float? = null) {
        val intent = Intent(this, SpeakerService::class.java).setAction(action)
        if (volume != null) intent.putExtra(SpeakerService.EXTRA_VOLUME, volume)
        ContextCompat.startForegroundService(this, intent)
    }
}
