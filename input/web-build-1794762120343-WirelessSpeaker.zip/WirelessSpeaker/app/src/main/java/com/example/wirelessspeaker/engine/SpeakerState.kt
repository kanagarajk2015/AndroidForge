package com.example.wirelessspeaker.engine

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class Status {
    OFF,
    WAITING_FOR_NETWORK,
    LISTENING,
    PLAYING,
    PAUSED;

    /** True while a sender is connected (playing or paused). */
    val hasSender: Boolean
        get() = this == PLAYING || this == PAUSED
}

data class SpeakerUiState(
    val status: Status = Status.OFF,
    val deviceName: String = "",
    /** Address senders connect to, e.g. "192.168.1.20:47820". */
    val address: String? = null,
    /** Address of the connected sender, if any. */
    val senderAddress: String? = null,
    val volume: Float = 0.8f,
)

/** Single source of truth shared by the service (writer) and the UI (reader). */
object SpeakerState {
    private val _state = MutableStateFlow(SpeakerUiState())
    val state: StateFlow<SpeakerUiState> = _state.asStateFlow()

    fun update(transform: (SpeakerUiState) -> SpeakerUiState) {
        _state.update(transform)
    }
}
