package com.example.wirelessspeaker.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.wirelessspeaker.net.Protocol

/**
 * Low-latency PCM output. The device buffer holds about [BUFFER_MS] of audio:
 * small enough to feel immediate, large enough to ride out short Wi-Fi hiccups.
 * Raise BUFFER_MS if you hear crackling on a weak link.
 */
class PcmPlayer(format: Protocol.Format) {

    private val channelMask = if (format.channels == 1) {
        AudioFormat.CHANNEL_OUT_MONO
    } else {
        AudioFormat.CHANNEL_OUT_STEREO
    }
    private val frameBytes = format.channels * 2
    private val track: AudioTrack

    init {
        val minBuffer = AudioTrack.getMinBufferSize(
            format.sampleRate, channelMask, AudioFormat.ENCODING_PCM_16BIT
        )
        require(minBuffer > 0) { "This device cannot play ${format.sampleRate} Hz audio" }

        val wanted = format.sampleRate * frameBytes * BUFFER_MS / 1000
        val size = maxOf(minBuffer, wanted).let { (it + frameBytes - 1) / frameBytes * frameBytes }

        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(format.sampleRate)
                    .setChannelMask(channelMask)
                    .build()
            )
            .setBufferSizeInBytes(size)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
    }

    fun play() {
        track.play()
    }

    /** Pauses and drops anything still queued, so resuming is immediate. */
    fun pause() {
        track.pause()
        track.flush()
    }

    /** Blocks while the device buffer is full. Returns bytes written, or a negative error code. */
    fun write(buffer: ByteArray, length: Int): Int =
        track.write(buffer, 0, length, AudioTrack.WRITE_BLOCKING)

    fun setVolume(volume: Float) {
        track.setVolume(volume.coerceIn(0f, 1f))
    }

    fun release() {
        runCatching { track.stop() }
        track.release()
    }

    private companion object {
        const val BUFFER_MS = 60
    }
}
