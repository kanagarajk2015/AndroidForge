package com.example.wirelessspeaker.engine

import android.util.Log
import com.example.wirelessspeaker.audio.PcmPlayer
import com.example.wirelessspeaker.net.Protocol
import java.io.DataInputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Accepts senders over TCP and plays their audio.
 *
 * Only one sender plays at a time. A new sender replaces the current one
 * straight away, so a sender that dropped and reconnects is picked up without
 * waiting for a timeout. When a sender leaves, the engine keeps listening.
 */
class SpeakerEngine {

    private val lock = Any()
    private var server: ServerSocket? = null
    private var session: Session? = null

    @Volatile
    private var volume = 0.8f

    /** Starts listening if needed and returns the bound port. Safe to call repeatedly. */
    fun ensureListening(preferredPort: Int): Int {
        synchronized(lock) {
            server?.takeIf { !it.isClosed }?.let { return it.localPort }

            val socket = openServer(preferredPort)
            server = socket
            Thread({ acceptLoop(socket) }, "speaker-accept").apply {
                isDaemon = true
                start()
            }
            return socket.localPort
        }
    }

    /** Pauses or resumes the current sender's audio. Audio is discarded while paused. */
    fun togglePlayPause() {
        val current = synchronized(lock) { session } ?: return
        current.paused = !current.paused
        current.player?.let { if (current.paused) it.pause() else it.play() }
        SpeakerState.update {
            it.copy(status = if (current.paused) Status.PAUSED else Status.PLAYING)
        }
    }

    /** Disconnects the current sender. The engine keeps listening for the next one. */
    fun stopSession() {
        synchronized(lock) { session?.close() }
    }

    fun setVolume(value: Float) {
        volume = value.coerceIn(0f, 1f)
        SpeakerState.update { it.copy(volume = volume) }
        synchronized(lock) { session?.player }?.setVolume(volume)
    }

    fun shutdown() {
        synchronized(lock) {
            session?.close()
            session = null
            server?.close()
            server = null
        }
    }

    private fun openServer(preferredPort: Int): ServerSocket =
        try {
            ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(preferredPort))
            }
        } catch (e: IOException) {
            Log.w(TAG, "Port $preferredPort unavailable, using a free port instead")
            ServerSocket(0)
        }

    private fun acceptLoop(socket: ServerSocket) {
        while (!socket.isClosed) {
            val client = try {
                socket.accept()
            } catch (e: IOException) {
                break
            }
            startSession(client)
        }
    }

    private fun startSession(client: Socket) {
        val next = Session(client)
        synchronized(lock) {
            session?.close()
            session = next
        }
        Thread({ runSession(next) }, "speaker-session").apply {
            isDaemon = true
            start()
        }
    }

    private fun runSession(s: Session) {
        var player: PcmPlayer? = null
        try {
            s.socket.apply {
                soTimeout = Protocol.READ_TIMEOUT_MS
                tcpNoDelay = true
                keepAlive = true
            }
            val input = DataInputStream(s.socket.getInputStream().buffered(64 * 1024))
            val format = Protocol.readHeader(input)

            val created = PcmPlayer(format).also { it.setVolume(volume) }
            player = created
            s.player = created
            if (!s.paused) created.play()

            val senderAddress = s.socket.inetAddress.hostAddress
            SpeakerState.update {
                it.copy(
                    status = if (s.paused) Status.PAUSED else Status.PLAYING,
                    senderAddress = senderAddress,
                )
            }

            val chunk = ByteArray(Protocol.CHUNK_BYTES)
            while (!s.closed) {
                input.readFully(chunk)
                if (!s.paused) {
                    if (created.write(chunk, chunk.size) < 0) throw IOException("Playback failed")
                }
            }
        } catch (e: Exception) {
            Log.i(TAG, "Sender disconnected: ${e.message}")
        } finally {
            s.close()
            s.player = null
            player?.release()

            synchronized(lock) {
                // Only reset the UI if no newer sender has taken over.
                if (session === s) {
                    session = null
                    SpeakerState.update {
                        it.copy(status = Status.LISTENING, senderAddress = null)
                    }
                }
            }
        }
    }

    private inner class Session(val socket: Socket) {
        @Volatile var player: PcmPlayer? = null
        @Volatile var paused = false
        @Volatile var closed = false

        fun close() {
            closed = true
            runCatching { socket.close() }
        }
    }

    private companion object {
        const val TAG = "SpeakerEngine"
    }
}
