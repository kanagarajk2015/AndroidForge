package com.example.wirelessspeaker.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.wirelessspeaker.engine.SpeakerUiState
import com.example.wirelessspeaker.engine.Status

@Composable
fun SpeakerScreen(
    state: SpeakerUiState,
    onTogglePlay: () -> Unit,
    onStop: () -> Unit,
    onVolume: (Float) -> Unit,
    onPowerOn: () -> Unit,
    onPowerOff: () -> Unit,
) {
    val isOff = state.status == Status.OFF

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF0B1020), Color(0xFF1B1446), Color(0xFF0B3A44))
                )
            ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Header(state)

            Spacer(Modifier.weight(1f))

            PlayOrb(
                icon = when {
                    isOff -> Icons.Filled.PowerSettingsNew
                    state.status == Status.PLAYING -> Icons.Filled.Pause
                    else -> Icons.Filled.PlayArrow
                },
                enabled = isOff || state.status.hasSender,
                pulsing = state.status == Status.PLAYING,
                onClick = if (isOff) onPowerOn else onTogglePlay,
            )

            Spacer(Modifier.height(24.dp))

            Text(
                text = detailLabel(state),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )

            Spacer(Modifier.weight(1f))

            if (!isOff) {
                VolumeRow(volume = state.volume, onVolume = onVolume)
                Spacer(Modifier.height(20.dp))
                FilledTonalButton(onClick = onStop, enabled = state.status.hasSender) {
                    Icon(Icons.Filled.Stop, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Stop")
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onPowerOff) {
                    Text("Turn off", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun Header(state: SpeakerUiState) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Wireless Speaker",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = state.deviceName.ifBlank { "This phone" },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(16.dp))
        StatusChip(statusLabel(state.status))
    }
}

@Composable
private fun StatusChip(label: String) {
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelLarge,
        )
    }
}

@Composable
private fun PlayOrb(
    icon: ImageVector,
    enabled: Boolean,
    pulsing: Boolean,
    onClick: () -> Unit,
) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 1f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "pulseScale",
    )

    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(240.dp)) {
        if (pulsing) {
            Box(
                Modifier
                    .size(200.dp)
                    .scale(pulse)
                    .background(primary.copy(alpha = 0.18f), androidx.compose.foundation.shape.CircleShape)
            )
        }
        Box(
            modifier = Modifier
                .size(180.dp)
                .clip(androidx.compose.foundation.shape.CircleShape)
                .background(Brush.linearGradient(listOf(primary, secondary)))
                .alpha(if (enabled) 1f else 0.4f)
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(84.dp),
                tint = MaterialTheme.colorScheme.onPrimary,
            )
        }
    }
}

@Composable
private fun VolumeRow(volume: Float, onVolume: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(
            Icons.Filled.VolumeDown,
            contentDescription = "Volume down",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Slider(
            value = volume,
            onValueChange = onVolume,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp),
        )
        Icon(
            Icons.Filled.VolumeUp,
            contentDescription = "Volume up",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

private fun statusLabel(status: Status): String = when (status) {
    Status.OFF -> "Off"
    Status.WAITING_FOR_NETWORK -> "Waiting for Wi-Fi"
    Status.LISTENING -> "Ready"
    Status.PLAYING -> "Playing"
    Status.PAUSED -> "Paused"
}

private fun detailLabel(state: SpeakerUiState): String = when (state.status) {
    Status.OFF -> "Tap the button to start receiving audio"
    Status.WAITING_FOR_NETWORK -> "Connect this phone to Wi-Fi"
    Status.LISTENING -> state.address?.let { "Connect a sender to $it" } ?: "Starting..."
    Status.PLAYING, Status.PAUSED -> "Receiving from ${state.senderAddress ?: "a sender"}"
}
