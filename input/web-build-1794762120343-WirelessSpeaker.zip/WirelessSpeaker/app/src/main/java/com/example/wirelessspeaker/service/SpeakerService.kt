package com.example.wirelessspeaker.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import com.example.wirelessspeaker.MainActivity
import com.example.wirelessspeaker.R
import com.example.wirelessspeaker.engine.SpeakerEngine
import com.example.wirelessspeaker.engine.SpeakerState
import com.example.wirelessspeaker.engine.SpeakerUiState
import com.example.wirelessspeaker.engine.Status
import com.example.wirelessspeaker.net.LocalAddress
import com.example.wirelessspeaker.net.NsdAdvertiser
import com.example.wirelessspeaker.net.Protocol
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground service that keeps the speaker alive in the background:
 * the TCP listener, the audio output, network advertising and the notification
 * with play/pause and stop buttons.
 */
class SpeakerService : Service() {

    private val engine = SpeakerEngine()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private lateinit var advertiser: NsdAdvertiser
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        advertiser = NsdAdvertiser(this)
        createChannel()
        acquireLocks()
        watchNetwork()

        scope.launch {
            SpeakerState.state.collect { state ->
                NotificationManagerCompat.from(this@SpeakerService)
                    .notify(NOTIFICATION_ID, buildNotification(state))
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(SpeakerState.state.value),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
        )

        val action = intent?.action
        if (action == ACTION_POWER_OFF) {
            stopSelf()
            return START_NOT_STICKY
        }

        ensureListening()

        when (action) {
            ACTION_TOGGLE_PLAY -> engine.togglePlayPause()
            ACTION_STOP -> engine.stopSession()
            ACTION_VOLUME -> engine.setVolume(intent?.getFloatExtra(EXTRA_VOLUME, 0.8f) ?: 0.8f)
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        networkCallback?.let {
            runCatching {
                getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it)
            }
        }
        advertiser.unregister()
        engine.shutdown()
        scope.cancel()

        wakeLock?.takeIf { it.isHeld }?.release()
        wifiLock?.takeIf { it.isHeld }?.release()

        SpeakerState.update { SpeakerUiState(status = Status.OFF, volume = it.volume) }
        super.onDestroy()
    }

    /** Makes sure the listener is up and advertised on the current network. */
    private fun ensureListening() {
        val port = engine.ensureListening(Protocol.DEFAULT_PORT)
        advertise(port)
    }

    private fun advertise(port: Int) {
        val ip = LocalAddress.ipv4()
        if (ip == null) {
            advertiser.unregister()
            SpeakerState.update {
                it.copy(
                    status = if (it.status.hasSender) it.status else Status.WAITING_FOR_NETWORK,
                    address = null,
                )
            }
            return
        }

        advertiser.register(Build.MODEL, port)
        SpeakerState.update {
            it.copy(
                status = if (it.status.hasSender) it.status else Status.LISTENING,
                deviceName = Build.MODEL,
                address = "$ip:$port",
            )
        }
    }

    /** Re-listens and re-advertises when Wi-Fi drops or comes back, so senders can reconnect. */
    private fun watchNetwork() {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                ensureListening()
            }

            override fun onLinkPropertiesChanged(network: Network, linkProperties: LinkProperties) {
                ensureListening()
            }

            override fun onLost(network: Network) {
                advertiser.unregister()
                SpeakerState.update {
                    it.copy(
                        status = if (it.status.hasSender) it.status else Status.WAITING_FOR_NETWORK,
                        address = null,
                    )
                }
            }
        }
        getSystemService(ConnectivityManager::class.java).registerDefaultNetworkCallback(callback)
        networkCallback = callback
    }

    private fun acquireLocks() {
        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WirelessSpeaker:playback")
            .apply {
                setReferenceCounted(false)
                acquire()
            }

        val wifiMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        } else {
            WifiManager.WIFI_MODE_FULL_HIGH_PERF
        }
        wifiLock = getSystemService(WifiManager::class.java)
            .createWifiLock(wifiMode, "WirelessSpeaker:wifi")
            .apply {
                setReferenceCounted(false)
                acquire()
            }
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Speaker status", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(state: SpeakerUiState): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(statusText(state))
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .addAction(0, "Play / Pause", actionIntent(ACTION_TOGGLE_PLAY, 1))
            .addAction(0, "Stop", actionIntent(ACTION_STOP, 2))
            .build()
    }

    private fun actionIntent(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getService(
            this,
            requestCode,
            Intent(this, SpeakerService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun statusText(state: SpeakerUiState): String = when (state.status) {
        Status.OFF -> "Off"
        Status.WAITING_FOR_NETWORK -> "Waiting for Wi-Fi"
        Status.LISTENING -> "Ready at ${state.address ?: "..."}"
        Status.PLAYING -> "Playing from ${state.senderAddress ?: "a sender"}"
        Status.PAUSED -> "Paused"
    }

    companion object {
        const val ACTION_START = "com.example.wirelessspeaker.action.START"
        const val ACTION_TOGGLE_PLAY = "com.example.wirelessspeaker.action.TOGGLE_PLAY"
        const val ACTION_STOP = "com.example.wirelessspeaker.action.STOP"
        const val ACTION_VOLUME = "com.example.wirelessspeaker.action.VOLUME"
        const val ACTION_POWER_OFF = "com.example.wirelessspeaker.action.POWER_OFF"
        const val EXTRA_VOLUME = "volume"

        private const val CHANNEL_ID = "speaker_status"
        private const val NOTIFICATION_ID = 1
    }
}
