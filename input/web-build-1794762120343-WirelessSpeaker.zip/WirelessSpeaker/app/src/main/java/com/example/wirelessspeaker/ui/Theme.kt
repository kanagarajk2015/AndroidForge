package com.example.wirelessspeaker.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SpeakerColors = darkColorScheme(
    primary = Color(0xFF5EE7DF),
    onPrimary = Color(0xFF00201E),
    secondary = Color(0xFFB490F5),
    background = Color(0xFF0B1020),
    onBackground = Color(0xFFE8ECF8),
    surface = Color(0xFF151C33),
    onSurface = Color(0xFFE8ECF8),
    surfaceVariant = Color(0xFF232C48),
    onSurfaceVariant = Color(0xFF9AA5C4),
)

@Composable
fun WirelessSpeakerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = SpeakerColors, content = content)
}
