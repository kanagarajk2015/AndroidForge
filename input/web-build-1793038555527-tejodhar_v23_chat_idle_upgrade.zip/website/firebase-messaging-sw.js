/* Tejodhar browser push (Firebase Cloud Messaging). Keep this file next to index.php. */
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js','https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');
var cfg=null;
try{cfg=JSON.parse(atob(decodeURIComponent(new URL(self.location.href).searchParams.get('c')||'')));}catch(e){}
if(cfg){
  firebase.initializeApp(cfg);
  var messaging=firebase.messaging();
  messaging.onBackgroundMessage(function(p){
    var d=(p&&p.data)||{};
    return self.registration.showNotification(d.title||'Tejodhar',{
      body:d.body||'',
      tag:d.tag||undefined,
      icon:'https://res.cloudinary.com/wpizqa3u/image/upload/f_auto,q_auto,w_192/v1791246585/file_000000008458820887ff6b6738cd6e8a.png',
      data:{tab:d.tab||''}
    });
  });
}
self.addEventListener('notificationclick',function(event){
  event.notification.close();
  var tab=(event.notification.data&&event.notification.data.tab)||'';
  event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(function(list){
    for(var i=0;i<list.length;i++){
      var c=list[i];
      if('focus' in c){c.postMessage({tjOpen:tab});return c.focus();}
    }
    var u=new URL('./',self.registration.scope);if(tab)u.searchParams.set('open',tab);
    return self.clients.openWindow(u.href);
  }));
});
