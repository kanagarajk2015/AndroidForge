package com.example.colourlauncher.ui

import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.Accent
import com.example.colourlauncher.data.AiKeyAction
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.data.drawsArtwork
import com.example.colourlauncher.service.AiKeyService
import com.example.colourlauncher.data.IconPackInfo
import com.example.colourlauncher.data.IconShape
import com.example.colourlauncher.data.LauncherSettings
import com.example.colourlauncher.data.LauncherStyle
import com.example.colourlauncher.data.ThemeMode
import com.example.colourlauncher.ui.theme.aquaGlassFill
import com.example.colourlauncher.util.openAppInfo
import com.example.colourlauncher.util.openSettingsScreen
import com.example.colourlauncher.util.runAiKeyAction
import com.example.colourlauncher.util.openIconPackStore

/** Bottom sheet for theme, wallpaper, icon pack and the icon grid look. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    settings: LauncherSettings,
    iconPacks: List<IconPackInfo>,
    apps: List<LauncherApp>,
    onChange: ((LauncherSettings) -> LauncherSettings) -> Unit,
    onPickWallpaper: () -> Unit,
    onAutoArrange: () -> Unit,
    onFreeArrange: () -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val glass = aquaGlassFill()
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = glass) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 24.dp, end = 24.dp, bottom = 32.dp),
        ) {
            Text(text = stringResource(R.string.settings_title), style = MaterialTheme.typography.titleLarge)

            Section(stringResource(R.string.settings_style)) {
                LauncherStyle.entries.forEach { style ->
                    FilterChip(
                        selected = settings.style == style,
                        // Picking a style also applies its matching accent and icon shape.
                        // Both can still be changed below afterwards.
                        onClick = {
                            onChange {
                                when (style) {
                                    LauncherStyle.Windows11 -> it.copy(
                                        style = style,
                                        accent = wallpaperAccentOr(Accent.Fluent),
                                        iconShape = IconShape.Rounded,
                                    )
                                    LauncherStyle.OxygenOS -> it.copy(
                                        style = style,
                                        accent = wallpaperAccentOr(Accent.Green),
                                        iconShape = IconShape.Circle,
                                        iconSizeDp = 60,
                                    )
                                    LauncherStyle.Aurora -> it.copy(
                                        style = style,
                                        accent = wallpaperAccentOr(Accent.Blue),
                                        iconShape = IconShape.Circle,
                                    )
                                    LauncherStyle.SunsetGold -> it.copy(
                                        style = style,
                                        accent = wallpaperAccentOr(Accent.Pink),
                                        iconShape = IconShape.Rounded,
                                    )
                                    LauncherStyle.GlassBlue -> it.copy(
                                        style = style,
                                        accent = wallpaperAccentOr(Accent.Blue),
                                        iconShape = IconShape.Circle,
                                    )
                                    LauncherStyle.SkyBlue -> it.copy(
                                        style = style,
                                        accent = wallpaperAccentOr(Accent.Blue),
                                        iconShape = IconShape.Circle,
                                    )
                                    LauncherStyle.PastelGlow -> it.copy(
                                        style = style,
                                        accent = wallpaperAccentOr(Accent.Blue),
                                        iconShape = IconShape.Rounded,
                                        iconSizeDp = 60,
                                    )
                                    LauncherStyle.DateFocus -> it.copy(
                                        style = style,
                                        accent = wallpaperAccentOr(Accent.Blue),
                                        iconShape = IconShape.Rounded,
                                    )
                                    LauncherStyle.RingClock -> it.copy(
                                        style = style,
                                        accent = wallpaperAccentOr(Accent.Pink),
                                        iconShape = IconShape.Rounded,
                                    )
                                    LauncherStyle.MidnightCircles -> it.copy(
                                        style = style,
                                        accent = wallpaperAccentOr(Accent.Blue),
                                        iconShape = IconShape.Circle,
                                    )
                                }
                            }
                        },
                        label = {
                            Text(
                                stringResource(
                                    when (style) {
                                        LauncherStyle.Windows11 -> R.string.style_windows11
                                        LauncherStyle.OxygenOS -> R.string.style_oxygenos
                                        LauncherStyle.Aurora -> R.string.style_aurora
                                        LauncherStyle.SunsetGold -> R.string.style_sunset_gold
                                        LauncherStyle.GlassBlue -> R.string.style_glass_blue
                                        LauncherStyle.SkyBlue -> R.string.style_sky_blue
                                        LauncherStyle.PastelGlow -> R.string.style_pastel_glow
                                        LauncherStyle.DateFocus -> R.string.style_date_focus
                                        LauncherStyle.RingClock -> R.string.style_ring_clock
                                        LauncherStyle.MidnightCircles -> R.string.style_midnight_circles
                                    },
                                ),
                            )
                        },
                    )
                }
            }

            Section(stringResource(R.string.home_layout_tools)) {
                OutlinedButton(onClick = onAutoArrange, enabled = !settings.lockHome) {
                    Text(stringResource(R.string.home_auto_arrange))
                }
                OutlinedButton(onClick = onFreeArrange, enabled = !settings.lockHome) {
                    Text(stringResource(R.string.home_free_arrange))
                }
            }
            Text(
                text = stringResource(R.string.home_layout_tools_summary),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Section(stringResource(R.string.settings_wallpaper)) {
                OutlinedButton(onClick = onPickWallpaper) {
                    Text(stringResource(R.string.settings_pick_wallpaper))
                }
            }
            if (settings.style.themed || settings.style == LauncherStyle.Windows11) {
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                        Text(stringResource(R.string.settings_style_artwork), style = MaterialTheme.typography.bodyLarge)
                        Text(
                            text = stringResource(R.string.settings_style_artwork_summary),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = settings.showArtwork,
                        onCheckedChange = { checked -> onChange { it.copy(showArtwork = checked) } },
                    )
                }
            }
            if (!settings.drawsArtwork) {
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.settings_wallpaper_dim), style = MaterialTheme.typography.bodyLarge)
                Slider(
                    value = settings.wallpaperDim,
                    onValueChange = { v -> onChange { it.copy(wallpaperDim = v) } },
                    valueRange = 0f..0.6f,
                )
            }

            Section(stringResource(R.string.settings_theme)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = settings.themeMode == mode,
                        onClick = { onChange { it.copy(themeMode = mode) } },
                        label = {
                            Text(
                                stringResource(
                                    when (mode) {
                                        ThemeMode.System -> R.string.theme_system
                                        ThemeMode.Light -> R.string.theme_light
                                        ThemeMode.Dark -> R.string.theme_dark
                                    },
                                ),
                            )
                        },
                    )
                }
            }

            Section(stringResource(R.string.settings_accent)) {
                Accent.entries
                    // Wallpaper colours only exist on Android 12 and later.
                    .filter { it != Accent.Wallpaper || Build.VERSION.SDK_INT >= Build.VERSION_CODES.S }
                    .forEach { accent ->
                        FilterChip(
                            selected = settings.accent == accent,
                            onClick = { onChange { it.copy(accent = accent) } },
                            label = {
                                Text(
                                    stringResource(
                                        when (accent) {
                                            Accent.Wallpaper -> R.string.accent_wallpaper
                                            Accent.Blue -> R.string.accent_blue
                                            Accent.Green -> R.string.accent_green
                                            Accent.Pink -> R.string.accent_pink
                                            Accent.Orange -> R.string.accent_orange
                                            Accent.Fluent -> R.string.accent_fluent
                                        },
                                    ),
                                )
                            },
                        )
                    }
            }

            Section(stringResource(R.string.settings_icon_pack)) {
                FilterChip(
                    selected = settings.iconPack.isEmpty(),
                    onClick = { onChange { it.copy(iconPack = "") } },
                    label = { Text(stringResource(R.string.icon_pack_default)) },
                )
                iconPacks.forEach { pack ->
                    FilterChip(
                        selected = settings.iconPack == pack.packageName,
                        onClick = { onChange { it.copy(iconPack = pack.packageName) } },
                        label = { Text(pack.label) },
                    )
                }
            }

            if (iconPacks.isEmpty()) {
                Text(
                    text = stringResource(R.string.icon_pack_none),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
            OutlinedButton(onClick = { context.openIconPackStore() }) {
                Text(stringResource(R.string.icon_pack_get))
            }

            Section(stringResource(R.string.settings_columns)) {
                listOf(4, 5).forEach { count ->
                    FilterChip(
                        selected = settings.columns == count,
                        onClick = { onChange { it.copy(columns = count) } },
                        label = { Text(count.toString()) },
                    )
                }
            }

            Section(stringResource(R.string.settings_icon_shape)) {
                IconShape.entries.forEach { shape ->
                    FilterChip(
                        selected = settings.iconShape == shape,
                        onClick = { onChange { it.copy(iconShape = shape) } },
                        label = {
                            Text(
                                stringResource(
                                    when (shape) {
                                        IconShape.Rounded -> R.string.shape_rounded
                                        IconShape.Circle -> R.string.shape_circle
                                        IconShape.Square -> R.string.shape_square
                                    },
                                ),
                            )
                        },
                    )
                }
            }

            Section(stringResource(R.string.settings_icon_size)) {
                listOf(48 to R.string.size_small, 56 to R.string.size_medium, 64 to R.string.size_large)
                    .forEach { (dp, label) ->
                        FilterChip(
                            selected = settings.iconSizeDp == dp,
                            onClick = { onChange { it.copy(iconSizeDp = dp) } },
                            label = { Text(stringResource(label)) },
                        )
                    }
            }

            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(stringResource(R.string.settings_show_labels), style = MaterialTheme.typography.bodyLarge)
                Switch(
                    checked = settings.showLabels,
                    onCheckedChange = { checked -> onChange { it.copy(showLabels = checked) } },
                )
            }

            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                    Text(stringResource(R.string.settings_lock_home), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        text = stringResource(R.string.settings_lock_home_summary),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = settings.lockHome,
                    onCheckedChange = { checked -> onChange { it.copy(lockHome = checked) } },
                )
            }

            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                    Text(stringResource(R.string.settings_badges), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        text = stringResource(R.string.settings_badges_summary),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = settings.showBadges,
                    onCheckedChange = { checked ->
                        onChange { it.copy(showBadges = checked) }
                        if (checked) {
                            // Badges need notification access, which Android only grants on its own screen.
                            context.startActivity(
                                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        }
                    },
                )
            }

            AiKeySettings(settings = settings, apps = apps, onChange = onChange)
        }
    }
}

/**
 * Every style uses the wallpaper's colours on Android 12 and later, so picking a style
 * follows the wallpaper. Older versions have no wallpaper colours and use [fallback].
 */
private fun wallpaperAccentOr(fallback: Accent): Accent =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Accent.Wallpaper else fallback

/** A titled row of chips. The row scrolls sideways so long lists (icon packs) never wrap off screen. */
@Composable
private fun Section(title: String, content: @Composable RowScope.() -> Unit) {
    Spacer(Modifier.height(16.dp))
    Text(text = title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(8.dp))
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        content = content,
    )
}


private val AiKeyActions = AiKeyAction.entries

private fun aiActionLabel(action: AiKeyAction): Int = when (action) {
    AiKeyAction.DoNothing -> R.string.ai_action_none
    AiKeyAction.Flashlight -> R.string.ai_action_flashlight
    AiKeyAction.Screenshot -> R.string.ai_action_screenshot
    AiKeyAction.OpenApp -> R.string.ai_action_open_app
    AiKeyAction.PlayPause -> R.string.ai_action_play_pause
    AiKeyAction.Notifications -> R.string.ai_action_notifications
    AiKeyAction.QuickSettings -> R.string.ai_action_quick_settings
    AiKeyAction.LockScreen -> R.string.ai_action_lock
    AiKeyAction.Recents -> R.string.ai_action_recents
    AiKeyAction.Home -> R.string.ai_action_home
}

/**
 * Hardware AI key: take it over, teach the launcher which key it is, and choose what a single,
 * double and long press do. The override only works while the accessibility service is on.
 */
@Composable
private fun AiKeySettings(
    settings: LauncherSettings,
    apps: List<LauncherApp>,
    onChange: ((LauncherSettings) -> LauncherSettings) -> Unit,
) {
    val context = LocalContext.current
    var serviceOn by remember { mutableStateOf(AiKeyService.isEnabled(context)) }
    var learning by remember { mutableStateOf(false) }
    var appMenu by remember { mutableStateOf(false) }

    // Coming back from Accessibility settings: check the switch again.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { serviceOn = AiKeyService.isEnabled(context) }
    DisposableEffect(Unit) { onDispose { AiKeyService.learnCallback = null } }

    Spacer(Modifier.height(24.dp))
    Text(
        text = stringResource(R.string.settings_ai_key),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
    )
    Spacer(Modifier.height(8.dp))
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
            Text(stringResource(R.string.ai_key_override), style = MaterialTheme.typography.bodyLarge)
            Text(
                text = stringResource(R.string.ai_key_override_summary),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Switch(
            checked = settings.aiKeyOverride,
            onCheckedChange = { checked -> onChange { it.copy(aiKeyOverride = checked) } },
        )
    }

    if (!settings.aiKeyOverride) return

    // Setup checklist: each line gets a tick once it is done.
    val keyLearned = settings.aiKeyCode != 0 || settings.aiKeyScanCode != 0
    Spacer(Modifier.height(8.dp))
    Text(
        text = listOf(
            (if (serviceOn) "\u2713 " else "\u25CB ") + stringResource(R.string.ai_key_step_service),
            (if (keyLearned) "\u2713 " else "\u25CB ") + stringResource(R.string.ai_key_step_learn),
            "\u25CB " + stringResource(R.string.ai_key_step_actions),
        ).joinToString("\n"),
        style = MaterialTheme.typography.bodyMedium,
    )
    Spacer(Modifier.height(8.dp))
    Text(
        text = stringResource(if (serviceOn) R.string.ai_key_service_on else R.string.ai_key_service_off),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    if (!serviceOn) {
        Text(
            text = stringResource(R.string.ai_key_restricted_help),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedButton(onClick = { context.openAppInfo(context.packageName) }) {
            Text(stringResource(R.string.ai_key_open_app_info))
        }
        OutlinedButton(onClick = {
            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text(stringResource(R.string.ai_key_enable_service)) }
    }

    val learned = settings.aiKeyCode != 0 || settings.aiKeyScanCode != 0
    Spacer(Modifier.height(8.dp))
    Text(
        text = when {
            learning -> stringResource(R.string.ai_key_learn_prompt)
            learned -> "${stringResource(R.string.ai_key_learned)}: " +
                (if (settings.aiKeyCode != 0) KeyEvent.keyCodeToString(settings.aiKeyCode) else "scan ${settings.aiKeyScanCode}")
            else -> stringResource(R.string.ai_key_not_learned)
        },
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    OutlinedButton(
        enabled = serviceOn && !learning,
        onClick = {
            learning = true
            AiKeyService.learnCallback = { keyCode, scanCode ->
                learning = false
                onChange { it.copy(aiKeyCode = keyCode, aiKeyScanCode = scanCode) }
                Toast.makeText(context, R.string.ai_key_learned, Toast.LENGTH_SHORT).show()
            }
        },
    ) {
        Text(stringResource(if (learned) R.string.ai_key_learn_again else R.string.ai_key_learn))
    }

    Section(stringResource(R.string.ai_key_single)) {
        AiKeyActions.forEach { a ->
            FilterChip(
                selected = settings.aiKeySingle == a,
                onClick = { onChange { it.copy(aiKeySingle = a) } },
                label = { Text(stringResource(aiActionLabel(a))) },
            )
        }
    }
    Section(stringResource(R.string.ai_key_double)) {
        AiKeyActions.forEach { a ->
            FilterChip(
                selected = settings.aiKeyDouble == a,
                onClick = { onChange { it.copy(aiKeyDouble = a) } },
                label = { Text(stringResource(aiActionLabel(a))) },
            )
        }
    }
    Section(stringResource(R.string.ai_key_long)) {
        AiKeyActions.forEach { a ->
            FilterChip(
                selected = settings.aiKeyLong == a,
                onClick = { onChange { it.copy(aiKeyLong = a) } },
                label = { Text(stringResource(aiActionLabel(a))) },
            )
        }
    }

    Spacer(Modifier.height(16.dp))
    Text(
        text = stringResource(R.string.ai_key_test),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { context.runAiKeyAction(settings.aiKeySingle, settings.aiKeyApp) }) {
            Text(stringResource(R.string.ai_key_single))
        }
        OutlinedButton(onClick = { context.runAiKeyAction(settings.aiKeyDouble, settings.aiKeyApp) }) {
            Text(stringResource(R.string.ai_key_double))
        }
        OutlinedButton(onClick = { context.runAiKeyAction(settings.aiKeyLong, settings.aiKeyApp) }) {
            Text(stringResource(R.string.ai_key_long))
        }
    }

    Spacer(Modifier.height(16.dp))
    Text(
        text = stringResource(R.string.ai_key_assistant_help),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    OutlinedButton(onClick = { context.openSettingsScreen(Settings.ACTION_VOICE_INPUT_SETTINGS) }) {
        Text(stringResource(R.string.ai_key_assistant_button))
    }

    val usesApp = AiKeyAction.OpenApp in listOf(settings.aiKeySingle, settings.aiKeyDouble, settings.aiKeyLong)
    if (usesApp) {
        Spacer(Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.ai_key_app),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
        )
        Spacer(Modifier.height(8.dp))
        val chosen = apps.firstOrNull { it.packageName == settings.aiKeyApp }
        androidx.compose.foundation.layout.Box {
            OutlinedButton(onClick = { appMenu = true }) {
                Text(chosen?.label ?: stringResource(R.string.ai_key_no_app))
            }
            DropdownMenu(expanded = appMenu, onDismissRequest = { appMenu = false }) {
                apps.sortedBy { it.label.lowercase() }.forEach { app ->
                    DropdownMenuItem(
                        text = { Text(app.label) },
                        onClick = {
                            appMenu = false
                            onChange { it.copy(aiKeyApp = app.packageName) }
                        },
                    )
                }
            }
        }
    }
}
