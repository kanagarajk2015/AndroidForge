# Colour Launcher

An Android home-screen launcher with a ColorOS-inspired look: rounded icons, a dock, a
searchable app drawer, and colours taken from your wallpaper on Android 12 and later.

This is an independent project. It is not affiliated with OPPO or ColorOS.

> **Status:** early prototype (v0.5.0). It has not been compiled or tested on a device yet.

## Features

- Home screen with a clock and date header and a 4-column grid of apps
- Dock with up to four apps. An empty slot shows an outline: tap it to open the app drawer, then long-press an app to add it. Dock icons press in when tapped, and swiping up to open the drawer gives a short haptic tick. The dock's page dots and handle take each style's ink colour. Windows 11 keeps its own taskbar
- App drawer with search. Swipe up on the dock, or tap the handle below it, to open it
- Long-press any app for actions: add or remove from home, add to or remove from a folder, move it to the previous or next home page, add or remove from dock, app info, uninstall
- Folders: a folder takes one home cell and shows a 2x2 preview of its first four apps. Create one with "Add to folder" > "New folder" in an app's menu, or drop an icon onto a folder while arranging. Tap a folder to open it, rename it in its sheet, and delete it to put its apps back on the home screen. A folder left empty is removed
- Home pages: swipe sideways on the home screen to turn pages. The dots above the dock show the current page. "Move to next page" adds a page when there isn't one. Icons move between pages from the app's menu, and drags stay on the page they start on
- Notification badges: Settings > Notification badges opens Android's Notification access screen. Once you allow Colour Launcher there, icons show how many notifications each app has. Ongoing notifications (music, navigation, downloads) are not counted
- Uninstall asks the package installer, so the launcher hears whether it worked. Android still shows its own confirmation unless the launcher is a privileged app or installed the app itself, so a normal phone will still ask
- Layout is saved between launches. Uninstalled apps leave an empty cell behind; Auto arrange closes the gap
- Quick controls: drag down from the top of the home screen (or tap the clock in the Windows 11 taskbar). Flashlight toggle, media volume slider, brightness slider (after you allow "modify system settings"), and tiles that open the system screen for Internet, Bluetooth, airplane mode, location and battery saver. Android does not let a launcher switch those directly
- Swipe up on the home screen (past the last row) to open the drawer; drag down at the top of the drawer to close it
- Settings sheet (gear icon, top right), saved between launches:
  - Launcher style: Windows 11 (flat full-width taskbar with the Windows logo, search, centred apps with a running-app bar, and a system tray with Wi-Fi, volume, battery, time and date; plain desktop icons with a pale selection box and two-line labels; a Start menu with search, Pinned apps, All apps A to Z, Recommended (recently installed) and an account and settings footer; an 8 px-corner quick settings flyout; a built-in Bloom-style blue backdrop that your own wallpaper replaces; follows light and dark mode) or OxygenOS 16 (white serif clock card, circular white-plate icons, dock-less floating icons with page dots, app drawer with an A–Z index). Picking a style also sets its accent and icon shape
  - Themed styles: Aurora (violet waves, an analog clock and a large day number), Sunset Gold (a gradient with gold wave lines and a gold outlined clock), Glass Blue (a glass clock card over blue slabs), Sky Blue (a bright sky with a centred clock) Pastel Glow (a pale gradient with a thin clock, dark labels and a light dock), Date Focus (a large date with the time in the corner on a violet glow), Ring Clock (a centred gold analog ring on charcoal) and Midnight Circles (a navy glow, a left-aligned clock and a floating dock). They draw their own artwork in place of the wallpaper, use fixed colours rather than the accent, and show no weather
  - Wallpaper: pick any image and set it as the system wallpaper. Themed styles normally draw their own artwork over the wallpaper, so picking a wallpaper turns "Style artwork" off and your image shows behind the icons in every style. Switch "Style artwork" back on to restore the artwork (Pastel Glow uses white text while the wallpaper is showing)
  - Theme: system, light or dark, with an accent from the wallpaper (Android 12+) or Blue, Green, Pink, Orange, Fluent blue. On Android 12+ every style uses the wallpaper's colours by default. The dock (except OxygenOS), the Start-menu panel and the sheets use frosted aqua glass, which is a translucent tint with a sheen and a rim rather than a live blur. The full-screen drawer stays opaque
  - Rearranging: long-press a home screen icon and choose "Move icons" (or use "Free arrange icons" in settings). Drag an icon onto an empty cell, or onto another icon to swap places, then tap Done. "Auto arrange (close gaps)" packs icons in their current order. Changing the column count packs them again. "Lock home screen layout" in settings blocks moving, adding and removing home screen icons
  - Icon packs: installed ADW/Nova-style packs (appfilter.xml). "Get icon packs from Play Store" in settings opens a Play Store search; packs you install appear in the list automatically. Apps the pack does not cover keep their own icon
  - 4 or 5 grid columns, icon shape (rounded, circle, square), icon size, app names on/off
- Home screen fills the whole display with cells, so icons can be dragged and dropped anywhere (long-press an icon, choose Arrange). Long-pressing empty space on the home screen opens the settings sheet, where the icon shape, size and grid options are
- AI key extras: setup checklist with ticks, Test buttons for each press, and a fallback that lets the launcher be the digital assistant app (no accessibility; single-press action only, and only if the AI key sends the assistant request). Flashlight, open app and play/pause work without accessibility; screenshot, notifications, quick settings, lock screen, recents and home need it
- Wallpaper dim: Dim wallpaper slider (up to 60%) shows whenever the wallpaper is visible, so labels stay readable on bright images
- AI key override (Motorola phones): Settings > AI key. Turn on "Take over the AI key", switch on the Colour Launcher accessibility service once, press "Set AI key" and press the key so the launcher learns it, then pick actions for single, double and long press (flashlight, screenshot, open app, play/pause, notifications, quick settings, lock screen, recents, home). The service only watches that one key and reads no screen content. Android does not let an app switch accessibility on by itself, so the first run asks once and opens Accessibility settings
- Wallpaper shows through the launcher. Accent colours come from the wallpaper (Android 12+)

## Not yet implemented

- Widgets, and gestures beyond the swipes and drags above
- Dragging icons between home pages (use the app menu instead)

## Build

Requirements: Android Studio (Ladybug or newer) and JDK 17.

From the command line:

```sh
./gradlew assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/`.

To use it as your home app: install the APK, then open **Settings > Apps > Default apps > Home app** and pick Colour Launcher.

## Project layout

```
app/src/main/java/com/example/colourlauncher/
├── MainActivity.kt          Entry point; listens for package changes and HOME presses
├── LauncherViewModel.kt     Installed apps plus the home pages, folders and dock
├── data/
│   ├── AppRepository.kt     Reads launchable apps from PackageManager
│   ├── LauncherApp.kt       App model (package, label, icon)
│   ├── HomeFolder.kt        Folder model and the cell token that marks a folder
│   ├── LayoutStore.kt       Saves home pages, folders and dock as JSON in SharedPreferences
│   ├── LauncherSettings.kt  Theme, accent, icon pack, columns, icon shape/size, labels
│   ├── IconPackRepository.kt Finds icon packs and reads appfilter.xml
│   └── SettingsStore.kt     Saves settings in SharedPreferences
├── ui/
│   ├── LauncherScreen.kt    Root: home screen, drawer, action sheet
│   ├── HomeScreen.kt        Clock, paged app grid, dock
│   ├── FolderComponents.kt  Folder tile, folder sheet, folder picker
│   ├── ThemedStyles.kt      Artwork, clocks and dock panels for the themed styles
│   ├── AppDrawer.kt         Searchable list of all apps
│   ├── AppComponents.kt     App icon with notification badge, action sheet
│   ├── ControlPanel.kt      Quick controls sheet / flyout (OxygenOS 16 look in that style)
│   ├── Taskbar.kt           Windows 11 style taskbar
│   ├── SettingsSheet.kt     Settings bottom sheet
│   ├── PullGesture.kt       Drag-past-the-end gesture for opening/closing the drawer
│   └── theme/Theme.kt       Material 3 palette, frosted glass helpers and wallpaper colours
├── service/NotificationBadgeService.kt  Counts notifications per app for the badges
├── util/Intents.kt          Launch, app info, and uninstall intents
├── util/UninstallResultReceiver.kt      Receives the package installer's uninstall result
└── util/Wallpaper.kt        Sets the system wallpaper from a picked image
```

## Before publishing

- Change `applicationId` and `namespace` in `app/build.gradle.kts` from the `com.example` placeholder.
- Add a license file. None is included yet.

## Contributing

Issues and pull requests are welcome. Keep changes small and run `./gradlew assembleDebug` before opening a PR.
