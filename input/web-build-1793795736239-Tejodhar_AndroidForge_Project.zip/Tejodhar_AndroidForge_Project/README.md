# Tejodhar AndroidForge / Android Studio WebView project

This is an Android application source project that opens the live Tejodhar website.

- Primary URL: https://tejodhar.in/
- Alternate URL: https://www.tejodhar.in/
- Application ID: `in.tejodhar.app`
- App name: Tejodhar
- Minimum Android: 6.0 (API 23)

## Build APK

1. Open this folder in Android Studio (or import it into a compatible Android project builder).
2. Allow Gradle sync to finish. Use JDK 17.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Included

- JavaScript and DOM storage for portal login/session behavior.
- HTTPS-only WebView (mixed content blocked).
- File picker support for website uploads.
- Download link handoff to Android.
- Runtime camera/microphone permission handling when requested by the website.
- Back navigation.

## Notes

The uploaded `Tejodhar_TeamChat_Minimal_Server.zip` contains PHP team-chat server files, not Android app source. This project is a separate Android wrapper for the live website; it does not modify or deploy the server ZIP.

For a production release, create and securely back up your own signing key, then build a signed APK/AAB. Test login, file upload/download, camera/microphone, and all portal pages on a physical Android device before distribution.
