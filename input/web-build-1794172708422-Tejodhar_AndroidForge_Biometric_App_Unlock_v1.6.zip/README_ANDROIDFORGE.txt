TEJODHAR SECURE ANDROID PROJECT - BIOMETRIC APP UNLOCK + HTTPS UPDATE
================================

Project layout includes:
- app/src/main/AndroidManifest.xml
- app/src/main/java/in/tejodhar/app/MainActivity.kt
- app/src/main/java/in/tejodhar/app/TokenVault.kt
- app/src/main/res/layout/activity_main.xml
- app/src/main/res/values/styles.xml
- settings.gradle.kts
- root build.gradle.kts
- gradle/libs.versions.toml
- app/build.gradle.kts

HTTPS / SSL BEHAVIOUR
--------------------
- The app starts at https://tejodhar.in/ (HTTPS only).
- In-app navigation to http://tejodhar.in or an owned *.tejodhar.in host is
  upgraded to HTTPS before the page is loaded.
- Plain HTTP is disabled by android:usesCleartextTraffic="false".
- SSL certificate errors are cancelled. The app never ignores certificate
  errors or accepts an invalid certificate.
- Third-party HTTP links are not loaded inside the app; they are handed to
  an external app/browser.
- The Android app does not repair the server certificate. Cloudflare and
  the hosting origin must still present a valid certificate.

APP LOCK BEHAVIOUR
------------------
On every cold app launch, the app requests a strong device biometric
(fingerprint or supported face authentication) before displaying the website.
This app-opening lock does not depend on the website biometric token being
registered. After the app is unlocked, the existing Tejodhar website login
still controls the account session; users can sign in with their existing
username/password and separately enable website biometric sign-in.

The website's existing native biometric login may request another biometric
scan to authenticate the PHP server session. This is separate from the app
opening lock. The app-lock scan alone does NOT create a PHP login session.

IMPORTANT LIMITATIONS
--------------------
- This is a source project ZIP, not a compiled APK. Version 1.6 (versionCode 7).
- The native app lock runs on every cold launch. A strong fingerprint or
  supported face biometric must be enrolled and available on the phone.
- If biometric hardware or enrollment is unavailable, the app stays locked;
  configure fingerprint/face unlock in Android Settings before opening Tejodhar.
- The app-lock prompt is an app-opening gate, not a replacement for the
  website's username/password, OTP, or server-side account authentication.
- Existing website username/password and PHP authentication are unchanged.
- Use AndroidForge's Android/Gradle build option to build the APK. After building, test both https://tejodhar.in and https://www.tejodhar.in on the phone. The app upgrades in-app HTTP links to HTTPS; it does not guarantee that the live server SSL certificate is valid.
- Test with a non-critical account before production rollout.

SECURITY NOTE
-------------
Do not commit database credentials, API keys, or GitHub tokens.
Rotate any credentials previously exposed in uploaded PHP source.
