# Wall Clock

Clock widget whose digits are filled with a wallpaper.

- 14 widgets (pick any from Widgets): Digital, Stacked, Big hour, Time + date, Analog, Analog numbers, Ring, Split, Binary, Words, Digital AM/PM, Date, Battery, Month calendar
- Position: Left / Centre / Right
- Colour types: Wallpaper, Solid, Gradient, Rainbow
- Wallpapers: 8 built-in, gallery photo, current phone wallpaper
- Per-widget settings (tap a widget), font, size, 24h, shadow, dark card

## Build
Push to GitHub -> Actions -> "Build APK" -> download `WallClock-debug-apk` artifact.
