package com.tejodhar.wallclock

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.graphics.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws the clock shape as a white mask, then fills the mask with
 * wallpaper / solid / gradient / rainbow (DST_IN), so the wallpaper shows inside the digits.
 */
object ClockRenderer {

    fun render(ctx: Context, s: ClockSettings, cal: Calendar, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        if (s.card) {
            val cp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000 }
            c.drawRoundRect(0f, 0f, w.toFloat(), h.toFloat(), h * 0.16f, h * 0.16f, cp)
        }

        val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val batt = if (s.style == ClockStyle.BATTERY) batteryLevel(ctx) else 0
        drawClock(Canvas(mask), s, cal, w, h, Color.WHITE, batt)

        if (s.shadow) {
            val blur = Paint().apply {
                maskFilter = BlurMaskFilter(max(2f, h * 0.015f), BlurMaskFilter.Blur.NORMAL)
            }
            val off = IntArray(2)
            val alpha = mask.extractAlpha(blur, off)
            val sp = Paint().apply { color = 0xB3000000L.toInt() }
            c.drawBitmap(alpha, off[0].toFloat(), off[1] + h * 0.012f, sp)
            alpha.recycle()
        }

        val fill = makeFill(ctx, s, w, h)
        val dstIn = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
        Canvas(fill).drawBitmap(mask, 0f, 0f, dstIn)
        c.drawBitmap(fill, 0f, 0f, null)
        mask.recycle()
        fill.recycle()
        return out
    }

    private fun batteryLevel(ctx: Context): Int {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l < 0 || sc <= 0) 0 else l * 100 / sc
    }

    private fun makeFill(ctx: Context, s: ClockSettings, w: Int, h: Int): Bitmap {
        if (s.fill == FillMode.WALLPAPER) {
            return WallpaperSource.load(ctx, s, w, h).copy(Bitmap.Config.ARGB_8888, true)
        }
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        when (s.fill) {
            FillMode.SOLID -> p.color = s.solid
            FillMode.GRADIENT -> {
                val g = Palettes.gradients[s.grad.coerceIn(0, Palettes.gradients.size - 1)]
                p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), g, null, Shader.TileMode.CLAMP)
            }
            else -> p.shader = LinearGradient(0f, 0f, w.toFloat(), 0f, Palettes.rainbow, null, Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        return b
    }

    // ---------- helpers ----------

    private fun bounds(p: Paint, t: String): Rect = Rect().also { p.getTextBounds(t, 0, t.length, it) }

    private fun fit(p: Paint, ref: String, maxW: Float, maxH: Float, k: Float): Float {
        p.textSize = 100f
        val b = bounds(p, ref)
        val sc = min(maxW / b.width(), maxH / b.height())
        return 100f * sc * k
    }

    private fun xFor(a: ClockAlign, w: Int, pad: Float, tw: Float): Float = when (a) {
        ClockAlign.LEFT -> pad
        ClockAlign.CENTER -> (w - tw) / 2f
        ClockAlign.RIGHT -> w - pad - tw
    }

    private fun circleCx(a: ClockAlign, w: Int, pad: Float, r: Float): Float = when (a) {
        ClockAlign.LEFT -> pad + r
        ClockAlign.CENTER -> w / 2f
        ClockAlign.RIGHT -> w - pad - r
    }

    private fun put(c: Canvas, p: Paint, t: String, ref: String, a: ClockAlign, w: Int, pad: Float, cy: Float) {
        val b = bounds(p, t)
        val r = bounds(p, ref)
        val x = xFor(a, w, pad, b.width().toFloat()) - b.left
        val base = cy - (r.top + r.bottom) / 2f
        c.drawText(t, x, base, p)
    }

    // ---------- clock layouts ----------

    private fun drawClock(c: Canvas, s: ClockSettings, cal: Calendar, w: Int, h: Int, color: Int, batt: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            typeface = Palettes.typeface(s.font)
        }
        val pad = w * 0.05f
        val maxW = w - 2 * pad
        val maxH = h - 2 * pad
        val cy = h / 2f
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val h12 = if (hour % 12 == 0) 12 else hour % 12
        val hh = if (s.is24) hour.toString().padStart(2, '0') else h12.toString()
        val mm = cal.get(Calendar.MINUTE).toString().padStart(2, '0')

        when (s.style) {
            ClockStyle.DIGITAL -> {
                p.textSize = fit(p, "00:00", maxW, maxH, s.scale)
                put(c, p, "$hh:$mm", "00:00", s.align, w, pad, cy)
            }

            ClockStyle.STACKED -> {
                p.textSize = fit(p, "00", maxW, maxH * 0.46f, s.scale)
                val bh = bounds(p, "00").height()
                val off = bh / 2f + maxH * 0.03f
                put(c, p, hh.padStart(2, '0'), "00", s.align, w, pad, cy - off)
                put(c, p, mm, "00", s.align, w, pad, cy + off)
            }

            ClockStyle.BIG_HOUR -> {
                val gapF = 0.08f
                var hs = fit(p, "00", maxW * 0.62f, maxH, s.scale)
                fun totalW(size: Float): Float {
                    p.textSize = size
                    val a = bounds(p, hh).width()
                    p.textSize = size * 0.42f
                    val b = bounds(p, mm).width()
                    return a + b + size * gapF
                }
                var tw = totalW(hs)
                if (tw > maxW) {
                    hs *= maxW / tw
                    tw = totalW(hs)
                }
                p.textSize = hs
                val bh = bounds(p, hh)
                val ref = bounds(p, "00")
                val x0 = xFor(s.align, w, pad, tw)
                val base = cy - (ref.top + ref.bottom) / 2f
                c.drawText(hh, x0 - bh.left, base, p)
                p.textSize = hs * 0.42f
                val bm = bounds(p, mm)
                c.drawText(mm, x0 + bh.width() + hs * gapF - bm.left, base, p)
            }

            ClockStyle.DATE -> {
                p.textSize = fit(p, "00:00", maxW, maxH * 0.62f, s.scale)
                val bt = bounds(p, "00:00").height()
                val dp = Paint(p).apply {
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    letterSpacing = 0.12f
                }
                val dateRef = "WED, 28 MAY"
                val dateText = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(cal.time).uppercase()
                dp.textSize = min(p.textSize * 0.34f, fit(dp, dateRef, maxW, maxH * 0.2f, s.scale))
                val bd = bounds(dp, dateRef).height()
                val gap = maxH * 0.06f
                val top = cy - (bt + gap + bd) / 2f
                put(c, p, "$hh:$mm", "00:00", s.align, w, pad, top + bt / 2f)
                put(c, dp, dateText, dateRef, s.align, w, pad, top + bt + gap + bd / 2f)
            }

            ClockStyle.DAY -> {
                p.textSize = fit(p, "00", maxW, maxH * 0.62f, s.scale)
                val bt = bounds(p, "00").height()
                val dp = Paint(p).apply {
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    letterSpacing = 0.12f
                }
                val ref = "WED \u00B7 MAY"
                val txt = SimpleDateFormat("EEE '\u00B7' MMM", Locale.getDefault()).format(cal.time).uppercase()
                dp.textSize = min(p.textSize * 0.34f, fit(dp, ref, maxW, maxH * 0.2f, s.scale))
                val bd = bounds(dp, ref).height()
                val gap = maxH * 0.06f
                val top = cy - (bt + gap + bd) / 2f
                put(c, p, cal.get(Calendar.DAY_OF_MONTH).toString(), "00", s.align, w, pad, top + bt / 2f)
                put(c, dp, txt, ref, s.align, w, pad, top + bt + gap + bd / 2f)
            }

            ClockStyle.BATTERY -> {
                p.textSize = fit(p, "100%", maxW, maxH * 0.66f, s.scale)
                val bt = bounds(p, "100%").height()
                val txt = "$batt%"
                val tw = bounds(p, txt).width().toFloat()
                val barH = maxH * 0.12f
                val gap = maxH * 0.07f
                val top = cy - (bt + gap + barH) / 2f
                put(c, p, txt, "100%", s.align, w, pad, top + bt / 2f)
                val bx = xFor(s.align, w, pad, tw)
                val by = top + bt + gap
                val bp = Paint(p).apply { style = Paint.Style.FILL; alpha = 90 }
                c.drawRoundRect(bx, by, bx + tw, by + barH, barH / 2f, barH / 2f, bp)
                bp.alpha = 255
                c.drawRoundRect(bx, by, bx + max(barH, tw * batt / 100f), by + barH, barH / 2f, barH / 2f, bp)
            }

            ClockStyle.MONTH -> {
                val gridW = maxW * s.scale
                val x0 = xFor(s.align, w, pad, gridW)
                val titleH = maxH * 0.13f
                val rowH = (maxH - titleH) / 7f
                val cellW = gridW / 7f
                val top = pad
                p.textAlign = Paint.Align.CENTER
                fun baseAt(cyy: Float): Float {
                    val fm = p.fontMetrics
                    return cyy - (fm.ascent + fm.descent) / 2f
                }
                val title = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time).uppercase()
                p.textSize = fit(p, "SEPTEMBER 2026", gridW, titleH * 0.7f, 1f)
                c.drawText(title, x0 + gridW / 2f, baseAt(top + titleH / 2f), p)

                val firstDow = cal.firstDayOfWeek
                val letters = "SMTWTFS"
                p.textSize = min(rowH * 0.5f, cellW * 0.5f)
                p.alpha = 130
                for (i in 0 until 7) {
                    c.drawText(
                        letters[(firstDow - 1 + i) % 7].toString(),
                        x0 + cellW * (i + 0.5f), baseAt(top + titleH + rowH * 0.5f), p
                    )
                }

                val first = cal.clone() as Calendar
                first.set(Calendar.DAY_OF_MONTH, 1)
                val off = (first.get(Calendar.DAY_OF_WEEK) - firstDow + 7) % 7
                val dim = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
                val today = cal.get(Calendar.DAY_OF_MONTH)
                p.textSize = min(rowH * 0.58f, cellW * 0.6f)
                for (d in 1..dim) {
                    val idx = off + d - 1
                    val cx = x0 + cellW * ((idx % 7) + 0.5f)
                    val cyy = top + titleH + rowH * ((idx / 7) + 1.5f)
                    if (d == today) {
                        p.alpha = 255
                        p.style = Paint.Style.STROKE
                        p.strokeWidth = rowH * 0.06f
                        c.drawCircle(cx, cyy, min(rowH, cellW) * 0.46f, p)
                        p.style = Paint.Style.FILL
                    } else {
                        p.alpha = 170
                    }
                    c.drawText(d.toString(), cx, baseAt(cyy), p)
                }
            }

            ClockStyle.WORDS -> {
                val names = arrayOf("TWELVE", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "ELEVEN")
                var r5 = ((cal.get(Calendar.MINUTE) + 2) / 5) * 5
                var hr = hour
                if (r5 == 60) { r5 = 0; hr += 1 }
                if (r5 > 30) hr += 1
                val hw = names[hr % 12]
                val mins = when (r5) {
                    5 -> "FIVE PAST"
                    10 -> "TEN PAST"
                    15 -> "QUARTER PAST"
                    20 -> "TWENTY PAST"
                    25 -> "TWENTY FIVE PAST"
                    30 -> "HALF PAST"
                    35 -> "TWENTY FIVE TO"
                    40 -> "TWENTY TO"
                    45 -> "QUARTER TO"
                    50 -> "TEN TO"
                    55 -> "FIVE TO"
                    else -> ""
                }
                val l1 = if (mins.isEmpty()) hw else mins
                val l2 = if (mins.isEmpty()) "O'CLOCK" else hw
                p.letterSpacing = 0.04f
                p.textSize = fit(p, "TWENTY FIVE PAST", maxW, maxH * 0.46f, s.scale)
                val bh = bounds(p, "TWENTY").height()
                val off = bh / 2f + maxH * 0.03f
                put(c, p, l1, "TWENTY", s.align, w, pad, cy - off)
                put(c, p, l2, "TWENTY", s.align, w, pad, cy + off)
            }

            ClockStyle.BINARY -> {
                val hv = if (s.is24) hour else h12
                val minute = cal.get(Calendar.MINUTE)
                val digits = intArrayOf(hv / 10, hv % 10, minute / 10, minute % 10)
                val cell = min(maxH / 4f, maxW / 4.6f) * s.scale
                val x0 = xFor(s.align, w, pad, cell * 4.6f)
                p.style = Paint.Style.FILL
                for (i in 0 until 4) {
                    val colX = x0 + cell * (i + 0.5f) + (if (i >= 2) cell * 0.6f else 0f)
                    for (row in 0 until 4) {
                        val bit = (digits[i] shr (3 - row)) and 1
                        p.alpha = if (bit == 1) 255 else 70
                        c.drawCircle(colX, cy + (row - 1.5f) * cell, cell * 0.38f, p)
                    }
                }
            }

            ClockStyle.SPLIT -> {
                val hh2 = hh.padStart(2, '0')
                var size = fit(p, "00", maxW * 0.46f, maxH, s.scale)
                fun tw(sz: Float): Float {
                    p.textSize = sz
                    return bounds(p, hh2).width() + bounds(p, mm).width() + sz * 0.4f
                }
                var total = tw(size)
                if (total > maxW) {
                    size *= maxW / total
                    total = tw(size)
                }
                p.textSize = size
                val bH = bounds(p, hh2)
                val bM = bounds(p, mm)
                val ref = bounds(p, "00")
                val x0 = xFor(s.align, w, pad, total)
                val base = cy - (ref.top + ref.bottom) / 2f
                c.drawText(hh2, x0 - bH.left, base, p)
                val sx = x0 + bH.width() + size * 0.2f
                c.drawCircle(sx, cy - size * 0.17f, size * 0.045f, p)
                c.drawCircle(sx, cy + size * 0.17f, size * 0.045f, p)
                c.drawText(mm, x0 + bH.width() + size * 0.4f - bM.left, base, p)
            }

            ClockStyle.ANALOG_NUM -> {
                val r = min(maxW, maxH) / 2f * s.scale
                val cx = circleCx(s.align, w, pad, r)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = r * 0.06f
                c.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
                p.style = Paint.Style.FILL
                p.textAlign = Paint.Align.CENTER
                p.textSize = r * 0.24f
                val fm = p.fontMetrics
                for (n in 1..12) {
                    val a = n * 30.0 * PI / 180.0
                    c.drawText(
                        n.toString(),
                        cx + (r * 0.76f * sin(a)).toFloat(),
                        cy - (r * 0.76f * cos(a)).toFloat() - (fm.ascent + fm.descent) / 2f, p
                    )
                }
                val minute = cal.get(Calendar.MINUTE)
                val ha = ((hour % 12) + minute / 60f) * 30.0 * PI / 180.0
                val ma = minute * 6.0 * PI / 180.0
                p.style = Paint.Style.STROKE
                p.strokeWidth = r * 0.09f
                c.drawLine(cx, cy, cx + (r * 0.40f * sin(ha)).toFloat(), cy - (r * 0.40f * cos(ha)).toFloat(), p)
                p.strokeWidth = r * 0.06f
                c.drawLine(cx, cy, cx + (r * 0.58f * sin(ma)).toFloat(), cy - (r * 0.58f * cos(ma)).toFloat(), p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.06f, p)
            }

            ClockStyle.RING -> {
                val r = min(maxW, maxH) / 2f * s.scale
                val cx = circleCx(s.align, w, pad, r)
                val sw = r * 0.12f
                val rr = r - sw / 2f
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = sw
                p.alpha = 70
                c.drawCircle(cx, cy, rr, p)
                p.alpha = 255
                val minute = cal.get(Calendar.MINUTE)
                c.drawArc(RectF(cx - rr, cy - rr, cx + rr, cy + rr), -90f, max(1f, minute * 6f), false, p)
                p.style = Paint.Style.FILL
                val inner = (r - sw * 1.5f) * 2f
                p.textSize = fit(p, "00:00", inner * 0.8f, inner * 0.4f, 1f)
                p.textAlign = Paint.Align.CENTER
                val ref = bounds(p, "00:00")
                c.drawText("$hh:$mm", cx, cy - (ref.top + ref.bottom) / 2f, p)
            }

            ClockStyle.AMPM -> {
                val tx = "$h12:$mm"
                val ap = if (hour < 12) "AM" else "PM"
                val gapF = 0.08f
                var hs = fit(p, "00:00", maxW * 0.8f, maxH, s.scale)
                fun tw(sz: Float): Float {
                    p.textSize = sz
                    val a = bounds(p, tx).width()
                    p.textSize = sz * 0.3f
                    return a + bounds(p, ap).width() + sz * gapF
                }
                var total = tw(hs)
                if (total > maxW) {
                    hs *= maxW / total
                    total = tw(hs)
                }
                p.textSize = hs
                val bt = bounds(p, tx)
                val ref = bounds(p, "00:00")
                val x0 = xFor(s.align, w, pad, total)
                val base = cy - (ref.top + ref.bottom) / 2f
                c.drawText(tx, x0 - bt.left, base, p)
                p.textSize = hs * 0.3f
                val ba = bounds(p, ap)
                c.drawText(ap, x0 + bt.width() + hs * gapF - ba.left, base, p)
            }

            ClockStyle.ANALOG -> {
                val r = min(maxW, maxH) / 2f * s.scale
                val cx = when (s.align) {
                    ClockAlign.LEFT -> pad + r
                    ClockAlign.CENTER -> w / 2f
                    ClockAlign.RIGHT -> w - pad - r
                }
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = r * 0.07f
                c.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
                for (i in 0 until 12) {
                    val a = i * 30.0 * PI / 180.0
                    val major = i % 3 == 0
                    val inner = r * (if (major) 0.74f else 0.84f)
                    val outer = r * 0.92f
                    p.strokeWidth = r * (if (major) 0.07f else 0.045f)
                    c.drawLine(
                        cx + (inner * sin(a)).toFloat(), cy - (inner * cos(a)).toFloat(),
                        cx + (outer * sin(a)).toFloat(), cy - (outer * cos(a)).toFloat(), p
                    )
                }
                val minute = cal.get(Calendar.MINUTE)
                val ha = ((hour % 12) + minute / 60f) * 30.0 * PI / 180.0
                val ma = minute * 6.0 * PI / 180.0
                p.strokeWidth = r * 0.1f
                c.drawLine(cx, cy, cx + (r * 0.5f * sin(ha)).toFloat(), cy - (r * 0.5f * cos(ha)).toFloat(), p)
                p.strokeWidth = r * 0.07f
                c.drawLine(cx, cy, cx + (r * 0.76f * sin(ma)).toFloat(), cy - (r * 0.76f * cos(ma)).toFloat(), p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.07f, p)
            }
        }
    }
}
