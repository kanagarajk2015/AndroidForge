package in.tejodhar.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.ConsoleMessage;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import androidx.biometric.BiometricManager;
import androidx.fragment.app.FragmentActivity;
import androidx.biometric.BiometricPrompt;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.Executor;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends FragmentActivity {
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int PERMISSION_REQUEST = 1002;
    private static final String PREFS = "tejodhar_secure_login";
    private static final String CREDENTIALS = "encrypted_credentials";
    private static final String KEY_ALIAS = "tejodhar_login_key";
    private static final String HOME_URL = "https://tejodhar.in/";
    private static final String WWW_URL = "https://www.tejodhar.in/";

    private WebView webView;
    private ProgressBar progress;
    private TextView errorPanel;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPermission;
    private String[] pendingGrantedResources;
    private boolean triedAlternate = false;
    private boolean pageCommitted = false;
    private boolean biometricUnlocked = false;
    private boolean biometricPromptShown = false;
    private String pendingUsername = null;
    private String pendingPassword = null;
    private final Executor biometricExecutor = command -> runOnUiThread(command);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(3), Gravity.TOP);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(progress, progressParams);

        errorPanel = new TextView(this);
        errorPanel.setTextColor(Color.DKGRAY);
        errorPanel.setTextSize(16);
        errorPanel.setGravity(Gravity.CENTER);
        errorPanel.setPadding(dp(28), dp(28), dp(28), dp(28));
        errorPanel.setBackgroundColor(Color.WHITE);
        errorPanel.setVisibility(View.GONE);
        root.addView(errorPanel, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setTextZoom(100);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        // Some hosting/WAF configurations reject the Android WebView "wv" user-agent.
        String ua = settings.getUserAgentString();
        settings.setUserAgentString(ua.replace("; wv", ""));

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new LoginBridge(), "TejodharNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }

            private boolean handleUrl(Uri uri) {
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    if (isTrustedPortal(uri.toString())) return false;
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "No app found to open this link", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "No app found to open this link", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (isTrustedPortal(url)) view.addJavascriptInterface(new LoginBridge(), "TejodharNative");
                else view.removeJavascriptInterface("TejodharNative");
                pageCommitted = false;
                errorPanel.setVisibility(View.GONE);
                progress.setVisibility(View.VISIBLE);
                progress.setProgress(5);
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                pageCommitted = true;
                errorPanel.setVisibility(View.GONE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                // Nudge responsive layouts after WebView's first layout pass.
                view.evaluateJavascript(
                    "(function(){document.documentElement.style.webkitTextSizeAdjust='100%';" +
                    "if(document.body)document.body.style.visibility='visible';})();", null);
                if (isTrustedPortal(view.getUrl())) {
                    installLoginCapture(view);
                    if (!biometricPromptShown && hasSavedCredentials()) {
                        biometricPromptShown = true;
                        promptBiometricUnlock();
                    }
                    if (biometricUnlocked) fillSavedCredentials(view);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (!request.isForMainFrame()) return;
                String detail = Build.VERSION.SDK_INT >= 23 ? error.getDescription().toString() : "Network error";
                tryAlternateOrShowError("Website could not load: " + detail);
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                            android.webkit.WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) {
                    tryAlternateOrShowError("Website server returned HTTP " + response.getStatusCode());
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel(); // Never bypass certificate validation.
                showError("Secure connection failed. Check the SSL certificate for tejodhar.in and www.tejodhar.in.");
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                android.util.Log.d("TejodharWeb", message.message() + " line " + message.lineNumber());
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "No file picker available", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (!isTrustedPortal(webView.getUrl())) {
                        request.deny();
                        return;
                    }
                    boolean needsCamera = false, needsMic = false, unsupported = false;
                    java.util.ArrayList<String> allowed = new java.util.ArrayList<>();
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                            needsCamera = true;
                            allowed.add(resource);
                        } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                            needsMic = true;
                            allowed.add(resource);
                        } else {
                            unsupported = true;
                        }
                    }
                    if (unsupported || allowed.isEmpty()) {
                        request.deny();
                        return;
                    }
                    pendingWebPermission = request;
                    pendingGrantedResources = allowed.toArray(new String[0]);
                    java.util.ArrayList<String> ask = new java.util.ArrayList<>();
                    if (needsCamera && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                        ask.add(Manifest.permission.CAMERA);
                    if (needsMic && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                        ask.add(Manifest.permission.RECORD_AUDIO);
                    if (ask.isEmpty()) {
                        request.grant(pendingGrantedResources);
                        pendingWebPermission = null;
                        pendingGrantedResources = null;
                    } else {
                        requestPermissions(ask.toArray(new String[0]), PERMISSION_REQUEST);
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, false, false);
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (ActivityNotFoundException e) {
                Toast.makeText(MainActivity.this, "Cannot open download link", Toast.LENGTH_SHORT).show();
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        }
        if (webView.getUrl() == null) webView.loadUrl(HOME_URL);
    }

    private void tryAlternateOrShowError(String message) {
        if (!triedAlternate) {
            triedAlternate = true;
            webView.stopLoading();
            webView.loadUrl(WWW_URL);
        } else if (!pageCommitted) {
            showError(message);
        }
    }

    private void showError(String message) {
        progress.setVisibility(View.GONE);
        errorPanel.setVisibility(View.VISIBLE);
        errorPanel.setText(message + "\n\nTap here to retry.\n\nIf Chrome opens the site but this app does not, send the AndroidForge build log and a screenshot.");
        errorPanel.setOnClickListener(v -> {
            triedAlternate = false;
            pageCommitted = false;
            webView.loadUrl(HOME_URL);
        });
    }


    private boolean isTrustedPortal(String url) {
        if (url == null) return false;
        Uri uri = Uri.parse(url);
        String host = uri.getHost();
        return "https".equalsIgnoreCase(uri.getScheme()) &&
                host != null && (host.equalsIgnoreCase("tejodhar.in") ||
                host.equalsIgnoreCase("www.tejodhar.in"));
    }

    private boolean hasSavedCredentials() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).contains(CREDENTIALS);
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(KEY_ALIAS))
            return ((SecretKey) keyStore.getKey(KEY_ALIAS, null));
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private void saveCredentialsEncrypted(String username, String password) {
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
            byte[] iv = cipher.getIV();
            byte[] encrypted = cipher.doFinal((username + "\n" + password).getBytes(StandardCharsets.UTF_8));
            ByteBuffer buffer = ByteBuffer.allocate(iv.length + encrypted.length);
            buffer.put(iv); buffer.put(encrypted);
            String value = Base64.encodeToString(buffer.array(), Base64.NO_WRAP);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(CREDENTIALS, value).apply();
            Toast.makeText(this, "Login saved securely for biometric unlock", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            android.util.Log.e("TejodharBio", "Credential encryption failed", e);
            Toast.makeText(this, "Could not securely save login", Toast.LENGTH_SHORT).show();
        }
    }

    private String[] decryptCredentials() throws Exception {
        String value = getSharedPreferences(PREFS, MODE_PRIVATE).getString(CREDENTIALS, null);
        if (value == null) return null;
        byte[] all = Base64.decode(value, Base64.NO_WRAP);
        byte[] iv = java.util.Arrays.copyOfRange(all, 0, 12);
        byte[] encrypted = java.util.Arrays.copyOfRange(all, 12, all.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
        String plain = new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        int split = plain.indexOf('\n');
        if (split < 0) return null;
        return new String[]{plain.substring(0, split), plain.substring(split + 1)};
    }

    private void promptBiometricUnlock() {
        int authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG;
        if (Build.VERSION.SDK_INT >= 30)
            authenticators |= BiometricManager.Authenticators.DEVICE_CREDENTIAL;
        BiometricManager manager = BiometricManager.from(this);
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Set up fingerprint or phone screen lock to use biometric login", Toast.LENGTH_LONG).show();
            return;
        }
        BiometricPrompt prompt = new BiometricPrompt(this, biometricExecutor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        biometricUnlocked = true;
                        if (webView != null) fillSavedCredentials(webView);
                    }
                    @Override public void onAuthenticationError(int code, CharSequence message) {
                        super.onAuthenticationError(code, message);
                        Toast.makeText(MainActivity.this, "Biometric unlock cancelled: " + message, Toast.LENGTH_SHORT).show();
                    }
                });
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Tejodhar login")
                .setSubtitle("Verify to fill your saved username and password")
                .setAllowedAuthenticators(authenticators)
                .build();
        prompt.authenticate(info);
    }

    private void fillSavedCredentials(WebView view) {
        if (!isTrustedPortal(view.getUrl())) return;
        try {
            String[] credentials = decryptCredentials();
            if (credentials == null) return;
            String user = org.json.JSONObject.quote(credentials[0]);
            String pass = org.json.JSONObject.quote(credentials[1]);
            String js = "(function(u,p){" +
                    "var forms=[...document.forms];" +
                    "for(var f of forms){" +
                    "var inputs=[...f.querySelectorAll('input')];" +
                    "var pw=inputs.find(x=>x.type==='password');" +
                    "if(!pw)continue;" +
                    "var un=inputs.find(x=>x!==pw && (/user|email|login/i.test((x.name||'')+' '+(x.id||'')+' '+(x.autocomplete||'')) || x.type==='email')) || inputs.find(x=>x!==pw && (x.type==='text'||!x.type));" +
                    "if(un){un.value=u;un.dispatchEvent(new Event('input',{bubbles:true}));un.dispatchEvent(new Event('change',{bubbles:true}));}" +
                    "pw.value=p;pw.dispatchEvent(new Event('input',{bubbles:true}));pw.dispatchEvent(new Event('change',{bubbles:true}));return true;" +
                    "}return false;})(" + user + "," + pass + ")";
            view.evaluateJavascript(js, null);
        } catch (Exception e) {
            android.util.Log.e("TejodharBio", "Credential decrypt failed", e);
        }
    }

    private void installLoginCapture(WebView view) {
        // Inject only on the trusted Tejodhar HTTPS origin. The button reads the
        // current form values when tapped, then asks Android to confirm and encrypt them.
        String js = "(function(){"
                + "if(window.__tejodharCaptureInstalled)return;"
                + "window.__tejodharCaptureInstalled=true;"
                + "function addButtons(){"
                + "var fields=Array.from(document.querySelectorAll('input[type=password]'));"
                + "fields.forEach(function(p){"
                + "var f=p.form||p.closest('form');if(!f)return;"
                + "if(f.querySelector('.tejodhar-native-save-login'))return;"
                + "var b=document.createElement('button');"
                + "b.type='button';b.className='tejodhar-native-save-login';"
                + "b.textContent='Enable fingerprint login';"
                + "b.style.cssText='display:block;margin:10px 0;padding:10px 14px;border:0;border-radius:8px;background:#142b52;color:#fff;font-weight:600;cursor:pointer;';"
                + "b.addEventListener('click',function(){"
                + "var pass=f.querySelector('input[type=password]');"
                + "var inputs=Array.from(f.querySelectorAll('input'));"
                + "var user=inputs.find(function(x){return x!==pass&&(/user|email|login/i.test((x.name||'')+' '+(x.id||'')+' '+(x.autocomplete||''))||x.type==='email');})"
                + "||inputs.find(function(x){return x!==pass&&(x.type==='text'||!x.type);});"
                + "if(!user||!pass||!user.value||!pass.value){alert('Enter your username and password first.');return;}"
                + "if(window.TejodharNative){window.TejodharNative.requestSave(user.value,pass.value);}"
                + "else{alert('Native biometric service is not available.');}"
                + "});"
                + "p.insertAdjacentElement('afterend',b);"
                + "});}"
                + "addButtons();"
                + "if(document.documentElement){new MutationObserver(addButtons).observe(document.documentElement,{childList:true,subtree:true});}"
                + "})();";
        view.evaluateJavascript(js, null);
    }

    private class LoginBridge {
        @android.webkit.JavascriptInterface
        public void requestSave(String username, String password) {
            if (username == null || password == null || username.length() > 256 || password.length() > 1024) return;
            runOnUiThread(() -> {
                pendingUsername = username;
                pendingPassword = password;
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setTitle("Save login securely?")
                        .setMessage("Save this username and password encrypted on this phone? Biometric verification will be required to use it.")
                        .setNegativeButton("Not now", (d, w) -> clearPendingCredentials())
                        .setPositiveButton("Save with biometric", (d, w) -> authenticateToSave())
                        .setOnCancelListener(d -> clearPendingCredentials())
                        .show();
            });
        }
    }

    private void authenticateToSave() {
        int authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG;
        if (Build.VERSION.SDK_INT >= 30)
            authenticators |= BiometricManager.Authenticators.DEVICE_CREDENTIAL;
        if (BiometricManager.from(this).canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Set up fingerprint or phone screen lock first", Toast.LENGTH_LONG).show();
            clearPendingCredentials();
            return;
        }
        BiometricPrompt prompt = new BiometricPrompt(this, biometricExecutor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        if (pendingUsername != null && pendingPassword != null)
                            saveCredentialsEncrypted(pendingUsername, pendingPassword);
                        clearPendingCredentials();
                    }
                    @Override public void onAuthenticationError(int code, CharSequence message) {
                        super.onAuthenticationError(code, message);
                        clearPendingCredentials();
                    }
                });
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Confirm saved login")
                .setSubtitle("Verify your identity to encrypt the credentials")
                .setAllowedAuthenticators(authenticators)
                .build();
        prompt.authenticate(info);
    }

    private void clearPendingCredentials() {
        pendingUsername = null;
        pendingPassword = null;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST && pendingWebPermission != null) {
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) granted &= result == PackageManager.PERMISSION_GRANTED;
            if (granted && pendingGrantedResources != null)
                pendingWebPermission.grant(pendingGrantedResources);
            else pendingWebPermission.deny();
            pendingWebPermission = null;
            pendingGrantedResources = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        if (pendingWebPermission != null) pendingWebPermission.deny();
        pendingWebPermission = null;
        pendingGrantedResources = null;
        clearPendingCredentials();
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
