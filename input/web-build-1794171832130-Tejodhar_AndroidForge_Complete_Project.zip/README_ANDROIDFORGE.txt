TEJODHAR SECURE ANDROID PROJECT
================================

Project layout includes:
- app/src/main/AndroidManifest.xml
- app/src/main/java/in/tejodhar/app/MainActivity.kt
- app/src/main/java/in/tejodhar/app/TokenVault.kt
- app/src/main/res/layout/activity_main.xml
- app/src/main/res/values/styles.xml
- settings.gradle.kts
- root build.gradle.kts
- gradle/libs.versions.toml
- app/build.gradle.kts

APP LOCK BEHAVIOUR
------------------
If a Tejodhar biometric token is already registered on this device,
the app requests a strong biometric before loading the website.
If no token is registered, the app opens the existing Tejodhar login
page so the user can sign in with their existing username/password and
enable biometric login through the existing PHP biometric flow.

After launch-gate success, the website's existing native biometric
login may request a second biometric scan to authenticate the server
session. This is intentional separation between app opening and server
account authentication. The app-lock scan alone does NOT create a PHP
login session.

IMPORTANT LIMITATIONS
--------------------
- This is a source project ZIP, not a compiled APK.
- The launch lock is enabled when a biometric token is already enrolled.
- If biometrics are unavailable after enrollment, the app remains locked;
  the user must restore device biometric availability. Do not clear app
  data to bypass this without understanding that local token data may be lost.
- Existing website username/password and PHP authentication are unchanged.
- Use AndroidForge's Android/Gradle build option to build the APK.
- Test with a non-critical account before production rollout.

SECURITY NOTE
-------------
Do not commit database credentials, API keys, or GitHub tokens.
Rotate any credentials previously exposed in uploaded PHP source.
