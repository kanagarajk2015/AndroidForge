package com.tejodhar.fingerprint

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/**
 * Animated backgrounds drawn behind the fingerprint. [t] runs 0..1 and every effect is periodic
 * over that range, so each loop joins up without a jump.
 */
object Effects {
    private const val TAU = 6.2831855f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    fun draw(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        when (s.effect) {
            Effect.RING -> ring(c, s, cx, cy, r, t)
            Effect.RIPPLE -> ripple(c, s, cx, cy, r, t)
            Effect.FLAME -> flame(c, s, cx, cy, r, t)
            Effect.SWEEP -> sweep(c, s, cx, cy, r, t)
            Effect.ZIGZAG -> zigzag(c, s, cx, cy, r, t)
            Effect.SPARKS -> sparks(c, s, cx, cy, r, t)
            Effect.BLOB -> blob(c, s, cx, cy, r, t)
            Effect.CRYSTAL -> crystal(c, s, cx, cy, r, t)
            Effect.LEAVES -> petals(c, s, cx, cy, r, t, leaf = true)
            Effect.PETALS -> petals(c, s, cx, cy, r, t, leaf = false)
            Effect.ORBIT -> orbit(c, s, cx, cy, r, t)
            Effect.HEART -> heart(c, s, cx, cy, r, t)
            Effect.RAYS -> rays(c, s, cx, cy, r, t)
            Effect.RAIN -> rain(c, s, cx, cy, r, t)
        }
    }

    /** Stable pseudo-random value in 0..1 for particle [i] and [salt]. */
    private fun rnd(i: Int, salt: Int): Float {
        val x = sin(i * 127.1 + salt * 311.7) * 43758.5453
        return (x - floor(x)).toFloat()
    }

    private fun withAlpha(col: Int, a: Float): Int =
        Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(col), Color.green(col), Color.blue(col))

    /** Blends [a] toward [b] by [f] (0..1). */
    fun mix(a: Int, b: Int, f: Float): Int {
        val k = f.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    private fun fill(c: Canvas, col: Int, a: Float, x: Float, y: Float, radius: Float) {
        paint.style = Paint.Style.FILL
        paint.shader = null
        paint.color = withAlpha(col, a)
        c.drawCircle(x, y, radius, paint)
    }

    private fun stroke(c: Canvas, col: Int, a: Float, width: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = width
        paint.strokeCap = Paint.Cap.ROUND
        paint.shader = null
        paint.color = withAlpha(col, a)
    }

    private fun ring(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        val rr = r * 1.12f
        rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
        for (k in 0..1) {
            val col = if (k == 0) s.c1 else s.c2
            val start = 360f * t + k * 180f
            stroke(c, col, 0.35f, r * 0.12f)
            c.drawArc(rect, start, 110f, false, paint)
            stroke(c, col, 1f, r * 0.035f)
            c.drawArc(rect, start, 110f, false, paint)
        }
    }

    private fun ripple(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        for (k in 0 until 3) {
            val p = (t + k / 3f) % 1f
            stroke(c, if (k % 2 == 0) s.c1 else s.c2, 1f - p, r * (0.05f + 0.03f * (1f - p)))
            c.drawCircle(cx, cy, r * (0.75f + 0.9f * p), paint)
        }
    }

    private fun flame(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        for (i in 0 until 22) {
            val p = (t + rnd(i, 1)) % 1f
            val ang = rnd(i, 2) * TAU
            val x = cx + cos(ang) * r * 1.05f + sin(p * 9f + i) * r * 0.08f
            val y = cy + sin(ang) * r * 1.05f - p * r * 0.9f
            fill(c, mix(s.c1, s.c2, p), 1f - p, x, y, r * 0.09f * (1f - p * 0.6f))
        }
    }

    private fun sweep(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        c.save()
        c.rotate(360f * t, cx, cy)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = r * 0.09f
        paint.shader = SweepGradient(cx, cy, intArrayOf(s.c1, s.c2, s.c1), floatArrayOf(0f, 0.5f, 1f))
        c.drawCircle(cx, cy, r * 1.15f, paint)
        paint.shader = null
        c.restore()
    }

    private fun zigzag(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        val frame = floor(t * 12f).toInt()
        val path = Path()
        for (k in 0 until 7) {
            val ang = (k / 7f) * TAU + rnd(k, 3) * 0.6f
            path.reset()
            path.moveTo(cx + cos(ang) * r * 0.95f, cy + sin(ang) * r * 0.95f)
            for (j in 1..4) {
                val d = r * (0.95f + 0.2f * j)
                val jitter = (rnd(k * 4 + j, frame + 5) - 0.5f) * 0.12f
                path.lineTo(cx + cos(ang + jitter) * d, cy + sin(ang + jitter) * d)
            }
            stroke(c, if (k % 2 == 0) s.c1 else s.c2, 0.9f, r * 0.03f)
            c.drawPath(path, paint)
        }
    }

    private fun sparks(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        for (i in 0 until 26) {
            val p = (t + rnd(i, 1)) % 1f
            val ang = rnd(i, 0) * TAU
            val d = r * (0.85f + 0.9f * p)
            fill(
                c, mix(s.c1, s.c2, rnd(i, 4)), 1f - p,
                cx + cos(ang) * d, cy + sin(ang) * d, r * 0.035f * (1.2f - p)
            )
        }
    }

    private fun blob(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        for (i in 0 until 7) {
            val ang = (i / 7f) * TAU + t * TAU
            val wobble = 0.85f + 0.15f * sin(t * TAU * 2f + i)
            val d = r * 0.85f * wobble
            fill(
                c, if (i % 2 == 0) s.c1 else s.c2, 0.16f,
                cx + cos(ang) * d, cy + sin(ang) * d, r * (0.45f + 0.1f * sin(t * TAU + i))
            )
        }
    }

    private fun crystal(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        val path = Path()
        for (k in 0 until 6) {
            val ang = (k / 6f) * TAU
            val shimmer = 0.5f + 0.5f * sin(t * TAU + k)
            val pulse = 0.85f + 0.15f * sin(t * TAU * 2f + k)
            val len = r * 0.42f * pulse
            val wid = r * 0.14f * pulse
            path.reset()
            path.moveTo(0f, -len)
            path.lineTo(wid, 0f)
            path.lineTo(0f, len * 0.6f)
            path.lineTo(-wid, 0f)
            path.close()
            c.save()
            c.translate(cx + cos(ang) * r * 1.05f, cy + sin(ang) * r * 1.05f)
            c.rotate(ang * 57.29578f + 90f)
            paint.style = Paint.Style.FILL
            paint.shader = null
            paint.color = withAlpha(mix(s.c1, s.c2, shimmer), 0.55f + 0.35f * pulse)
            c.drawPath(path, paint)
            c.restore()
        }
    }

    private fun petals(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float, leaf: Boolean) {
        val n = if (leaf) 8 else 6
        val sway = (if (leaf) 22f else 10f) * sin(t * TAU)
        val breathe = 0.92f + 0.08f * sin(t * TAU * 2f)
        val len = if (leaf) r * 0.36f * breathe else r * 0.26f * breathe
        val wid = if (leaf) r * 0.12f else r * 0.2f
        for (k in 0 until n) {
            c.save()
            c.translate(cx, cy)
            c.rotate(k * 360f / n + sway)
            c.translate(0f, -r * 1.08f)
            rect.set(-wid, -len, wid, len)
            paint.style = Paint.Style.FILL
            paint.shader = null
            paint.color = withAlpha(if (k % 2 == 0) s.c1 else s.c2, 0.85f)
            c.drawOval(rect, paint)
            c.restore()
        }
    }

    private fun orbit(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        val rx = r * 1.22f
        val ry = r * 0.42f
        for (k in 0 until 3) {
            c.save()
            c.translate(cx, cy)
            c.rotate(k * 60f)
            stroke(c, s.c1, 0.3f, r * 0.02f)
            rect.set(-rx, -ry, rx, ry)
            c.drawOval(rect, paint)
            val a = t * TAU * (k + 1)
            paint.style = Paint.Style.FILL
            paint.shader = null
            paint.color = if (k == 1) s.c2 else s.c1
            c.drawCircle(cos(a) * rx, sin(a) * ry, r * 0.07f, paint)
            c.restore()
        }
    }

    private fun heart(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        val beat = 1f + 0.07f * (sin(t * TAU * 2f) + 0.5f * sin(t * TAU * 4f))
        val size = r * 1.22f * beat
        val path = Path()
        path.moveTo(0f, 0.9f)
        path.cubicTo(-1.4f, 0.1f, -0.6f, -0.9f, 0f, -0.35f)
        path.cubicTo(0.6f, -0.9f, 1.4f, 0.1f, 0f, 0.9f)
        path.close()
        c.save()
        c.translate(cx, cy)
        c.scale(size, size)
        stroke(c, s.c1, 0.35f, 0.12f)
        c.drawPath(path, paint)
        stroke(c, s.c1, 1f, 0.035f)
        c.drawPath(path, paint)
        c.restore()
    }

    private fun rays(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        fill(c, s.c2, 0.28f, cx, cy, r * 1.02f)
        val len = r * (1.25f + 0.12f * sin(t * TAU * 2f))
        val path = Path()
        c.save()
        c.translate(cx, cy)
        c.rotate(45f * t)
        for (k in 0 until 16) {
            c.save()
            c.rotate(k * 22.5f)
            path.reset()
            path.moveTo(-r * 0.05f, -r * 1.02f)
            path.lineTo(r * 0.05f, -r * 1.02f)
            path.lineTo(0f, -len)
            path.close()
            paint.style = Paint.Style.FILL
            paint.shader = null
            paint.color = withAlpha(if (k % 2 == 0) s.c1 else s.c2, 0.85f)
            c.drawPath(path, paint)
            c.restore()
        }
        c.restore()
    }

    private fun rain(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        val cols = 9
        for (i in 0 until cols) {
            val x = cx + (i / (cols - 1f) - 0.5f) * r * 2.6f
            for (j in 0 until 6) {
                val p = (t + rnd(i, 6) + j / 6f) % 1f
                val y = cy - r * 1.3f + p * r * 2.6f
                fill(c, if (j == 0) s.c2 else s.c1, (1f - p) * 0.9f, x, y, r * 0.025f)
            }
        }
    }
}
