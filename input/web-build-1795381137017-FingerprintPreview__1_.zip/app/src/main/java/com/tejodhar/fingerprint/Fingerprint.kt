package com.tejodhar.fingerprint

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.random.Random

/** A fingerprint-like glyph: concentric ridges, each broken by a gap at its own angle. */
object Fingerprint {
    private const val RIDGES = 9
    private val gapStart = FloatArray(RIDGES)
    private val gapLen = FloatArray(RIDGES)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        // Fixed seed, so the glyph looks the same on every redraw.
        val rnd = Random(7)
        for (i in 0 until RIDGES) {
            gapStart[i] = rnd.nextFloat() * 360f
            gapLen[i] = 35f + rnd.nextFloat() * 60f
        }
    }

    fun draw(c: Canvas, cx: Float, cy: Float, radius: Float, color: Int, width: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = width
        paint.color = color
        for (i in 0 until RIDGES) {
            val rr = radius * (i + 1) / RIDGES
            rect.set(cx - rr * 0.8f, cy - rr, cx + rr * 0.8f, cy + rr)
            c.drawArc(rect, gapStart[i] + gapLen[i], 360f - gapLen[i], false, paint)
        }
    }
}
