package com.tejodhar.fingerprint

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView

/** Full-screen preview of one style. Tap anywhere to close. */
class PreviewActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val index = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, Styles.ALL.size - 1)
        val style = Styles.ALL[index]
        val metrics = resources.displayMetrics
        val side = (minOf(metrics.widthPixels, metrics.heightPixels) * 0.9f).toInt()

        val animated = AnimatedFingerprintView(this).apply {
            fill = 0.27f
            preview = style
        }

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            setOnClickListener { finish() }
            addView(animated, FrameLayout.LayoutParams(side, side, Gravity.CENTER))
            addView(
                TextView(this@PreviewActivity).apply {
                    text = style.name
                    setTextColor(Color.WHITE)
                    textSize = 22f
                    gravity = Gravity.CENTER
                },
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.CENTER_HORIZONTAL
                ).apply { topMargin = dp(40) }
            )
            addView(
                TextView(this@PreviewActivity).apply {
                    text = "Preview only. Tap to close."
                    setTextColor(0xFFB0BEC5.toInt())
                    textSize = 13f
                    gravity = Gravity.CENTER
                },
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                ).apply { bottomMargin = dp(40) }
            )
        }
        setContentView(root)
    }

    companion object {
        const val EXTRA_INDEX = "index"
    }
}
