package com.tejodhar.fingerprint

enum class Effect { RING, RIPPLE, FLAME, SWEEP, ZIGZAG, SPARKS, BLOB, CRYSTAL, LEAVES, PETALS, ORBIT, HEART, RAYS, RAIN }

/**
 * One preview style. [speed] is how many times the effect repeats per loop (1 or 2). Every effect
 * is periodic, so a higher speed only runs faster and still joins up.
 */
data class PreviewStyle(
    val name: String,
    val effect: Effect,
    val c1: Int,
    val c2: Int,
    val speed: Int = 1
)

object Styles {
    private fun argb(v: Long): Int = v.toInt()

    val ALL: List<PreviewStyle> = listOf(
        PreviewStyle("Jade Dragon", Effect.RING, argb(0xFF2E7D32), argb(0xFFD4AF37)),
        PreviewStyle("Gold Dragon", Effect.RING, argb(0xFFFFC107), argb(0xFFFFF59D)),
        PreviewStyle("Neon Blue", Effect.RIPPLE, argb(0xFF2979FF), argb(0xFF00E5FF)),
        PreviewStyle("Fire & Flames", Effect.FLAME, argb(0xFFFF6D00), argb(0xFFFFD600), speed = 2),
        PreviewStyle("Galaxy", Effect.SWEEP, argb(0xFFAA00FF), argb(0xFF2962FF)),
        PreviewStyle("Aurora Glow", Effect.SWEEP, argb(0xFF00E676), argb(0xFFFF4081)),

        PreviewStyle("Red Pulse", Effect.RIPPLE, argb(0xFFFF1744), argb(0xFFFF8A80)),
        PreviewStyle("Cyan Energy", Effect.ZIGZAG, argb(0xFF00E5FF), argb(0xFF40C4FF), speed = 2),
        PreviewStyle("Purple Spark", Effect.SPARKS, argb(0xFFB388FF), argb(0xFFE040FB), speed = 2),
        PreviewStyle("Green Energy", Effect.BLOB, argb(0xFF76FF03), argb(0xFF00C853)),
        PreviewStyle("Ice Crystal", Effect.CRYSTAL, argb(0xFF80D8FF), argb(0xFFE0F7FA)),
        PreviewStyle("Diamond Shine", Effect.CRYSTAL, argb(0xFFFFFFFF), argb(0xFF82B1FF)),

        PreviewStyle("Water Ripple", Effect.RIPPLE, argb(0xFF2196F3), argb(0xFF64B5F6)),
        PreviewStyle("Golden Particles", Effect.SPARKS, argb(0xFFFFD54F), argb(0xFFFFA000)),
        PreviewStyle("Leaf Nature", Effect.LEAVES, argb(0xFF66BB6A), argb(0xFFA5D6A7)),
        PreviewStyle("Flower Bloom", Effect.PETALS, argb(0xFFF48FB1), argb(0xFFFFCDD2)),
        PreviewStyle("Butterfly Light", Effect.ORBIT, argb(0xFF448AFF), argb(0xFFB388FF)),
        PreviewStyle("Heart Glow", Effect.HEART, argb(0xFFFF4081), argb(0xFFE040FB)),

        PreviewStyle("Tech Circuit", Effect.ZIGZAG, argb(0xFF18FFFF), argb(0xFF00B0FF)),
        PreviewStyle("Cyberpunk", Effect.SWEEP, argb(0xFFD500F9), argb(0xFF00E5FF)),
        PreviewStyle("Matrix Code", Effect.RAIN, argb(0xFF00FF41), argb(0xFF00C853), speed = 2),
        PreviewStyle("Time Ring", Effect.RING, argb(0xFFFFD700), argb(0xFFFF8F00)),
        PreviewStyle("Space Orbit", Effect.ORBIT, argb(0xFF82B1FF), argb(0xFFFFAB40)),
        PreviewStyle("Solar Eclipse", Effect.RAYS, argb(0xFFFFAB00), argb(0xFFFF6D00)),

        PreviewStyle("Smoke Flow", Effect.BLOB, argb(0xFFEEEEEE), argb(0xFF9E9E9E)),
        PreviewStyle("Flame Ring", Effect.FLAME, argb(0xFFD50000), argb(0xFFFF6E40)),
        PreviewStyle("Rainbow Ring", Effect.SWEEP, argb(0xFFFF4081), argb(0xFF40C4FF)),
        PreviewStyle("Ripple Wave", Effect.RIPPLE, argb(0xFF1565C0), argb(0xFF42A5F5)),
        PreviewStyle("Crystal Shine", Effect.CRYSTAL, argb(0xFF29B6F6), argb(0xFFB3E5FC)),
        PreviewStyle("Golden Lotus", Effect.PETALS, argb(0xFFFFC107), argb(0xFFFFE082))
    )
}
