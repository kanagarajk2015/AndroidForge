package com.tejodhar.fingerprint

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator

/** Plays one preview style. It animates only while it is attached to a window. */
class AnimatedFingerprintView(context: Context) : View(context) {

    /** The style to play. Setting it changes the preview. */
    var preview: PreviewStyle? = null
        set(value) {
            field = value
            invalidate()
        }

    /** Radius of the effect area, as a share of the view's side. */
    var fill: Float = 0.2f

    private var phase = 0f
    private var animator: ValueAnimator? = null
    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 0, 0, 0) }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // Always square, so each tile is a square cell.
        val side = View.MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(side, side)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (animator == null) {
            animator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = LOOP_MS
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    phase = it.animatedValue as Float
                    invalidate()
                }
            }
        }
        animator?.start()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val st = preview ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val side = minOf(w, h)
        val cx = w / 2f
        val cy = h / 2f
        val r = side * fill
        val t = (phase * st.speed) % 1f

        Effects.draw(canvas, st, cx, cy, r, t)
        canvas.drawCircle(cx, cy, r * 0.95f, discPaint)
        Fingerprint.draw(canvas, cx, cy, r * 0.8f, Effects.mix(st.c1, Color.WHITE, 0.45f), r * 0.06f)
    }

    companion object {
        private const val LOOP_MS = 2400L
    }
}
