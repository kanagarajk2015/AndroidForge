package com.tejodhar.fingerprint

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "Fingerprint animation styles"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, dp(4))
        }
        val note = TextView(this).apply {
            text = "Preview only. These styles do not unlock or verify anything on your phone."
            setTextColor(0xFFB0BEC5.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(16), 0, dp(16), dp(12))
        }
        val grid = GridView(this).apply {
            setNumColumns(3)
            setVerticalSpacing(dp(8))
            setHorizontalSpacing(dp(8))
            setPadding(dp(8), 0, dp(8), dp(8))
            adapter = StyleAdapter(this@MainActivity)
            setOnItemClickListener { _, _, position, _ ->
                startActivity(
                    Intent(this@MainActivity, PreviewActivity::class.java)
                        .putExtra(PreviewActivity.EXTRA_INDEX, position)
                )
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            addView(title)
            addView(note)
            addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
    }
}

/** One square tile per style: the animated preview with its name underneath. */
class StyleAdapter(private val ctx: Context) : BaseAdapter() {

    override fun getCount(): Int = Styles.ALL.size

    override fun getItem(position: Int): Any = Styles.ALL[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val tile = (convertView as? LinearLayout) ?: createTile()
        val style = Styles.ALL[position]
        (tile.getChildAt(0) as AnimatedFingerprintView).preview = style
        (tile.getChildAt(1) as TextView).text = style.name
        return tile
    }

    private fun createTile(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        val pad = ctx.dp(4)
        setPadding(pad, pad, pad, pad)
        addView(
            AnimatedFingerprintView(ctx),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        addView(TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
    }
}
