package in.tejodhar.app

import org.json.JSONObject

/**
 * JavaScript injected into the Tejodhar web login page.
 *
 * It does not depend on the form's field names: it finds the visible password box
 * and the text box just above it (username / mobile / email).
 */
object LoginScripts {

    // Defines tdFields(): returns { user, pw, form } for the visible login form, or null.
    private val FIELD_FINDER = """
        function tdFields() {
          var pw = null;
          var pws = document.querySelectorAll('input[type="password"]');
          for (var i = 0; i < pws.length; i++) {
            if (!pws[i].disabled && pws[i].offsetParent !== null) { pw = pws[i]; break; }
          }
          if (!pw) return null;
          var form = pw.form;
          var inputs = Array.prototype.slice.call((form || document).querySelectorAll('input'));
          var user = null;
          for (var j = inputs.indexOf(pw) - 1; j >= 0; j--) {
            var el = inputs[j];
            var t = (el.type || 'text').toLowerCase();
            if ((t === 'text' || t === 'email' || t === 'tel') && !el.disabled && !el.readOnly && el.offsetParent !== null) {
              user = el;
              break;
            }
          }
          return user ? { user: user, pw: pw, form: form } : null;
        }
    """.trimIndent()

    /**
     * Runs on every Tejodhar page. When the user submits a login form, the typed
     * username and password are sent to native code, which saves them only after
     * the login is confirmed to have worked.
     */
    val LOGIN_HOOK: String = "(function () {" + FIELD_FINDER + """
        if (window.__tdLoginHook) return;
        window.__tdLoginHook = true;
        function capture() {
          var f = tdFields();
          if (f && f.user.value && f.pw.value && window.AndroidNative) {
            AndroidNative.onLoginSubmit(f.user.value, f.pw.value);
          }
        }
        document.addEventListener('submit', capture, true);
        document.addEventListener('click', function (e) {
          var b = e.target && e.target.closest ? e.target.closest('button,input[type=submit]') : null;
          if (b && b.form && (b.type || 'submit').toLowerCase() === 'submit') capture();
        }, true);
    })();
    """.trimIndent()

    /** Fills the visible login form with the saved login and submits it. Result: '1' if submitted, '0' if no form. */
    fun autofill(user: String, pass: String): String =
        "(function (__u, __p) {" + FIELD_FINDER + """
        var f = tdFields();
        if (!f) return '0';
        function put(el, v) {
          var d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
          if (d && d.set) { d.set.call(el, v); } else { el.value = v; }
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
        }
        put(f.user, __u);
        put(f.pw, __p);
        if (f.form) {
          if (f.form.requestSubmit) { f.form.requestSubmit(); } else { f.form.submit(); }
        } else {
          var btn = document.querySelector('button,input[type=submit]');
          if (btn) btn.click();
        }
        return '1';
    })(""".trimIndent() + JSONObject.quote(user) + "," + JSONObject.quote(pass) + ");"

    /** Result: '1' if a password box is visible on the page (still on the login form), else '0'. */
    val PASSWORD_VISIBLE: String = """
        (function () {
          var pws = document.querySelectorAll('input[type="password"]');
          for (var i = 0; i < pws.length; i++) { if (pws[i].offsetParent !== null) return '1'; }
          return '0';
        })();
    """.trimIndent()
}
