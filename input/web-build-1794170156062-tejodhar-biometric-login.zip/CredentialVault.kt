package in.tejodhar.app

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class LoginCreds(val user: String, val pass: String)

/**
 * Stores the username + password encrypted with a key in the Android Keystore.
 *
 * The key needs a fresh fingerprint / face scan for every use, so the saved login
 * can only be read or written after the user passes BiometricPrompt with the
 * cipher returned by [decryptCipher] / [encryptCipher] (CryptoObject).
 * If fingerprints or faces are added or removed, the key is invalidated and
 * the saved login is dropped, so the user signs in with the password once more.
 */
object CredentialVault {

    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "tejodhar_login_key"
    private const val TRANSFORM = "AES/GCM/NoPadding"
    private const val PREFS = "tejodhar_login"
    private const val K_USER = "user"
    private const val K_IV = "iv"
    private const val K_BLOB = "blob"
    private const val K_DECLINED = "declined_user"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun keyStore(): KeyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }

    private fun existingKey(): SecretKey? =
        runCatching { keyStore().getKey(KEY_ALIAS, null) as? SecretKey }.getOrNull()

    private fun createKey(): SecretKey {
        val builder = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)        // every use needs a fresh scan
            .setInvalidatedByBiometricEnrollment(true)  // adding/removing a fingerprint kills the key

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Only a strong biometric (fingerprint / 3D face) may unlock this key, not the PIN.
            builder.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
        }

        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            .apply { init(builder.build()) }
            .generateKey()
    }

    private fun deleteKey() {
        runCatching { keyStore().deleteEntry(KEY_ALIAS) }
    }

    /** True only when an encrypted login exists AND its Keystore key is still present. */
    fun hasSavedLogin(ctx: Context): Boolean {
        val p = prefs(ctx)
        return p.contains(K_BLOB) && p.contains(K_IV) && existingKey() != null
    }

    fun savedUser(ctx: Context): String? =
        if (hasSavedLogin(ctx)) prefs(ctx).getString(K_USER, null) else null

    /** Cipher used to encrypt a new login. Only usable after a biometric success. */
    fun encryptCipher(): Cipher = try {
        newEncryptCipher()
    } catch (e: KeyPermanentlyInvalidatedException) {
        deleteKey()
        newEncryptCipher()
    }

    private fun newEncryptCipher(): Cipher {
        val key = existingKey() ?: createKey()
        return Cipher.getInstance(TRANSFORM).apply { init(Cipher.ENCRYPT_MODE, key) }
    }

    /**
     * Cipher used to read the saved login. Returns null when nothing is saved.
     * Throws KeyPermanentlyInvalidatedException when fingerprints/faces changed.
     */
    fun decryptCipher(ctx: Context): Cipher? {
        val iv = prefs(ctx).getString(K_IV, null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return null
        val key = existingKey() ?: return null
        return Cipher.getInstance(TRANSFORM).apply {
            init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        }
    }

    /** Encrypts and stores the login using the cipher the biometric prompt just unlocked. */
    fun save(ctx: Context, cipher: Cipher, creds: LoginCreds) {
        val json = JSONObject().put("u", creds.user).put("p", creds.pass).toString()
        val blob = cipher.doFinal(json.toByteArray(Charsets.UTF_8))
        prefs(ctx).edit()
            .putString(K_USER, creds.user)
            .putString(K_IV, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString(K_BLOB, Base64.encodeToString(blob, Base64.NO_WRAP))
            .apply()
    }

    /** Decrypts the saved login using the cipher the biometric prompt just unlocked. */
    fun read(ctx: Context, cipher: Cipher): LoginCreds {
        val blob = Base64.decode(prefs(ctx).getString(K_BLOB, "") ?: "", Base64.NO_WRAP)
        val json = JSONObject(String(cipher.doFinal(blob), Charsets.UTF_8))
        return LoginCreds(json.getString("u"), json.getString("p"))
    }

    /** Forgets the saved login and its key. */
    fun clear(ctx: Context) {
        prefs(ctx).edit().remove(K_USER).remove(K_IV).remove(K_BLOB).apply()
        deleteKey()
    }

    /** The user said "Not now" for this username, so do not ask again for it. */
    fun declined(ctx: Context, user: String): Boolean = prefs(ctx).getString(K_DECLINED, null) == user

    fun setDeclined(ctx: Context, user: String) {
        prefs(ctx).edit().putString(K_DECLINED, user).apply()
    }
}
