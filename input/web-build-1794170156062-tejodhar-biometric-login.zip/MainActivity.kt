package in.tejodhar.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executor
import javax.crypto.Cipher

class MainActivity : AppCompatActivity() {

    // What the current biometric prompt is for
    private enum class Mode { UNLOCK, DECRYPT, ENCRYPT, WEB_CHECK }

    private lateinit var webView: WebView
    private lateinit var lockPanel: LinearLayout
    private lateinit var btnFingerprint: Button
    private lateinit var btnPassword: Button
    private lateinit var btnForget: Button

    private val PERMISSION_REQUEST_CODE = 101
    private val TARGET_URL = "https://www.tejodhar.in/"

    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private var mode = Mode.UNLOCK

    private var unlocked = false
    private var pendingSave: LoginCreds? = null       // waiting for fingerprint to save it
    private var pendingAutofill: LoginCreds? = null   // fill these into the next login page
    private var autofillInFlight = false              // saved login was submitted; check the result
    private var pendingLogin: LoginCreds? = null      // typed by the user; save once login works

    // Native JavaScript Interface for web interaction
    inner class WebAppInterface {
        @JavascriptInterface
        fun triggerBiometricAuth() {
            runOnUiThread {
                promptWebCheck()
            }
        }

        @JavascriptInterface
        fun isNativeApp(): Boolean {
            return true
        }

        // Called by the injected login hook when the user submits a login form on the site
        @JavascriptInterface
        fun onLoginSubmit(username: String, password: String) {
            runOnUiThread {
                if (autofillInFlight || username.isBlank() || password.isEmpty()) return@runOnUiThread
                if (!isOwnUrl(webView.url)) return@runOnUiThread
                pendingLogin = LoginCreds(username.trim(), password)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        lockPanel = findViewById(R.id.lockPanel)
        btnFingerprint = findViewById(R.id.btnFingerprint)
        btnPassword = findViewById(R.id.btnPassword)
        btnForget = findViewById(R.id.btnForget)
        executor = ContextCompat.getMainExecutor(this)

        requestHardwarePermissions()
        setupWebView()
        setupBiometricPrompt()

        btnFingerprint.setOnClickListener { startFingerprintUnlock() }
        btnPassword.setOnClickListener { signInWithPassword() }
        btnForget.setOnClickListener {
            CredentialVault.clear(this)
            showLock()
            toast("Fingerprint sign-in turned off")
        }

        // Lock on open: show the lock screen, then ask for fingerprint / face straight away.
        // The web site is not loaded until the user unlocks or chooses username & password.
        showLock()
        if (biometricAvailable()) startFingerprintUnlock()
    }

    private fun requestHardwarePermissions() {
        val permissions = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.MODIFY_AUDIO_SETTINGS
        )

        val neededPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (neededPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, neededPermissions.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true

            // Custom User-Agent tag to allow Web App to detect native wrapper
            userAgentString = userAgentString + " TejodharAppNative/1.1"
        }

        // Expose JavaScript Interface as "AndroidNative"
        webView.addJavascriptInterface(WebAppInterface(), "AndroidNative")

        webView.webViewClient = object : WebViewClient() {
            // Keep the site inside the app. Other links (tel:, WhatsApp, other websites) open outside.
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme ?: return false
                return when (scheme) {
                    "http", "https" -> if (isOwnHost(uri.host)) false else openExternal(uri)
                    "about", "data", "blob", "javascript" -> false
                    else -> openExternal(uri)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (view != null && isOwnUrl(url)) handleLoginPage(view)
            }
        }

        // Grant WebRTC camera & microphone permissions automatically inside WebView
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.run {
                    grant(resources)
                }
            }
        }
    }

    // Runs after every page of the Tejodhar site loads
    private fun handleLoginPage(view: WebView) {
        view.evaluateJavascript(LoginScripts.LOGIN_HOOK, null)

        // Saved login (after fingerprint unlock): fill username + password and submit
        val fill = pendingAutofill
        pendingAutofill = null
        if (fill != null) {
            autofillInFlight = true
            view.evaluateJavascript(LoginScripts.autofill(fill.user, fill.pass)) { result ->
                if (!isTrue(result)) autofillInFlight = false  // no login form on this page
            }
            return
        }

        view.evaluateJavascript(LoginScripts.PASSWORD_VISIBLE) { result ->
            val stillOnLoginForm = isTrue(result)
            if (autofillInFlight) {
                // This page came after the saved login was submitted
                autofillInFlight = false
                if (stillOnLoginForm) {
                    // Saved password was refused: drop it so the user can save the new one
                    CredentialVault.clear(this)
                    toast("Saved fingerprint login was rejected. Please sign in with your password.")
                }
                return@evaluateJavascript
            }
            if (!stillOnLoginForm) {
                // The typed login went through: offer to save it
                pendingLogin?.let { offerToSave(it) }
                pendingLogin = null
            }
        }
    }

    private fun isTrue(js: String?): Boolean = js?.trim('"') == "1"

    private fun offerToSave(creds: LoginCreds) {
        if (!strongAvailable()) return
        if (CredentialVault.savedUser(this) == creds.user) return
        if (CredentialVault.declined(this, creds.user)) return

        AlertDialog.Builder(this)
            .setTitle("Sign in with fingerprint?")
            .setMessage(
                "Save this login on this phone, locked by your fingerprint or face. " +
                    "Next time, unlock the app and you will be signed in automatically."
            )
            .setPositiveButton("Turn on") { _, _ ->
                pendingSave = creds
                startEncryptPrompt()
            }
            .setNegativeButton("Not now") { _, _ -> CredentialVault.setDeclined(this, creds.user) }
            .setOnCancelListener { CredentialVault.setDeclined(this, creds.user) }
            .show()
    }

    private fun startEncryptPrompt() {
        val cipher = try {
            CredentialVault.encryptCipher()
        } catch (e: Exception) {
            pendingSave = null
            toast("Fingerprint sign-in could not be set up on this phone.")
            return
        }
        mode = Mode.ENCRYPT
        biometricPrompt.authenticate(
            strongPromptInfo("Turn on fingerprint sign-in", "Confirm to save your login on this phone", "Not now"),
            BiometricPrompt.CryptoObject(cipher)
        )
    }

    // Lock screen "unlock" action. Uses the saved login when there is one.
    private fun startFingerprintUnlock() {
        if (!biometricAvailable()) {
            toast("Fingerprint or face unlock is not set up on this phone.")
            return
        }
        if (strongAvailable() && CredentialVault.hasSavedLogin(this)) {
            val cipher = try {
                CredentialVault.decryptCipher(this)
            } catch (e: Exception) {
                // Fingerprints or faces changed, so the key was invalidated: drop the saved login
                CredentialVault.clear(this)
                toast("Fingerprint or face settings changed. Sign in with your password once to turn it back on.")
                null
            }
            if (cipher != null) {
                mode = Mode.DECRYPT
                biometricPrompt.authenticate(
                    strongPromptInfo("Tejodhar App Unlock", "Unlock to sign in automatically", "Use username & password"),
                    BiometricPrompt.CryptoObject(cipher)
                )
                return
            }
        }
        mode = Mode.UNLOCK
        biometricPrompt.authenticate(weakPromptInfo())
    }

    // Called from the web page through AndroidNative.triggerBiometricAuth()
    private fun promptWebCheck() {
        if (!biometricAvailable()) {
            toast("Fingerprint or face unlock is not set up on this phone.")
            return
        }
        mode = Mode.WEB_CHECK
        biometricPrompt.authenticate(weakPromptInfo())
    }

    private fun setupBiometricPrompt() {
        biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    val cipher = result.cryptoObject?.cipher
                    when (mode) {
                        Mode.UNLOCK -> unlockApp(null)

                        Mode.DECRYPT -> unlockApp(cipher?.let { readSavedLogin(it) })

                        Mode.ENCRYPT -> {
                            val creds = pendingSave
                            pendingSave = null
                            if (cipher != null && creds != null) {
                                try {
                                    CredentialVault.save(this@MainActivity, cipher, creds)
                                    toast("Fingerprint sign-in is on")
                                } catch (e: Exception) {
                                    toast("Login could not be saved")
                                }
                            }
                        }

                        Mode.WEB_CHECK -> webView.evaluateJavascript(
                            "if(typeof onNativeBiometricSuccess === 'function'){ onNativeBiometricSuccess(); }",
                            null
                        )
                    }
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    if (mode == Mode.ENCRYPT) pendingSave = null
                    when (errorCode) {
                        // "Use username & password" on the unlock prompt: go to the web sign-in
                        BiometricPrompt.ERROR_NEGATIVE_BUTTON -> {
                            if (mode == Mode.UNLOCK || mode == Mode.DECRYPT) signInWithPassword()
                        }
                        // Cancelled by the user or the system: stay on the lock screen
                        BiometricPrompt.ERROR_USER_CANCELED, BiometricPrompt.ERROR_CANCELED -> Unit
                        else -> toast("Auth Error: $errString")
                    }
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    toast("Not recognised, try again")
                }
            })
    }

    private fun readSavedLogin(cipher: Cipher): LoginCreds? = try {
        CredentialVault.read(this, cipher)
    } catch (e: Exception) {
        CredentialVault.clear(this)
        null
    }

    // Shows the site. With creds, the login page is filled and submitted automatically.
    private fun unlockApp(creds: LoginCreds?, clearSession: Boolean = false) {
        unlocked = true
        pendingAutofill = creds
        autofillInFlight = false
        pendingLogin = null
        lockPanel.visibility = View.GONE
        webView.visibility = View.VISIBLE

        if (clearSession) {
            // Forget the web session so the login form shows instead of the dashboard
            CookieManager.getInstance().removeAllCookies { runOnUiThread { webView.loadUrl(TARGET_URL) } }
        } else {
            webView.loadUrl(TARGET_URL)
        }
    }

    private fun signInWithPassword() {
        unlockApp(null, clearSession = true)
    }

    private fun showLock() {
        unlocked = false
        lockPanel.visibility = View.VISIBLE
        webView.visibility = View.GONE
        btnFingerprint.visibility = if (biometricAvailable()) View.VISIBLE else View.GONE
        btnForget.visibility = if (CredentialVault.hasSavedLogin(this)) View.VISIBLE else View.GONE
    }

    private fun biometricAvailable(): Boolean =
        BiometricManager.from(this).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
        ) == BiometricManager.BIOMETRIC_SUCCESS

    private fun strongAvailable(): Boolean =
        BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
            BiometricManager.BIOMETRIC_SUCCESS

    private fun weakPromptInfo(): BiometricPrompt.PromptInfo = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Tejodhar App Unlock")
        .setSubtitle("Use fingerprint or face to unlock")
        .setNegativeButtonText("Use username & password")
        .setAllowedAuthenticators(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
        )
        .build()

    // Prompts that use a CryptoObject only accept strong biometrics
    private fun strongPromptInfo(title: String, subtitle: String, negative: String): BiometricPrompt.PromptInfo =
        BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setNegativeButtonText(negative)
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()

    private fun isOwnHost(host: String?): Boolean =
        host != null && (host == "tejodhar.in" || host.endsWith(".tejodhar.in"))

    private fun isOwnUrl(url: String?): Boolean = url != null && isOwnHost(Uri.parse(url).host)

    private fun openExternal(uri: Uri): Boolean {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            toast("No app found to open this link")
        }
        return true
    }

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        if (unlocked && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
