package com.example.colourlauncher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Windows 11 look: its blue, its mica/acrylic surfaces, and the way its buttons highlight. */
val WinBlue = Color(0xFF0078D4)

@Composable
private fun isDarkSurface(): Boolean = MaterialTheme.colorScheme.surface.luminance() < 0.5f

/** Taskbar, Start menu and flyout surface: dark #202020 or light #F3F3F3, slightly see-through. */
@Composable
fun winAcrylic(): Color =
    if (isDarkSurface()) Color(0xFF202020).copy(alpha = 0.92f) else Color(0xFFF3F3F3).copy(alpha = 0.92f)

/** Text and icon colour on those surfaces. */
@Composable
fun winInk(): Color = if (isDarkSurface()) Color.White else Color(0xFF1B1B1B)

/** Secondary text colour on those surfaces. */
@Composable
fun winSubInk(): Color = if (isDarkSurface()) Color(0xFFC5C5C5) else Color(0xFF5E5E5E)

/** Hairline around flyouts and above the taskbar. */
@Composable
fun winStroke(): Color = if (isDarkSurface()) Color.White.copy(alpha = 0.10f) else Color.Black.copy(alpha = 0.10f)

/** Fill of controls such as the search box and buttons. */
@Composable
fun winControl(): Color = if (isDarkSurface()) Color.White.copy(alpha = 0.07f) else Color.White.copy(alpha = 0.75f)

/**
 * Windows 11 button behaviour: a flat rounded highlight under the finger instead of a ripple or
 * a press-in scale.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.winButton(
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    radius: Dp = 4.dp,
    onClickLabel: String? = null,
): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val shape = RoundedCornerShape(radius)
    val hover = if (isDarkSurface()) Color.White.copy(alpha = 0.10f) else Color.Black.copy(alpha = 0.07f)
    return this
        .clip(shape)
        .background(if (pressed) hover else Color.Transparent, shape)
        .combinedClickable(
            interactionSource = source,
            indication = null,
            onClickLabel = onClickLabel,
            onClick = onClick,
            onLongClick = onLongClick,
        )
}

/** The Windows 11 logo: four blue panes in a square. */
@Composable
fun WindowsLogo(size: Dp = 20.dp) {
    val gap = 1.5.dp
    val pane = (size - gap) / 2
    val top = Color(0xFF4CC2FF)
    val bottom = Color(0xFF0078D4)
    Column(verticalArrangement = Arrangement.spacedBy(gap)) {
        repeat(2) { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                repeat(2) { col ->
                    // Panes shade from light blue (top left) to deeper blue (bottom right).
                    val mix = (row + col) / 2f
                    Column(
                        modifier = Modifier
                            .size(pane)
                            .background(
                                Color(
                                    red = top.red + (bottom.red - top.red) * mix,
                                    green = top.green + (bottom.green - top.green) * mix,
                                    blue = top.blue + (bottom.blue - top.blue) * mix,
                                ),
                                RoundedCornerShape(1.dp),
                            ),
                    ) {}
                }
            }
        }
    }
}

/**
 * Stand-in for the Windows 11 "Bloom" wallpaper: blue petals around a glowing centre, on a deep
 * blue (dark) or pale blue (light) base. It sits behind the home screen like the themed styles'
 * artwork, and picking a wallpaper in settings replaces it with the real one.
 */
@Composable
fun WindowsBloomBackdrop() {
    val dark = isDarkSurface()
    Canvas(modifier = Modifier.fillMaxSize()) {
        drawRect(
            Brush.verticalGradient(
                if (dark) listOf(Color(0xFF040B1F), Color(0xFF0A2463)) else listOf(Color(0xFFE3F0FC), Color(0xFFB4D3F5)),
            ),
        )
        val centre = Offset(size.width * 0.5f, size.height * 0.60f)
        val radius = size.minDimension * 0.62f
        val petal = if (dark) Color(0xFF2F7BF0).copy(alpha = 0.60f) else Color(0xFF4A9BFF).copy(alpha = 0.55f)
        val deep = if (dark) Color(0xFF0F3FA8).copy(alpha = 0.55f) else Color(0xFF2B73E0).copy(alpha = 0.40f)
        for (i in 0 until 8) {
            rotate(degrees = i * 45f, pivot = centre) {
                drawOval(
                    brush = Brush.radialGradient(
                        colors = listOf(if (i % 2 == 0) petal else deep, Color.Transparent),
                        center = Offset(centre.x, centre.y - radius * 0.5f),
                        radius = radius * 0.55f,
                    ),
                    topLeft = Offset(centre.x - radius * 0.30f, centre.y - radius),
                    size = Size(radius * 0.60f, radius * 0.95f),
                )
            }
        }
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = if (dark) 0.30f else 0.70f), Color.Transparent),
                center = centre,
                radius = radius * 0.45f,
            ),
            radius = radius * 0.45f,
            center = centre,
        )
    }
}
