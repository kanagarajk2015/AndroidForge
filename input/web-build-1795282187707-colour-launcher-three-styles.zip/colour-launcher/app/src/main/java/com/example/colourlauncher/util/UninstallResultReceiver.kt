package com.example.colourlauncher.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.widget.Toast
import com.example.colourlauncher.R

/**
 * Receives the outcome of [uninstallPackage] from the package installer.
 *
 * When the system needs the user to confirm, the confirmation screen comes in [Intent.EXTRA_INTENT]
 * and is opened here. A successful uninstall needs no handling: the package-removed broadcast
 * already reloads the app list.
 */
class UninstallResultReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(confirm)
                }
            }
            PackageInstaller.STATUS_SUCCESS -> Unit
            else -> Toast.makeText(context, R.string.uninstall_failed, Toast.LENGTH_SHORT).show()
        }
    }
}
