package com.example.colourlauncher.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Saves the home pages, the folders and the dock.
 *
 * A home page is a list of cells in reading order. A cell holds a package name, a folder token
 * (see [folderToken]) or null for an empty cell. Layouts saved before pages existed kept a single
 * page under the "home" key, and they still load. The dock is a plain ordered list of packages.
 */
class LayoutStore(context: Context) {

    private val prefs = context.getSharedPreferences("layout", Context.MODE_PRIVATE)

    /** Null until the user's layout has been saved, so callers can apply defaults. */
    fun loadPages(): List<List<String?>>? {
        val raw = prefs.getString(KEY_PAGES, null) ?: return readCells(KEY_HOME)?.let { listOf(it) }
        return runCatching {
            val pages = JSONArray(raw)
            List(pages.length()) { cellsOf(pages.getJSONArray(it)) }
        }.getOrNull()
    }

    fun savePages(pages: List<List<String?>>) {
        val outer = JSONArray()
        pages.forEach { page ->
            val inner = JSONArray()
            page.forEach { inner.put(it ?: JSONObject.NULL) }
            outer.put(inner)
        }
        prefs.edit().putString(KEY_PAGES, outer.toString()).apply()
    }

    /** Folders keyed by id. Missing or corrupt data gives no folders. */
    fun loadFolders(): Map<String, HomeFolder> {
        val raw = prefs.getString(KEY_FOLDERS, null) ?: return emptyMap()
        return runCatching {
            val obj = JSONObject(raw)
            val folders = LinkedHashMap<String, HomeFolder>()
            val ids = obj.keys()
            while (ids.hasNext()) {
                val id = ids.next()
                val folder = obj.getJSONObject(id)
                val apps = folder.getJSONArray("apps")
                folders[id] = HomeFolder(
                    id = id,
                    name = folder.optString("name"),
                    packages = List(apps.length()) { apps.getString(it) },
                )
            }
            folders
        }.getOrNull() ?: emptyMap()
    }

    fun saveFolders(folders: Map<String, HomeFolder>) {
        val obj = JSONObject()
        folders.values.forEach { folder ->
            obj.put(folder.id, JSONObject().put("name", folder.name).put("apps", JSONArray(folder.packages)))
        }
        prefs.edit().putString(KEY_FOLDERS, obj.toString()).apply()
    }

    fun loadDock(): List<String>? {
        val raw = prefs.getString(KEY_DOCK, null) ?: return null
        return runCatching {
            val array = JSONArray(raw)
            List(array.length()) { array.getString(it) }
        }.getOrNull()
    }

    fun saveDock(packages: List<String>) {
        prefs.edit().putString(KEY_DOCK, JSONArray(packages).toString()).apply()
    }

    /** Reads a single-page cell list from the old format. */
    private fun readCells(key: String): List<String?>? {
        val raw = prefs.getString(key, null) ?: return null
        return runCatching { cellsOf(JSONArray(raw)) }.getOrNull()
    }

    /** JSON null entries come back as null cells. */
    private fun cellsOf(array: JSONArray): List<String?> =
        List(array.length()) { index -> if (array.isNull(index)) null else array.getString(index) }

    private companion object {
        const val KEY_PAGES = "pages"
        const val KEY_FOLDERS = "folders"
        const val KEY_HOME = "home"
        const val KEY_DOCK = "dock"
    }
}
