package com.example.colourlauncher.util

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.widget.Toast
import com.example.colourlauncher.R
import com.example.colourlauncher.data.AiKeyAction
import com.example.colourlauncher.service.AiKeyService

/** Back-camera torch that remembers whether it is on, so one call toggles it. */
object Torch {
    private var id: String? = null
    private var on = false
    private var registered = false

    /** Returns false if this phone has no usable torch. */
    fun toggle(context: Context): Boolean {
        val manager = context.applicationContext.getSystemService(CameraManager::class.java)
        if (!registered) {
            registered = true
            id = runCatching {
                manager.cameraIdList.firstOrNull { cam ->
                    val c = manager.getCameraCharacteristics(cam)
                    c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                        c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                }
            }.getOrNull()
            manager.registerTorchCallback(
                object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                        if (cameraId == id) on = enabled
                    }
                },
                Handler(Looper.getMainLooper()),
            )
        }
        val torch = id ?: return false
        return runCatching { manager.setTorchMode(torch, !on) }.isSuccess
    }
}

/**
 * Runs one AI key action. Flashlight, open app and play/pause work from anywhere. The rest
 * (screenshot, notifications, quick settings, lock screen, recents, home) are system-wide
 * gestures that Android only lets an enabled accessibility service perform.
 */
fun Context.runAiKeyAction(action: AiKeyAction, appPackage: String) {
    when (action) {
        AiKeyAction.DoNothing -> Unit
        AiKeyAction.Flashlight -> if (!Torch.toggle(this)) toast(R.string.ai_key_unsupported)
        AiKeyAction.OpenApp -> if (appPackage.isBlank()) toast(R.string.ai_key_no_app) else launchPackage(appPackage)
        AiKeyAction.PlayPause -> {
            val audio = getSystemService(AudioManager::class.java)
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
        }
        else -> {
            val service = AiKeyService.instance
            if (service == null) toast(R.string.ai_key_needs_service) else service.performSystemAction(action)
        }
    }
}

private fun Context.toast(message: Int) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
