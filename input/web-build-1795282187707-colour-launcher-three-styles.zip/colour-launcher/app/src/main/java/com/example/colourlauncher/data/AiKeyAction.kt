package com.example.colourlauncher.data

/** What one gesture of the hardware AI key does while the launcher's override is on. */
enum class AiKeyAction {
    DoNothing,
    Flashlight,
    Screenshot,
    OpenApp,
    PlayPause,
    Notifications,
    QuickSettings,
    LockScreen,
    Recents,
    Home,
}
