package com.example.colourlauncher.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.KeyEvent
import android.view.ViewConfiguration
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import com.example.colourlauncher.R
import com.example.colourlauncher.data.AiKeyAction
import com.example.colourlauncher.data.LauncherSettings
import com.example.colourlauncher.data.SettingsStore
import com.example.colourlauncher.util.runAiKeyAction

/**
 * Takes over the hardware AI key while the launcher's override is on.
 *
 * A normal app cannot see hardware keys, so this is an accessibility service that filters key
 * events. It only looks at the one key the user taught it ("Set AI key" in settings) and
 * consumes that key, so the system's own AI key action no longer runs. Every other key is
 * left alone. It reads no screen content.
 *
 * Gestures: single press, double press, and long press, each with its own [AiKeyAction].
 */
class AiKeyService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var settings = LauncherSettings()
    private var longFired = false
    private var pendingSingle: Runnable? = null
    private var swallowUpFor = -1

    private val longPress = Runnable {
        longFired = true
        perform(settings.aiKeyLong)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Learning mode: the next non-system key press is remembered as the AI key.
        val learn = learnCallback
        if (learn != null && event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && !event.isReserved()) {
            learnCallback = null
            swallowUpFor = event.keyCode
            learn(event.keyCode, event.scanCode)
            return true
        }
        if (event.action == KeyEvent.ACTION_UP && swallowUpFor != -1 && event.keyCode == swallowUpFor) {
            swallowUpFor = -1
            return true
        }

        settings = SettingsStore(this).load()
        if (!settings.aiKeyOverride || !event.isAiKey(settings)) return false

        when (event.action) {
            KeyEvent.ACTION_DOWN -> if (event.repeatCount == 0) {
                longFired = false
                handler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
            }
            KeyEvent.ACTION_UP -> {
                handler.removeCallbacks(longPress)
                if (!longFired) onTap()
            }
        }
        return true
    }

    private fun onTap() {
        // With no double-press action there is nothing to wait for: act at once.
        if (settings.aiKeyDouble == AiKeyAction.DoNothing) {
            perform(settings.aiKeySingle)
            return
        }
        val waiting = pendingSingle
        if (waiting != null) {
            handler.removeCallbacks(waiting)
            pendingSingle = null
            perform(settings.aiKeyDouble)
            return
        }
        val single = Runnable {
            pendingSingle = null
            perform(settings.aiKeySingle)
        }
        pendingSingle = single
        handler.postDelayed(single, ViewConfiguration.getDoubleTapTimeout().toLong())
    }

    private fun perform(action: AiKeyAction) = runAiKeyAction(action, settings.aiKeyApp)

    /** System-wide actions that only an accessibility service may perform. */
    fun performSystemAction(action: AiKeyAction) {
        when (action) {
            AiKeyAction.Screenshot -> global(GLOBAL_ACTION_TAKE_SCREENSHOT, Build.VERSION_CODES.P)
            AiKeyAction.Notifications -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            AiKeyAction.QuickSettings -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            AiKeyAction.LockScreen -> global(GLOBAL_ACTION_LOCK_SCREEN, Build.VERSION_CODES.P)
            AiKeyAction.Recents -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            AiKeyAction.Home -> performGlobalAction(GLOBAL_ACTION_HOME)
            else -> Unit
        }
    }

    /** Runs a global action that needs [minSdk] or newer, with a message on older Android. */
    private fun global(action: Int, minSdk: Int) {
        if (Build.VERSION.SDK_INT >= minSdk) {
            performGlobalAction(action)
        } else {
            Toast.makeText(this, R.string.ai_key_unsupported, Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        /** The running service, or null while it is off. */
        @Volatile
        var instance: AiKeyService? = null

        /**
         * Set while the settings screen is waiting for the user to press the AI key. Called once
         * with the key code and scan code of the next key press, then cleared.
         */
        @Volatile
        var learnCallback: ((keyCode: Int, scanCode: Int) -> Unit)? = null

        /** True when the user has switched this service on in Accessibility settings. */
        fun isEnabled(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
            ) ?: return false
            val me = "${context.packageName}/${AiKeyService::class.java.name}"
            val splitter = TextUtils.SimpleStringSplitter(':').apply { setString(enabled) }
            while (splitter.hasNext()) {
                if (splitter.next().equals(me, ignoreCase = true)) return true
            }
            return false
        }
    }
}

/** Keys the user must not be able to learn as the AI key, so they cannot lock themselves out. */
private fun KeyEvent.isReserved(): Boolean = keyCode in setOf(
    KeyEvent.KEYCODE_VOLUME_UP,
    KeyEvent.KEYCODE_VOLUME_DOWN,
    KeyEvent.KEYCODE_VOLUME_MUTE,
    KeyEvent.KEYCODE_POWER,
    KeyEvent.KEYCODE_HOME,
    KeyEvent.KEYCODE_BACK,
    KeyEvent.KEYCODE_APP_SWITCH,
)

/** True if this event is the key the user taught the launcher. */
private fun KeyEvent.isAiKey(s: LauncherSettings): Boolean {
    val learned = s.aiKeyCode != 0 || s.aiKeyScanCode != 0
    return learned && keyCode == s.aiKeyCode && (s.aiKeyScanCode == 0 || scanCode == s.aiKeyScanCode)
}
