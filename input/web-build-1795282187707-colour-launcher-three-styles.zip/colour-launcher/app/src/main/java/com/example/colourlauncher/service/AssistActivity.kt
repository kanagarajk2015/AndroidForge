package com.example.colourlauncher.service

import android.app.Activity
import android.os.Bundle
import com.example.colourlauncher.data.SettingsStore
import com.example.colourlauncher.util.runAiKeyAction

/**
 * Fallback that needs no accessibility service. If the user picks Colour Launcher as the phone's
 * digital assistant, an AI key press that asks the system for the assistant ends up here, and
 * the single-press action runs. It has no screen: it runs the action and closes at once.
 */
class AssistActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val settings = SettingsStore(this).load()
        if (settings.aiKeyOverride) runAiKeyAction(settings.aiKeySingle, settings.aiKeyApp)
        finish()
    }
}
