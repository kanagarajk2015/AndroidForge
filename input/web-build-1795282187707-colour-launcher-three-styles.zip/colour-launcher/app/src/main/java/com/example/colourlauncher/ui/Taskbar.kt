package com.example.colourlauncher.ui

import android.text.format.DateFormat
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherApp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import kotlinx.coroutines.delay

/** Height of the Windows 11 taskbar, not counting the system navigation bar. */
val TaskbarHeight: Dp = 48.dp

@Composable
private fun rememberNow(): State<LocalDateTime> = produceState(initialValue = LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(10_000L)
    }
}

/**
 * Windows 11 taskbar: a flat full-width bar with a hairline on top. The Start button, search and
 * the dock apps sit in the middle, and the system tray (Wi-Fi, volume, battery, then the clock
 * and date) on the right. The tray opens the quick settings flyout. Apps opened from the
 * launcher in this session get the short accent bar under their icon that Windows shows for
 * running apps.
 */
@Composable
fun Taskbar(
    apps: List<LauncherApp>,
    runningPackages: Set<String>,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    onStart: () -> Unit,
    onOpenControls: () -> Unit,
) {
    val now by rememberNow()
    val context = LocalContext.current
    val is24 = DateFormat.is24HourFormat(context)
    val timeFormat = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a") }
    val dateFormat = remember { DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT) }
    val ink = winInk()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(winAcrylic())
            .navigationBarsPadding(),
    ) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(winStroke()))
        BoxWithConstraints(modifier = Modifier.fillMaxWidth().height(TaskbarHeight - 1.dp)) {
            // Narrow phones only have room for the clock in the tray.
            val showTrayIcons = maxWidth >= 400.dp
            Row(
                modifier = Modifier.fillMaxWidth().height(TaskbarHeight - 1.dp).padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TaskbarButton(onClick = onStart, label = stringResource(R.string.start_menu)) {
                        WindowsLogo(20.dp)
                    }
                    TaskbarButton(onClick = onStart, label = stringResource(R.string.start_search)) {
                        Icon(Icons.Filled.Search, contentDescription = null, tint = ink, modifier = Modifier.size(20.dp))
                    }
                    apps.forEach { app ->
                        TaskbarButton(
                            onClick = { onLaunch(app.packageName) },
                            onLongClick = { onLongPress(app) },
                            label = app.label,
                            running = app.packageName in runningPackages,
                        ) {
                            Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(24.dp))
                        }
                    }
                }

                // System tray: tapping it opens the quick settings flyout.
                Row(
                    modifier = Modifier
                        .winButton(onClick = onOpenControls, onClickLabel = stringResource(R.string.controls_title))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (showTrayIcons) {
                        Icon(Icons.Filled.Wifi, contentDescription = null, tint = ink, modifier = Modifier.size(16.dp))
                        Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, tint = ink, modifier = Modifier.size(16.dp))
                        Icon(Icons.Filled.BatteryFull, contentDescription = null, tint = ink, modifier = Modifier.size(16.dp))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = now.format(timeFormat),
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp, lineHeight = 14.sp),
                            color = ink,
                            textAlign = TextAlign.End,
                        )
                        Text(
                            text = now.format(dateFormat),
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp, lineHeight = 14.sp),
                            color = ink,
                            textAlign = TextAlign.End,
                        )
                    }
                }
            }
        }
    }
}

/** One 40 dp taskbar button with the Windows 11 highlight and, for a running app, an accent bar. */
@Composable
private fun TaskbarButton(
    onClick: () -> Unit,
    label: String,
    onLongClick: (() -> Unit)? = null,
    running: Boolean = false,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(width = 44.dp, height = 40.dp)
            .winButton(onClick = onClick, onLongClick = onLongClick, onClickLabel = label)
            .then(if (running) Modifier.background(winInk().copy(alpha = 0.06f)) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        content()
        if (running) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 2.dp)
                    .size(width = 16.dp, height = 3.dp)
                    .clip(CircleShape)
                    .background(WinBlue),
            )
        }
    }
}
