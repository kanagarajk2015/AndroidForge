package com.example.colourlauncher.ui.theme

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.data.Accent
import com.example.colourlauncher.data.LauncherSettings
import com.example.colourlauncher.data.ThemeMode

/** AquaOS palette: cool cyan highlights, deep navy surfaces and soft blue glass tones. */
private fun Accent.seed(): Color = when (this) {
    Accent.Wallpaper, Accent.Blue -> Color(0xFF55C8F5)
    Accent.Green -> Color(0xFF39C6A5)
    Accent.Pink -> Color(0xFFFF78B7)
    Accent.Orange -> Color(0xFFFFB36B)
    Accent.Fluent -> Color(0xFF72AFFF)
}

private fun aquaDarkScheme(seed: Color): ColorScheme = darkColorScheme(
    primary = seed,
    onPrimary = Color(0xFF00212B),
    primaryContainer = Color(0xFF124A60),
    onPrimaryContainer = Color(0xFFD0F4FF),
    secondary = Color(0xFFB6C8FF),
    onSecondary = Color(0xFF17264A),
    secondaryContainer = Color(0xFF293B66),
    onSecondaryContainer = Color(0xFFDCE3FF),
    tertiary = Color(0xFFB9C7FF),
    background = Color(0xFF071426),
    onBackground = Color(0xFFEAF4FF),
    surface = Color(0xFF0C1D32),
    onSurface = Color(0xFFEAF4FF),
    surfaceVariant = Color(0xFF20364F),
    onSurfaceVariant = Color(0xFFC0D2E6),
    surfaceContainer = Color(0xFF10243B),
    surfaceContainerHigh = Color(0xFF18304A),
    surfaceContainerHighest = Color(0xFF213B57),
    outline = Color(0xFF66839E),
    outlineVariant = Color(0xFF314A64),
)

/** Light scheme: the accent is darkened so white labels stay readable on it. */
private fun aquaLightScheme(seed: Color): ColorScheme = lightColorScheme(
    primary = lerp(seed, Color.Black, 0.4f),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC7F0FF),
    onPrimaryContainer = Color(0xFF003545),
    secondary = Color(0xFF52658E),
    background = Color(0xFFF2F8FF),
    onBackground = Color(0xFF101C2B),
    surface = Color(0xFFF8FBFF),
    onSurface = Color(0xFF101C2B),
    surfaceVariant = Color(0xFFDCE9F5),
    onSurfaceVariant = Color(0xFF40566D),
    surfaceContainer = Color(0xFFEAF3FC),
    surfaceContainerHigh = Color(0xFFE2EEF9),
    surfaceContainerHighest = Color(0xFFD7E7F5),
    outline = Color(0xFF71879C),
    outlineVariant = Color(0xFFBDCDDC),
)

/** Material 3 theme for the launcher's surfaces. Wallpaper colours remain an optional accent. */
@Composable
fun ColourLauncherTheme(settings: LauncherSettings, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val dark = when (settings.themeMode) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Light -> false
        ThemeMode.Dark -> true
    }
    val useWallpaper = settings.accent == Accent.Wallpaper && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val scheme: ColorScheme = when {
        useWallpaper && dark -> dynamicDarkColorScheme(context)
        useWallpaper -> dynamicLightColorScheme(context)
        dark -> aquaDarkScheme(settings.accent.seed())
        else -> aquaLightScheme(settings.accent.seed())
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

/** True when the current colour scheme is dark. */
@Composable
private fun isDarkScheme(): Boolean = MaterialTheme.colorScheme.surface.luminance() < 0.5f

/**
 * Fill for frosted aqua glass surfaces: a translucent tint of the scheme's raised surface.
 * Use it as the container colour of sheets that should let the wallpaper show through.
 */
@Composable
fun aquaGlassFill(): Color {
    val alpha = if (isDarkScheme()) 0.74f else 0.86f
    return MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = alpha)
}

/**
 * Frosted aqua glass panel: a translucent fill, a soft accent sheen from the top, and a thin
 * rim that fades toward the bottom. The wallpaper shows through the fill. This is not a live
 * blur of what sits behind the panel.
 */
@Composable
fun Modifier.aquaGlass(shape: Shape): Modifier {
    val rimAlpha = if (isDarkScheme()) 0.26f else 0.9f
    val rim = Color.White.copy(alpha = rimAlpha)
    val sheen = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
    return this
        .clip(shape)
        .background(aquaGlassFill(), shape)
        .background(Brush.verticalGradient(listOf(sheen, Color.Transparent)), shape)
        .border(1.dp, Brush.verticalGradient(listOf(rim, rim.copy(alpha = 0.06f))), shape)
}
