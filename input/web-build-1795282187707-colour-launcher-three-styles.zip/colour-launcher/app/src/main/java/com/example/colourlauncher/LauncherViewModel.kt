package com.example.colourlauncher

import android.app.Application
import android.provider.Telephony
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.colourlauncher.data.AppRepository
import com.example.colourlauncher.data.HomeFolder
import com.example.colourlauncher.data.IconPackInfo
import com.example.colourlauncher.data.IconPackRepository
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.data.LauncherSettings
import com.example.colourlauncher.data.LayoutStore
import com.example.colourlauncher.data.SettingsStore
import com.example.colourlauncher.data.folderIdOf
import com.example.colourlauncher.data.folderToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

/** Maximum number of apps shown in the dock. */
const val DOCK_CAPACITY = 4

/** Number of apps placed on the first home page before the user has arranged it. */
private const val DEFAULT_HOME_SIZE = 16

/** Package names that can fill each default dock slot, most likely first. Missing ones are skipped. */
private val DOCK_PHONE = listOf(
    "com.google.android.dialer", "com.samsung.android.dialer", "com.android.dialer",
    "com.oneplus.dialer", "com.oplus.dialer",
)
private val DOCK_MESSAGES = listOf(
    "com.google.android.apps.messaging", "com.samsung.android.messaging",
    "com.android.messaging", "com.android.mms",
)
private val DOCK_CAMERA = listOf(
    "com.google.android.GoogleCamera", "com.sec.android.app.camera", "com.android.camera2",
    "com.android.camera", "com.oneplus.camera", "com.oplus.camera", "com.miui.camera",
)
private val DOCK_WHATSAPP = listOf("com.whatsapp", "com.whatsapp.w4b")

/** Longest folder name kept. Longer names are cut short. */
private const val MAX_FOLDER_NAME = 32

/**
 * Holds the installed apps and the user's home pages, folders and dock.
 *
 * Each home page is a list of cells in reading order. A cell holds an app's package name, a
 * folder token (see [folderToken]) or null for an empty cell. An app sits in at most one place:
 * a home cell or one folder.
 */
class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val layoutStore = LayoutStore(application)
    private val settingsStore = SettingsStore(application)
    private val iconPackRepository = IconPackRepository(application)

    private val _apps = MutableStateFlow<List<LauncherApp>>(emptyList())
    val apps: StateFlow<List<LauncherApp>> = _apps.asStateFlow()

    /** Home pages, left to right. The list is never empty, and only the first page may be empty. */
    private val _pages = MutableStateFlow<List<List<String?>>>(listOf(emptyList<String?>()))
    val pages: StateFlow<List<List<String?>>> = _pages.asStateFlow()

    /** Folders on the home screen, keyed by id. */
    private val _folders = MutableStateFlow<Map<String, HomeFolder>>(emptyMap())
    val folders: StateFlow<Map<String, HomeFolder>> = _folders.asStateFlow()

    /** Package names in the dock, in display order. */
    private val _dock = MutableStateFlow<List<String>>(emptyList())
    val dock: StateFlow<List<String>> = _dock.asStateFlow()

    private val _settings = MutableStateFlow(settingsStore.load())
    val settings: StateFlow<LauncherSettings> = _settings.asStateFlow()

    private val _iconPacks = MutableStateFlow<List<IconPackInfo>>(emptyList())
    val iconPacks: StateFlow<List<IconPackInfo>> = _iconPacks.asStateFlow()

    init {
        reload()
    }

    /**
     * Re-reads the installed apps and reconciles the saved layout with them.
     * Runs on start and whenever a package is added, removed or updated.
     */
    fun reload() {
        viewModelScope.launch {
            _iconPacks.value = withContext(Dispatchers.IO) { iconPackRepository.findPacks() }
            val installed = repository.loadLauncherApps(_settings.value.iconPack)
            if (installed.isEmpty()) return@launch
            _apps.value = installed

            val installedPackages = installed.map { it.packageName }
            val installedSet = installedPackages.toSet()
            val dockPackages = (layoutStore.loadDock() ?: defaultDock(installedPackages))
                .filter { it in installedSet }
                .take(DOCK_CAPACITY)
            val savedPages = layoutStore.loadPages()
                ?: listOf(installedPackages.filterNot { it in dockPackages }.take(DEFAULT_HOME_SIZE))
            val (pages, folders) = reconcile(savedPages, layoutStore.loadFolders(), installedSet)

            _dock.value = dockPackages
            _pages.value = pages.tidied()
            _folders.value = folders
            layoutStore.saveDock(dockPackages)
            layoutStore.savePages(_pages.value)
            layoutStore.saveFolders(folders)
        }
    }

    /**
     * The dock for a fresh install: phone, messages, camera and WhatsApp, in that order. Each slot
     * takes the first installed app from its candidates. A slot with no match is filled from the
     * other installed apps.
     */
    private fun defaultDock(installed: List<String>): List<String> {
        val present = installed.toSet()
        val messages = Telephony.Sms.getDefaultSmsPackage(getApplication<Application>())
        val picks = listOf(
            DOCK_PHONE,
            listOfNotNull(messages) + DOCK_MESSAGES,
            DOCK_CAMERA,
            DOCK_WHATSAPP,
        ).mapNotNull { candidates -> candidates.firstOrNull { it in present } }
        return (picks + installed.filterNot { it in picks }).take(DOCK_CAPACITY)
    }

    fun updateSettings(change: (LauncherSettings) -> LauncherSettings) {
        val old = _settings.value
        _settings.value = change(old)
        settingsStore.save(_settings.value)
        if (_settings.value.iconPack != old.iconPack) reload()
        // Cell positions depend on the column count, so changing it packs the icons again.
        if (_settings.value.columns != old.columns) packPages()
    }

    /** Puts the app in the first empty cell of any page, or after the last icon. Does nothing if it is placed. */
    fun addToHome(packageName: String) {
        if (isPlaced(packageName)) return
        commit(_pages.value.placeFirstFree(packageName), _folders.value)
    }

    /** Removes the app from the home screen and leaves its cell empty. */
    fun removeFromHome(packageName: String) {
        val pages = _pages.value.map { page -> page.map { if (it == packageName) null else it } }
        commit(pages, _folders.value)
    }

    /** Closes the gaps on every page: icons keep their current order and move up. */
    fun autoArrangeHome() {
        if (_settings.value.lockHome) return
        packPages()
    }

    /**
     * Drops the home cell [token] onto [slot] of [page]. An empty cell takes it, an occupied cell
     * swaps places with it, and an app dropped onto a folder joins that folder. Ignored if the
     * layout is locked. Icons don't move between pages this way.
     */
    fun dropHome(page: Int, token: String, slot: Int) {
        if (_settings.value.lockHome || slot < 0) return
        val cells = _pages.value.getOrNull(page)?.toMutableList() ?: return
        val from = cells.indexOf(token)
        if (from < 0 || from == slot) return

        val folders = _folders.value.toMutableMap()
        val targetFolder = folderIdOf(cells.getOrNull(slot))
            ?.takeIf { folderIdOf(token) == null && it in folders }
        if (targetFolder != null) {
            cells[from] = null
            val folder = folders.getValue(targetFolder)
            folders[targetFolder] = folder.copy(packages = folder.packages + token)
        } else {
            while (cells.size <= slot) cells.add(null)
            val displaced = cells[slot]
            cells[slot] = token
            cells[from] = displaced
        }
        commit(_pages.value.replaced(page, cells), folders, tidy = false)
    }

    /** Adds an empty page at the end. */
    fun addPage() {
        commit(_pages.value + listOf(emptyList<String?>()), _folders.value, tidy = false)
    }

    /** Moves a home icon to the page [delta] away (-1 or +1). Moving past the last page adds one. */
    fun moveToPage(packageName: String, delta: Int) {
        val (page, index) = findHomeCell(packageName) ?: return
        val target = page + delta
        if (target < 0) return
        val base = if (target >= _pages.value.size) {
            _pages.value + listOf(emptyList<String?>())
        } else {
            _pages.value
        }
        val cleared = base.replaced(page, base[page].toMutableList().also { it[index] = null })
        commit(cleared.replaced(target, cleared[target].withFirstFree(packageName)), _folders.value)
    }

    /** Creates a folder holding [packageName]. A home icon becomes the folder in its own cell. */
    fun createFolder(packageName: String) {
        val id = UUID.randomUUID().toString()
        val name = getApplication<Application>().getString(R.string.folder_default_name, _folders.value.size + 1)
        val home = findHomeCell(packageName)
        val (pages, folders) = detached(packageName)
        val withFolder = if (home != null) {
            val (page, index) = home
            pages.replaced(page, pages[page].toMutableList().also { it[index] = folderToken(id) })
        } else {
            pages.placeFirstFree(folderToken(id))
        }
        commit(withFolder, folders + (id to HomeFolder(id, name, listOf(packageName))))
    }

    /** Moves [packageName] into the folder [folderId], taking it off the home screen if it was there. */
    fun addToFolder(packageName: String, folderId: String) {
        val target = _folders.value[folderId] ?: return
        if (packageName in target.packages) return
        val (pages, folders) = detached(packageName)
        val updated = folders[folderId] ?: return
        commit(pages, folders + (folderId to updated.copy(packages = updated.packages + packageName)))
    }

    /** Takes [packageName] out of its folder and puts it on the first free home cell. */
    fun removeFromFolder(packageName: String) {
        val (pages, folders) = detached(packageName)
        commit(pages.placeFirstFree(packageName), folders)
    }

    fun renameFolder(folderId: String, name: String) {
        val folder = _folders.value[folderId] ?: return
        val renamed = folder.copy(name = name.take(MAX_FOLDER_NAME))
        commit(_pages.value, _folders.value + (folderId to renamed), tidy = false)
    }

    /** Deletes a folder. Its apps go back onto the home screen. */
    fun deleteFolder(folderId: String) {
        val folder = _folders.value[folderId] ?: return
        var pages = _pages.value.map { page -> page.map { if (folderIdOf(it) == folderId) null else it } }
        folder.packages.forEach { pages = pages.placeFirstFree(it) }
        commit(pages, _folders.value - folderId)
    }

    /** Returns false if the dock is full or the app is already docked. */
    fun addToDock(packageName: String): Boolean {
        val current = _dock.value
        if (packageName in current || current.size >= DOCK_CAPACITY) return false
        updateDock(current + packageName)
        return true
    }

    fun removeFromDock(packageName: String) = updateDock(_dock.value - packageName)

    private fun isPlaced(packageName: String): Boolean =
        _pages.value.any { packageName in it } || _folders.value.values.any { packageName in it.packages }

    private fun findHomeCell(packageName: String): Pair<Int, Int>? {
        _pages.value.forEachIndexed { page, cells ->
            val index = cells.indexOf(packageName)
            if (index >= 0) return Pair(page, index)
        }
        return null
    }

    /**
     * The pages and folders with [packageName] taken off the home screen and out of its folder.
     * Folders left empty are removed, along with their cells. Pages are not tidied here, so the
     * caller can still place the app at the position it came from.
     */
    private fun detached(packageName: String): Pair<List<List<String?>>, Map<String, HomeFolder>> {
        val pages = _pages.value.map { page -> page.map { if (it == packageName) null else it } }
        val folders = _folders.value.mapValues { (_, folder) ->
            folder.copy(packages = folder.packages - packageName)
        }
        val emptied = folders.filterValues { it.packages.isEmpty() }.keys
        if (emptied.isEmpty()) return pages to folders
        val cleared = pages.map { page -> page.map { if (isFolderIn(it, emptied)) null else it } }
        return cleared to (folders - emptied)
    }

    private fun isFolderIn(cell: String?, folderIds: Set<String>): Boolean {
        val id = folderIdOf(cell) ?: return false
        return id in folderIds
    }

    /** Closes the gaps on every page. */
    private fun packPages() {
        commit(_pages.value.map { page -> page.filterNotNull() }, _folders.value)
    }

    /** Publishes and saves the layout. Empty pages at the end are dropped unless [tidy] is false. */
    private fun commit(
        pages: List<List<String?>>,
        folders: Map<String, HomeFolder>,
        tidy: Boolean = true,
    ) {
        val result = if (tidy) pages.tidied() else pages
        _pages.value = result
        _folders.value = folders
        layoutStore.savePages(result)
        layoutStore.saveFolders(folders)
    }

    private fun updateDock(packages: List<String>) {
        _dock.value = packages
        layoutStore.saveDock(packages)
    }

    /**
     * Brings saved pages and folders in line with the installed apps. Uninstalled apps leave an
     * empty cell behind, an app appears only once, and folders that sit on no page are dropped.
     */
    private fun reconcile(
        savedPages: List<List<String?>>,
        savedFolders: Map<String, HomeFolder>,
        installed: Set<String>,
    ): Pair<List<List<String?>>, Map<String, HomeFolder>> {
        val placedFolderIds = savedPages.flatten().mapNotNull { folderIdOf(it) }.toSet()
        val claimed = HashSet<String>()
        val folders = LinkedHashMap<String, HomeFolder>()
        for ((id, folder) in savedFolders) {
            if (id !in placedFolderIds) continue
            val kept = folder.packages.filter { it in installed && claimed.add(it) }
            if (kept.isNotEmpty()) folders[id] = folder.copy(packages = kept)
        }

        val seen = HashSet<String>()
        val pages = savedPages.map { page ->
            page.map { cell ->
                val folderId = folderIdOf(cell)
                val usable = cell != null && seen.add(cell) && (
                    if (folderId != null) folderId in folders else cell in installed && cell !in claimed
                )
                if (usable) cell else null
            }
        }
        return pages to folders
    }

    /** Puts [token] in the first empty cell of the first page that has one, else after the last icon of the last page. */
    private fun List<List<String?>>.placeFirstFree(token: String): List<List<String?>> {
        if (isEmpty()) return listOf(listOf(token))
        val page = indexOfFirst { it.contains(null) }
        return if (page >= 0) {
            replaced(page, this[page].withFirstFree(token))
        } else {
            replaced(lastIndex, this[lastIndex] + token)
        }
    }

    private fun List<String?>.withFirstFree(token: String): List<String?> {
        val index = indexOf(null)
        return if (index >= 0) toMutableList().also { it[index] = token } else this + token
    }

    private fun List<List<String?>>.replaced(index: Int, page: List<String?>): List<List<String?>> =
        mapIndexed { i, old -> if (i == index) page else old }

    /** Drops empty cells after each page's last icon, and empty pages at the end. Keeps at least one page. */
    private fun List<List<String?>>.tidied(): List<List<String?>> {
        val pages = map { page -> page.dropLastWhile { it == null } }.toMutableList()
        while (pages.size > 1 && pages.last().isEmpty()) pages.removeAt(pages.lastIndex)
        return if (pages.isEmpty()) listOf(emptyList<String?>()) else pages
    }
}
