package com.example.colourlauncher.data

/**
 * A folder on the home screen. [packages] are its apps in display order.
 *
 * A folder takes one home cell. That cell holds [folderToken] instead of a package name, so
 * folders and app icons share the same cell list. Package names never contain ':', so a token
 * can't be mistaken for an app.
 */
data class HomeFolder(val id: String, val name: String, val packages: List<String>)

private const val FolderPrefix = "folder:"

/** The cell value that stands for the folder with [id]. */
fun folderToken(id: String): String = FolderPrefix + id

/** The folder id a home cell holds, or null if the cell holds an app or is empty. */
fun folderIdOf(cell: String?): String? =
    cell?.takeIf { it.startsWith(FolderPrefix) }?.removePrefix(FolderPrefix)
