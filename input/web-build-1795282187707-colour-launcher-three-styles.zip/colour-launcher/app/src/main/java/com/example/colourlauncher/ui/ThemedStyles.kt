package com.example.colourlauncher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherStyle
import com.example.colourlauncher.ui.theme.aquaGlass
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

// Midnight Circles is original artwork with fixed colours, so the accent setting does not change it.

private val MidnightText = Color(0xFFBFD9FF)
private val TimeOnlyFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val LongDateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM")

/**
 * Panel behind the dock. Midnight Circles has none: its icons float on the navy glow. The other
 * styles keep the frosted glass panel. OxygenOS has no panel, and [DockBar] does not call this for it.
 */
@Composable
fun Modifier.themedDockPanel(style: LauncherStyle, shape: Shape): Modifier = when (style) {
    LauncherStyle.MidnightCircles -> this
    else -> this.aquaGlass(shape)
}

/** The navy artwork behind the home screen for Midnight Circles. It replaces the wallpaper there. */
@Composable
fun ThemedBackdrop() {
    Canvas(modifier = Modifier.fillMaxSize()) { drawMidnightCircles() }
}

/** The clock, date and settings button for the themed style. */
@Composable
fun ThemedHeader(onOpenSettings: () -> Unit) {
    val now by produceState(initialValue = LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(10_000L)
        }
    }
    MidnightHeader(now = now, onOpenSettings = onOpenSettings)
}

/** Midnight Circles: a left-aligned clock and date in soft blue, with the settings button on the right. */
@Composable
private fun MidnightHeader(now: LocalDateTime, onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, top = 24.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = now.format(TimeOnlyFormat),
                style = MaterialTheme.typography.displayLarge,
                color = MidnightText,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = now.format(LongDateFormat),
                style = MaterialTheme.typography.titleMedium,
                color = MidnightText.copy(alpha = 0.75f),
            )
        }
        IconButton(onClick = onOpenSettings) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = stringResource(R.string.settings_open),
                tint = MidnightText,
            )
        }
    }
}

private fun DrawScope.drawMidnightCircles() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF0A1B3D), Color(0xFF050E24), Color(0xFF020710))))
    drawRect(
        Brush.radialGradient(
            colors = listOf(Color(0xFF2D7CFF).copy(alpha = 0.40f), Color.Transparent),
            center = Offset(size.width / 2f, size.height * 0.95f),
            radius = size.width * 0.9f,
        ),
    )
}
