package com.example.colourlauncher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.HomeFolder
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.data.LauncherStyle
import com.example.colourlauncher.ui.theme.aquaGlassFill

/**
 * A folder on the home grid: its first four apps in a 2x2 preview tile, with the folder's name
 * underneath. Tapping it opens the folder.
 */
@Composable
fun FolderIcon(
    folder: HomeFolder,
    appsByPackage: Map<String, LauncherApp>,
    onClick: () -> Unit,
    labelColor: Color = Color.White,
) {
    val settings = LocalLauncherSettings.current
    val oxygen = settings.style == LauncherStyle.OxygenOS
    val source = remember { MutableInteractionSource() }
    val tile = settings.iconSizeDp.dp
    val miniShape = settings.iconShape.toShape()
    val preview = remember(folder, appsByPackage) {
        folder.packages.mapNotNull { appsByPackage[it] }.take(4)
    }

    Column(
        modifier = Modifier
            .pressScale(source, 0.9f)
            .clickable(interactionSource = source, indication = LocalIndication.current, onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(tile)
                .clip(if (oxygen) CircleShape else settings.iconShape.toShape())
                .background(if (oxygen) Color.White else Color.White.copy(alpha = 0.28f)),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier.padding(tile * 0.12f),
                verticalArrangement = Arrangement.spacedBy(tile * 0.06f),
            ) {
                for (row in 0 until 2) {
                    Row(horizontalArrangement = Arrangement.spacedBy(tile * 0.06f)) {
                        for (column in 0 until 2) {
                            val app = preview.getOrNull(row * 2 + column)
                            Box(modifier = Modifier.size(tile * 0.34f), contentAlignment = Alignment.Center) {
                                if (app != null) {
                                    Image(
                                        bitmap = app.icon,
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize().clip(miniShape),
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        if (settings.showLabels) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = folder.name,
                color = labelColor,
                style = MaterialTheme.typography.labelMedium.copy(
                    shadow = LauncherTextShadow,
                ),
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 76.dp),
            )
        }
    }
}

/**
 * An open folder: its name, which can be edited, and its apps. Tapping an app opens it. A long
 * press opens the app's action sheet, where it can be removed from the folder.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FolderSheet(
    folder: HomeFolder,
    appsByPackage: Map<String, LauncherApp>,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    val apps = folder.packages.mapNotNull { appsByPackage[it] }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = aquaGlassFill()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 24.dp, bottom = 24.dp),
        ) {
            OutlinedTextField(
                value = folder.name,
                onValueChange = onRename,
                singleLine = true,
                label = { Text(stringResource(R.string.folder_name)) },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
            if (apps.isEmpty()) {
                Text(
                    text = stringResource(R.string.folder_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                apps.chunked(4).forEach { row ->
                    Row(modifier = Modifier.fillMaxWidth()) {
                        row.forEach { app ->
                            AppIcon(
                                app = app,
                                onClick = { onLaunch(app.packageName) },
                                onLongClick = { onLongPress(app) },
                                modifier = Modifier.weight(1f),
                                labelColor = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onDelete) { Text(stringResource(R.string.folder_delete)) }
        }
    }
}

/** Asks which folder an app should go into: one that exists, or a new one. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FolderPickerSheet(
    folders: List<HomeFolder>,
    onPick: (String) -> Unit,
    onNewFolder: () -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = aquaGlassFill()) {
        Text(
            text = stringResource(R.string.folder_pick_title),
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
        )
        ListItem(
            headlineContent = { Text(stringResource(R.string.folder_new)) },
            modifier = Modifier.clickable { onNewFolder() },
        )
        folders.forEach { folder ->
            ListItem(
                headlineContent = { Text(folder.name) },
                modifier = Modifier.clickable { onPick(folder.id) },
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}
