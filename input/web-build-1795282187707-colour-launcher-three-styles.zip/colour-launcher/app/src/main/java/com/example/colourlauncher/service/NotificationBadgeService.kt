package com.example.colourlauncher.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Counts each app's notifications for the icon badges. It reads only the package name and
 * whether a notification is ongoing, never the text. The user turns it on in
 * Settings > Notification access, which the launcher opens when badges are switched on.
 */
class NotificationBadgeService : NotificationListenerService() {

    override fun onListenerConnected() = publish()

    override fun onListenerDisconnected() = BadgeCounts.publish(emptyMap())

    override fun onNotificationPosted(sbn: StatusBarNotification?) = publish()

    override fun onNotificationRemoved(sbn: StatusBarNotification?) = publish()

    private fun publish() {
        val active: Array<StatusBarNotification> = try {
            activeNotifications ?: emptyArray()
        } catch (e: SecurityException) {
            emptyArray()
        }
        // Ongoing notifications (music, navigation, downloads) don't count, and neither do our own.
        val counts = active
            .filter { !it.isOngoing && it.packageName != packageName }
            .groupingBy { it.packageName }
            .eachCount()
        BadgeCounts.publish(counts)
    }
}

/** The latest notification count for each package, shared with the launcher UI. */
object BadgeCounts {

    private val _counts = MutableStateFlow<Map<String, Int>>(emptyMap())
    val counts: StateFlow<Map<String, Int>> = _counts.asStateFlow()

    fun publish(counts: Map<String, Int>) {
        _counts.value = counts
    }
}
