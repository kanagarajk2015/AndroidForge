import java.net.URL
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.pockethost.server"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.pockethost.server"
        minSdk = 26
        targetSdk = 34
        versionCode = 20
        versionName = "5.4.4"
        ndk { abiFilters += "arm64-v8a" }
    }
    packaging { jniLibs { useLegacyPackaging = true } }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("org.apache.commons:commons-compress:1.27.1")
    implementation("org.mariadb.jdbc:mariadb-java-client:3.5.6")
    debugImplementation("androidx.compose.ui:ui-tooling")
}

// Downloads the PHP 8.4 ARM64 binary at build time and bundles it as libphp.so,
// so it works no matter which GitHub workflow file is used.
val fetchPhp by tasks.registering {
    val outFile = layout.projectDirectory.file("src/main/jniLibs/arm64-v8a/libphp.so").asFile
    outputs.file(outFile)
    onlyIf { !outFile.exists() }
    doLast {
        val url = "https://github.com/pmmp/PHP-Binaries/releases/download/pm5-php-8.4-latest/PHP-8.4-Android-arm64-PM5.tar.gz"
        val sha = "d8867966340121f821591b9bb29c80a58ad77abd6cc8e0e44d1cbbb3aaedd70c"
        val tmp = File(temporaryDir, "php.tar.gz")
        URL(url).openStream().use { input -> tmp.outputStream().use { output -> input.copyTo(output) } }
        val md = MessageDigest.getInstance("SHA-256")
        tmp.inputStream().use { i -> val b = ByteArray(65536); while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
        val actual = md.digest().joinToString("") { b -> String.format("%02x", b) }
        check(actual == sha) { "PHP archive SHA-256 mismatch: $actual" }
        val ex = File(temporaryDir, "x").apply { deleteRecursively(); mkdirs() }
        val p = ProcessBuilder("tar", "-xzf", tmp.absolutePath, "-C", ex.absolutePath).inheritIO().start()
        check(p.waitFor() == 0) { "tar extract failed" }
        val php = ex.walkTopDown().first { it.isFile && it.name == "php" }
        outFile.parentFile.mkdirs()
        php.copyTo(outFile, overwrite = true)
        outFile.setExecutable(true)
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchPhp) }

// Generate the MariaDB runtime automatically from Gradle. This is important
// because AndroidForge's generic builder runs Gradle directly and does not run
// this project's own .github/workflows/android.yml steps.
val mariadbArchive = layout.projectDirectory.file("src/main/assets/mariadb-rootfs.tar.gz").asFile
val mariadbChecksum = layout.projectDirectory.file("src/main/assets/mariadb-rootfs.sha256").asFile
val mariadbBuilder = rootProject.file("scripts/build_mariadb_rootfs.py")

val buildMariaDbRuntime by tasks.registering(Exec::class) {
    inputs.file(mariadbBuilder)
    outputs.files(mariadbArchive, mariadbChecksum)
    workingDir(rootProject.projectDir)
    doFirst {
        check(mariadbBuilder.isFile) {
            "MariaDB builder script is missing: ${mariadbBuilder.absolutePath}"
        }
        mariadbArchive.parentFile.mkdirs()
    }
    commandLine("python3", mariadbBuilder.absolutePath)
}

val verifyMariaDbAssets by tasks.registering {
    dependsOn(buildMariaDbRuntime)
    inputs.files(mariadbArchive, mariadbChecksum)
    doLast {
        check(mariadbArchive.isFile && mariadbArchive.length() > 0L) {
            "MariaDB runtime generation completed without creating mariadb-rootfs.tar.gz."
        }
        check(mariadbChecksum.isFile && mariadbChecksum.readText().trim().matches(Regex("[0-9a-f]{64}"))) {
            "MariaDB runtime checksum is missing or invalid after generation."
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(verifyMariaDbAssets)
}
