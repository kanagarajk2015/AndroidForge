package com.pockethost.server

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Stores the local MariaDB administrator password encrypted with Android Keystore AES-GCM. */
class DbSecretStore(context: Context) {
    private val prefs = context.getSharedPreferences("pockethost_db_secrets", Context.MODE_PRIVATE)
    private val alias = "pockethost.mariadb.admin.v1"

    fun read(): String? = readSecret("admin_password")
    fun write(value: String) = writeSecret("admin_password", value)
    fun readDatabasePassword(database: String): String? = readSecret("db_${database}_password")
    fun writeDatabasePassword(database: String, value: String) = writeSecret("db_${database}_password", value)
    fun deleteDatabasePassword(database: String) {
        prefs.edit().remove("db_${database}_password").apply()
    }

    private fun readSecret(prefKey: String): String? {
        val packed = prefs.getString(prefKey, null) ?: return null
        return runCatching {
            val bytes = Base64.decode(packed, Base64.NO_WRAP)
            val iv = bytes.copyOfRange(0, 12)
            val encrypted = bytes.copyOfRange(12, bytes.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        }.getOrNull()
    }

    private fun writeSecret(prefKey: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val packed = cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        check(prefs.edit().putString(prefKey, Base64.encodeToString(packed, Base64.NO_WRAP)).commit()) {
            "Could not save encrypted database credentials"
        }
    }

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }
}
