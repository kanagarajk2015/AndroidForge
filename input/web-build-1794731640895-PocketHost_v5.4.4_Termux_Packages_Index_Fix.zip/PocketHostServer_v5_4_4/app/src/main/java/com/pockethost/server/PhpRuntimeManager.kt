package com.pockethost.server

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream
import kotlin.concurrent.thread

/**
 * Downloads the Android ARM64 PHP 8.4 runtime into app-private storage.
 *
 * Android 10+ blocks direct exec() of writable app-data binaries for apps
 * targeting API 29+. We invoke the system's linker64 with the downloaded
 * Bionic-linked PHP ELF as its argument (the same system_linker_exec pattern
 * documented by Termux). This is an Android-specific compatibility path.
 */
class PhpRuntimeManager(private val context: Context) {
    companion object {
        private const val PHP_URL =
            "https://github.com/pmmp/PHP-Binaries/releases/download/pm5-php-8.4-latest/PHP-8.4-Android-arm64-PM5.tar.gz"
        private const val PHP_SHA256 =
            "d8867966340121f821591b9bb29c80a58ad77abd6cc8e0e44d1cbbb3aaedd70c"
        private const val MAX_ARCHIVE_BYTES = 120L * 1024L * 1024L
    }

    @Volatile var status: String = "PHP 8.4 not installed"
        private set

    // PHP ships inside the APK as lib/arm64-v8a/libphp.so. Android only allows
    // exec() from the (read-only) native library directory, and the pmmp build is
    // a non-PIE ET_EXEC binary that linker64 refuses, so it is executed directly.
    private val runtimeDir = File(context.applicationInfo.nativeLibraryDir)
    init {
        if (findPhp(runtimeDir) != null) status = "PHP 8.4 bundled • execution test required"
    }

    private val siteProcesses = ConcurrentHashMap<String, Process>()
    private val sitePorts = ConcurrentHashMap<String, Int>()

    val phpExecutable: File?
        get() = findPhp(runtimeDir)

    val isInstalled: Boolean
        get() = phpExecutable?.isFile == true

    // Kept for compatibility with older UI code during the transition.
    val isBundled: Boolean
        get() = isInstalled

    fun diagnostic(): String {
        val php = phpExecutable
        return if (php != null) {
            "PHP file: ${php.absolutePath}\nDirect exec from nativeLibraryDir\nInstalled: ${php.isFile}"
        } else {
            "libphp.so is not bundled in this APK (rebuild with the updated GitHub workflow)."
        }
    }

    /** Verifies the bundled PHP binary. No download/extraction is needed any more. */
    fun install(onComplete: (Boolean, String) -> Unit) {
        thread(name = "PocketHost-PHP-Verify") {
            try {
                val php = findPhp(runtimeDir)
                    ?: throw IllegalStateException("libphp.so is missing from the APK (nativeLibraryDir=${runtimeDir.absolutePath})")
                status = "Testing bundled PHP…"
                val version = runCommand(listOf("-v"), runtimeDir, 30_000)
                if (version.first != 0) {
                    throw IllegalStateException("PHP self-test failed (${version.first}): ${version.second.take(900)}")
                }
                val modules = runCommand(listOf("-m"), runtimeDir, 30_000)
                status = "PHP 8.4 ready • ${version.second.lineSequence().firstOrNull().orEmpty()}\n" +
                    "Modules: ${modules.second.lineSequence().filter { it.isNotBlank() }.take(14).joinToString(", ")}"
                onComplete(true, status)
            } catch (e: Exception) {
                status = "PHP check failed: ${e.message ?: e.javaClass.simpleName}"
                onComplete(false, status)
            }
        }
    }

    /** Reports whether the bundled PHP build has MySQL client extensions. */
    fun mysqlExtensionStatus(): String {
        return try {
            val code = "echo 'mysqli='.(extension_loaded('mysqli')?'yes':'no').PHP_EOL;" +
                "echo 'pdo_mysql='.(extension_loaded('pdo_mysql')?'yes':'no').PHP_EOL;"
            val result = runCommand(listOf("-r", code), runtimeDir, 10_000)
            if (result.first == 0) result.second.trim()
            else "PHP extension check failed: ${result.second.take(300)}"
        } catch (e: Exception) {
            "PHP MySQL extension check failed: ${e.message}"
        }
    }

    fun startSiteServer(siteDir: File): Int {
        val php = phpExecutable
            ?: throw IllegalStateException("Install PHP 8.4 from the PocketHost dashboard first")
        val key = siteDir.canonicalPath
        val old = siteProcesses[key]
        val oldPort = sitePorts[key]
        if (old != null && old.isAlive && oldPort != null) return oldPort

        val port = 18000 + (siteDir.name.hashCode().toLong().and(0x7fffffff) % 10000).toInt()
        val log = File(siteDir, ".pockethost-php.log")
        val command = mutableListOf(
            php.absolutePath,
            "-S", "127.0.0.1:$port",
            "-t", siteDir.absolutePath
        )
        val builder = ProcessBuilder(command).redirectErrorStream(true).redirectOutput(log)
        configureEnvironment(builder, runtimeDir)
        val process = builder.start()

        Thread.sleep(700)
        if (!process.isAlive) {
            val detail = runCatching { log.readText().take(900) }.getOrDefault("")
            throw IllegalStateException("PHP web server did not start. $detail")
        }
        siteProcesses[key] = process
        sitePorts[key] = port
        return port
    }

    fun stopAll() {
        siteProcesses.values.forEach { runCatching { it.destroy() } }
        siteProcesses.clear()
        sitePorts.clear()
    }

    private fun runCommand(args: List<String>, root: File, timeoutMs: Long): Pair<Int, String> {
        val php = findPhp(root) ?: throw IllegalStateException("PHP executable missing")
        val command = mutableListOf(php.absolutePath)
        command.addAll(args)
        val builder = ProcessBuilder(command).redirectErrorStream(true)
        configureEnvironment(builder, root)
        val process = builder.start()
        val output = StringBuilder()
        val reader = thread(name = "PocketHost-PHP-output") {
            process.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { output.append(it).append('\n') }
            }
        }
        if (!process.waitFor(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS)) {
            process.destroyForcibly()
            reader.join(1000)
            throw IllegalStateException("PHP self-test timed out")
        }
        reader.join(3000)
        return process.exitValue() to output.toString()
    }

    private fun configureEnvironment(builder: ProcessBuilder, root: File) {
        val env = builder.environment()
        val libraryDirs = root.walkTopDown()
            .filter { it.isFile && it.name.endsWith(".so") }
            .mapNotNull { it.parentFile?.absolutePath }
            .distinct()
            .toList()
        env["LD_LIBRARY_PATH"] = (libraryDirs + root.absolutePath).distinct().joinToString(":")
        env["HOME"] = context.filesDir.absolutePath
        env["TMPDIR"] = context.cacheDir.absolutePath
        env["ANDROID_ROOT"] = "/system"
        env["ANDROID_DATA"] = "/data"
        env["PATH"] = listOfNotNull(findPhp(root)?.parentFile?.absolutePath, "/system/bin").joinToString(":")
        val ini = root.walkTopDown().firstOrNull { it.isFile && it.name == "php.ini" }
        if (ini != null) {
            env["PHPRC"] = ini.absolutePath
            env["PHP_INI_SCAN_DIR"] = ini.parentFile?.absolutePath.orEmpty()
        }
    }

    private fun downloadVerified(destination: File) {
        val connection = (URL(PHP_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "PocketHost-Android/5.3")
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("PHP download HTTP ${connection.responseCode}")
            }
            val length = connection.contentLengthLong
            if (length > MAX_ARCHIVE_BYTES) throw IllegalStateException("PHP archive exceeds the size limit")
            val digest = MessageDigest.getInstance("SHA-256")
            var total = 0L
            connection.inputStream.use { input ->
                FileOutputStream(destination).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        total += n
                        if (total > MAX_ARCHIVE_BYTES) throw IllegalStateException("PHP archive exceeds the size limit")
                        digest.update(buffer, 0, n)
                        output.write(buffer, 0, n)
                    }
                }
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            if (!actual.equals(PHP_SHA256, ignoreCase = true)) {
                destination.delete()
                throw SecurityException("PHP archive SHA-256 mismatch. Expected $PHP_SHA256, got $actual")
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun extractSafely(archive: File, destination: File) {
        val root = destination.canonicalFile.toPath()
        TarArchiveInputStream(GZIPInputStream(BufferedInputStream(FileInputStream(archive)))).use { tar ->
            val buffer = ByteArray(64 * 1024)
            var entry = tar.nextTarEntry
            while (entry != null) {
                val normalized = entry.name.replace('\\', '/').replace(Regex("^(\\./)+"), "")
                val parts = normalized.split('/').filter { it.isNotEmpty() && it != "." }
                if (normalized.startsWith("/") || parts.any { it == ".." }) {
                    throw SecurityException("Unsafe PHP archive path: ${entry.name}")
                }
                val outputPath = root.resolve(parts.joinToString("/")).normalize()
                if (!outputPath.startsWith(root)) throw SecurityException("Unsafe PHP archive path: ${entry.name}")
                val output = outputPath.toFile()
                when {
                    entry.isDirectory -> output.mkdirs()
                    entry.isSymbolicLink -> {
                        val link = entry.linkName.replace('\\', '/')
                        if (!link.startsWith("/")) {
                            val target = (outputPath.parent ?: root).resolve(link).normalize()
                            if (target.startsWith(root)) {
                                output.parentFile?.mkdirs()
                                runCatching {
                                    java.nio.file.Files.createSymbolicLink(outputPath, (outputPath.parent ?: root).relativize(target))
                                }
                            }
                        }
                    }
                    entry.isLink -> Unit // Hard links are optional in this runtime package.
                    entry.isFile -> {
                        output.parentFile?.mkdirs()
                        FileOutputStream(output).use { stream ->
                            while (true) {
                                val count = tar.read(buffer)
                                if (count <= 0) break
                                stream.write(buffer, 0, count)
                            }
                        }
                        output.setReadable(true, true)
                        output.setWritable(true, true)
                    }
                }
                entry = tar.nextTarEntry
            }
        }
    }

    private fun findPhp(root: File): File? {
        val f = File(root, "libphp.so")
        return if (f.isFile && isElf(f)) f else null
    }

    private fun isElf(file: File): Boolean = runCatching {
        FileInputStream(file).use { input ->
            input.read() == 0x7f && input.read() == 0x45 && input.read() == 0x4c && input.read() == 0x46
        }
    }.getOrDefault(false)

    private fun deleteTree(file: File) {
        if (file.isDirectory) file.listFiles()?.forEach { deleteTree(it) }
        runCatching { file.delete() }
    }
}
