package com.pockethost.server

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class SharedStorageManager(private val context: Context) {
    data class CopySummary(val files: Int, val directories: Int)

    fun importFolder(treeUri: Uri, destination: File): CopySummary {
        val tree = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("The selected shared folder is unavailable")
        if (!tree.canRead()) throw SecurityException("Read access to the selected folder was not granted")
        destination.mkdirs()
        val counts = intArrayOf(0, 0)
        copyFromDocumentTree(tree, destination, counts, 0)
        return CopySummary(counts[0], counts[1])
    }

    fun exportWebsite(source: File, treeUri: Uri): CopySummary {
        if (!source.isDirectory) throw IllegalArgumentException("Website folder does not exist")
        val tree = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("The selected shared folder is unavailable")
        if (!tree.canWrite()) throw SecurityException("Write access to the selected folder was not granted")

        val root = findOrCreateDirectory(tree, "PocketHost")
        val siteFolder = findOrCreateDirectory(root, safeName(source.name))
        val counts = intArrayOf(0, 0)
        copyFromFileTree(source, siteFolder, counts, 0)
        return CopySummary(counts[0], counts[1])
    }

    private fun copyFromDocumentTree(
        source: DocumentFile,
        destination: File,
        counts: IntArray,
        depth: Int
    ) {
        if (depth > 20) throw IllegalStateException("Folder nesting exceeds the 20-level safety limit")
        for (child in source.listFiles()) {
            val name = safeName(child.name ?: continue)
            if (name.isBlank() || name == "." || name == "..") continue
            if (child.isDirectory) {
                val dir = File(destination, name)
                if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Cannot create folder $name")
                counts[1]++
                copyFromDocumentTree(child, dir, counts, depth + 1)
            } else if (child.isFile) {
                if (++counts[0] > 5000) throw IllegalStateException("Import exceeds 5,000 files")
                val out = File(destination, name)
                context.contentResolver.openInputStream(child.uri)?.use { input ->
                    FileOutputStream(out).use { output -> input.copyTo(output) }
                } ?: throw IllegalStateException("Cannot read ${child.name}")
            }
        }
    }

    private fun copyFromFileTree(
        source: File,
        destination: DocumentFile,
        counts: IntArray,
        depth: Int
    ) {
        if (depth > 20) throw IllegalStateException("Folder nesting exceeds the 20-level safety limit")
        val children = source.listFiles() ?: throw IllegalStateException("Cannot read ${source.absolutePath}")
        for (child in children) {
            if (child.name.startsWith(".pockethost-")) continue
            val name = safeName(child.name)
            if (name.isBlank() || name == "." || name == "..") continue
            if (child.isDirectory) {
                val dir = findOrCreateDirectory(destination, name)
                counts[1]++
                copyFromFileTree(child, dir, counts, depth + 1)
            } else if (child.isFile) {
                if (++counts[0] > 5000) throw IllegalStateException("Export exceeds 5,000 files")
                val mime = mimeFor(child.extension)
                destination.findFile(name)?.delete()
                val target = destination.createFile(mime, name)
                    ?: throw IllegalStateException("Cannot create shared file $name")
                FileInputStream(child).use { input ->
                    context.contentResolver.openOutputStream(target.uri, "w")?.use { output ->
                        input.copyTo(output)
                    } ?: throw IllegalStateException("Cannot write shared file $name")
                }
            }
        }
    }

    private fun findOrCreateDirectory(parent: DocumentFile, name: String): DocumentFile {
        val existing = parent.findFile(name)
        if (existing != null && existing.isDirectory) return existing
        if (existing != null) existing.delete()
        return parent.createDirectory(name)
            ?: throw IllegalStateException("Cannot create shared folder $name")
    }

    private fun safeName(value: String): String =
        value.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().take(180)

    private fun mimeFor(extension: String): String = when (extension.lowercase()) {
        "html", "htm" -> "text/html"
        "css" -> "text/css"
        "js" -> "application/javascript"
        "json" -> "application/json"
        "txt", "log" -> "text/plain"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "gif" -> "image/gif"
        "svg" -> "image/svg+xml"
        "pdf" -> "application/pdf"
        "php", "py", "rb", "rs" -> "text/plain"
        else -> "application/octet-stream"
    }
}
