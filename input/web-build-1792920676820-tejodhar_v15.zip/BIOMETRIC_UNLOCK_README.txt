Tejodhar biometric unlock
- New splash: res/raw/tejodhar_splash.gif (1080x2340, 4.16 s, white bg) replaces old splash; fallback frame res/drawable-nodpi/tejodhar_splash_last.png.
- Outer (login-page) biometric unlock and Median splash screen removed.
- No second lock when the app opens.
- Native bridge: app/src/main/java/co/median/android/BiometricBridge.java (window.TejodharBio).
- Server side: website/index.php (bio_native_register / bio_native_login).
- Source change only; build with AndroidForge.
