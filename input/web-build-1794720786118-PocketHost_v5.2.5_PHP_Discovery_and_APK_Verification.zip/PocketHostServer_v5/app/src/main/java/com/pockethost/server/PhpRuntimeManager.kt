package com.pockethost.server

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

/**
 * PHP executable is packaged in the APK's jniLibs/arm64-v8a directory and
 * extracted by Android Package Manager into ApplicationInfo.nativeLibraryDir.
 * Do not download or execute native code from filesDir on modern Android.
 */
class PhpRuntimeManager(private val context: Context) {
    @Volatile var status: String = "PHP runtime not bundled in this APK"
        private set

    val phpExecutable: File
        get() = File(context.applicationInfo.nativeLibraryDir, "libphp.so")

    val isBundled: Boolean
        get() = phpExecutable.isFile && phpExecutable.canExecute()

    fun diagnostic(): String {
        val dir = File(context.applicationInfo.nativeLibraryDir)
        val names = dir.list()?.sorted()?.joinToString(", ").orEmpty().ifBlank { "(empty)" }
        return "Native library directory: ${dir.absolutePath}\nFiles: $names\nExpected: libphp.so"
    }

    private val siteProcesses = ConcurrentHashMap<String, Process>()
    private val sitePorts = ConcurrentHashMap<String, Int>()

    init {
        status = if (phpExecutable.isFile && phpExecutable.canExecute()) {
            "PHP 8.4 bundled • ready to test"
        } else {
            "PHP runtime missing from APK • rebuild using GitHub Actions"
        }
    }

    fun install(onComplete: (Boolean, String) -> Unit) {
        thread(name = "PocketHost-PHP-prepare") {
            try {
                val php = phpExecutable
                if (!php.isFile) {
                    throw IllegalStateException(
                        "PHP executable is not packaged in this APK. Rebuild with the PHP runtime workflow step."
                    )
                }
                if (!php.canExecute()) {
                    throw IllegalStateException(
                        "Android did not extract the PHP executable into nativeLibraryDir. Check extractNativeLibs."
                    )
                }

                val runtimeDir = File(context.filesDir, "php-runtime")
                runtimeDir.mkdirs()
                copyAssets("php-runtime", runtimeDir)

                val builder = ProcessBuilder(php.absolutePath, "-v").redirectErrorStream(true)
                configureEnvironment(builder, runtimeDir)
                val process = builder.start()
                val output = process.inputStream.bufferedReader().use { it.readText() }
                val exit = process.waitFor()
                if (exit != 0) throw IllegalStateException("PHP self-test exited $exit: ${output.take(700)}")

                status = "PHP 8.4 ready • ${output.lineSequence().firstOrNull() ?: "CLI verified"}"
                onComplete(true, status)
            } catch (e: Exception) {
                status = "PHP test failed: ${e.message ?: e.javaClass.simpleName}"
                onComplete(false, status)
            }
        }
    }

    fun startSiteServer(siteDir: File): Int {
        val php = phpExecutable
        if (!php.isFile || !php.canExecute()) {
            throw IllegalStateException("Bundled PHP executable is unavailable. Rebuild the APK.")
        }
        val key = siteDir.canonicalPath
        val existing = siteProcesses[key]
        val existingPort = sitePorts[key]
        if (existing != null && existing.isAlive && existingPort != null) return existingPort

        val port = 18000 + (siteDir.name.hashCode().toLong().and(0x7fffffff) % 10000).toInt()
        val runtimeDir = File(context.filesDir, "php-runtime")
        val log = File(siteDir, ".pockethost-php.log")
        val builder = ProcessBuilder(
            php.absolutePath, "-S", "127.0.0.1:$port", "-t", siteDir.absolutePath
        ).redirectErrorStream(true).redirectOutput(log)
        configureEnvironment(builder, runtimeDir)
        val process = builder.start()

        Thread.sleep(500)
        if (!process.isAlive) {
            throw IllegalStateException("PHP server failed to start. Check ${log.name}")
        }
        siteProcesses[key] = process
        sitePorts[key] = port
        return port
    }

    fun stopAll() {
        siteProcesses.values.forEach { runCatching { it.destroy() } }
        siteProcesses.clear()
        sitePorts.clear()
    }

    private fun configureEnvironment(builder: ProcessBuilder, runtimeDir: File) {
        val nativeDir = context.applicationInfo.nativeLibraryDir
        val env = builder.environment()
        env["HOME"] = context.filesDir.absolutePath
        env["TMPDIR"] = context.cacheDir.absolutePath
        env["LD_LIBRARY_PATH"] = nativeDir
        env["PHPRC"] = File(runtimeDir, "php.ini").takeIf { it.isFile }?.absolutePath ?: runtimeDir.absolutePath
        env["PHP_INI_SCAN_DIR"] = File(runtimeDir, "conf.d").absolutePath
    }

    private fun copyAssets(assetPath: String, destination: File) {
        val children = context.assets.list(assetPath) ?: return
        for (child in children) {
            val childAsset = "$assetPath/$child"
            val out = File(destination, child)
            val nested = context.assets.list(childAsset)
            if (!nested.isNullOrEmpty()) {
                out.mkdirs()
                copyAssets(childAsset, out)
            } else {
                out.parentFile?.mkdirs()
                runCatching {
                    context.assets.open(childAsset).use { input ->
                        FileOutputStream(out).use { output -> input.copyTo(output) }
                    }
                }
            }
        }
    }
}