from pathlib import Path
root = Path(".")
workflow = (root / ".github/workflows/android.yml").read_text()
php = (root / "app/src/main/java/com/pockethost/server/PhpRuntimeManager.kt").read_text()
main = (root / "app/src/main/java/com/pockethost/server/MainActivity.kt").read_text()
gradle = (root / "app/build.gradle.kts").read_text()
assert "find -L .build/php" in workflow
assert "ELF 64-bit.*ARM aarch64" in workflow
assert "Verify PHP and dependencies are inside APK" in workflow
assert "lib/arm64-v8a/libphp.so" in workflow
assert "sha256sum -c -" in workflow
assert "nativeLibraryDir" in php and "libphp.so" in php
assert "phpManager.diagnostic()" in main
assert "keepDebugSymbols" in gradle and "arm64-v8a" in gradle
print("PocketHost v5.2.5 source/workflow smoke checks: PASS")
