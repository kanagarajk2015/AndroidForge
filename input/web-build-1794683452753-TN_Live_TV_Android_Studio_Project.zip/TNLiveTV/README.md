# TN Live TV — Android TV prototype

A TV-remote-friendly Android app shell for previewing an HDMI capture card that Android exposes as an external USB camera (UVC).

## Important limitations
- This prototype uses Android Camera2 external-camera discovery. Some Android TV firmware does not expose USB capture devices to third-party apps; if the app reports no USB video input, this TV firmware/capture-card combination is not supported by this implementation.
- Buy only a UVC-compliant HDMI-to-USB capture device and confirm return eligibility. USB 3.0 is preferred, but the TV's USB host implementation and power output also matter.
- HDCP-protected HDMI output may be blocked and show a black screen. This app does not bypass HDCP.
- TV remote navigation is implemented. Channel up/down cannot normally tune the TN Cable box over HDMI. The box must support a separate control protocol (such as HDMI-CEC, IR, or network control) and expose it; HDMI video itself is one-way.
- This is source code, not a tested APK. It must be built and tested on the actual VW TV and capture card.

## Build
1. Open this folder in Android Studio.
2. Install JDK 17 and Android SDK platform 35.
3. Sync Gradle and build `app` > `assembleDebug`.
4. Install the generated APK on the VW TV and connect a UVC capture card.

Package: `com.tejodhar.tnlivetv`
App name: `TN Live TV`

## Controls
- OK / Enter: retry USB device detection
- CH+ / CH− / D-pad up/down: show a notice that channel tuning requires a set-top-box control interface
- Back: exit

## Technical basis
Android supports external USB cameras when the device firmware implements USB host and external-camera support. See Android's external USB camera documentation: https://source.android.com/docs/core/camera/external-usb-cameras
