package com.tejodhar.tnlivetv;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** TV-first HDMI capture preview shell. Uses Android's external-camera provider when exposed by TV firmware. */
public class MainActivity extends Activity implements TextureView.SurfaceTextureListener {
    private TextureView preview;
    private TextView status, channel;
    private String[] externalIds = new String[0];
    private int channelNumber = 1;
    private android.hardware.camera2.CameraDevice camera;
    private android.hardware.camera2.CameraCaptureSession session;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(8,13,24)); root.setPadding(32,24,32,24);
        TextView title = text("TN LIVE TV", 28, Color.WHITE); root.addView(title);
        TextView subtitle = text("USB HDMI CAPTURE  •  TV REMOTE CONTROL", 13, Color.LTGRAY); root.addView(subtitle);
        preview = new TextureView(this); preview.setSurfaceTextureListener(this);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1,0,1); pp.topMargin=18; pp.bottomMargin=14; root.addView(preview,pp);
        status = text("Connect a UVC HDMI capture card to the TV USB port.",16,Color.WHITE); root.addView(status);
        channel = text("INPUT  •  HDMI CAPTURE",18,Color.rgb(255,160,40)); root.addView(channel);
        TextView help = text("OK: reconnect   •   BACK: exit   •   CH+/CH−: channel box control not available over HDMI",13,Color.LTGRAY); root.addView(help);
        setContentView(root);
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{android.Manifest.permission.CAMERA}, 41); } else { scanExternalCameras(); }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){ super.onRequestPermissionsResult(requestCode, permissions, grantResults); if(requestCode==41 && grantResults.length>0 && grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED) scanExternalCameras(); else status.setText("Camera permission is required to access a USB capture device."); }
    private TextView text(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(8,8,8,8); return t; }
    private void scanExternalCameras(){
        try { CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE); java.util.ArrayList<String> ids=new java.util.ArrayList<>();
            for(String id:cm.getCameraIdList()){ CameraCharacteristics c=cm.getCameraCharacteristics(id); Integer facing=c.get(CameraCharacteristics.LENS_FACING); if(facing!=null && facing==CameraCharacteristics.LENS_FACING_EXTERNAL) ids.add(id); }
            externalIds=ids.toArray(new String[0]);
            if(externalIds.length==0) status.setText("No USB video input detected by Android. TV firmware may not expose UVC capture cards to apps.");
            else { status.setText("USB video device detected. Opening preview…"); if(preview.isAvailable()) openCamera(preview.getSurfaceTexture()); }
        } catch(Exception e){ status.setText("Camera detection unavailable: "+e.getMessage()); }
    }
    private void openCamera(SurfaceTexture texture){
        if(externalIds.length==0 || texture==null) return;
        try { CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE); cm.openCamera(externalIds[0], new android.hardware.camera2.CameraDevice.StateCallback(){
            @Override public void onOpened(android.hardware.camera2.CameraDevice d){ camera=d; Surface s=new Surface(texture); try { d.createCaptureSession(java.util.Collections.singletonList(s),new android.hardware.camera2.CameraCaptureSession.StateCallback(){
                @Override public void onConfigured(android.hardware.camera2.CameraCaptureSession cs){ session=cs; try { android.hardware.camera2.CaptureRequest.Builder b=d.createCaptureRequest(android.hardware.camera2.CameraDevice.TEMPLATE_PREVIEW); b.addTarget(s); cs.setRepeatingRequest(b.build(),null,null); runOnUiThread(()->status.setText("Capture device connected. If video is black, check UVC/HDCP compatibility.")); }catch(Exception ex){runOnUiThread(()->status.setText("Preview error: "+ex.getMessage()));} }
                @Override public void onConfigureFailed(android.hardware.camera2.CameraCaptureSession cs){runOnUiThread(()->status.setText("Could not start capture preview."));}
            },null);}catch(Exception ex){runOnUiThread(()->status.setText("Capture session error: "+ex.getMessage()));} }
            @Override public void onDisconnected(android.hardware.camera2.CameraDevice d){d.close();camera=null;}
            @Override public void onError(android.hardware.camera2.CameraDevice d,int error){d.close();camera=null;runOnUiThread(()->status.setText("USB camera error: "+error));}
        },null);} catch(SecurityException e){ status.setText("Allow camera permission for USB capture."); } catch(Exception e){ status.setText("Unable to open USB capture: "+e.getMessage()); }
    }
    @Override public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){ openCamera(s); }
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s){ closeCamera(); return true; }
    @Override public void onSurfaceTextureUpdated(SurfaceTexture s){}
    private void closeCamera(){ try{if(session!=null)session.close();}catch(Exception ignored){} try{if(camera!=null)camera.close();}catch(Exception ignored){} session=null;camera=null; }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_DPAD_CENTER || keyCode==KeyEvent.KEYCODE_ENTER){ scanExternalCameras(); return true; }
        if(keyCode==KeyEvent.KEYCODE_CHANNEL_UP || keyCode==KeyEvent.KEYCODE_CHANNEL_DOWN || keyCode==KeyEvent.KEYCODE_DPAD_UP || keyCode==KeyEvent.KEYCODE_DPAD_DOWN){
            Toast.makeText(this,"Channel changing must be handled by the TN Cable box. HDMI video alone cannot send channel commands.",Toast.LENGTH_LONG).show(); return true;
        }
        return super.onKeyDown(keyCode,event);
    }
    @Override protected void onDestroy(){closeCamera();super.onDestroy();}
}
