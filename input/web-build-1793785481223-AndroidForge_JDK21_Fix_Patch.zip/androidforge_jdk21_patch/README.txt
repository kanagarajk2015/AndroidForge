ANDROIDFORGE JDK 21 FIX PATCH
============================

This patch addresses the exact failure shown in the supplied AndroidForge run log:

  Toolchain JSON selected jdk_version = 21
  but workflow case 21 mapped JAVA_HOME to /usr/lib/jvm/java-17-openjdk-amd64
  and java -version reported 17.0.20.1.

The Tejodhar source requires Java 21 (app/build.gradle uses JavaVersion.VERSION_21
and kotlin.jvmToolchain(21)).

WHAT THIS PATCH DOES
--------------------
1. Adds Eclipse Temurin JDK 21 to AndroidForge's Ubuntu 22.04 Docker build image.
2. Preserves the existing JDK 8, 11 and 17 installations.
3. Adds JAVA_HOME_21=/usr/lib/jvm/temurin-21-jdk-amd64.
4. Changes the AndroidForge workflow's JDK 21 case from the JDK 17 path to the
   actual JDK 21 path.

HOW TO APPLY (GitHub / Android phone)
-------------------------------------
1. Download and extract your repository ZIP from:
   https://github.com/kanagarajk2015/AndroidForge
2. Copy apply_jdk21_fix.py into the extracted AndroidForge folder.
3. Run from that folder:
      python3 apply_jdk21_fix.py .
   Or, if Python is not available, edit the two files manually using the
   instructions below.
4. Commit and push the changed Dockerfile.android and workflow file to main.
5. In GitHub Actions, run "Build & Publish Android Image" and wait for it to
   complete successfully. This rebuild is required; editing Dockerfile alone
   does not change the already-published container image.
6. Run "Build Android APK" again with Tejodhar_Android_Branded_Source.zip.

MANUAL CHANGES
--------------
A) Dockerfile.android
- Add the Adoptium apt key/repository before installing the JDK packages:

  RUN mkdir -p /etc/apt/keyrings && \
      wget -qO- https://packages.adoptium.net/artifactory/api/gpg/key/public | gpg --dearmor -o /etc/apt/keyrings/adoptium.gpg && \
      echo "deb [signed-by=/etc/apt/keyrings/adoptium.gpg] https://packages.adoptium.net/artifactory/deb $(. /etc/os-release && echo ${VERSION_CODENAME}) main" > /etc/apt/sources.list.d/adoptium.list

- Add temurin-21-jdk to the apt package list beside openjdk-8-jdk,
  openjdk-11-jdk and openjdk-17-jdk.
- Add:
  ENV JAVA_HOME_21=/usr/lib/jvm/temurin-21-jdk-amd64

B) .github/workflows/build-android.yml
- In the JDK switch case, set:
  21) NEW_JH=/usr/lib/jvm/temurin-21-jdk-amd64 ;;
- Do not map 21 to the Java 17 directory.

IMPORTANT
---------
This is a patch bundle, not a complete AndroidForge repository. It does not
contain or replace your Tejodhar Android source ZIP, and it does not itself
produce an APK. The AndroidForge repository must be updated and its Docker
image rebuilt before the next APK build can use JDK 21.

The JDK 21 path is the standard Temurin path for the Ubuntu/Debian package.
The image build's final sanity check should show Java 21. Confirm with:
  /usr/lib/jvm/temurin-21-jdk-amd64/bin/java -version
