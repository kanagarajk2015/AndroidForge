#!/usr/bin/env python3
"""Apply the JDK 21 fix to an AndroidForge repository checkout."""
from pathlib import Path
import re
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.')
dockerfile = root / 'Dockerfile.android'
workflow_dir = root / '.github' / 'workflows'
if not dockerfile.is_file() or not workflow_dir.is_dir():
    raise SystemExit('ERROR: Run this script from an AndroidForge checkout (Dockerfile.android and .github/workflows must exist).')

text = dockerfile.read_text(encoding='utf-8')
# Add the Eclipse Temurin apt repository and JDK 21 while preserving JDK 8/11/17.
old = '''RUN apt-get update && apt-get install -y --no-install-recommends \\

openjdk-8-jdk openjdk-11-jdk openjdk-17-jdk \\

&& rm -rf /var/lib/apt/lists/*'''
new = '''# Add Eclipse Temurin repository for JDK 21 (Ubuntu 22.04 base).
RUN mkdir -p /etc/apt/keyrings && \\
    wget -qO- https://packages.adoptium.net/artifactory/api/gpg/key/public | gpg --dearmor -o /etc/apt/keyrings/adoptium.gpg && \\
    echo "deb [signed-by=/etc/apt/keyrings/adoptium.gpg] https://packages.adoptium.net/artifactory/deb $(. /etc/os-release && echo ${VERSION_CODENAME}) main" > /etc/apt/sources.list.d/adoptium.list

RUN apt-get update && apt-get install -y --no-install-recommends \\

openjdk-8-jdk openjdk-11-jdk openjdk-17-jdk temurin-21-jdk \\

&& rm -rf /var/lib/apt/lists/*'''
if 'JAVA_HOME_21=' not in text:
    if old not in text:
        raise SystemExit('ERROR: Could not find expected JDK install block in Dockerfile.android; no files changed.')
    text = text.replace(old, new, 1)
    anchor = 'ENV JAVA_HOME_17=/usr/lib/jvm/java-17-openjdk-amd64'
    if anchor not in text:
        raise SystemExit('ERROR: Could not find JAVA_HOME_17 declaration; no files changed.')
    text = text.replace(anchor, anchor + '\n\nENV JAVA_HOME_21=/usr/lib/jvm/temurin-21-jdk-amd64', 1)
    anchor2 = 'echo "JDK 17: $($JAVA_HOME_17/bin/java -version 2>&1 | head -1) at $JAVA_HOME_17" && \\'
    if anchor2 in text:
        text = text.replace(anchor2, anchor2 + '\n\necho "JDK 21: $($JAVA_HOME_21/bin/java -version 2>&1 | head -1) at $JAVA_HOME_21" && \\', 1)
    else:
        # Still add an explicit build-time validation even if the final diagnostic block differs.
        text += '\nRUN $JAVA_HOME_21/bin/java -version\n'
    dockerfile.write_text(text, encoding='utf-8')

# The log shows the workflow explicitly mapped JDK 21 to JDK 17.
found = False
for wf in workflow_dir.glob('*.yml'):
    content = wf.read_text(encoding='utf-8')
    updated = re.sub(
        r'(?m)^(\s*21\)\s*NEW_JH=)/usr/lib/jvm/java-17-openjdk-amd64(\s*;;[^\n]*)$',
        r'\1/usr/lib/jvm/temurin-21-jdk-amd64\2',
        content,
    )
    if updated != content:
        wf.write_text(updated, encoding='utf-8')
        found = True
if not found:
    raise SystemExit('Dockerfile updated, but no workflow line matching the logged JDK 21 -> JDK 17 fallback was found. Inspect .github/workflows/build-android.yml and set case 21 to /usr/lib/jvm/temurin-21-jdk-amd64.')

print('JDK 21 fix applied. Next: commit/push changes, run Build & Publish Android Image, then rerun Build Android APK.')
