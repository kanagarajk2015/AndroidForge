package in.tejodhar.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.util.concurrent.Executor
import javax.crypto.Cipher

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val PERMISSION_REQUEST_CODE = 101
    private val TARGET_URL = "https://www.tejodhar.in/"

    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt

    // Address of the page in the WebView. Also read from the bridge's background thread.
    @Volatile private var pageUrl: String? = null

    // The one fingerprint prompt the site can have open at a time
    private enum class Job { UNLOCK, REGISTER }
    private var job: Job? = null
    private var jobCallback = ""
    private var jobToken = ""

    /**
     * window.TejodharBio, used by index.php (bioNative / bioNativeCall there).
     * Results go back by running window[callbackName](result) in the page.
     */
    inner class TejodharBioBridge {
        @JavascriptInterface
        fun isAvailable(): Boolean = strongAvailable()

        @JavascriptInterface
        fun hasToken(): Boolean = TokenVault.hasToken(this@MainActivity)

        @JavascriptInterface
        fun clear() {
            if (isOwnUrl(pageUrl)) TokenVault.clear(this@MainActivity)
        }

        @JavascriptInterface
        fun unlock(callback: String) {
            runOnUiThread { startUnlock(callback) }
        }

        @JavascriptInterface
        fun register(token: String, callback: String) {
            runOnUiThread { startRegister(token, callback) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        executor = ContextCompat.getMainExecutor(this)

        requestHardwarePermissions()
        setupWebView()
        setupBiometricPrompt()

        // The site shows its own fingerprint login on its login page
        webView.loadUrl(TARGET_URL)
    }

    private fun requestHardwarePermissions() {
        val permissions = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.MODIFY_AUDIO_SETTINGS
        )

        val neededPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (neededPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, neededPermissions.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true

            // Custom User-Agent tag to allow Web App to detect native wrapper
            // Keep both markers so the website can identify the native Android wrapper.
            userAgentString = userAgentString + " TejodharAppNative/1.1 TejodharApp/1.3"
        }

        // Expose the bridge under both names. The current website code may use
        // window.TejodharBio or the legacy window.bioNative name.
        val bioBridge = TejodharBioBridge()
        webView.addJavascriptInterface(bioBridge, "TejodharBio")
        webView.addJavascriptInterface(bioBridge, "bioNative")

        webView.webViewClient = object : WebViewClient() {
            // The site stays inside the app, so only tejodhar.in pages can use the bridge.
            // Other links (tel:, WhatsApp, other websites) open outside the app.
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme ?: return false
                return when (scheme) {
                    "http", "https" -> if (isOwnHost(uri.host)) false else openExternal(uri)
                    "about", "data", "blob", "javascript" -> false
                    else -> openExternal(uri)   // tel:, mailto:, whatsapp:, intent: ...
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                pageUrl = url
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pageUrl = url
            }
        }

        // Grant WebRTC camera & microphone permissions automatically inside WebView
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.run {
                    grant(resources)
                }
            }
        }
    }

    private fun setupBiometricPrompt() {
        biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    val current = job
                    val callback = jobCallback
                    val token = jobToken
                    clearJob()

                    val cipher = result.cryptoObject?.cipher
                    if (current == null || cipher == null) {
                        answer(callback, failure("failed"))
                        return
                    }
                    try {
                        when (current) {
                            Job.UNLOCK -> answer(
                                callback,
                                JSONObject().put("ok", true).put("token", TokenVault.read(this@MainActivity, cipher))
                            )
                            Job.REGISTER -> {
                                TokenVault.save(this@MainActivity, cipher, token)
                                answer(callback, JSONObject().put("ok", true))
                            }
                        }
                    } catch (e: Exception) {
                        if (current == Job.UNLOCK) TokenVault.clear(this@MainActivity)
                        answer(callback, failure("failed"))
                    }
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    val callback = jobCallback
                    clearJob()
                    answer(callback, failure(errorReason(errorCode)))
                }
            })
    }

    // The site asks for the stored token: fingerprint first, then the token is returned to the page
    private fun startUnlock(callback: String) {
        if (!isOwnUrl(pageUrl)) {
            answer(callback, failure("failed"))
            return
        }
        if (job != null) {
            answer(callback, failure("busy"))
            return
        }
        if (!strongAvailable()) {
            answer(callback, failure("unavailable"))
            return
        }
        val cipher: Cipher = try {
            TokenVault.decryptCipher(this) ?: run {
                answer(callback, failure("not_registered"))
                return
            }
        } catch (e: KeyPermanentlyInvalidatedException) {
            // Fingerprints or faces changed: the key is gone, so the token is useless
            TokenVault.clear(this)
            answer(callback, failure("not_registered"))
            return
        } catch (e: Exception) {
            answer(callback, failure("failed"))
            return
        }

        job = Job.UNLOCK
        jobCallback = callback
        showPrompt(
            promptInfo("Tejodhar sign-in", "Use your fingerprint or face to sign in", "Use username & password"),
            cipher
        )
    }

    // The site sends a new token after "Enable on this phone": save it behind a fingerprint
    private fun startRegister(token: String, callback: String) {
        if (!isOwnUrl(pageUrl)) {
            answer(callback, failure("failed"))
            return
        }
        if (job != null) {
            answer(callback, failure("busy"))
            return
        }
        if (!strongAvailable()) {
            answer(callback, failure("unavailable"))
            return
        }
        if (token.length !in 20..200) {
            answer(callback, failure("failed"))
            return
        }
        val cipher: Cipher = try {
            TokenVault.encryptCipher()
        } catch (e: Exception) {
            answer(callback, failure("failed"))
            return
        }

        job = Job.REGISTER
        jobCallback = callback
        jobToken = token
        showPrompt(
            promptInfo("Turn on fingerprint sign-in", "Confirm to link this phone to your account", "Not now"),
            cipher
        )
    }

    // Opens the fingerprint prompt. If the system refuses, the page still gets an answer.
    private fun showPrompt(info: BiometricPrompt.PromptInfo, cipher: Cipher) {
        try {
            biometricPrompt.authenticate(info, BiometricPrompt.CryptoObject(cipher))
        } catch (e: Exception) {
            val callback = jobCallback
            clearJob()
            answer(callback, failure("failed"))
        }
    }

    // Sends a result to the page's window. Callback names come from index.php and are checked here.
    private fun answer(callback: String, result: JSONObject) {
        if (!Regex("^__bioCb[A-Za-z0-9]{1,40}$").matches(callback)) return
        runOnUiThread {
            webView.evaluateJavascript("window['$callback'] && window['$callback']($result);", null)
        }
    }

    private fun failure(reason: String): JSONObject =
        JSONObject().put("ok", false).put("error", reason)

    // Error codes that index.php understands (see bioLogin / bioEnable there)
    private fun errorReason(code: Int): String = when (code) {
        BiometricPrompt.ERROR_NEGATIVE_BUTTON,
        BiometricPrompt.ERROR_USER_CANCELED,
        BiometricPrompt.ERROR_CANCELED -> "cancelled"
        BiometricPrompt.ERROR_LOCKOUT,
        BiometricPrompt.ERROR_LOCKOUT_PERMANENT -> "locked"
        BiometricPrompt.ERROR_NO_BIOMETRICS,
        BiometricPrompt.ERROR_HW_UNAVAILABLE,
        BiometricPrompt.ERROR_HW_NOT_PRESENT -> "unavailable"
        else -> "failed"
    }

    private fun clearJob() {
        job = null
        jobCallback = ""
        jobToken = ""
    }

    private fun strongAvailable(): Boolean =
        BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
            BiometricManager.BIOMETRIC_SUCCESS

    // Prompts that use a CryptoObject only accept strong biometrics
    private fun promptInfo(title: String, subtitle: String, negative: String): BiometricPrompt.PromptInfo =
        BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setNegativeButtonText(negative)
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()

    private fun isOwnHost(host: String?): Boolean =
        host != null && (host == "tejodhar.in" || host.endsWith(".tejodhar.in"))

    private fun isOwnUrl(url: String?): Boolean = url != null && isOwnHost(Uri.parse(url).host)

    private fun openExternal(uri: Uri): Boolean {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(applicationContext, "No app found to open this link", Toast.LENGTH_SHORT).show()
        }
        return true
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
