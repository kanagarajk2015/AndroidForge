TEJODHAR BIOMETRIC BRIDGE FIX
=============================

What changed
------------
1. Exposes the same Android biometric bridge as both:
   - window.TejodharBio
   - window.bioNative
   This supports either naming convention in the website JavaScript.
2. Adds the TejodharApp/1.3 WebView user-agent marker while preserving
   TejodharAppNative/1.1.

Files
-----
Replace your app's MainActivity.kt with the included file.
TokenVault.kt, activity_main.xml and build.gradle.kts are retained unchanged.

Important
---------
This ZIP contains Android source files, not a compiled APK and not the PHP
website source. Rebuild and install the APK after replacing MainActivity.kt.

If Settings still displays "Biometric login is not available here", send the
website's index.php (or the PHP ZIP containing the biometric login JavaScript).
The website-side detector and callback names must match the Android bridge.

Security
--------
Do not expose the bridge to arbitrary websites. Keep the WebView restricted to
tejodhar.in and its trusted subdomains. Review camera/microphone permissions
separately before release.
