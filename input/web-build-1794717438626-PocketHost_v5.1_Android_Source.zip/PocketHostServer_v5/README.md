# PocketHost Server v5.0 — Android starter

An Android-hosted **local static website server** and a GitHub Actions APK build pipeline.
Designed as the foundation for the PocketHost project. No Termux is required.

## Current implemented scope
- Android foreground service keeps the HTTP server active while the app is backgrounded (subject to Android battery/background restrictions).
- HTTP server listens on port `8080` on the device network interfaces.
- Serves files from the app's private `files/www` directory.
- Creates a default `index.html` on first launch.
- Basic path traversal protection and GET/HEAD-only request handling.
- Simple control panel with Start / Stop and website folder creation.
- GitHub Actions builds a debug APK on push or manual workflow dispatch.

## Not implemented in this starter
PHP execution, MySQL/MariaDB daemon, Python, Rust, Ruby, FTP, multi-tenant cPanel, registrar integration, authoritative DNS, public certificate issuance, automatic backups, and public internet ingress are **not included**. The dashboard deliberately reports these as unavailable instead of pretending they work.

## Build on GitHub
1. Create a repository named `PocketHostServer` (or upload this folder to your existing repository).
2. Push the contents to the `main` branch.
3. Open **Actions → Build PocketHost Android APK → Run workflow**.
4. Download the `PocketHostServer-debug` artifact from the completed workflow.
5. Install the APK on your Android phone.

You can also build locally with JDK 17 and Gradle:
```bash
gradle :app:assembleDebug
```

## Test the static server
1. Install and open the app.
2. Tap **Start server**.
3. From the phone, open `http://127.0.0.1:8080`.
4. From another device on the same Wi-Fi, open `http://PHONE_LAN_IP:8080` if the router/firewall allows device-to-device traffic.

## Important deployment constraints
- Android may stop long-running work due to battery optimization, thermal limits, memory pressure, or vendor power management. Keep the app unrestricted in battery settings for longer sessions.
- A public hosting service needs a stable public ingress endpoint. Most mobile networks use carrier-grade NAT and block inbound ports; port forwarding on Wi-Fi does not solve mobile-network CGNAT.
- A real hosting platform needs isolated per-site processes/containers, resource limits, authentication, abuse controls, database lifecycle management, and security patching. Do not expose this starter server directly to the public internet.
- Domain registration and nameserver delegation require a registrar or DNS provider. TLS certificates require a publicly reachable validation path or DNS challenge and secure private-key storage.
- MySQL is a server daemon, not the same as Android's built-in SQLite database.

## Next engineering milestones
1. Bundle and validate an ARM64 PHP runtime and FastCGI process manager.
2. Add MariaDB only after proving a stable ARM64 Android build, data durability, backup and recovery.
3. Add isolated Python/Ruby runtimes and a Rust toolchain (large storage and memory footprint).
4. Add authenticated admin API, per-site users, quotas, logs, backups and file uploads.
5. Add a public ingress/tunnel or a remote Linux host for domains, DNS and HTTPS.
6. Implement the cPanel-style UI only after the backend services are real and secured.

## Security
This is a development starter, not a production shared-hosting platform. Do not put confidential or customer data on it.


## v5.1 app dashboard upgrade
- Native in-app dashboard with Dashboard / Websites / Files navigation.
- Create multiple isolated static site folders.
- Browse each site's top-level files, create new files, upload files through Android document picker, edit text-based web files, and delete files.
- Preview a site inside the app using an embedded WebView.
- Site URLs use `http://127.0.0.1:8080/<site-name>/`.

The file manager stores files in the app's private storage. Uninstalling the app removes this private data unless separately exported/backed up. The editor intentionally limits editable file types and file size to avoid loading large/binary files into memory.

PHP and database files may be uploaded/stored but are not executed. PHP/MySQL and other language runtimes remain future milestones.
