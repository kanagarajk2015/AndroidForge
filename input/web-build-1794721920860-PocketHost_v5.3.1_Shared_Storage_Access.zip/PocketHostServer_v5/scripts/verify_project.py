from pathlib import Path
root = Path(".")
main = (root / "app/src/main/java/com/pockethost/server/MainActivity.kt").read_text()
storage = (root / "app/src/main/java/com/pockethost/server/SharedStorageManager.kt").read_text()
manifest = (root / "app/src/main/AndroidManifest.xml").read_text()
gradle = (root / "app/build.gradle.kts").read_text()
assert "OpenDocumentTree" in main
assert "takePersistableUriPermission" in main
assert "Import folder" in main and "Export website" in main
assert "DocumentFile.fromTreeUri" in storage
assert "importFolder" in storage and "exportWebsite" in storage
assert "androidx.documentfile:documentfile:1.0.1" in gradle
assert "MANAGE_EXTERNAL_STORAGE" not in manifest
assert "READ_EXTERNAL_STORAGE" not in manifest
assert "versionName = \"5.3.1\"" in gradle
print("PocketHost v5.3.1 shared-storage source checks: PASS")
