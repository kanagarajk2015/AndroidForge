package com.example.colourlauncher.ui

import android.os.Build
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.Accent
import com.example.colourlauncher.data.IconPackInfo
import com.example.colourlauncher.data.IconShape
import com.example.colourlauncher.data.LauncherSettings
import com.example.colourlauncher.data.LauncherStyle
import com.example.colourlauncher.data.ThemeMode

/** Bottom sheet for theme, wallpaper, icon pack and the icon grid look. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    settings: LauncherSettings,
    iconPacks: List<IconPackInfo>,
    onChange: ((LauncherSettings) -> LauncherSettings) -> Unit,
    onPickWallpaper: () -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 24.dp, end = 24.dp, bottom = 32.dp),
        ) {
            Text(text = stringResource(R.string.settings_title), style = MaterialTheme.typography.titleLarge)

            Section(stringResource(R.string.settings_style)) {
                LauncherStyle.entries.forEach { style ->
                    FilterChip(
                        selected = settings.style == style,
                        // Picking a style also applies its matching accent and icon shape.
                        // Both can still be changed below afterwards.
                        onClick = {
                            onChange {
                                when (style) {
                                    LauncherStyle.Classic -> it.copy(style = style)
                                    LauncherStyle.Android17 -> it.copy(
                                        style = style,
                                        accent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Accent.Wallpaper else Accent.Blue,
                                        iconShape = IconShape.Circle,
                                    )
                                    LauncherStyle.Windows11 -> it.copy(
                                        style = style,
                                        accent = Accent.Fluent,
                                        iconShape = IconShape.Rounded,
                                    )
                                    LauncherStyle.OxygenOS -> it.copy(
                                        style = style,
                                        accent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Accent.Wallpaper else Accent.Green,
                                        iconShape = IconShape.Circle,
                                        iconSizeDp = 60,
                                    )
                                }
                            }
                        },
                        label = {
                            Text(
                                stringResource(
                                    when (style) {
                                        LauncherStyle.Classic -> R.string.style_classic
                                        LauncherStyle.Android17 -> R.string.style_android17
                                        LauncherStyle.Windows11 -> R.string.style_windows11
                                        LauncherStyle.OxygenOS -> R.string.style_oxygenos
                                    },
                                ),
                            )
                        },
                    )
                }
            }

            Section(stringResource(R.string.settings_wallpaper)) {
                OutlinedButton(onClick = onPickWallpaper) {
                    Text(stringResource(R.string.settings_pick_wallpaper))
                }
            }

            Section(stringResource(R.string.settings_theme)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = settings.themeMode == mode,
                        onClick = { onChange { it.copy(themeMode = mode) } },
                        label = {
                            Text(
                                stringResource(
                                    when (mode) {
                                        ThemeMode.System -> R.string.theme_system
                                        ThemeMode.Light -> R.string.theme_light
                                        ThemeMode.Dark -> R.string.theme_dark
                                    },
                                ),
                            )
                        },
                    )
                }
            }

            Section(stringResource(R.string.settings_accent)) {
                Accent.entries
                    // Wallpaper colours only exist on Android 12 and later.
                    .filter { it != Accent.Wallpaper || Build.VERSION.SDK_INT >= Build.VERSION_CODES.S }
                    .forEach { accent ->
                        FilterChip(
                            selected = settings.accent == accent,
                            onClick = { onChange { it.copy(accent = accent) } },
                            label = {
                                Text(
                                    stringResource(
                                        when (accent) {
                                            Accent.Wallpaper -> R.string.accent_wallpaper
                                            Accent.Blue -> R.string.accent_blue
                                            Accent.Green -> R.string.accent_green
                                            Accent.Pink -> R.string.accent_pink
                                            Accent.Orange -> R.string.accent_orange
                                            Accent.Fluent -> R.string.accent_fluent
                                        },
                                    ),
                                )
                            },
                        )
                    }
            }

            Section(stringResource(R.string.settings_icon_pack)) {
                FilterChip(
                    selected = settings.iconPack.isEmpty(),
                    onClick = { onChange { it.copy(iconPack = "") } },
                    label = { Text(stringResource(R.string.icon_pack_default)) },
                )
                iconPacks.forEach { pack ->
                    FilterChip(
                        selected = settings.iconPack == pack.packageName,
                        onClick = { onChange { it.copy(iconPack = pack.packageName) } },
                        label = { Text(pack.label) },
                    )
                }
            }

            Section(stringResource(R.string.settings_columns)) {
                listOf(4, 5).forEach { count ->
                    FilterChip(
                        selected = settings.columns == count,
                        onClick = { onChange { it.copy(columns = count) } },
                        label = { Text(count.toString()) },
                    )
                }
            }

            Section(stringResource(R.string.settings_icon_shape)) {
                IconShape.entries.forEach { shape ->
                    FilterChip(
                        selected = settings.iconShape == shape,
                        onClick = { onChange { it.copy(iconShape = shape) } },
                        label = {
                            Text(
                                stringResource(
                                    when (shape) {
                                        IconShape.Rounded -> R.string.shape_rounded
                                        IconShape.Circle -> R.string.shape_circle
                                        IconShape.Square -> R.string.shape_square
                                    },
                                ),
                            )
                        },
                    )
                }
            }

            Section(stringResource(R.string.settings_icon_size)) {
                listOf(48 to R.string.size_small, 56 to R.string.size_medium, 64 to R.string.size_large)
                    .forEach { (dp, label) ->
                        FilterChip(
                            selected = settings.iconSizeDp == dp,
                            onClick = { onChange { it.copy(iconSizeDp = dp) } },
                            label = { Text(stringResource(label)) },
                        )
                    }
            }

            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(stringResource(R.string.settings_show_labels), style = MaterialTheme.typography.bodyLarge)
                Switch(
                    checked = settings.showLabels,
                    onCheckedChange = { checked -> onChange { it.copy(showLabels = checked) } },
                )
            }
        }
    }
}

/** A titled row of chips. The row scrolls sideways so long lists (icon packs) never wrap off screen. */
@Composable
private fun Section(title: String, content: @Composable RowScope.() -> Unit) {
    Spacer(Modifier.height(16.dp))
    Text(text = title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(8.dp))
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        content = content,
    )
}
