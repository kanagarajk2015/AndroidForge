package com.tejodhar.mobilespeaker
import android.app.Activity
import android.os.Bundle
import android.media.*
import android.widget.*
import android.view.Gravity
import java.net.*
import java.io.*
import java.security.MessageDigest
import kotlin.concurrent.thread

class MainActivity: Activity() {
 private var server: ServerSocket?=null
 private var audio: AudioTrack?=null
 private lateinit var info: TextView
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val box=LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER; setPadding(24,30,24,30) }
  box.addView(TextView(this).apply { text="MOBILE SPEAKER"; textSize=26f; gravity=Gravity.CENTER })
  info=TextView(this).apply { text="Start the Wi-Fi receiver"; textSize=16f; gravity=Gravity.CENTER }
  box.addView(info)
  box.addView(Button(this).apply { text="START WI-FI SPEAKER"; setOnClickListener { startReceiver() } })
  box.addView(TextView(this).apply { text="Connect both devices to the same Wi-Fi. Open the address shown above in Chrome on your computer, choose a tab/screen, enable Share audio, then start streaming.\n\nBluetooth: Most Android phones can transmit Bluetooth audio but cannot receive it as a speaker. Android does not provide ordinary apps a public API to enable Bluetooth A2DP Sink on unsupported phones. Wi-Fi receiver is supported here."; textSize=14f })
  setContentView(box)
 }
 private fun startReceiver() {
  if(server!=null)return
  try {
   server=ServerSocket(8765)
   val ip=NetworkInterface.getNetworkInterfaces().toList().flatMap{it.inetAddresses.toList()}.firstOrNull{!it.isLoopbackAddress && it is Inet4Address}?.hostAddress ?: "PHONE-IP"
   info.text="Running\nhttp://$ip:8765"
   thread {
    while(server!=null) try { val c=server!!.accept(); thread { handle(c) } } catch(_:Exception) { break }
   }
  } catch(e:Exception) { info.text="Server error: ${e.message}" }
 }
 private fun handle(c:Socket) {
  try {
   val input=BufferedInputStream(c.getInputStream()); val output=c.getOutputStream()
   val head=readHeader(input)
   if(head.contains("Upgrade: websocket",true)) {
    val key=Regex("Sec-WebSocket-Key:\\s*(.+)",RegexOption.IGNORE_CASE).find(head)!!.groupValues[1].trim()
    val hash=MessageDigest.getInstance("SHA-1").digest((key+"258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toByteArray())
    val accept=android.util.Base64.encodeToString(hash,android.util.Base64.NO_WRAP)
    output.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: $accept\r\n\r\n").toByteArray())
    val min=AudioTrack.getMinBufferSize(44100,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT)
    audio=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()).setAudioFormat(AudioFormat.Builder().setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()).setBufferSizeInBytes((min*4).coerceAtLeast(8192)).setTransferMode(AudioTrack.MODE_STREAM).build()
    audio?.play()
    while(true) {
     val b1=input.read(); if(b1<0)break
     val b2=input.read(); if(b2<0)break
     val op=b2 and 15; var len=(b2 and 127).toLong()
     if(len==126L)len=((readByte(input).toLong() shl 8) or readByte(input).toLong())
     else if(len==127L){len=0;repeat(8){len=(len shl 8) or readByte(input).toLong()}}
     val masked=(b2 and 128)!=0; val mask=if(masked)ByteArray(4).also{readFully(input,it)}else ByteArray(0)
     if(len>1000000)break
     val payload=ByteArray(len.toInt());readFully(input,payload)
     if(masked)for(i in payload.indices)payload[i]=(payload[i].toInt() xor mask[i%4].toInt()).toByte()
     if(op==8)break
     if(op==2)audio?.write(payload,0,payload.size,AudioTrack.WRITE_BLOCKING)
    }
   } else {
    val html=PAGE.toByteArray()
    output.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: ${html.size}\r\nConnection: close\r\n\r\n").toByteArray());output.write(html);output.flush()
   }
  } catch(_:Exception) {} finally { try{audio?.stop();audio?.release()}catch(_:Exception){};audio=null;try{c.close()}catch(_:Exception){} }
 }
 private fun readHeader(i:InputStream):String { val o=ByteArrayOutputStream();var s=0;while(o.size()<8192){val b=i.read();if(b<0)break;o.write(b);s=when{s==0&&b==13->1;s==1&&b==10->2;s==2&&b==13->3;s==3&&b==10->4;b==13->1;else->0};if(s==4)break};return o.toString("UTF-8") }
 private fun readByte(i:InputStream)=i.read().also{if(it<0)throw EOFException()}
 private fun readFully(i:InputStream,b:ByteArray){var p=0;while(p<b.size){val n=i.read(b,p,b.size-p);if(n<0)throw EOFException();p+=n}}
 override fun onDestroy(){try{server?.close()}catch(_:Exception){};server=null;super.onDestroy()}
 companion object {
  private val PAGE = """<!doctype html><html><meta name="viewport" content="width=device-width"><body style="font:18px Arial;background:#101827;color:white;padding:24px"><h2>Mobile Speaker</h2><p>On desktop Chrome choose a tab or screen and enable Share audio.</p><button id="go">Start sharing audio</button><button id="end">Stop</button><p id="s">Ready</p><script>
  let ws,st,ctx,src,node;const status=document.getElementById('s');
  document.getElementById('go').onclick=async()=>{try{st=await navigator.mediaDevices.getDisplayMedia({video:true,audio:true});st.getVideoTracks().forEach(t=>t.stop());if(!st.getAudioTracks().length)throw Error('Select a tab and enable Share audio');ws=new WebSocket('ws://'+location.host+'/stream');ws.onopen=()=>{ctx=new AudioContext({sampleRate:44100});src=ctx.createMediaStreamSource(new MediaStream(st.getAudioTracks()));node=ctx.createScriptProcessor(4096,1,1);node.onaudioprocess=e=>{if(ws.readyState!==1)return;let a=e.inputBuffer.getChannelData(0),p=new Int16Array(a.length);for(let i=0;i<a.length;i++)p[i]=Math.max(-32768,Math.min(32767,a[i]*32767));ws.send(p.buffer)};src.connect(node);node.connect(ctx.destination);status.textContent='Streaming audio'};}catch(e){status.textContent=e.message}};
  document.getElementById('end').onclick=()=>{if(ws)ws.close();if(st)st.getTracks().forEach(t=>t.stop());if(node)node.disconnect();if(ctx)ctx.close();status.textContent='Stopped'};
  </script></body></html>"""
 }
}
