# Mobile Speaker Android project

This Android Studio project provides a local Wi-Fi audio receiver. The phone serves a small sender page on port 8765 and receives browser audio over WebSocket, playing mono 44.1 kHz PCM through Android AudioTrack.

## Use
1. Open this folder in Android Studio with JDK 17.
2. Sync Gradle and build: Build > Build APK(s).
3. Install on the Android phone.
4. Connect phone and computer to the same Wi-Fi.
5. Start the receiver and open the displayed http://PHONE-IP:8765 address in desktop Chrome.
6. Press Start sharing audio. Select a Chrome tab or screen and enable Share audio.

Desktop Chrome tab audio capture is the intended sender. Mobile browser support varies. Keep the app open while using it. Use only on a trusted local network; this starter has no encryption or authentication.

## Bluetooth limitation
Most Android phones are Bluetooth A2DP sources, not sinks. Ordinary third-party apps cannot activate the hidden/system A2DP Sink profile on unsupported phones. Therefore Wi-Fi audio reception is implemented; Bluetooth phone-to-phone reception cannot be guaranteed by a normal Android app. You can pair a Bluetooth speaker to this phone for audio output.

Minimum Android 8.0 (API 26). Compile SDK 35. No prebuilt APK is included.
