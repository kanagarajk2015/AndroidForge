# Tejodhar AndroidForge — White Screen Diagnostic Fix

This revision updates the Android WebView wrapper for the live portal:
- https://tejodhar.in/
- https://www.tejodhar.in/

## Changes
- Better WebView initialization, DOM storage, responsive viewport and cookies.
- Removes the Android WebView `; wv` user-agent marker to improve compatibility with hosting/WAF rules that reject embedded browsers.
- Adds a loading progress indicator.
- Adds alternate-host retry when the primary host fails.
- Displays a readable error panel instead of leaving a blank white screen.
- Logs JavaScript console messages under `TejodharWeb`.
- Keeps SSL certificate validation strict; it does not ignore certificate errors.
- Preserves file chooser, download, camera and microphone support.

## Build
Open/import this folder in AndroidForge, build a new APK, uninstall the old APK, install the new APK and test on mobile data and Wi-Fi.

## Important
The previous log ZIP available in this conversation was from the earlier compilation failure, not a runtime WebView white-screen trace. This source update addresses common WebView blank-screen causes and adds diagnostics, but the exact runtime cause cannot be confirmed until the new APK is tested or a fresh runtime log/screenshot is supplied.


## Biometric login, camera and microphone update
- Adds AndroidX BiometricPrompt for fingerprint / strong biometric and device screen-lock fallback.
- Login credentials are saved only after the user explicitly confirms and authenticates; they are encrypted with an AES-GCM key held by Android Keystore.
- On a later launch, biometric authentication decrypts and attempts to fill the portal login form.
- Login-field detection is generic (username/email plus password input). If the portal uses custom non-standard login controls, its exact field selectors may need adjustment.
- Adds biometric manifest permissions and optional camera/microphone hardware declarations.
- WebRTC camera/microphone requests from the trusted `tejodhar.in` origins trigger Android runtime permission prompts. Other origins are denied/opened externally.
- Android permissions do not by themselves create voice/video calling; the website's calling implementation must request the matching WebRTC media devices.
- Requires an internet connection and AndroidX dependency resolution during build. Build the APK in AndroidForge, install it, then test on a real phone with fingerprint enrolled.


## Build-log correction (2026-11-04)
The AndroidForge log showed two Java compile errors: AndroidX BiometricPrompt requires a FragmentActivity, but MainActivity extended the platform Activity. MainActivity now extends androidx.fragment.app.FragmentActivity and imports that class. This addresses both reported constructor errors.


## Review of uploaded AndroidForge-app-debug (9).apk
Static inspection of the uploaded APK confirmed that it includes AndroidX Biometric classes, TejodharBiometric JavaScript bridge strings, Android Keystore / AES-GCM credential encryption strings, and CAMERA / RECORD_AUDIO permission handling strings. The APK's injected login-helper JavaScript had a scope error: it referenced `p` outside the callback where `p` was declared. That can stop the "Enable fingerprint login" control from being inserted. This source revision replaces that helper with an explicit button that safely locates the username and password fields at click time.

## Final device test checklist
1. Install on a real Android phone with a screen lock and fingerprint enrolled.
2. Open the Tejodhar login page and verify "Enable fingerprint login" appears below the password field.
3. Enter username and password, tap the button, approve the save prompt, and complete biometric authentication.
4. Close and reopen the app; biometric prompt should appear and, after success, saved login fields should be filled.
5. Test a wrong fingerprint, cancel, and device credential fallback; credentials must not be filled before successful authentication.
6. Open a one-to-one voice call and verify Android asks for microphone permission and two-way audio works.
7. Open a video call and verify camera permission, preview, and two-way audio/video work.
8. Deny each permission once, then grant it from Android App Info and retry.
9. Test file upload/download and navigation.

Important: APK static inspection is not a substitute for running the app on a physical device. Camera/microphone access also depends on the website's calling code requesting WebRTC media (`getUserMedia`) and a functioning signaling/call service. This ZIP is corrected Android source; it is not a newly compiled APK. Build it in AndroidForge and provide the resulting build log if Gradle reports errors.

Additional compatibility hardening in this revision:
- Uses biometric-only authentication on Android 6–10, and allows device-credential fallback together with biometrics on Android 11+.
- Grants only WebView camera and microphone capture resources, and rejects unrecognized web permission resources.
