package co.median.android;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.JavascriptInterface;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

/** Local, on-device notifications. Does not require Firebase or a network connection. */
public final class LocalNotificationBridge {
    private static final String CHANNEL_ID = "tejodhar_local_alerts";
    private final MainActivity activity;

    LocalNotificationBridge(MainActivity activity) {
        this.activity = activity;
        ensureChannel(activity);
    }

    /** JavaScript API: window.TejodharLocalNotifications.show(title, body) */
    @JavascriptInterface
    public void show(String title, String body) {
        if (title == null || title.trim().isEmpty()) title = "Tejodhar Constructions";
        if (body == null || body.trim().isEmpty()) body = "You have a new reminder.";
        final String safeTitle = title.trim().substring(0, Math.min(title.trim().length(), 100));
        final String safeBody = body.trim().substring(0, Math.min(body.trim().length(), 1000));
        activity.runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(activity,
                    Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                activity.requestLocalNotificationPermission();
                return;
            }
            ensureChannel(activity);
            Intent open = new Intent(activity, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int id = (int) (System.currentTimeMillis() & 0x7fffffff);
            PendingIntent pending = PendingIntent.getActivity(activity, id, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            NotificationCompat.Builder notification = new NotificationCompat.Builder(activity, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_stat_onesignal_default)
                    .setContentTitle(safeTitle)
                    .setContentText(safeBody)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(safeBody))
                    .setContentIntent(pending)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH);
            try {
                NotificationManagerCompat.from(activity).notify(id, notification.build());
            } catch (SecurityException ignored) {
                // User disabled notifications in Android settings.
            }
        });
    }

    /** JavaScript API: window.TejodharLocalNotifications.requestPermission() */
    @JavascriptInterface
    public void requestPermission() {
        activity.requestLocalNotificationPermission();
    }

    private static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                "Tejodhar reminders", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Local reminders and alerts from the Tejodhar app");
        manager.createNotificationChannel(channel);
    }
}
