Tejodhar push notifications (Firebase Cloud Messaging)

WHO GETS WHAT
- Employee applies leave            -> Admin(s) + the Authorised Manager(s) of that employee's project
- Employee applies missed attendance / forgot punch -> Admin(s)
- Leave approved / rejected         -> that employee (rejection shows the reason)
- Missed attendance approved / rejected -> that employee (rejection shows the reason)
- Team chat message                 -> everyone else logged in on a phone (not the sender; hidden while the app is open)
Rejecting now asks for a reason (required); it is also shown in the employee's history.
Tapping a notification opens the app on the right screen (chat / approvals / leave / requests).

ONE-TIME SETUP (about 10 minutes)
1. console.firebase.google.com -> Add project (free) -> Add Android app.
   Package name must be EXACTLY the app's applicationId (app/build.gradle -> applicationId, currently co.median.android.qdqjelz).
   If your build tool changes the package name, use that one.
2. Download google-services.json  -> put it in the  app/  folder (next to app/build.gradle). Without it the APK still builds, but has no push.
3. Firebase -> Project settings -> Service accounts -> Generate new private key.
   Rename the downloaded file to  fcm_service_account.json  and upload it to the website folder next to index.php
   (htaccess.txt now blocks it from download - make sure your live .htaccess has that block).
4. Upload the new index.php (and the updated .htaccess), rebuild the APK and install it.
5. Open the app, log in as Admin, allow notifications, wait ~10 s, then open  https://<your-site>/index.php?tool=push_test
   It prints a 5-step checklist and sends a test notification to your phone.

NOTES
- Needs the MySQL database (same as Team Chat). Table app_push is created automatically.
- Phones are registered after login and removed on logout. A phone that is never logged out keeps receiving until its session ends.
- Plain browsers (not the Android app) do not get pushes.
- iPhone is not covered (this project is the Android wrapper).
- Source files: website/index.php, PushBridge.java, TejodharMessagingService.java, PushTapActivity.java, AndroidManifest.xml, build.gradle files.

=====================================================================
END-TO-END ENCRYPTED TEAM CHAT
- Messages, photos and documents are encrypted in the phone/browser (AES-256-GCM) before they leave it. The server, MySQL and Cloudinary
  only ever hold ciphertext. Old (pre-update) messages stay readable as plain text; new ones are encrypted.
- Each device makes its own key pair (private key stays on the device). An ADMIN device hands the shared chat key to every other device
  automatically. The first time ever, the first admin who opens the chat creates the key.
  => After updating, an admin must open the app/portal once. Until then employees see "Setting up secure chat...".
  => A new phone, cleared app data or a new browser also waits for an admin to open the app once; old messages then become readable again.
- Chat push notifications show only "<sender>: New message" (the server cannot read the text).
- Not covered: a malicious server operator who edits the database/code could still add their own device and receive the key. This
  protects against database leaks, hosting/Cloudinary staff and backups, not against whoever controls index.php. Also no key rotation yet:
  anyone who ever received the key (e.g. a stolen unlocked phone) keeps it.
- Attachments are decrypted on the phone; documents are saved through a download (Android may ask where to save).
- Old app/page versions cannot send chat messages any more and show "refresh to update".

LOCAL ANDROID NOTIFICATIONS (NO FIREBASE REQUIRED)
=================================================
The Android app now exposes a native JavaScript bridge for on-device notifications.
It can display a notification while the app is backgrounded, after the page asks Android to show it.

From the Tejodhar portal page:
  window.TejodharLocalNotifications.requestPermission();
  window.TejodharLocalNotifications.show('Attendance reminder', 'Please mark your attendance.');

Call show() after notification permission has been granted on Android 13 and newer. If permission
is denied in Android settings, Android will suppress notifications. These are local notifications:
they do not arrive from the server automatically, and do not require Firebase. The portal must call
the bridge when a local event/reminder should be displayed. Existing Firebase push support remains
unchanged.
