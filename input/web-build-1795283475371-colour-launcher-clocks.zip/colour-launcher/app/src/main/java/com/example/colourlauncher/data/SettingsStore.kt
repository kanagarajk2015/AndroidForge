package com.example.colourlauncher.data

import android.content.Context

/** Saves [LauncherSettings] in SharedPreferences. Bad or missing values fall back to defaults. */
class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): LauncherSettings {
        val d = LauncherSettings()
        return LauncherSettings(
            columns = prefs.getInt(KEY_COLUMNS, d.columns).coerceIn(4, 5),
            iconShape = readEnum(KEY_SHAPE, d.iconShape),
            iconSizeDp = prefs.getInt(KEY_SIZE, d.iconSizeDp).coerceIn(48, 64),
            showLabels = prefs.getBoolean(KEY_LABELS, d.showLabels),
            themeMode = readEnum(KEY_THEME, d.themeMode),
            accent = readEnum(KEY_ACCENT, d.accent),
            iconPack = prefs.getString(KEY_ICON_PACK, "") ?: "",
            style = readEnum(KEY_STYLE, d.style),
            clockStyle = readEnum(KEY_CLOCK, d.clockStyle),
            lockHome = prefs.getBoolean(KEY_LOCK_HOME, d.lockHome),
            showBadges = prefs.getBoolean(KEY_BADGES, d.showBadges),
            showArtwork = prefs.getBoolean(KEY_ARTWORK, d.showArtwork),
            wallpaperDim = prefs.getFloat(KEY_DIM, d.wallpaperDim).coerceIn(0f, 0.6f),
            aiKeyOverride = prefs.getBoolean(KEY_AI_ON, d.aiKeyOverride),
            aiKeySingle = readEnum(KEY_AI_SINGLE, d.aiKeySingle),
            aiKeyDouble = readEnum(KEY_AI_DOUBLE, d.aiKeyDouble),
            aiKeyLong = readEnum(KEY_AI_LONG, d.aiKeyLong),
            aiKeyApp = prefs.getString(KEY_AI_APP, "") ?: "",
            aiKeyCode = prefs.getInt(KEY_AI_CODE, 0),
            aiKeyScanCode = prefs.getInt(KEY_AI_SCAN, 0),
            aiKeyPrompted = prefs.getBoolean(KEY_AI_PROMPTED, false),
        )
    }

    fun save(s: LauncherSettings) {
        prefs.edit()
            .putInt(KEY_COLUMNS, s.columns)
            .putString(KEY_SHAPE, s.iconShape.name)
            .putInt(KEY_SIZE, s.iconSizeDp)
            .putBoolean(KEY_LABELS, s.showLabels)
            .putString(KEY_THEME, s.themeMode.name)
            .putString(KEY_ACCENT, s.accent.name)
            .putString(KEY_ICON_PACK, s.iconPack)
            .putString(KEY_STYLE, s.style.name)
            .putString(KEY_CLOCK, s.clockStyle.name)
            .putBoolean(KEY_LOCK_HOME, s.lockHome)
            .putBoolean(KEY_BADGES, s.showBadges)
            .putBoolean(KEY_ARTWORK, s.showArtwork)
            .putFloat(KEY_DIM, s.wallpaperDim)
            .putBoolean(KEY_AI_ON, s.aiKeyOverride)
            .putString(KEY_AI_SINGLE, s.aiKeySingle.name)
            .putString(KEY_AI_DOUBLE, s.aiKeyDouble.name)
            .putString(KEY_AI_LONG, s.aiKeyLong.name)
            .putString(KEY_AI_APP, s.aiKeyApp)
            .putInt(KEY_AI_CODE, s.aiKeyCode)
            .putInt(KEY_AI_SCAN, s.aiKeyScanCode)
            .putBoolean(KEY_AI_PROMPTED, s.aiKeyPrompted)
            .apply()
    }

    private inline fun <reified T : Enum<T>> readEnum(key: String, default: T): T =
        runCatching { enumValueOf<T>(prefs.getString(key, "") ?: "") }.getOrDefault(default)

    private companion object {
        const val KEY_COLUMNS = "columns"
        const val KEY_SHAPE = "icon_shape"
        const val KEY_SIZE = "icon_size_dp"
        const val KEY_LABELS = "show_labels"
        const val KEY_THEME = "theme_mode"
        const val KEY_ACCENT = "accent"
        const val KEY_ICON_PACK = "icon_pack"
        const val KEY_STYLE = "style"
        const val KEY_CLOCK = "clock_style"
        const val KEY_LOCK_HOME = "lock_home"
        const val KEY_BADGES = "show_badges"
        const val KEY_ARTWORK = "show_artwork"
        const val KEY_DIM = "wallpaper_dim"
        const val KEY_AI_ON = "ai_key_on"
        const val KEY_AI_SINGLE = "ai_key_single"
        const val KEY_AI_DOUBLE = "ai_key_double"
        const val KEY_AI_LONG = "ai_key_long"
        const val KEY_AI_APP = "ai_key_app"
        const val KEY_AI_CODE = "ai_key_code"
        const val KEY_AI_SCAN = "ai_key_scan"
        const val KEY_AI_PROMPTED = "ai_key_prompted"
    }
}
