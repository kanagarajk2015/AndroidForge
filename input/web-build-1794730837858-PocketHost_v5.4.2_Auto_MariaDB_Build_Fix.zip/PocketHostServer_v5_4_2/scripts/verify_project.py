from pathlib import Path
root = Path(".")
main = (root / "app/src/main/java/com/pockethost/server/MainActivity.kt").read_text()
php = (root / "app/src/main/java/com/pockethost/server/PhpRuntimeManager.kt").read_text()
db = (root / "app/src/main/java/com/pockethost/server/MariaDbManager.kt").read_text()
secrets = (root / "app/src/main/java/com/pockethost/server/DbSecretStore.kt").read_text()
gradle = (root / "app/build.gradle.kts").read_text()
workflow = (root / ".github/workflows/android.yml").read_text()
builder = (root / "scripts/build_mariadb_rootfs.py").read_text()
assert "php -v" in main and "phpInstalled = success" in main
assert "mysqlExtensionStatus()" in php
assert 'listOf("Dashboard", "Websites", "Files", "Databases")' in main
assert "MariaDbManager" in main and "Create database" in main
assert "127.0.0.1:$PORT" in db and "--bind-address=127.0.0.1" in db
assert "CREATE DATABASE" in db and "DROP DATABASE" in db
assert "CREATE USER" in db and "GRANT ALL PRIVILEGES" in db
assert "lastDbCredentials" in main and "DatabaseCredential" in main
assert "AndroidKeyStore" in secrets and "AES/GCM/NoPadding" in secrets
assert "mariadb-rootfs.tar.gz" in db and "SHA-256 mismatch" in db
assert "verifyMariaDbAssets" in gradle
assert "buildMariaDbRuntime" in gradle
assert "dependsOn(buildMariaDbRuntime)" in gradle
assert 'commandLine("python3", mariadbBuilder.absolutePath)' in gradle
assert "actual four ELF bytes" not in builder or 'b"\\x7fELF"' in builder
assert "PINNED_MARIADB_VERSION" in builder and "SHA256" in builder
assert "build_mariadb_rootfs.py" in workflow and "mariadb-rootfs.tar.gz" in workflow
assert "assets/mariadb-rootfs.tar.gz" in workflow
assert "PocketHostServer-v5.4.2-debug" in workflow
assert "org.mariadb.jdbc:mariadb-java-client:3.5.6" in gradle
assert 'versionName = "5.4.2"' in gradle
print("PocketHost v5.4.2 source smoke checks: PASS")
