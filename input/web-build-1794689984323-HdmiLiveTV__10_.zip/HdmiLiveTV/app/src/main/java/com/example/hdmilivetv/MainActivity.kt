package com.example.hdmilivetv

import android.app.Activity
import android.content.Intent
import android.media.AudioManager
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.media.tv.TvTrackInfo
import android.media.tv.TvView
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var tvView: TvView
    private lateinit var bar: LinearLayout
    private lateinit var status: TextView
    private lateinit var quality: TextView
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var tvm: TvInputManager
    private lateinit var audio: AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private val hideBar = Runnable { bar.visibility = View.GONE; status.visibility = View.GONE; quality.visibility = View.GONE }

    // HDMI state
    private var hdmiInputs: List<TvInputInfo> = emptyList()
    private val lastState = mutableMapOf<String, Int>()   // inputId -> INPUT_STATE_*
    private var currentInputId: String? = null

    // Digital TV (DVB / ATSC / ISDB tuner) state
    data class Channel(
        val id: Long, val inputId: String, val number: String, val name: String,
        val passthrough: Boolean = false   // true = an HDMI input shown as a channel (H1, H2...)
    )
    private lateinit var channelList: ListView
    private var allChannels: List<Channel> = emptyList()   // everything found by the scan
    private var channels: List<Channel> = emptyList()      // what the list shows (all or favorites)
    private var showFavs = false
    private var favs: MutableSet<String> = mutableSetOf()
    private var channelIndex = 0
    private var onTuner = false
    private var hasTuner = false
    private val REQ_SCAN = 100
    private val digitBuffer = StringBuilder()
    private val commitDigits = Runnable { jumpToTypedChannel() }

    // Fires when an HDMI source is plugged in / unplugged / powered on or off
    private val inputCallback = object : TvInputManager.TvInputCallback() {
        override fun onInputStateChanged(inputId: String, state: Int) {
            val info = hdmiInputs.firstOrNull { it.id == inputId }
            val wasConnected = lastState[inputId] == TvInputManager.INPUT_STATE_CONNECTED
            lastState[inputId] = state
            refreshInputs()
            if (info == null) return
            val nowConnected = state == TvInputManager.INPUT_STATE_CONNECTED
            if (nowConnected && !wasConnected) {
                tuneHdmi(info)                       // new source found: switch silently
            } else if (!nowConnected && wasConnected && currentInputId == inputId) {
                autoSelectSource()                   // source gone: another HDMI, else digital TV
            }
        }
        override fun onInputAdded(inputId: String) = refreshInputs()
        override fun onInputRemoved(inputId: String) = refreshInputs()
        override fun onInputUpdated(inputId: String) = refreshInputs()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvView = findViewById(R.id.tvView)
        bar = findViewById(R.id.bar)
        channelList = findViewById(R.id.channelList)
        status = findViewById(R.id.status)
        quality = findViewById(R.id.quality)
        // Keep the info overlays above the video surface
        listOf<View>(status, quality, bar, channelList).forEach { it.elevation = 20f; it.bringToFront() }
        prefs = getSharedPreferences("tnlive", MODE_PRIVATE)
        favs = prefs.getStringSet("fav", emptySet())!!.toMutableSet()
        enableUhd()
        tvView.setCallback(object : TvView.TvInputCallback() {
            override fun onVideoAvailable(inputId: String) = updateQuality()
            override fun onTracksChanged(inputId: String, tracks: MutableList<TvTrackInfo>) = updateQuality()
            override fun onTrackSelected(inputId: String, type: Int, trackId: String?) = updateQuality()
        })
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        tvm = getSystemService(TV_INPUT_SERVICE) as TvInputManager

        channelList.setOnItemLongClickListener { _, _, pos, _ -> toggleFavorite(pos); true }
        channelList.setOnItemClickListener { _, _, pos, _ -> tuneChannel(pos); hideChannelList() }
        loadChannels()
        refreshInputs()

        autoSelectSource()
        bar.visibility = View.GONE
        if (hasTuner && allChannels.none { !it.passthrough }) {
            showBar()
            flash("No digital channels yet. Choose Scan channels (or press RED).")
        }
    }

    override fun onStart() {
        super.onStart()
        tvm.registerCallback(inputCallback, handler)
        loadChannels()
        refreshInputs()
    }

    override fun onStop() {
        tvm.unregisterCallback(inputCallback)
        super.onStop()
    }

    private fun isConnected(info: TvInputInfo) =
        tvm.getInputState(info.id) == TvInputManager.INPUT_STATE_CONNECTED

    /** Re-reads all inputs and rebuilds the selector bar, marking HDMI ports that have a signal. */
    private fun refreshInputs() {
        val inputs = tvm.tvInputList
        // TvInputInfo.getHdmiDeviceInfo() is a hidden API, so label by the TV's own names
        hdmiInputs = inputs.filter { it.type == TvInputInfo.TYPE_HDMI }.sortedBy { labelFor(it, 0) }
        hdmiInputs.forEach { lastState.getOrPut(it.id) { tvm.getInputState(it.id) } }

        hasTuner = inputs.any { it.type == TvInputInfo.TYPE_TUNER }

        val hadFocus = bar.hasFocus()
        bar.removeAllViews()
        if (hasTuner || channels.isNotEmpty()) {
            addButton("Channel list", false) {
                if (channels.isEmpty()) flash("No channels yet. Choose Scan channels.")
                else showChannelList()
            }
        }
        if (hasTuner) {
            addButton(if (showFavs) "All channels" else "Favorites ★", false) { toggleFavFilter() }
            addButton("Scan channels", false) { startScan() }
            if (allChannels.none { !it.passthrough }) addButton("System Live TV", false) { openSystemLiveTv() }
        }
        if (hadFocus) bar.getChildAt(0)?.requestFocus()
    }

    private fun labelFor(info: TvInputInfo, fallbackNumber: Int): String {
        val custom = info.loadCustomLabel(this)?.toString()
        val label = custom?.takeIf { it.isNotBlank() } ?: info.loadLabel(this)?.toString()
        return label?.takeIf { it.isNotBlank() } ?: "HDMI $fallbackNumber"
    }

    private fun addButton(text: String, dim: Boolean, onClick: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            textSize = 20f
            alpha = if (dim) 0.55f else 1f
            isFocusable = true
            setOnClickListener { onClick(); scheduleHide() }
        }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(16, 0, 16, 0)
        bar.addView(b, lp)
    }

    private fun tuneHdmi(info: TvInputInfo) {
        onTuner = false
        currentInputId = info.id
        tvView.tune(info.id, TvContract.buildChannelUriForPassthroughInput(info.id))
        quality.visibility = View.GONE
    }

    /** Silently picks what to play: an HDMI source that has a signal, otherwise the last digital channel. */
    private fun autoSelectSource() {
        val hdmi = hdmiInputs.firstOrNull { isConnected(it) }
        when {
            hdmi != null -> tuneHdmi(hdmi)
            channels.isNotEmpty() -> tuneChannel(channelIndex)
        }
    }

    /** Reads the scanned digital channels (DVB-T/T2/C/S, ATSC, ISDB, DTMB...) from the TV database. */
    private fun loadChannels() {
        val tunerIds = tvm.tvInputList.filter { it.type == TvInputInfo.TYPE_TUNER }.map { it.id }.toSet()
                val list = mutableListOf<Channel>()
        try {
            contentResolver.query(
                TvContract.Channels.CONTENT_URI,
                arrayOf(
                    TvContract.Channels._ID,
                    TvContract.Channels.COLUMN_INPUT_ID,
                    TvContract.Channels.COLUMN_DISPLAY_NUMBER,
                    TvContract.Channels.COLUMN_DISPLAY_NAME
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val input = c.getString(1) ?: continue
                    if (input !in tunerIds) continue
                    list += Channel(c.getLong(0), input, c.getString(2) ?: "", c.getString(3) ?: "")
                }
            }
        } catch (e: SecurityException) {
            // READ_EPG_DATA not granted on this device
        }
        // Sort naturally by number: 2, 7.1, 7.2, 10, 11 ...
        val digital = list.sortedWith(compareBy({ numPart(it.number, 0) }, { numPart(it.number, 1) }))
        allChannels = digital
        applyChannels()
    }

    private fun isFav(ch: Channel) = ch.id.toString() in favs

    private fun rowText(ch: Channel): String {
        val q = prefs.getString("q_${ch.id}", null)
        return (if (isFav(ch)) "★ " else "    ") + "${ch.number}   ${ch.name}" + (q?.let { "   [$it]" } ?: "")
    }

    /** Builds the on-screen digital TV list (all channels, or favorites only). */
    private fun applyChannels() {
        val currentId = channels.getOrNull(channelIndex)?.id
        channels = if (showFavs) allChannels.filter { isFav(it) } else allChannels
        channelIndex = channels.indexOfFirst { it.id == currentId }.takeIf { it >= 0 } ?: 0
        channelList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, channels.map { rowText(it) })
        if (channels.isNotEmpty()) channelList.setItemChecked(channelIndex, true)
    }

    private fun toggleFavorite(pos: Int) {
        val ch = channels.getOrNull(pos) ?: return
        if (!favs.remove(ch.id.toString())) favs.add(ch.id.toString())
        prefs.edit().putStringSet("fav", HashSet(favs)).apply()
        applyChannels()
        channelList.setSelection(channels.indexOfFirst { it.id == ch.id }.coerceAtLeast(0))
        flash(if (isFav(ch)) "★ Added ${ch.name} to favorites" else "Removed ${ch.name} from favorites")
    }

    private fun toggleFavFilter() {
        if (!showFavs && allChannels.none { isFav(it) }) {
            flash("No favorites yet. Hold OK or press YELLOW on a channel to add one.")
            return
        }
        showFavs = !showFavs
        applyChannels()
        refreshInputs()
        flash(if (showFavs) "Favorites (${channels.size})" else "All channels (${channels.size})")
    }

    /** Shows 4K UHD / Full HD / HD / SD from the real video track of what is playing. */
    private fun updateQuality() {
        val tracks = tvView.getTracks(TvTrackInfo.TYPE_VIDEO) ?: emptyList<TvTrackInfo>()
        val sel = tvView.getSelectedTrack(TvTrackInfo.TYPE_VIDEO)
        val track = tracks.firstOrNull { it.id == sel } ?: tracks.firstOrNull()
        val h = track?.videoHeight ?: 0
        val label = when {
            h >= 2160 -> "4K UHD"
            h >= 1440 -> "2K QHD"
            h >= 1080 -> "Full HD"
            h >= 720 -> "HD"
            h > 0 -> "SD"
            else -> null
        }
        if (label == null || !onTuner) { quality.visibility = View.GONE; return }
        quality.text = "$label  ${track!!.videoWidth}×${track.videoHeight}"
        quality.visibility = View.VISIBLE
        channels.getOrNull(channelIndex)?.let {
            prefs.edit().putString("q_${it.id}", label).apply()
        }
        scheduleHide()
    }

    /** Ultra HD: ask the TV for its highest resolution display mode (e.g. 3840x2160) and keep the screen on. */
    private fun enableUhd() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            val d = windowManager.defaultDisplay
            val modes = d.supportedModes
            val cur = d.mode
            val maxPx = modes.maxOf { it.physicalWidth * it.physicalHeight }
            if (cur.physicalWidth * cur.physicalHeight >= maxPx) return
            val best = modes.filter { it.physicalWidth * it.physicalHeight == maxPx }
                .minByOrNull { Math.abs(it.refreshRate - 60f) } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            window.attributes = lp
        } catch (e: Exception) {
            // keep the TV's current mode
        }
    }

    private fun numPart(number: String, i: Int): Int =
        number.split(Regex("[^0-9]+")).filter { it.isNotEmpty() }.getOrNull(i)?.toIntOrNull() ?: 0

    private fun tuneChannel(index: Int) {
        if (channels.isEmpty()) return
        channelIndex = (index + channels.size) % channels.size
        val ch = channels[channelIndex]
        // On a digital channel CH+/- step this list; on HDMI they are passed to the box (HDMI-CEC)
        onTuner = !ch.passthrough
        currentInputId = ch.inputId
        val uri = if (ch.passthrough) TvContract.buildChannelUriForPassthroughInput(ch.inputId)
                  else TvContract.buildChannelUri(ch.id)
        tvView.tune(ch.inputId, uri)
        channelList.setItemChecked(channelIndex, true)
        flash((if (isFav(ch)) "★ " else "") + "${ch.number}   ${ch.name}")
    }

    /** Typed channel numbers like 5, 12 or 7.1 (use the . or - key for sub-channels). */
    private fun typeDigit(ch: Char) {
        digitBuffer.append(ch)
        status.text = digitBuffer.toString()
        status.visibility = View.VISIBLE
        handler.removeCallbacks(commitDigits)
        handler.postDelayed(commitDigits, 1500)
    }

    private fun jumpToTypedChannel() {
        val typed = digitBuffer.toString().replace('-', '.')
        digitBuffer.clear()
        val hit = allChannels.firstOrNull { it.number.replace('-', '.') == typed }
        if (hit == null) { flash("No channel $typed"); return }
        if (hit !in channels) { showFavs = false; applyChannels() }
        tuneChannel(channels.indexOf(hit))
    }

    /** Opens the TV's own channel-scan screen (DVB-T/T2/C/S, ATSC, ISDB...) for the built-in tuner. */
    private fun startScan() {
        val intent = tvm.tvInputList
            .filter { it.type == TvInputInfo.TYPE_TUNER }
            .firstNotNullOfOrNull { it.createSetupIntent() }
        if (intent == null) {
            flash("Scan not available here. Use TV Settings → Channels → Auto scan.")
            return
        }
        try {
            startActivityForResult(intent, REQ_SCAN)
        } catch (e: Exception) {
            flash("Could not open scan. Use TV Settings → Channels → Auto scan.")
        }
    }

    /** Fallback when this app can't read the channel database: open the TV's own Live Channels app. */
    private fun openSystemLiveTv() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI))
        } catch (e: Exception) {
            flash("System Live TV app not found.")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SCAN) return
        loadChannels()
        refreshInputs()
        val found = allChannels.count { !it.passthrough }
        if (found > 0) {
            flash("$found channels found")
            tuneChannel(0)
            showChannelList()
        } else {
            flash("No channels found or access denied. Try System Live TV.")
        }
    }

    private fun showChannelList() {
        applyChannels()
        channelList.visibility = View.VISIBLE
        channelList.setSelection(channelIndex)
        channelList.requestFocus()
        handler.removeCallbacks(hideBar)
    }

    private fun hideChannelList() {
        channelList.visibility = View.GONE
        scheduleHide()
    }

    override fun onBackPressed() {
        if (channelList.visibility == View.VISIBLE) hideChannelList() else super.onBackPressed()
    }

    /** Banner on screen plus a system toast (the toast stays visible even above hardware video layers). */
    private fun announce(msg: String) {
        flash(msg)
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun flash(msg: String) {
        status.text = msg
        status.visibility = View.VISIBLE
        scheduleHide()
    }

    // Remote control handling
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        // Volume always works
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> { adjustVolume(AudioManager.ADJUST_RAISE); return true }
            KeyEvent.KEYCODE_VOLUME_DOWN -> { adjustVolume(AudioManager.ADJUST_LOWER); return true }
            KeyEvent.KEYCODE_VOLUME_MUTE -> { adjustVolume(AudioManager.ADJUST_TOGGLE_MUTE); return true }
        }
        // While the channel list is open, let the list handle D-pad/OK
        if (channelList.visibility == View.VISIBLE) {
            when (keyCode) {
                KeyEvent.KEYCODE_PROG_YELLOW -> { toggleFavorite(channelList.selectedItemPosition); return true }
                KeyEvent.KEYCODE_PROG_BLUE -> { toggleFavFilter(); return true }
                KeyEvent.KEYCODE_PROG_GREEN, KeyEvent.KEYCODE_GUIDE -> { hideChannelList(); return true }
            }
            return super.onKeyDown(keyCode, event)
        }

        when (keyCode) {
            KeyEvent.KEYCODE_MENU -> { showBar(); return true }
            KeyEvent.KEYCODE_PROG_RED -> if (hasTuner) { startScan(); return true }
            KeyEvent.KEYCODE_PROG_YELLOW ->
                if (onTuner) { channels.getOrNull(channelIndex)?.let { toggleFavorite(channelIndex) }; return true }
            KeyEvent.KEYCODE_PROG_BLUE -> if (hasTuner) { toggleFavFilter(); return true }
            KeyEvent.KEYCODE_PROG_GREEN -> if (channels.isNotEmpty()) { showChannelList(); return true }

            // GUIDE / LIST / DPAD-LEFT open the digital channel list
            KeyEvent.KEYCODE_GUIDE ->
                if (channels.isNotEmpty()) { showChannelList(); return true }
            KeyEvent.KEYCODE_DPAD_LEFT ->
                if (onTuner && bar.visibility != View.VISIBLE) { showChannelList(); return true }

            // On HDMI the channel keys are not consumed, so the TV can pass them on via HDMI-CEC
            KeyEvent.KEYCODE_CHANNEL_UP ->
                if (onTuner) { tuneChannel(channelIndex + 1); return true }
            KeyEvent.KEYCODE_CHANNEL_DOWN ->
                if (onTuner) { tuneChannel(channelIndex - 1); return true }
            KeyEvent.KEYCODE_DPAD_UP ->
                if (onTuner && bar.visibility != View.VISIBLE) { tuneChannel(channelIndex + 1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN ->
                if (bar.visibility != View.VISIBLE) {
                    if (onTuner) tuneChannel(channelIndex - 1) else showBar()
                    return true
                }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER ->
                if (bar.visibility != View.VISIBLE) {
                    if (onTuner) showChannelList() else showBar()
                    return true
                }

            // Number keys: 0-9, and . or - for sub-channels (7.1)
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 ->
                if (onTuner) { typeDigit('0' + (keyCode - KeyEvent.KEYCODE_0)); return true }
            KeyEvent.KEYCODE_PERIOD, KeyEvent.KEYCODE_NUMPAD_DOT, KeyEvent.KEYCODE_MINUS ->
                if (onTuner) { typeDigit('.'); return true }
        }
        scheduleHide()
        return super.onKeyDown(keyCode, event)
    }

    private fun adjustVolume(direction: Int) {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun showBar() {
        bar.visibility = View.VISIBLE
        bar.getChildAt(0)?.requestFocus()
        scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideBar)
        handler.postDelayed(hideBar, 6000)
    }

    override fun onDestroy() {
        tvView.reset()
        super.onDestroy()
    }
}
