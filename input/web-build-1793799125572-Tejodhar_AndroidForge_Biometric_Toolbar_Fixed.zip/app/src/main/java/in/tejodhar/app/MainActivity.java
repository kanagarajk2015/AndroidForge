package in.tejodhar.app;

import android.Manifest;
import androidx.fragment.app.FragmentActivity;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import androidx.biometric.BiometricPrompt;
import androidx.biometric.BiometricManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.content.ContextCompat;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.Executor;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.ConsoleMessage;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends FragmentActivity {
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int PERMISSION_REQUEST = 1002;
    private static final String HOME_URL = "https://tejodhar.in/";
    private static final String WWW_URL = "https://www.tejodhar.in/";

    private WebView webView;
    private ProgressBar progress;
    private TextView errorPanel;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPermission;
    private boolean triedAlternate = false;
    private boolean pageCommitted = false;
    private static final String KEY_ALIAS = "tejodhar_biometric_login_v1";
    private static final String VAULT_PREFS = "tejodhar_biometric_vault";
    private static final String PREF_IV = "iv";
    private static final String PREF_CIPHER = "ciphertext";
    private boolean biometricPromptInProgress = false;
    private boolean autofillAttempted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Keep app content below the status bar and above the navigation bar (Android 15 edge-to-edge).
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getWindow().getDecorView().setSystemUiVisibility(0);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(3), Gravity.TOP);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(progress, progressParams);

        errorPanel = new TextView(this);
        errorPanel.setTextColor(Color.DKGRAY);
        errorPanel.setTextSize(16);
        errorPanel.setGravity(Gravity.CENTER);
        errorPanel.setPadding(dp(28), dp(28), dp(28), dp(28));
        errorPanel.setBackgroundColor(Color.WHITE);
        errorPanel.setVisibility(View.GONE);
        root.addView(errorPanel, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        ViewCompat.requestApplyInsets(root);

        // Only expose the credential bridge to the trusted Tejodhar HTTPS origin.
        webView.addJavascriptInterface(new CredentialBridge(), "TejodharBiometric");

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setTextZoom(100);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        // Some hosting/WAF configurations reject the Android WebView "wv" user-agent.
        String ua = settings.getUserAgentString();
        settings.setUserAgentString(ua.replace("; wv", ""));

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }

            private boolean handleUrl(Uri uri) {
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "No app found to open this link", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageCommitted = false;
                errorPanel.setVisibility(View.GONE);
                progress.setVisibility(View.VISIBLE);
                progress.setProgress(5);
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                pageCommitted = true;
                errorPanel.setVisibility(View.GONE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                // Nudge responsive layouts after WebView's first layout pass.
                view.evaluateJavascript(
                    "(function(){document.documentElement.style.webkitTextSizeAdjust='100%';" +
                    "document.body.style.visibility='visible';})();", null);
                if (isTrustedOrigin(url)) {
                    injectBiometricLoginHelper();
                    injectBiometricSettingsStatus();
                    if (hasSavedCredentials() && !autofillAttempted) {
                        autofillAttempted = true;
                        webView.postDelayed(() -> authenticateAndFill(), 650);
                    }
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (!request.isForMainFrame()) return;
                String detail = Build.VERSION.SDK_INT >= 23 ? error.getDescription().toString() : "Network error";
                tryAlternateOrShowError("Website could not load: " + detail);
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                            android.webkit.WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) {
                    tryAlternateOrShowError("Website server returned HTTP " + response.getStatusCode());
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel(); // Never bypass certificate validation.
                showError("Secure connection failed. Check the SSL certificate for tejodhar.in and www.tejodhar.in.");
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                android.util.Log.d("TejodharWeb", message.message() + " line " + message.lineNumber());
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "No file picker available", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    pendingWebPermission = request;
                    boolean needsCamera = false, needsMic = false;
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) needsCamera = true;
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) needsMic = true;
                    }
                    boolean cameraOk = !needsCamera || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
                    boolean micOk = !needsMic || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
                    if (cameraOk && micOk) {
                        request.grant(request.getResources());
                        pendingWebPermission = null;
                    } else {
                        java.util.ArrayList<String> ask = new java.util.ArrayList<>();
                        if (needsCamera && !cameraOk) ask.add(Manifest.permission.CAMERA);
                        if (needsMic && !micOk) ask.add(Manifest.permission.RECORD_AUDIO);
                        requestPermissions(ask.toArray(new String[0]), PERMISSION_REQUEST);
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, false, false);
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (ActivityNotFoundException e) {
                Toast.makeText(MainActivity.this, "Cannot open download link", Toast.LENGTH_SHORT).show();
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        }
        if (webView.getUrl() == null) webView.loadUrl(HOME_URL);
    }


    private boolean isTrustedOrigin(String url) {
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            return "https".equalsIgnoreCase(uri.getScheme()) &&
                    ("tejodhar.in".equalsIgnoreCase(host) || "www.tejodhar.in".equalsIgnoreCase(host));
        } catch (Exception e) { return false; }
    }

    private SharedPreferences vault() {
        return getSharedPreferences(VAULT_PREFS, MODE_PRIVATE);
    }

    private boolean hasSavedCredentials() {
        return vault().contains(PREF_IV) && vault().contains(PREF_CIPHER);
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            return ((SecretKey) ks.getKey(KEY_ALIAS, null));
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec.Builder spec = new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .setUserAuthenticationRequired(true);
        if (Build.VERSION.SDK_INT >= 30) {
            spec.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG);
        } else {
            spec.setUserAuthenticationValidityDurationSeconds(-1);
            if (Build.VERSION.SDK_INT >= 24) {
                spec.setInvalidatedByBiometricEnrollment(true);
            }
        }
        generator.init(spec.build());
        return generator.generateKey();
    }

    private Cipher newEncryptCipher() throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        return cipher;
    }

    private Cipher newDecryptCipher() throws Exception {
        byte[] iv = Base64.decode(vault().getString(PREF_IV, ""), Base64.NO_WRAP);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
        return cipher;
    }

    private BiometricPrompt createBiometricPrompt(String title, String subtitle,
                                                   BiometricPrompt.AuthenticationCallback callback) {
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor, callback);
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle(title)
                .setSubtitle(subtitle)
                .setNegativeButtonText("Cancel")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                .build();
        prompt.authenticate(info, new BiometricPrompt.CryptoObject(
                title.startsWith("Save") ? safeEncryptCipher() : safeDecryptCipher()));
        return prompt;
    }

    private Cipher safeEncryptCipher() {
        try { return newEncryptCipher(); }
        catch (Exception e) { showBiometricToast("Could not prepare secure storage: " + e.getMessage()); return null; }
    }

    private Cipher safeDecryptCipher() {
        try { return newDecryptCipher(); }
        catch (Exception e) { showBiometricToast("Saved fingerprint login is unavailable. Sign in normally and enable it again."); return null; }
    }

    private void showBiometricToast(String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    private void saveCredentialsWithBiometric(String username, String password) {
        if (username == null || password == null || username.trim().isEmpty() || password.isEmpty()) {
            showBiometricToast("Enter your username and password first.");
            return;
        }
        if (biometricPromptInProgress) return;
        biometricPromptInProgress = true;
        try {
            Cipher cipher = newEncryptCipher();
            BiometricPrompt prompt = new BiometricPrompt(this, ContextCompat.getMainExecutor(this),
                    new BiometricPrompt.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    biometricPromptInProgress = false;
                    try {
                        Cipher authenticated = result.getCryptoObject().getCipher();
                        byte[] encrypted = authenticated.doFinal((username + "\n" + password).getBytes(StandardCharsets.UTF_8));
                        vault().edit()
                                .putString(PREF_IV, Base64.encodeToString(authenticated.getIV(), Base64.NO_WRAP))
                                .putString(PREF_CIPHER, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                                .apply();
                        showBiometricToast("Fingerprint login securely enabled on this device.");
                    } catch (Exception e) {
                        showBiometricToast("Could not save credentials securely.");
                    }
                }
                @Override public void onAuthenticationError(int code, CharSequence err) {
                    biometricPromptInProgress = false;
                    showBiometricToast("Fingerprint setup cancelled: " + err);
                }
                @Override public void onAuthenticationFailed() {
                    showBiometricToast("Fingerprint not recognized. Try again.");
                }
            });
            BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Save Tejodhar login")
                    .setSubtitle("Verify your fingerprint to encrypt your login credentials")
                    .setNegativeButtonText("Cancel")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    .build();
            prompt.authenticate(info, new BiometricPrompt.CryptoObject(cipher));
        } catch (Exception e) {
            biometricPromptInProgress = false;
            showBiometricToast("Biometric setup unavailable: " + e.getMessage());
        }
    }

    private void authenticateAndFill() {
        if (!hasSavedCredentials() || biometricPromptInProgress || !isTrustedOrigin(webView.getUrl())) return;
        try {
            Cipher cipher = newDecryptCipher();
            biometricPromptInProgress = true;
            BiometricPrompt prompt = new BiometricPrompt(this, ContextCompat.getMainExecutor(this),
                    new BiometricPrompt.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    biometricPromptInProgress = false;
                    try {
                        Cipher authenticated = result.getCryptoObject().getCipher();
                        String clear = new String(authenticated.doFinal(
                                Base64.decode(vault().getString(PREF_CIPHER, ""), Base64.NO_WRAP)), StandardCharsets.UTF_8);
                        int split = clear.indexOf('\n');
                        if (split <= 0) throw new IllegalStateException("Invalid credential record");
                        String user = clear.substring(0, split);
                        String pass = clear.substring(split + 1);
                        String js = "(function(){var u=" + JSONObjectQuote(user) + ",p=" + JSONObjectQuote(pass) + ";" +
                                "var forms=Array.from(document.forms);var f=forms.find(x=>x.querySelector('input[type=password]'));" +
                                "if(!f)return false;var pw=f.querySelector('input[type=password]');" +
                                "var us=f.querySelector('input[autocomplete=username],input[type=email],input[name*=user i],input[id*=user i],input[type=text]');" +
                                "if(us){var setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;setter.call(us,u);us.dispatchEvent(new Event('input',{bubbles:true}));us.dispatchEvent(new Event('change',{bubbles:true}));}" +
                                "var setter2=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;setter2.call(pw,p);pw.dispatchEvent(new Event('input',{bubbles:true}));pw.dispatchEvent(new Event('change',{bubbles:true}));return true;})();";
                        webView.evaluateJavascript(js, value -> {
                            if ("true".equals(value)) showBiometricToast("Fingerprint verified. Login details filled; tap Sign in.");
                            else showBiometricToast("Login form not detected. Sign in normally.");
                        });
                    } catch (Exception e) {
                        showBiometricToast("Could not unlock saved login. Sign in normally.");
                    }
                }
                @Override public void onAuthenticationError(int code, CharSequence err) {
                    biometricPromptInProgress = false;
                    showBiometricToast("Fingerprint login cancelled. You can sign in with your password.");
                }
                @Override public void onAuthenticationFailed() {
                    showBiometricToast("Fingerprint not recognized. Try again.");
                }
            });
            BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock Tejodhar login")
                    .setSubtitle("Verify your fingerprint to fill your saved username and password")
                    .setNegativeButtonText("Use password")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    .build();
            prompt.authenticate(info, new BiometricPrompt.CryptoObject(cipher));
        } catch (Exception e) {
            biometricPromptInProgress = false;
            showBiometricToast("Fingerprint login unavailable. Use your password and enable it again.");
        }
    }

    private String JSONObjectQuote(String value) {
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029").replace("<", "\\u003c") + "\"";
    }

    private void injectBiometricLoginHelper() {
        String js = "(function(){if(window.__tejodharBioHelper)return;window.__tejodharBioHelper=true;" +
                "function add(){var forms=Array.from(document.forms);var f=forms.find(x=>x.querySelector('input[type=password]'));" +
                "if(!f||f.querySelector('.tejodhar-bio-save'))return;var b=document.createElement('button');" +
                "b.type='button';b.className='tejodhar-bio-save';b.textContent='Enable fingerprint login';" +
                "b.style.cssText='display:block;margin:10px 0;padding:10px 14px;border:0;border-radius:8px;background:#142b52;color:white;font-weight:600;cursor:pointer;';" +
                "b.onclick=function(){var p=f.querySelector('input[type=password]');var u=f.querySelector('input[autocomplete=username],input[type=email],input[name*=user i],input[id*=user i],input[type=text]');" +
                "if(!u||!p){alert('Please enter your username and password first.');return;}" +
                "if(window.TejodharBiometric)window.TejodharBiometric.saveCredentials(u.value,p.value);};" +
                "p.parentNode.insertAdjacentElement('afterend',b);}" +
                "if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',add);else add();" +
                "new MutationObserver(add).observe(document.documentElement,{childList:true,subtree:true});})();";
        webView.evaluateJavascript(js, null);
    }


    private void injectBiometricSettingsStatus() {
        String js = "(function(){if(window.__tejodharNativeBioStatus)return;window.__tejodharNativeBioStatus=true;" +
            "function update(){var nodes=Array.from(document.querySelectorAll('p,div,span,small')); " +
            "var target=nodes.find(function(n){return n.children.length<4 && /Biometric login is not available here/i.test(n.innerText||'');});" +
            "if(!target)return; var saved=!!(window.TejodharBiometric&&window.TejodharBiometric.hasSavedCredentials());" +
            "var ready=!!(window.TejodharBiometric&&window.TejodharBiometric.isBiometricAvailable());" +
            "target.innerText=saved?'Fingerprint login is enabled on this device. Use fingerprint verification to unlock your saved Tejodhar login.':" +
            "(ready?'Native fingerprint support is available in this Tejodhar app. To enable it, sign in with your username and password, then choose Enable fingerprint login on the login form.':'Fingerprint hardware or screen-lock authentication is not configured. Set up a screen lock or fingerprint in Android Settings.');" +
            "target.style.color='#b45309';" +
            "if(saved&&!target.parentElement.querySelector('.tejodhar-native-bio-test')){var b=document.createElement('button');b.className='tejodhar-native-bio-test';b.type='button';b.innerText='Unlock with fingerprint';" +
            "b.style.cssText='margin-top:12px;padding:10px 16px;border:0;border-radius:8px;background:#142b52;color:white;font-weight:600;';" +
            "b.onclick=function(){window.TejodharBiometric.authenticateSavedLogin();};target.insertAdjacentElement('afterend',b);}}" +
            "update();new MutationObserver(update).observe(document.documentElement,{childList:true,subtree:true,characterData:true});})();";
        webView.evaluateJavascript(js, null);
    }

    private class CredentialBridge {
        @android.webkit.JavascriptInterface
        public boolean isNativeApp() { return true; }

        @android.webkit.JavascriptInterface
        public boolean hasSavedCredentials() {
            return MainActivity.this.hasSavedCredentials();
        }

        @android.webkit.JavascriptInterface
        public boolean isBiometricAvailable() {
            BiometricManager manager = BiometricManager.from(MainActivity.this);
            return manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    == BiometricManager.BIOMETRIC_SUCCESS;
        }

        @android.webkit.JavascriptInterface
        public void authenticateSavedLogin() {
            runOnUiThread(() -> authenticateAndFill());
        }

        @android.webkit.JavascriptInterface
        public void saveCredentials(String username, String password) {
            runOnUiThread(() -> {
                if (isTrustedOrigin(webView.getUrl())) saveCredentialsWithBiometric(username, password);
            });
        }

        @android.webkit.JavascriptInterface
        public void disableBiometricLogin() {
            runOnUiThread(() -> {
                vault().edit().clear().apply();
                try {
                    KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
                    ks.load(null);
                    if (ks.containsAlias(KEY_ALIAS)) ks.deleteEntry(KEY_ALIAS);
                } catch (Exception ignored) { }
                showBiometricToast("Fingerprint login removed from this device.");
            });
        }
    }

    private void tryAlternateOrShowError(String message) {
        if (!triedAlternate) {
            triedAlternate = true;
            webView.stopLoading();
            webView.loadUrl(WWW_URL);
        } else if (!pageCommitted) {
            showError(message);
        }
    }

    private void showError(String message) {
        progress.setVisibility(View.GONE);
        errorPanel.setVisibility(View.VISIBLE);
        errorPanel.setText(message + "\n\nTap here to retry.\n\nIf Chrome opens the site but this app does not, send the AndroidForge build log and a screenshot.");
        errorPanel.setOnClickListener(v -> {
            triedAlternate = false;
            pageCommitted = false;
            webView.loadUrl(HOME_URL);
        });
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST && pendingWebPermission != null) {
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) granted &= result == PackageManager.PERMISSION_GRANTED;
            if (granted) pendingWebPermission.grant(pendingWebPermission.getResources());
            else pendingWebPermission.deny();
            pendingWebPermission = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        if (pendingWebPermission != null) pendingWebPermission.deny();
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
