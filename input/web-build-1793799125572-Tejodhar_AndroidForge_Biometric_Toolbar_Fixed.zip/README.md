# Tejodhar AndroidForge — White Screen Diagnostic Fix

This revision updates the Android WebView wrapper for the live portal:
- https://tejodhar.in/
- https://www.tejodhar.in/

## Changes
- Better WebView initialization, DOM storage, responsive viewport and cookies.
- Removes the Android WebView `; wv` user-agent marker to improve compatibility with hosting/WAF rules that reject embedded browsers.
- Adds a loading progress indicator.
- Adds alternate-host retry when the primary host fails.
- Displays a readable error panel instead of leaving a blank white screen.
- Logs JavaScript console messages under `TejodharWeb`.
- Keeps SSL certificate validation strict; it does not ignore certificate errors.
- Preserves file chooser, download, camera and microphone support.

## Build
Open/import this folder in AndroidForge, build a new APK, uninstall the old APK, install the new APK and test on mobile data and Wi-Fi.

## Important
The previous log ZIP available in this conversation was from the earlier compilation failure, not a runtime WebView white-screen trace. This source update addresses common WebView blank-screen causes and adds diagnostics, but the exact runtime cause cannot be confirmed until the new APK is tested or a fresh runtime log/screenshot is supplied.


## Biometric credential authorization (Option 2)
- Uses AndroidX BiometricPrompt with BIOMETRIC_STRONG only.
- Creates an AES-256/GCM key in Android Keystore with per-use biometric authentication.
- Username and password are encrypted locally; plaintext credentials are not written to preferences or files.
- On subsequent visits to the Tejodhar login page, fingerprint verification decrypts credentials in memory and fills the detected login form. The user must still tap Sign in.
- A one-time **Enable fingerprint login** button is injected on detected username/password forms. Enter credentials, tap it, and verify fingerprint to enroll.
- Enrollment is device-specific. Removing biometrics/changing enrolled fingerprints can invalidate the key; sign in normally and enroll again.
- The bridge is restricted to the exact HTTPS hosts `tejodhar.in` and `www.tejodhar.in`.

### Website compatibility / security notes
The app injects a helper button into standard HTML login forms. For custom login forms or SPA-controlled inputs, test the detected selectors and adjust the username/password selectors in `MainActivity.java`. For strongest integration, call `window.TejodharBiometric.saveCredentials(username, password)` only after a successful login, from the trusted portal origin. Do not expose this bridge to untrusted frames or external hosts. A portal logout should optionally call `window.TejodharBiometric.disableBiometricLogin()` if the user chooses to remove this device's saved login.


## Updated branding and camera/microphone permissions
- Added the approved circular Tejodhar Construction logo as standard and round Android launcher icons at all legacy density sizes.
- Camera and microphone permissions remain declared in the manifest but are requested only when a website feature invokes the WebView camera/microphone permission API.
- No camera or microphone prompt is shown at app startup or during ordinary login/navigation.
- If the user denies a permission, that feature is unavailable but the rest of the portal continues to work. Users can later change permission choices in Android Settings.
- WebView permission requests are granted only for the camera/microphone resources actually requested by the trusted page, after Android runtime permission is granted.


## Icon-only branding (final)
- Tejodhar circular logo is retained only as the Android launcher icon (`ic_launcher` and `ic_launcher_round`).
- No logo is embedded in the WebView/app page.
- Android 12+ system splash is configured with a plain white background and transparent splash artwork; the launcher icon remains unchanged.
- Website content and branding are not modified.


## Build log correction
- Removed the unsupported `android:postSplashScreenTheme` resource item that caused `:app:processDebugResources` to fail.
- Kept the plain white Android 12+ splash background and transparent splash artwork.
- Kept the Tejodhar circular logo only in launcher icon resources.


## AndroidForge log fixes (2026-11-04)
- Latest supplied build log showed Java compile failures: AndroidX BiometricPrompt requires FragmentActivity, and the authenticator constants belong to BiometricManager.
- MainActivity now extends FragmentActivity; biometric strong-authenticator constants use BiometricManager.Authenticators.
- Added explicit AndroidX Fragment dependency.
- Enabled decor fitting so the app content stays below the status bar and above the navigation bar on Android 15+ devices.
- This corrects the source issues identified in the log; an actual AndroidForge build and device layout test are still required.


## Latest build-log correction (2026-11-04)
- The latest AndroidForge build failed at `:app:checkDebugDuplicateClasses`.
- Root cause: duplicate Kotlin JDK7/JDK8 extension classes were included from `kotlin-stdlib-1.8.22` and legacy `kotlin-stdlib-jdk7/jdk8-1.6.21`.
- Added Gradle dependency exclusions for the obsolete split `kotlin-stdlib-jdk7` and `kotlin-stdlib-jdk8` artifacts. Kotlin 1.8+ already contains those classes in `kotlin-stdlib`.


## Biometric and toolbar integration update
- Added an explicit Android native bridge status (`isNativeApp`, biometric availability, and saved-credential status) for the trusted Tejodhar origin.
- The portal's generic WebAuthn-not-available message is adapted in-app to explain native fingerprint setup, and shows an unlock action when credentials are saved.
- Credential enrollment still requires the user to enter credentials on the login form and tap **Enable fingerprint login**. This avoids silently collecting passwords from the website.
- Added system-bar inset padding to the native root view and cleared fullscreen/layout-no-limits flags to prevent the WebView header overlapping the Android status bar and navigation bar.
- This native bridge is an Android WebView integration. A web portal's own passkey/WebAuthn feature still requires separate website-side support if it is intended to operate independently in Chrome.
