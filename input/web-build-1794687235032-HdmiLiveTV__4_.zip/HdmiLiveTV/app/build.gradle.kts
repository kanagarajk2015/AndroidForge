plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.hdmilivetv"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.hdmilivetv"
        minSdk = 23          // HdmiDeviceInfo port IDs need API 23+
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    kotlinOptions { jvmTarget = "17" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
