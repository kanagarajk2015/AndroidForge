package com.tejodhar.widgetpack

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RemoteViews
import android.widget.TextView

/** Intent builders shared by the shortcut, link and photo widgets. */
object Links {

    /** The first of [actions] this device can open, otherwise the main Settings screen. */
    fun firstResolvable(ctx: Context, actions: List<String>): Intent {
        for (action in actions) {
            val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(ctx.packageManager) != null) return i
        }
        return Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun view(url: String): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun search(term: String): Intent = view("https://www.google.com/search?q=" + Uri.encode(term))

    /** Opens the dialer with the number filled in. The user still presses call. */
    fun dial(number: String): Intent =
        Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Opens [cls] for widget [id], used to set up or change a widget's value. */
    fun configure(ctx: Context, id: Int, cls: Class<*>): Intent =
        Intent(ctx, cls)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun digits(s: String): String = s.filter { it.isDigit() }

    fun phone(s: String): String = s.filter { it.isDigit() || it == '+' }
}

/** Opens a WhatsApp chat with a saved number. Tapping it unset opens the setup screen. */
class WhatsAppWidget : BaseWidget() {
    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        val number = Links.digits(Store.get(ctx, id, "value").orEmpty())
        if (number.isEmpty()) {
            Views.text(v, "WhatsApp", "Set number", "Tap to set a number")
            onTap(ctx, v, id, Links.configure(ctx, id, TextConfigActivity::class.java))
        } else {
            Views.text(v, "WhatsApp", "Chat", "+$number")
            onTap(ctx, v, id, Links.view("https://wa.me/$number"))
        }
    }
}

/** Opens the dialer with a saved number. It does not place the call. */
class DialWidget : BaseWidget() {
    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        val number = Links.phone(Store.get(ctx, id, "value").orEmpty())
        if (number.isEmpty()) {
            Views.text(v, "Call", "Set number", "Tap to set a number")
            onTap(ctx, v, id, Links.configure(ctx, id, TextConfigActivity::class.java))
        } else {
            Views.text(v, "Call", "Dial", "Opens the dialer for $number")
            onTap(ctx, v, id, Links.dial(number))
        }
    }
}

/** Opens a Google search for a saved phrase. It is not a live search box. */
class SearchWidget : BaseWidget() {
    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        val term = Store.get(ctx, id, "value").orEmpty().trim()
        if (term.isEmpty()) {
            Views.text(v, "Web search", "Set text", "Tap to set a search")
            onTap(ctx, v, id, Links.configure(ctx, id, TextConfigActivity::class.java))
        } else {
            Views.text(v, "Web search", "Search", term)
            onTap(ctx, v, id, Links.search(term))
        }
    }
}

/**
 * Setup screen for the number and search widgets. The kind is picked from the widget's provider
 * class, so one screen serves all three.
 */
class TextConfigActivity : Activity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    private class Kind(val title: String, val hint: String, val inputType: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val kind = kindFor()
        val saved = Store.get(this, widgetId, "value").orEmpty()
        val pad = (16 * resources.displayMetrics.density).toInt()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val heading = TextView(this).apply { text = kind.title }
        val input = EditText(this).apply {
            inputType = kind.inputType
            hint = kind.hint
            setText(saved)
        }
        val save = Button(this).apply {
            text = "Save"
            setOnClickListener { saveAndClose(input.text.toString()) }
        }
        box.addView(heading)
        box.addView(input)
        box.addView(save)
        setContentView(box)
    }

    private fun kindFor(): Kind {
        val cls = AppWidgetManager.getInstance(this).getAppWidgetInfo(widgetId)?.provider?.className.orEmpty()
        return when {
            cls.endsWith("SearchWidget") ->
                Kind("Web search", "Text to search for", InputType.TYPE_CLASS_TEXT)
            cls.endsWith("DialWidget") ->
                Kind("Phone number", "Number with country code, e.g. +44...", InputType.TYPE_CLASS_PHONE)
            else ->
                Kind("WhatsApp number", "Number with country code", InputType.TYPE_CLASS_PHONE)
        }
    }

    private fun saveAndClose(raw: String) {
        Store.put(this, widgetId, "value", raw.trim())
        Refresher.refreshWidget(this, widgetId)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        finish()
    }
}
