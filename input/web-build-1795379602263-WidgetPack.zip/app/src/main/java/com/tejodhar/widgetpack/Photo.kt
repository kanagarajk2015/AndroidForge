package com.tejodhar.widgetpack

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RemoteViews
import android.widget.TextView

/** A single still photo the user picks. Tapping the widget chooses a different one. */
class PhotoFrameWidget : BaseWidget() {
    override val layoutId: Int get() = R.layout.widget_photo

    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        val uri = Store.get(ctx, id, "uri")
        val bmp = if (uri == null) null else PhotoLoader.load(ctx, Uri.parse(uri))
        if (bmp == null) {
            v.setViewVisibility(R.id.hint, View.VISIBLE)
        } else {
            v.setImageViewBitmap(R.id.photo, bmp)
            v.setViewVisibility(R.id.hint, View.GONE)
        }
        onTap(ctx, v, id, Links.configure(ctx, id, PhotoConfigActivity::class.java))
    }
}

object PhotoLoader {

    /**
     * Decodes [uri] and scales it so the longest side is at most [maxPx]. The limit keeps the
     * bitmap small enough to send to the launcher inside a RemoteViews.
     */
    fun load(ctx: Context, uri: Uri, maxPx: Int = 320): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }

        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxPx && bounds.outHeight / (sample * 2) >= maxPx) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (decoded == null) null else fit(decoded, maxPx)
    } catch (e: Exception) {
        null
    }

    private fun fit(src: Bitmap, maxPx: Int): Bitmap {
        val longest = maxOf(src.width, src.height)
        if (longest <= maxPx) return src
        val scale = maxPx.toFloat() / longest
        val w = (src.width * scale).toInt().coerceAtLeast(1)
        val h = (src.height * scale).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, w, h, true)
    }
}

/** Lets the user pick the photo. Back out before choosing and a newly added widget is removed. */
class PhotoConfigActivity : Activity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val message = TextView(this).apply {
            text = "Pick one photo. It is shown as a still image, not a slideshow."
        }
        val pick = Button(this).apply {
            text = "Choose photo"
            setOnClickListener { openPicker() }
        }
        box.addView(message)
        box.addView(pick)
        setContentView(box)
    }

    private fun openPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("image/*")
        startActivityForResult(i, REQ_PICK)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || uri == null) return

        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            // Some providers refuse a lasting grant. The photo may stop loading later.
        }
        Store.put(this, widgetId, "uri", uri.toString())
        Refresher.refreshWidget(this, widgetId)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        finish()
    }

    companion object {
        private const val REQ_PICK = 41
    }
}
