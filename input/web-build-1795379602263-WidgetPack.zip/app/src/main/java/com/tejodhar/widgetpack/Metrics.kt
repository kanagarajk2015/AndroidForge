package com.tejodhar.widgetpack

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.util.Locale

/** Battery readings from Android's sticky battery broadcast. [percent] is -1 when unknown. */
data class BatteryInfo(
    val percent: Int,
    val status: Int,
    val plugged: Int,
    val health: Int,
    val tempC: Float,
    val voltageV: Float
) {
    val charging: Boolean get() = plugged != 0
}

/** Device-wide network rates in bytes per second. [ready] is false until a second sample exists. */
data class NetRate(val down: Double, val up: Double, val ready: Boolean, val supported: Boolean)

object Metrics {

    fun battery(ctx: Context): BatteryInfo {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        return BatteryInfo(
            percent = percent,
            status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
                ?: BatteryManager.BATTERY_STATUS_UNKNOWN,
            plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0,
            health = i?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
                ?: BatteryManager.BATTERY_HEALTH_UNKNOWN,
            tempC = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f,
            voltageV = (i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0) / 1000f
        )
    }

    fun statusText(status: Int): String = when (status) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
        BatteryManager.BATTERY_STATUS_FULL -> "Full"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "On battery"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
        else -> "Status unknown"
    }

    fun plugText(plugged: Int): String = when (plugged) {
        BatteryManager.BATTERY_PLUGGED_AC -> "AC charger"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
        else -> "Unplugged"
    }

    fun healthText(health: Int): String = when (health) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheating"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
        BatteryManager.BATTERY_HEALTH_COLD -> "Too cold"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
        else -> "Unknown"
    }

    /** Total and available RAM in bytes. */
    fun ram(ctx: Context): Pair<Long, Long> {
        val mi = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return mi.totalMem to mi.availMem
    }

    /** Total and available bytes on the app-data partition. */
    fun storage(): Pair<Long, Long> {
        val st = StatFs(Environment.getDataDirectory().path)
        return st.totalBytes to st.availableBytes
    }

    fun usedPercent(total: Long, avail: Long): Int =
        if (total <= 0L) 0 else (((total - avail) * 100L) / total).toInt()

    fun gb(bytes: Long): String = String.format(Locale.US, "%.1f GB", bytes / 1_073_741_824.0)

    /**
     * Average device-wide rate since the last sample. Samples closer than 15 s reuse the previous
     * result, so a charger event between minute ticks cannot produce a spiky reading.
     */
    fun netRate(ctx: Context): NetRate {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx < 0L || tx < 0L) return NetRate(0.0, 0.0, ready = false, supported = false)

        val p = Store.prefs(ctx)
        val now = System.currentTimeMillis()
        val last = p.getLong("net_t", 0L)
        if (last == 0L) {
            save(ctx, now, rx, tx, 0f, 0f)
            return NetRate(0.0, 0.0, ready = false, supported = true)
        }
        val seconds = (now - last) / 1000.0
        if (seconds < 15.0) {
            return NetRate(
                p.getFloat("net_down", 0f).toDouble(),
                p.getFloat("net_up", 0f).toDouble(),
                ready = true,
                supported = true
            )
        }
        val down = ((rx - p.getLong("net_rx", rx)) / seconds).coerceAtLeast(0.0)
        val up = ((tx - p.getLong("net_tx", tx)) / seconds).coerceAtLeast(0.0)
        save(ctx, now, rx, tx, down.toFloat(), up.toFloat())
        return NetRate(down, up, ready = true, supported = true)
    }

    private fun save(ctx: Context, t: Long, rx: Long, tx: Long, down: Float, up: Float) {
        Store.prefs(ctx).edit()
            .putLong("net_t", t)
            .putLong("net_rx", rx)
            .putLong("net_tx", tx)
            .putFloat("net_down", down)
            .putFloat("net_up", up)
            .apply()
    }

    fun rateText(bytesPerSec: Double): String {
        val kb = bytesPerSec / 1024.0
        return when {
            kb < 1.0 -> "0 KB/s"
            kb < 1024.0 -> String.format(Locale.US, "%.0f KB/s", kb)
            else -> String.format(Locale.US, "%.1f MB/s", kb / 1024.0)
        }
    }

    fun tempText(c: Float): String = String.format(Locale.US, "%.1f°C", c)

    fun voltText(v: Float): String = String.format(Locale.US, "%.2f V", v)
}
