package com.tejodhar.widgetpack

import android.content.Context
import android.widget.RemoteViews

class BatteryPercentWidget : BaseWidget() {
    override val timed: Boolean get() = true

    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        val b = Metrics.battery(ctx)
        if (b.percent < 0) {
            Views.text(v, "Battery", "--", Metrics.statusText(b.status))
        } else {
            Views.text(v, "Battery", "${b.percent}%", Metrics.statusText(b.status))
            Views.meter(v, b.percent)
        }
    }
}

class BatteryHealthWidget : BaseWidget() {
    override val timed: Boolean get() = true

    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        val b = Metrics.battery(ctx)
        Views.text(v, "Battery health", Metrics.healthText(b.health), "Category from Android, not a %")
    }
}

class BatteryTempWidget : BaseWidget() {
    override val timed: Boolean get() = true

    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        val b = Metrics.battery(ctx)
        Views.text(v, "Battery temp", Metrics.tempText(b.tempC), "Voltage " + Metrics.voltText(b.voltageV))
    }
}

class ChargingWidget : BaseWidget() {
    override val timed: Boolean get() = true

    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        val b = Metrics.battery(ctx)
        val value = if (b.charging) Metrics.plugText(b.plugged) else "Unplugged"
        val pct = if (b.percent < 0) "--" else "${b.percent}%"
        Views.text(v, "Charging", value, Metrics.statusText(b.status) + " - " + pct)
    }
}

class RamWidget : BaseWidget() {
    override val timed: Boolean get() = true

    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        val (total, avail) = Metrics.ram(ctx)
        val used = Metrics.usedPercent(total, avail)
        Views.text(v, "RAM", "$used%", "${Metrics.gb(total - avail)} of ${Metrics.gb(total)} used")
        Views.meter(v, used)
    }
}

class StorageWidget : BaseWidget() {
    override val timed: Boolean get() = true

    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        val (total, avail) = Metrics.storage()
        val used = Metrics.usedPercent(total, avail)
        Views.text(v, "Storage", "$used%", "${Metrics.gb(avail)} free of ${Metrics.gb(total)}")
        Views.meter(v, used)
    }
}

class NetSpeedWidget : BaseWidget() {
    override val timed: Boolean get() = true

    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        val r = Metrics.netRate(ctx)
        when {
            !r.supported -> Views.text(v, "Download", "--", "Not reported on this device")
            !r.ready -> Views.text(v, "Download", "--", "Measuring...")
            else -> Views.text(
                v, "Download", Metrics.rateText(r.down),
                "Upload " + Metrics.rateText(r.up) + ", 1-min average"
            )
        }
    }
}
