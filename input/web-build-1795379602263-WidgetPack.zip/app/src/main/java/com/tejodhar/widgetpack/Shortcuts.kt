package com.tejodhar.widgetpack

import android.content.Context
import android.widget.RemoteViews

/**
 * Opens a settings screen. Since Android 10 apps cannot switch Wi-Fi, Bluetooth, mobile data or
 * hotspot on or off, so these shortcuts open the screen where the user does it.
 */
abstract class SettingsShortcut : BaseWidget() {
    abstract val label: String

    /** Candidate actions, most specific first. The first one this device can open is used. */
    abstract val actions: List<String>

    override fun render(ctx: Context, id: Int, v: RemoteViews) {
        Views.text(v, "Settings", label, "Opens settings")
        onTap(ctx, v, id, Links.firstResolvable(ctx, actions))
    }
}

class WifiShortcutWidget : SettingsShortcut() {
    override val label = "Wi-Fi"
    override val actions = listOf(
        "android.settings.panel.action.WIFI",
        "android.settings.WIFI_SETTINGS"
    )
}

class BluetoothShortcutWidget : SettingsShortcut() {
    override val label = "Bluetooth"
    override val actions = listOf(
        "android.settings.BLUETOOTH_SETTINGS"
    )
}

class MobileDataShortcutWidget : SettingsShortcut() {
    override val label = "Mobile data"
    override val actions = listOf(
        "android.settings.panel.action.INTERNET_CONNECTIVITY",
        "android.settings.WIRELESS_SETTINGS"
    )
}

class HotspotShortcutWidget : SettingsShortcut() {
    override val label = "Hotspot"
    override val actions = listOf(
        "android.settings.TETHER_SETTINGS",
        "android.settings.WIRELESS_SETTINGS"
    )
}

class VpnShortcutWidget : SettingsShortcut() {
    override val label = "VPN"
    override val actions = listOf(
        "android.settings.VPN_SETTINGS",
        "android.settings.WIRELESS_SETTINGS"
    )
}
