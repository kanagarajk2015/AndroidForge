package com.tejodhar.widgetpack

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.View
import android.widget.RemoteViews

/** Common shape of every widget in the pack. */
abstract class BaseWidget : AppWidgetProvider() {

    /** Timed widgets re-render every minute from the alarm in [Refresher]. Others render when placed or configured. */
    open val timed: Boolean get() = false

    open val layoutId: Int get() = R.layout.widget_text

    /** Fill [v] with this widget's current content for widget [id]. */
    abstract fun render(ctx: Context, id: Int, v: RemoteViews)

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(ctx, mgr, it) }
        if (timed) Refresher.schedule(ctx)
    }

    override fun onEnabled(ctx: Context) {
        if (timed) Refresher.schedule(ctx)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        Store.clear(ctx, ids)
    }

    fun updateOne(ctx: Context, mgr: AppWidgetManager, id: Int) {
        val v = RemoteViews(ctx.packageName, layoutId)
        render(ctx, id, v)
        mgr.updateAppWidget(id, v)
    }

    /** Tapping the widget opens [intent]. */
    protected fun onTap(ctx: Context, v: RemoteViews, id: Int, intent: Intent) {
        val pi = PendingIntent.getActivity(
            ctx, javaClass.name.hashCode() + id, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        v.setOnClickPendingIntent(R.id.root, pi)
    }
}

/** Per-widget settings and small sampling state, kept in one preferences file. */
object Store {
    private const val FILE = "widgetpack"

    fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun get(ctx: Context, id: Int, key: String): String? = prefs(ctx).getString("w${id}_$key", null)

    fun put(ctx: Context, id: Int, key: String, value: String) {
        prefs(ctx).edit().putString("w${id}_$key", value).apply()
    }

    fun clear(ctx: Context, ids: IntArray) {
        val p = prefs(ctx)
        val e = p.edit()
        p.all.keys.filter { k -> ids.any { k.startsWith("w${it}_") } }.forEach { e.remove(it) }
        e.apply()
    }
}

/** Helpers for filling the shared text layout. */
object Views {
    fun text(v: RemoteViews, title: String, value: String, sub: String) {
        v.setTextViewText(R.id.title, title)
        v.setTextViewText(R.id.value, value)
        v.setTextViewText(R.id.sub, sub)
    }

    fun meter(v: RemoteViews, percent: Int) {
        v.setProgressBar(R.id.meter, 100, percent.coerceIn(0, 100), false)
        v.setViewVisibility(R.id.meter, View.VISIBLE)
    }
}

/** Drives the once-a-minute refresh for timed widgets. */
object Refresher {
    const val ACTION_TICK = "com.tejodhar.widgetpack.TICK"

    private val ALL: List<BaseWidget> = listOf(
        BatteryPercentWidget(), BatteryHealthWidget(), BatteryTempWidget(), ChargingWidget(),
        RamWidget(), StorageWidget(), NetSpeedWidget(),
        WifiShortcutWidget(), BluetoothShortcutWidget(), MobileDataShortcutWidget(),
        HotspotShortcutWidget(), VpnShortcutWidget(),
        WhatsAppWidget(), DialWidget(), SearchWidget(), PhotoFrameWidget()
    )

    /** Schedules the next tick at the start of the next minute. */
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val next = (System.currentTimeMillis() / 60_000L + 1) * 60_000L
        val pi = tickIntent(ctx)
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            }
        } catch (e: SecurityException) {
            am.set(AlarmManager.RTC, next, pi)
        }
    }

    /** Re-renders every placed timed widget, then keeps the alarm going if any exist. */
    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        var anyTimed = false
        for (w in ALL) {
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, w.javaClass))
            if (ids.isEmpty() || !w.timed) continue
            anyTimed = true
            ids.forEach { w.updateOne(ctx, mgr, it) }
        }
        if (anyTimed) schedule(ctx)
    }

    /** Re-renders one widget, e.g. after its setting changed. */
    fun refreshWidget(ctx: Context, id: Int) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val cls = mgr.getAppWidgetInfo(id)?.provider?.className ?: return
        ALL.firstOrNull { it.javaClass.name == cls }?.updateOne(ctx, mgr, id)
    }

    private fun tickIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 0, Intent(ctx, TickReceiver::class.java).setAction(ACTION_TICK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
}

/** Receives the minute tick, power changes, boot and time changes. */
class TickReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Refresher.updateAll(ctx)
    }
}
