Tejodhar Android project (package in.tejodhar.app) - loads https://tejodhar.in/
- Launcher icon: Tejodhar logo (adaptive + round)
- Biometric/PIN unlock on launch (BiometricPrompt), skipped if the phone has no lock screen
- Camera, microphone, location, file/photo upload (camera or gallery), downloads
Build: push to GitHub (Actions builds app-debug.apk) or run: gradle assembleDebug
