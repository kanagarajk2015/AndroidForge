Tejodhar push notifications (Firebase Cloud Messaging)

WHO GETS WHAT
- Employee applies leave            -> Admin(s) + the Authorised Manager(s) of that employee's project
- Employee applies missed attendance / forgot punch -> Admin(s)
- Leave approved / rejected         -> that employee (rejection shows the reason)
- Missed attendance approved / rejected -> that employee (rejection shows the reason)
- Team chat message                 -> everyone else logged in on a phone (not the sender; hidden while the app is open)
Rejecting now asks for a reason (required); it is also shown in the employee's history.
Tapping a notification opens the app on the right screen (chat / approvals / leave / requests).

ONE-TIME SETUP (about 10 minutes)
1. console.firebase.google.com -> Add project (free) -> Add Android app.
   Package name must be EXACTLY the app's applicationId (app/build.gradle -> applicationId, currently co.median.android.qdqjelz).
   If your build tool changes the package name, use that one.
2. Download google-services.json  -> put it in the  app/  folder (next to app/build.gradle).
3. Firebase -> Project settings -> Service accounts -> Generate new private key.
   Rename the downloaded file to  fcm_service_account.json  and upload it to the website folder next to index.php
   (htaccess.txt now blocks it from download - make sure your live .htaccess has that block).
4. Upload the new index.php (and the updated .htaccess), rebuild the APK and install it.
5. Open the app, log in as Admin, allow notifications, wait ~10 s, then open  https://<your-site>/index.php?tool=push_test
   It prints a 5-step checklist and sends a test notification to your phone.

NOTES
- Needs the MySQL database (same as Team Chat). Table app_push is created automatically.
- Phones are registered after login and removed on logout. A phone that is never logged out keeps receiving until its session ends.
- Plain browsers (not the Android app) do not get pushes.
- iPhone is not covered (this project is the Android wrapper).
- Source files: website/index.php, PushBridge.java, TejodharMessagingService.java, PushTapActivity.java, AndroidManifest.xml, build.gradle files.
