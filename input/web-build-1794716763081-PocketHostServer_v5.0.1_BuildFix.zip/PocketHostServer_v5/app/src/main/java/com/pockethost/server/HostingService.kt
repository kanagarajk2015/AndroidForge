package com.pockethost.server

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.io.FileInputStream
import java.net.URLConnection

class HostingService : Service() {
    private var server: SiteServer? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification())
        val root = File(filesDir, "www").apply { mkdirs() }
        server = SiteServer(root).also { it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) }
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        server?.stop()
        server = null
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "PocketHost server", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("PocketHost is hosting")
            .setContentText("Local web server listening on port 8080")
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setOngoing(true)
            .build()

    private class SiteServer(private val root: File) : NanoHTTPD("0.0.0.0", 8080) {
        override fun serve(session: IHTTPSession): Response {
            if (session.method != Method.GET && session.method != Method.HEAD) {
                return newFixedLengthResponse(Response.Status.METHOD_NOT_ALLOWED, MIME_PLAINTEXT, "Method not allowed")
            }
            val raw = session.uri.substringBefore('?')
            val decoded = try { java.net.URLDecoder.decode(raw, "UTF-8") } catch (_: Exception) { "/" }
            if (decoded.contains("..") || decoded.contains('\\') || decoded.startsWith("//")) {
                return newFixedLengthResponse(Response.Status.FORBIDDEN, MIME_PLAINTEXT, "Forbidden")
            }
            val requested = if (decoded == "/") File(root, "index.html") else File(root, decoded.removePrefix("/"))
            val file = if (requested.isDirectory) File(requested, "index.html") else requested
            val canonicalRoot = root.canonicalFile.toPath()
            val canonicalFile = file.canonicalFile.toPath()
            if (!canonicalFile.startsWith(canonicalRoot)) {
                return newFixedLengthResponse(Response.Status.FORBIDDEN, MIME_PLAINTEXT, "Forbidden")
            }
            if (!file.isFile) return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "404 - Not Found")
            val mime = URLConnection.guessContentTypeFromName(file.name) ?: "application/octet-stream"
            val response = newChunkedResponse(Response.Status.OK, mime, FileInputStream(file))
            response.addHeader("X-Content-Type-Options", "nosniff")
            response.addHeader("Cache-Control", "no-store")
            return response
        }
    }

    companion object {
        @Volatile var isRunning: Boolean = false
            private set
        private const val CHANNEL_ID = "pockethost_server"
        private const val NOTIFICATION_ID = 5100
    }
}
