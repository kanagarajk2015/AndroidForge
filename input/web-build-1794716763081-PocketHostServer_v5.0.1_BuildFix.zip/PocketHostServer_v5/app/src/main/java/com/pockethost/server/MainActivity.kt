package com.pockethost.server

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webRoot = File(filesDir, "www").apply { mkdirs() }
        val welcome = File(webRoot, "index.html")
        if (!welcome.exists()) welcome.writeText(
            """<!doctype html><html><head><meta name="viewport" content="width=device-width"><title>PocketHost</title></head><body style="font-family:Arial;padding:32px"><h1>PocketHost is running</h1><p>Your first website is online on this device.</p></body></html>"""
        )
        setContent {
            MaterialTheme {
                var running by remember { mutableStateOf(HostingService.isRunning) }
                var refresh by remember { mutableIntStateOf(0) }
                val sites = remember(refresh) { webRoot.listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList() }
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("PocketHost Server", style = MaterialTheme.typography.headlineMedium)
                        Text("Android personal web hosting • v5.0")
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(if (running) "Server status: RUNNING" else "Server status: STOPPED",
                                    style = MaterialTheme.typography.titleMedium)
                                Text("Local address: http://127.0.0.1:8080")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = {
                                        val i = Intent(this@MainActivity, HostingService::class.java)
                                        ContextCompat.startForegroundService(this@MainActivity, i)
                                        running = true
                                    }, enabled = !running) { Text("Start server") }
                                    OutlinedButton(onClick = {
                                        stopService(Intent(this@MainActivity, HostingService::class.java))
                                        running = false
                                    }, enabled = running) { Text("Stop") }
                                }
                            }
                        }
                        Text("Website directory", style = MaterialTheme.typography.titleLarge)
                        Text(webRoot.absolutePath, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = {
                            val dir = File(webRoot, "site${(System.currentTimeMillis() % 100000)}")
                            dir.mkdirs()
                            File(dir, "index.html").writeText("<h1>New website</h1><p>Edit this file to publish your site.</p>")
                            refresh++
                        }) { Text("Create website folder") }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(sites) { name -> ListItem(headlineContent = { Text(name) }) }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("Runtime status", style = MaterialTheme.typography.titleLarge)
                        Text("Static website server: included")
                        Text("PHP / MySQL / Python / Rust / Ruby: not installed in this starter build")
                        Text("Public domains, authoritative DNS and internet SSL: require external infrastructure and configuration.",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
