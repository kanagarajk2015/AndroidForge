from pathlib import Path
required = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/pockethost/server/MainActivity.kt",
    "app/src/main/java/com/pockethost/server/HostingService.kt",
    ".github/workflows/android.yml",
]
missing = [f for f in required if not Path(f).is_file()]
assert not missing, f"Missing project files: {missing}"
manifest = Path(required[3]).read_text()
service = Path(required[5]).read_text()
root_gradle = Path("build.gradle.kts").read_text()
app_gradle = Path("app/build.gradle.kts").read_text()
assert 'android.permission.INTERNET' in manifest
assert '0.0.0.0", 8080' in service
assert 'contains("..")' in service
assert 'org.jetbrains.kotlin.plugin.compose' in root_gradle
assert 'id("org.jetbrains.kotlin.plugin.compose")' in app_gradle
assert 'composeOptions' not in app_gradle
print("Project structure and Kotlin 2 Compose plugin checks: PASS")
