package com.example.colourlauncher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherStyle
import com.example.colourlauncher.ui.theme.aquaGlass
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay

// The themed styles are original artwork in the spirit of the wave, glass and gold looks.
// They use fixed colours, so the accent setting does not change them.

private val GoldAccent = Color(0xFFFFC93C)

/** Dark ink for text and dots on the pale Pastel Glow artwork. The home screen uses it for labels too. */
val PastelInk = Color(0xFF1B2433)

/** Ink for the dock's page dots, handle and empty slots. Each style's dock takes the colour of its look. */
fun dockInk(style: LauncherStyle): Color = when (style) {
    LauncherStyle.PastelGlow -> PastelInk
    LauncherStyle.SunsetGold, LauncherStyle.RingClock -> GoldAccent
    else -> Color.White
}

private val ShortDateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE, MMM d")
private val DayFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("dd")
private val MonthFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("MMMM yyyy")
private val WeekdayFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE")
private val TimeOnlyFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val LongDateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM")

/**
 * Panel behind the dock. Each themed style has its own. The other styles keep the frosted glass
 * panel. OxygenOS has no panel, and [DockBar] does not call this for it.
 */
@Composable
fun Modifier.themedDockPanel(style: LauncherStyle, shape: Shape): Modifier = when (style) {
    LauncherStyle.Aurora -> this
        .background(Color.White.copy(alpha = 0.14f), shape)
        .border(1.dp, Color.White.copy(alpha = 0.3f), shape)
    LauncherStyle.SunsetGold -> this.border(1.5.dp, GoldAccent, shape)
    LauncherStyle.SkyBlue -> this
        .background(Color.White.copy(alpha = 0.24f), shape)
        .border(1.dp, Color.White.copy(alpha = 0.5f), shape)
    LauncherStyle.PastelGlow -> this
        .background(Color.White.copy(alpha = 0.42f), shape)
        .border(1.dp, Color.White.copy(alpha = 0.7f), shape)
    LauncherStyle.RingClock -> this
        .background(Color.Black.copy(alpha = 0.35f), shape)
        .border(1.dp, GoldAccent.copy(alpha = 0.45f), shape)
    // Midnight Circles has no panel: its icons float on the navy glow.
    LauncherStyle.MidnightCircles -> this
    else -> this.aquaGlass(shape)
}

/** Artwork drawn behind the home screen for the themed styles. It replaces the wallpaper there. */
@Composable
fun ThemedBackdrop(style: LauncherStyle) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        when (style) {
            LauncherStyle.Aurora -> drawAurora()
            LauncherStyle.SunsetGold -> drawSunsetGold()
            LauncherStyle.GlassBlue -> drawGlassBlue()
            LauncherStyle.PastelGlow -> drawPastelGlow()
            LauncherStyle.DateFocus -> drawDateFocus()
            LauncherStyle.RingClock -> drawRingClock()
            LauncherStyle.MidnightCircles -> drawMidnightCircles()
            else -> drawSkyBlue()
        }
    }
}

/** Clock, date and settings button for the themed styles. Each style lays them out differently. */
@Composable
fun ThemedHeader(style: LauncherStyle, onOpenSettings: () -> Unit) {
    val now by produceState(initialValue = LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(10_000L)
        }
    }

    // Styles with their own layout return early. The rest share the row below.
    when (style) {
        LauncherStyle.PastelGlow -> return PastelHeader(now = now, onOpenSettings = onOpenSettings)
        LauncherStyle.DateFocus -> return DateFocusHeader(now = now, onOpenSettings = onOpenSettings)
        LauncherStyle.RingClock -> return RingClockHeader(now = now, onOpenSettings = onOpenSettings)
        LauncherStyle.MidnightCircles -> return MidnightHeader(now = now, onOpenSettings = onOpenSettings)
        else -> Unit
    }

    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 8.dp, top = 24.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        when (style) {
            LauncherStyle.Aurora -> AuroraClock(now, Modifier.weight(1f))
            LauncherStyle.SunsetGold -> SunsetClock(now, Modifier.weight(1f))
            LauncherStyle.GlassBlue -> GlassClock(now, Modifier.weight(1f))
            else -> SkyClock(now, Modifier.weight(1f))
        }
        IconButton(onClick = onOpenSettings) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = stringResource(R.string.settings_open),
                tint = Color.White,
            )
        }
    }
}

/** Date Focus: the date is the hero in large numerals. The time and settings button sit in the corner. */
@Composable
private fun DateFocusHeader(now: LocalDateTime, onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, top = 24.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = now.format(DayFormat),
                style = MaterialTheme.typography.displayLarge.copy(shadow = LauncherTextShadow),
                color = Color.White,
                fontWeight = FontWeight.Thin,
            )
            Text(
                text = now.format(MonthFormat),
                style = MaterialTheme.typography.titleMedium.copy(shadow = LauncherTextShadow),
                color = Color.White,
            )
            Text(
                text = now.format(WeekdayFormat),
                style = MaterialTheme.typography.titleMedium.copy(shadow = LauncherTextShadow),
                color = Color.White,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = now.format(TimeOnlyFormat),
                style = MaterialTheme.typography.titleLarge.copy(shadow = LauncherTextShadow),
                color = Color.White,
                fontWeight = FontWeight.Medium,
            )
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = stringResource(R.string.settings_open),
                    tint = Color.White,
                )
            }
        }
    }
}

/** Ring Clock: a large gold analog clock centred at the top, with the date beneath it. */
@Composable
private fun RingClockHeader(now: LocalDateTime, onOpenSettings: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 12.dp)) {
        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            AnalogClock(now = now, modifier = Modifier.size(200.dp), tint = GoldAccent, ticks = true)
            Spacer(Modifier.height(16.dp))
            Text(
                text = now.format(LongDateFormat),
                style = MaterialTheme.typography.titleMedium,
                color = GoldAccent,
            )
        }
        IconButton(onClick = onOpenSettings, modifier = Modifier.align(Alignment.TopEnd)) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = stringResource(R.string.settings_open),
                tint = GoldAccent,
            )
        }
    }
}

private val MidnightText = Color(0xFFBFD9FF)

/** Midnight Circles: a left-aligned clock and date in soft blue, with the settings button on the right. */
@Composable
private fun MidnightHeader(now: LocalDateTime, onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, top = 24.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = now.format(TimeOnlyFormat),
                style = MaterialTheme.typography.displayLarge,
                color = MidnightText,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = now.format(LongDateFormat),
                style = MaterialTheme.typography.titleMedium,
                color = MidnightText.copy(alpha = 0.75f),
            )
        }
        IconButton(onClick = onOpenSettings) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = stringResource(R.string.settings_open),
                tint = MidnightText,
            )
        }
    }
}

/** Pastel Glow: a large, thin clock with the date under it, in dark ink on the pale artwork. */
@Composable
private fun PastelHeader(now: LocalDateTime, onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, top = 28.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = now.format(TimeOnlyFormat),
                style = MaterialTheme.typography.displayLarge,
                color = PastelInk,
                fontWeight = FontWeight.Light,
            )
            Text(
                text = now.format(ShortDateFormat),
                style = MaterialTheme.typography.titleMedium,
                color = PastelInk.copy(alpha = 0.8f),
            )
        }
        IconButton(onClick = onOpenSettings) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = stringResource(R.string.settings_open),
                tint = PastelInk,
            )
        }
    }
}

/** Aurora: an analog clock beside a large day number, as on a wave-lock design. */
@Composable
private fun AuroraClock(now: LocalDateTime, modifier: Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        AnalogClock(now = now, modifier = Modifier.size(92.dp))
        Spacer(Modifier.width(20.dp))
        Column {
            Text(
                text = now.format(DayFormat),
                style = MaterialTheme.typography.displayLarge.copy(shadow = LauncherTextShadow),
                color = Color.White,
                fontWeight = FontWeight.Light,
            )
            Text(
                text = now.format(MonthFormat),
                style = MaterialTheme.typography.titleMedium.copy(shadow = LauncherTextShadow),
                color = Color.White,
            )
            Text(
                text = now.format(WeekdayFormat),
                style = MaterialTheme.typography.titleSmall.copy(shadow = LauncherTextShadow),
                color = Color.White,
            )
        }
    }
}

/** Sunset Gold: a digital time inside a gold outline, with the date in gold underneath. */
@Composable
private fun SunsetClock(now: LocalDateTime, modifier: Modifier) {
    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .padding(horizontal = 20.dp, vertical = 6.dp)
                .border(1.5.dp, GoldAccent, RoundedCornerShape(24.dp)),
        ) {
            Text(
                text = now.format(TimeOnlyFormat),
                style = MaterialTheme.typography.displayLarge,
                color = GoldAccent,
                fontWeight = FontWeight.Light,
            )
        }
        Text(
            text = now.format(LongDateFormat),
            style = MaterialTheme.typography.titleMedium.copy(shadow = LauncherTextShadow),
            color = GoldAccent,
            modifier = Modifier.padding(start = 8.dp, top = 8.dp),
        )
    }
}

/** Glass Blue: the clock and date on a frosted glass card. Text follows the theme so it stays readable. */
@Composable
private fun GlassClock(now: LocalDateTime, modifier: Modifier) {
    Box(
        modifier = modifier.aquaGlass(RoundedCornerShape(28.dp)),
    ) {
        Column(modifier = Modifier.padding(horizontal = 22.dp, vertical = 16.dp)) {
            Text(
                text = now.format(TimeOnlyFormat),
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = now.format(LongDateFormat),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Sky Blue: a centred, light clock on a bright sky. */
@Composable
private fun SkyClock(now: LocalDateTime, modifier: Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = now.format(TimeOnlyFormat),
            style = MaterialTheme.typography.displayLarge.copy(shadow = LauncherTextShadow),
            color = Color.White,
            fontWeight = FontWeight.Thin,
        )
        Text(
            text = now.format(LongDateFormat),
            style = MaterialTheme.typography.titleMedium.copy(shadow = LauncherTextShadow),
            color = Color.White,
        )
    }
}

/** Analog clock face: a ring, an hour hand and a minute hand. */
@Composable
private fun AnalogClock(now: LocalDateTime, modifier: Modifier, tint: Color = Color.White, ticks: Boolean = false) {
    Canvas(modifier = modifier) {
        val centre = center
        val radius = size.minDimension / 2f
        if (ticks) {
            for (i in 0 until 12) drawTick(centre, i * 30f, radius * 0.84f, radius * 0.96f, tint)
        }
        drawCircle(
            color = tint,
            radius = radius - 2.dp.toPx(),
            center = centre,
            style = Stroke(width = 2.dp.toPx()),
        )
        val minute = now.minute + now.second / 60f
        val hour = (now.hour % 12) + minute / 60f
        drawHand(centre, angle = hour / 12f * 360f, length = radius * 0.5f, width = 4.dp.toPx(), tint = tint)
        drawHand(centre, angle = minute / 60f * 360f, length = radius * 0.82f, width = 2.dp.toPx(), tint = tint)
    }
}

/** A hand from [centre] at [angle] degrees, where 0 is twelve o'clock. */
private fun DrawScope.drawHand(centre: Offset, angle: Float, length: Float, width: Float, tint: Color) {
    val radians = Math.toRadians((angle - 90f).toDouble())
    val end = Offset(
        centre.x + length * cos(radians).toFloat(),
        centre.y + length * sin(radians).toFloat(),
    )
    drawLine(color = tint, start = centre, end = end, strokeWidth = width, cap = StrokeCap.Round)
}

/** A short tick mark between [inner] and [outer] radius, at [angle] degrees from twelve o'clock. */
private fun DrawScope.drawTick(centre: Offset, angle: Float, inner: Float, outer: Float, tint: Color) {
    val radians = Math.toRadians((angle - 90f).toDouble())
    val cosA = cos(radians).toFloat()
    val sinA = sin(radians).toFloat()
    drawLine(
        color = tint,
        start = Offset(centre.x + inner * cosA, centre.y + inner * sinA),
        end = Offset(centre.x + outer * cosA, centre.y + outer * sinA),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round,
    )
}

private fun DrawScope.drawDateFocus() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF2A0E5C), Color(0xFF12053A), Color(0xFF070218))))
    drawRect(
        Brush.radialGradient(
            colors = listOf(Color(0xFFD14BFF).copy(alpha = 0.55f), Color.Transparent),
            center = Offset(size.width * 0.85f, size.height * 0.12f),
            radius = size.width * 0.9f,
        ),
    )
    drawPath(wavePath(0.78f, 0.05f, flip = false, closed = true), Color(0xFF7B2FFF).copy(alpha = 0.35f))
}

private fun DrawScope.drawRingClock() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF232832), Color(0xFF0E1117), Color(0xFF07090D))))
    drawRect(
        Brush.radialGradient(
            colors = listOf(GoldAccent.copy(alpha = 0.18f), Color.Transparent),
            center = Offset(size.width / 2f, size.height * 0.2f),
            radius = size.width * 0.8f,
        ),
    )
}

private fun DrawScope.drawMidnightCircles() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF0A1B3D), Color(0xFF050E24), Color(0xFF020710))))
    drawRect(
        Brush.radialGradient(
            colors = listOf(Color(0xFF2D7CFF).copy(alpha = 0.40f), Color.Transparent),
            center = Offset(size.width / 2f, size.height * 0.95f),
            radius = size.width * 0.9f,
        ),
    )
}

private fun DrawScope.drawPastelGlow() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFFD9E8FF), Color(0xFFE9E2FF), Color(0xFFF7E6F3))))
    drawPath(wavePath(0.42f, 0.10f, flip = false, closed = true), Color(0xFFFFC6E2).copy(alpha = 0.55f))
    drawPath(wavePath(0.60f, 0.09f, flip = true, closed = true), Color(0xFFB8D2FF).copy(alpha = 0.55f))
    drawPath(wavePath(0.80f, 0.06f, flip = false, closed = true), Color.White.copy(alpha = 0.35f))
}

private fun DrawScope.drawAurora() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF4A12B0), Color(0xFF1A0A5C), Color(0xFF0A0524))))
    drawPath(wavePath(0.50f, 0.16f, flip = false, closed = true), Color(0xFFE040FF).copy(alpha = 0.45f))
    drawPath(wavePath(0.62f, 0.12f, flip = true, closed = true), Color(0xFF9B2BFF).copy(alpha = 0.55f))
    drawPath(wavePath(0.76f, 0.10f, flip = false, closed = true), Color(0xFF5A3BFF).copy(alpha = 0.6f))
}

private fun DrawScope.drawSunsetGold() {
    drawRect(
        Brush.linearGradient(
            colors = listOf(Color(0xFFFF2E7E), Color(0xFF7B2FE0), Color(0xFF2452FF)),
            start = Offset.Zero,
            end = Offset(size.width, size.height),
        ),
    )
    val gold = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
    drawPath(wavePath(0.56f, 0.07f, flip = false, closed = false), GoldAccent, style = gold)
    drawPath(wavePath(0.70f, 0.07f, flip = true, closed = false), GoldAccent, style = gold)
}

private fun DrawScope.drawGlassBlue() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF17456F), Color(0xFF0A2440), Color(0xFF040E1E))))
    drawPath(slabPath(0.42f, 0.12f, 0.60f, 0.30f), Color(0xFF8FD3FF).copy(alpha = 0.16f))
    drawPath(slabPath(0.66f, 0.44f, 0.72f, 0.50f), Color(0xFF5FB8FF).copy(alpha = 0.12f))
}

private fun DrawScope.drawSkyBlue() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFFBFE6FF), Color(0xFF5AAEFF), Color(0xFF2C6FE0))))
    drawPath(wavePath(0.82f, 0.05f, flip = false, closed = true), Color.White.copy(alpha = 0.22f))
    drawPath(wavePath(0.90f, 0.04f, flip = true, closed = true), Color.White.copy(alpha = 0.14f))
}

/**
 * A wave across the full width. [baseFraction] and [amplitudeFraction] are fractions of the height.
 * A closed wave is filled down to the bottom edge. An open wave is only a line, for stroking.
 */
private fun DrawScope.wavePath(
    baseFraction: Float,
    amplitudeFraction: Float,
    flip: Boolean,
    closed: Boolean,
): Path {
    val w = size.width
    val h = size.height
    val baseY = h * baseFraction
    val amplitude = h * amplitudeFraction
    val segment = w / 4f
    return Path().apply {
        moveTo(0f, baseY)
        for (i in 0 until 4) {
            val up = (i % 2 == 0) != flip
            quadraticBezierTo(
                segment * i + segment / 2f,
                baseY + (if (up) -amplitude else amplitude),
                segment * (i + 1),
                baseY,
            )
        }
        if (closed) {
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
    }
}

/** A slanted band across the screen. Each argument is a height fraction at the left or right edge. */
private fun DrawScope.slabPath(leftTop: Float, rightTop: Float, leftBottom: Float, rightBottom: Float): Path {
    val w = size.width
    val h = size.height
    return Path().apply {
        moveTo(0f, h * leftTop)
        lineTo(w, h * rightTop)
        lineTo(w, h * rightBottom)
        lineTo(0f, h * leftBottom)
        close()
    }
}
