# Tejodhar Android WebView Project

## Applied branding and configuration changes
- App display name changed to **Tejodhar Constructions**.
- Android application ID changed to `in.tejodhar.constructions`.
- Supplied Tejodhar logo applied to launcher, adaptive launcher foreground, and sidebar logo assets.
- Tejodhar blue (`#0755A4`) applied to primary/accent theme colors.
- Median-branded app banner removed and app-facing theme names changed to `Theme.Tejodhar`.
- Initial URL remains `https://tejodhar.in/`.
- User-agent branding changed to `TejodharAndroid`.
- Camera and microphone Android permissions declared; WebRTC camera/microphone options enabled in app config.
- Existing WebView framework, upload/download implementation, app navigation, and native bridge source retained.

## Important framework/dependency note
The project imports `co.median.median_core.*` throughout its Android source and depends on
`co.median.android:core` from the Median Maven repository. Removing that SDK dependency while
keeping this exact framework intact would break compilation. It has therefore been retained
rather than deleting or damaging the framework, as requested. A true SDK-free build requires
replacing/porting those framework classes first.

## Features not yet verified/implemented
- Fingerprint unlock is **not yet wired into the activity lifecycle**. The current source did not
  contain a biometric implementation. It needs a deliberate lock/opt-in flow so it does not block
  first-time website login or repeatedly prompt during Android permission dialogs.
- Demo accounts are not present in the supplied Android source. Demo credentials, if displayed,
  are likely served by the website/backend and must be removed there.
- Website login and portal access continue to load from the configured HTTPS URL. Native APK
  login behavior must be tested against the live portal.

## Build verification
A Gradle build was attempted, but the environment could not download the Gradle 9.5.1 distribution
because external network DNS access was unavailable (`UnknownHostException: services.gradle.org`).
Therefore this ZIP is a source update, not a verified APK build.
