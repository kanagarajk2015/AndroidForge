from pathlib import Path
root = Path(".")
main = (root / "app/src/main/java/com/pockethost/server/MainActivity.kt").read_text()
php = (root / "app/src/main/java/com/pockethost/server/PhpRuntimeManager.kt").read_text()
gradle = (root / "app/build.gradle.kts").read_text()
workflow = (root / ".github/workflows/android.yml").read_text()
assert "php -v" in main
assert "enabled = !phpInstalling && phpManager.isInstalled" in main
assert "phpInstalled = success" in main
assert "PHP 8.4 bundled • execution test required" in php
assert 'versionName = "5.3.3"' in gradle
assert "PocketHostServer-v5.3.3-debug" in workflow
assert "libphp.so" in workflow
print("PocketHost v5.3.3 PHP verification source checks: PASS")
