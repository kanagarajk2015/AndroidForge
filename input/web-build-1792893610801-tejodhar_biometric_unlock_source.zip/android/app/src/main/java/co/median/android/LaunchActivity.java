package co.median.android;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;

/**
 * App-launch biometric gate. Uses the device's system biometric prompt and
 * permits the device PIN/pattern/password as a fallback.
 */
public class LaunchActivity extends MainActivity {
    private boolean authStarted = false;
    private boolean unlocked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null && savedInstanceState.getBoolean("biometric_unlocked", false)) {
            unlocked = true;
            return;
        }
        startBiometricUnlock();
    }

    private void startBiometricUnlock() {
        if (authStarted || unlocked || isFinishing()) return;
        authStarted = true;

        int authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG
                | BiometricManager.Authenticators.DEVICE_CREDENTIAL;
        BiometricManager manager = BiometricManager.from(this);
        int availability = manager.canAuthenticate(authenticators);

        if (availability != BiometricManager.BIOMETRIC_SUCCESS) {
            // Do not lock users out on devices without biometric/device credential setup.
            authStarted = false;
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        unlocked = true;
                    }

                    @Override
                    public void onAuthenticationFailed() {
                        super.onAuthenticationFailed();
                        // Keep the system prompt open so the user can retry.
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                        super.onAuthenticationError(errorCode, errString);
                        if (errorCode == BiometricPrompt.ERROR_USER_CANCELED
                                || errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON
                                || errorCode == BiometricPrompt.ERROR_CANCELED) {
                            finish();
                        } else {
                            authStarted = false;
                            finish();
                        }
                    }
                });

        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Tejodhar Construction")
                .setSubtitle("Verify your identity to open the app")
                .setAllowedAuthenticators(authenticators)
                .build();
        prompt.authenticate(info);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putBoolean("biometric_unlocked", unlocked);
        super.onSaveInstanceState(outState);
    }
}
