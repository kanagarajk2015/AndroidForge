Tejodhar Construction biometric unlock
====================================

Changes:
- Added AndroidX Biometric dependency.
- Added a system biometric unlock prompt at app launch.
- Allows strong biometrics or the device PIN/pattern/password as a fallback.
- If no supported biometric/device credential is configured, the app opens without a prompt so the user is not locked out.
- Canceling the system prompt closes the app.

Build:
- Build with the project's supported Gradle/Android SDK setup.
- This is a source change; it has not been compiled or tested into an APK in this environment.
