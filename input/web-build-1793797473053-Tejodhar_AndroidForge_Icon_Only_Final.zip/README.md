# Tejodhar AndroidForge — White Screen Diagnostic Fix

This revision updates the Android WebView wrapper for the live portal:
- https://tejodhar.in/
- https://www.tejodhar.in/

## Changes
- Better WebView initialization, DOM storage, responsive viewport and cookies.
- Removes the Android WebView `; wv` user-agent marker to improve compatibility with hosting/WAF rules that reject embedded browsers.
- Adds a loading progress indicator.
- Adds alternate-host retry when the primary host fails.
- Displays a readable error panel instead of leaving a blank white screen.
- Logs JavaScript console messages under `TejodharWeb`.
- Keeps SSL certificate validation strict; it does not ignore certificate errors.
- Preserves file chooser, download, camera and microphone support.

## Build
Open/import this folder in AndroidForge, build a new APK, uninstall the old APK, install the new APK and test on mobile data and Wi-Fi.

## Important
The previous log ZIP available in this conversation was from the earlier compilation failure, not a runtime WebView white-screen trace. This source update addresses common WebView blank-screen causes and adds diagnostics, but the exact runtime cause cannot be confirmed until the new APK is tested or a fresh runtime log/screenshot is supplied.


## Biometric credential authorization (Option 2)
- Uses AndroidX BiometricPrompt with BIOMETRIC_STRONG only.
- Creates an AES-256/GCM key in Android Keystore with per-use biometric authentication.
- Username and password are encrypted locally; plaintext credentials are not written to preferences or files.
- On subsequent visits to the Tejodhar login page, fingerprint verification decrypts credentials in memory and fills the detected login form. The user must still tap Sign in.
- A one-time **Enable fingerprint login** button is injected on detected username/password forms. Enter credentials, tap it, and verify fingerprint to enroll.
- Enrollment is device-specific. Removing biometrics/changing enrolled fingerprints can invalidate the key; sign in normally and enroll again.
- The bridge is restricted to the exact HTTPS hosts `tejodhar.in` and `www.tejodhar.in`.

### Website compatibility / security notes
The app injects a helper button into standard HTML login forms. For custom login forms or SPA-controlled inputs, test the detected selectors and adjust the username/password selectors in `MainActivity.java`. For strongest integration, call `window.TejodharBiometric.saveCredentials(username, password)` only after a successful login, from the trusted portal origin. Do not expose this bridge to untrusted frames or external hosts. A portal logout should optionally call `window.TejodharBiometric.disableBiometricLogin()` if the user chooses to remove this device's saved login.


## Updated branding and camera/microphone permissions
- Added the approved circular Tejodhar Construction logo as standard and round Android launcher icons at all legacy density sizes.
- Camera and microphone permissions remain declared in the manifest but are requested only when a website feature invokes the WebView camera/microphone permission API.
- No camera or microphone prompt is shown at app startup or during ordinary login/navigation.
- If the user denies a permission, that feature is unavailable but the rest of the portal continues to work. Users can later change permission choices in Android Settings.
- WebView permission requests are granted only for the camera/microphone resources actually requested by the trusted page, after Android runtime permission is granted.


## Icon-only branding (final)
- Tejodhar circular logo is retained only as the Android launcher icon (`ic_launcher` and `ic_launcher_round`).
- No logo is embedded in the WebView/app page.
- Android 12+ system splash is configured with a plain white background and transparent splash artwork; the launcher icon remains unchanged.
- Website content and branding are not modified.
