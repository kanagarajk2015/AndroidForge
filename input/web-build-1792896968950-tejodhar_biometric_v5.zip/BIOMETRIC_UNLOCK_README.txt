Tejodhar Construction biometric unlock (v2)
- Opaque lock screen covers the website until fingerprint/face or device PIN/pattern/password succeeds.
- Re-locks after 30 seconds in the background.
- Uses BIOMETRIC_WEAK + DEVICE_CREDENTIAL (works on Android 5+; STRONG+CREDENTIAL fails on Android 9-10).
- Cancel/error keeps the app locked with an Unlock button (no force close).
- No biometrics/screen lock set on device: app opens normally.
- Source change only; not compiled in this environment.
