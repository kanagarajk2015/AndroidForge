package co.median.android;

import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import java.util.concurrent.Executor;

/**
 * App-launch biometric lock.
 * - An opaque lock screen covers the website until the user authenticates
 *   (fingerprint / face, with device PIN / pattern / password as fallback).
 * - Re-locks when the app returns from the background after LOCK_AFTER_MS.
 * - If the device has no screen lock / biometrics enrolled, the app opens normally.
 */
public class LaunchActivity extends MainActivity {
    private static final long LOCK_AFTER_MS = 30_000L;
    private static final int AUTHENTICATORS =
            BiometricManager.Authenticators.BIOMETRIC_WEAK
                    | BiometricManager.Authenticators.DEVICE_CREDENTIAL;

    private FrameLayout lockOverlay;
    private TextView lockMessage;
    private boolean promptShowing = false;
    private boolean unlocked = false;
    private long stoppedAt = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildLockOverlay();
        if (canAuthenticate()) {
            showLock();
            authenticate();
        } else {
            unlocked = true; // nothing enrolled: do not lock the user out
            hideLock();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (!isChangingConfigurations()) stoppedAt = SystemClock.elapsedRealtime();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (lockOverlay == null) return;
        if (unlocked && stoppedAt > 0
                && SystemClock.elapsedRealtime() - stoppedAt > LOCK_AFTER_MS
                && canAuthenticate()) {
            unlocked = false;
            showLock();
            authenticate();
        }
        stoppedAt = 0L;
    }

    private boolean canAuthenticate() {
        return BiometricManager.from(this).canAuthenticate(AUTHENTICATORS)
                == BiometricManager.BIOMETRIC_SUCCESS;
    }

    private void buildLockOverlay() {
        lockOverlay = new FrameLayout(this);
        lockOverlay.setBackgroundColor(Color.WHITE);
        lockOverlay.setClickable(true); // swallow touches so the page underneath is unreachable
        lockOverlay.setVisibility(View.GONE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText("Tejodhar Construction");
        title.setTextSize(22f);
        title.setTextColor(Color.parseColor("#111111"));
        title.setGravity(Gravity.CENTER);

        lockMessage = new TextView(this);
        lockMessage.setText("App locked");
        lockMessage.setTextSize(15f);
        lockMessage.setTextColor(Color.parseColor("#555555"));
        lockMessage.setGravity(Gravity.CENTER);
        lockMessage.setPadding(0, 16, 0, 32);

        Button unlock = new Button(this);
        unlock.setText("Unlock");
        unlock.setOnClickListener(v -> authenticate());

        box.addView(title);
        box.addView(lockMessage);
        box.addView(unlock);

        lockOverlay.addView(box, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));
        addContentView(lockOverlay, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void showLock() {
        lockOverlay.setVisibility(View.VISIBLE);
        lockOverlay.bringToFront();
    }

    private void hideLock() {
        lockOverlay.setVisibility(View.GONE);
    }

    private void authenticate() {
        if (promptShowing || isFinishing()) return;
        promptShowing = true;

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(
                            @NonNull BiometricPrompt.AuthenticationResult result) {
                        promptShowing = false;
                        unlocked = true;
                        hideLock();
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                        promptShowing = false;
                        // Stay locked; user can tap Unlock to retry.
                        lockMessage.setText(errString);
                    }
                });

        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Tejodhar Construction")
                .setSubtitle("Verify your identity to open the app")
                .setAllowedAuthenticators(AUTHENTICATORS)
                .build();
        prompt.authenticate(info);
    }
}
