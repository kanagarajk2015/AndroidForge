from pathlib import Path
required = [
    "settings.gradle.kts", "build.gradle.kts", "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/pockethost/server/MainActivity.kt",
    "app/src/main/java/com/pockethost/server/HostingService.kt",
    "app/src/main/java/com/pockethost/server/PhpRuntimeManager.kt",
    ".github/workflows/android.yml",
]
missing = [f for f in required if not Path(f).is_file()]
assert not missing, f"Missing project files: {missing}"
manifest = Path(required[3]).read_text()
main = Path(required[4]).read_text()
service = Path(required[5]).read_text()
php = Path(required[6]).read_text()
root_gradle = Path("build.gradle.kts").read_text()
app_gradle = Path("app/build.gradle.kts").read_text()
assert "android.permission.INTERNET" in manifest
assert '0.0.0.0", 8080' in service
assert 'contains("..")' in service
assert "org.jetbrains.kotlin.plugin.compose" in root_gradle
assert 'id("org.jetbrains.kotlin.plugin.compose")' in app_gradle
assert "commons-compress" in app_gradle
assert "Install PHP 8.4" in main
assert "PHP_SHA256" in php and "d8867966340121f821591b9bb29c80a58ad77abd6cc8e0e44d1cbbb3aaedd70c" in php
assert "Unsafe archive entry path" in php
assert "Unsafe path in PHP archive" not in php
assert 'replace(Regex("^(\\\\\\\\./)+"), "")' in php
assert "startSiteServer" in service and "servePhp" in service
assert "PHP runtime unavailable" in service
assert "filesDir, \"php-runtime\"" in php
for feature in ["Create website", "Upload file", "File manager", "Preview", "Edit"]:
    assert feature in main, f"Missing UI feature: {feature}"
print("PocketHost v5.2 source/feature/security smoke checks: PASS")
