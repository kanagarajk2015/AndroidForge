package com.example.colourlauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherApp

/**
 * List of every app, with a search field at the top. Full screen by default.
 * With [panel] set it is a rounded Start-menu panel sized by [modifier], and
 * [onOpenSettings] adds a settings button in a footer.
 */
@Composable
fun AppDrawer(
    apps: List<LauncherApp>,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    panel: Boolean = false,
    onOpenSettings: (() -> Unit)? = null,
) {
    val columns = LocalLauncherSettings.current.columns
    val pullDown = rememberPullConnection(upward = false, threshold = 80.dp, onTrigger = onClose)
    var query by rememberSaveable { mutableStateOf("") }
    val results = remember(apps, query) {
        val needle = query.trim()
        if (needle.isEmpty()) apps else apps.filter { it.label.contains(needle, ignoreCase = true) }
    }

    val base = if (panel) modifier.clip(RoundedCornerShape(12.dp)) else modifier.fillMaxSize()
    Column(
        modifier = base
            .background(MaterialTheme.colorScheme.surface.copy(alpha = if (panel) 0.96f else 0.92f))
            // Dragging down past the top of the grid closes the drawer.
            .nestedScroll(pullDown)
            // safeDrawing keeps the search box and grid clear of the status bar, nav bar and keyboard.
            // The panel sits above the taskbar, so it skips the insets.
            .then(if (panel) Modifier else Modifier.windowInsetsPadding(WindowInsets.safeDrawing)),
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            singleLine = true,
            shape = RoundedCornerShape(if (panel) 8.dp else 28.dp),
            placeholder = { Text(stringResource(R.string.search_apps)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        )

        if (results.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center,
            ) {
                Text(text = stringResource(R.string.no_apps_found), color = MaterialTheme.colorScheme.onSurface)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(columns),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            ) {
                items(results, key = { it.packageName }) { app ->
                    AppIcon(
                        app = app,
                        labelColor = MaterialTheme.colorScheme.onSurface,
                        onClick = { onLaunch(app.packageName) },
                        onLongClick = { onLongPress(app) },
                    )
                }
            }
        }

        if (onOpenSettings != null) {
            HorizontalDivider()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.End,
            ) {
                IconButton(onClick = onOpenSettings) {
                    Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = stringResource(R.string.settings_open),
                    )
                }
            }
        }
    }
}
