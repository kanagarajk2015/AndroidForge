#!/usr/bin/env python3
"""Fetch a checksum-verified Termux ARM64 MariaDB package and its runtime dependencies."""
import hashlib, lzma, os, re, shutil, subprocess, sys, tarfile, tempfile, urllib.request
from pathlib import Path

# Use the official primary Termux repository first, then known mirrors.
# Some CDN/mirror edges may return 404 for an index while another mirror is healthy.
REPOSITORIES = [
    "https://packages.termux.dev/apt/termux-main",
    "https://packages-cf.termux.dev/apt/termux-main",
    "https://mirrors.in.sahilister.net/termux/termux-main",
]
INDEX_PATH = "/dists/stable/main/binary-aarch64/Packages.xz"
BASE = None
INDEX = None
PINNED_MARIADB_VERSION = "2:13.0.2"
OUT = Path("app/src/main/assets")
WORK = Path(".build/mariadb")
ROOTFS = WORK / "rootfs"
MAX_PACKAGE_BYTES = 80 * 1024 * 1024

def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "PocketHost-Builder/5.4"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return r.read()

def parse_index(raw):
    data = lzma.decompress(raw).decode("utf-8", "replace")
    records = []
    for stanza in re.split(r"\n\s*\n", data):
        fields, current = {}, None
        for line in stanza.splitlines():
            if line.startswith((" ", "\t")) and current:
                fields[current] += "\n" + line.strip()
            elif ":" in line:
                current, value = line.split(":", 1)
                fields[current] = value.strip()
        if fields.get("Package") and fields.get("Filename"):
            records.append(fields)
    return records

def dep_names(value):
    result=[]
    for group in (value or "").split(","):
        alternatives=group.split("|")
        for alt in alternatives:
            alt=re.sub(r"\[[^]]*]|\([^)]*\)|<[^>]*>", "", alt).strip()
            name=re.match(r"[A-Za-z0-9+_.:-]+", alt)
            if name:
                result.append(name.group(0))
                break
    return result

def main():
    global BASE, INDEX
    WORK.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(parents=True, exist_ok=True)

    index_blob = None
    failures = []
    for repository in REPOSITORIES:
        candidate = repository + INDEX_PATH
        try:
            print("Trying Termux package index:", candidate, flush=True)
            index_blob = fetch(candidate)
            BASE, INDEX = repository, candidate
            break
        except Exception as exc:
            failures.append(f"{candidate}: {type(exc).__name__}: {exc}")
            print("Repository unavailable; trying next mirror.", flush=True)
    if index_blob is None:
        raise SystemExit(
            "Could not download the Termux ARM64 package index from any configured repository:\\n"
            + "\\n".join(failures)
        )

    print("Using repository:", BASE)
    records=parse_index(index_blob)
    by_name={}
    for r in records:
        arch=r.get("Architecture","")
        if arch in ("aarch64","all"):
            by_name[r["Package"]]=r
    mariadb=by_name.get("mariadb")
    if not mariadb:
        raise SystemExit("MariaDB package not present in Termux ARM64 index")
    if mariadb.get("Version") != PINNED_MARIADB_VERSION:
        raise SystemExit(f"MariaDB version changed: expected {PINNED_MARIADB_VERSION}, got {mariadb.get('Version')}. Review and pin a new version.")
    selected={}
    queue=["mariadb"]
    while queue:
        name=queue.pop(0)
        if name in selected: continue
        record=by_name.get(name)
        if not record:
            raise SystemExit(f"Unresolved runtime dependency: {name}")
        selected[name]=record
        for dep in dep_names(record.get("Pre-Depends","") + "," + record.get("Depends","")):
            if dep not in selected:
                queue.append(dep)
    print("Resolved packages:", ", ".join(f'{n}={r.get("Version")}' for n,r in selected.items()))
    shutil.rmtree(WORK, ignore_errors=True)
    (WORK/"debs").mkdir(parents=True)
    ROOTFS.mkdir(parents=True)
    for name,record in selected.items():
        rel=record["Filename"]
        expected=record.get("SHA256","").lower()
        if not re.fullmatch(r"[0-9a-f]{64}", expected):
            raise SystemExit(f"Missing SHA256 for {name}")
        blob=fetch(BASE + "/" + rel)
        if len(blob)>MAX_PACKAGE_BYTES:
            raise SystemExit(f"Package too large: {name}")
        actual=hashlib.sha256(blob).hexdigest()
        if actual != expected:
            raise SystemExit(f"SHA256 mismatch for {name}: {actual} != {expected}")
        deb=WORK/"debs"/(name+".deb")
        deb.write_bytes(blob)
        extracted=WORK/"extract"/name
        extracted.mkdir(parents=True)
        subprocess.run(["dpkg-deb","-x",str(deb),str(extracted)],check=True)
        # Termux packages store their prefix under data/data/com.termux/files/usr.
        prefix=extracted/"data/data/com.termux/files/usr"
        if not prefix.is_dir():
            prefix=extracted/"usr"
        if not prefix.is_dir():
            raise SystemExit(f"Cannot locate Termux prefix in {name}.deb")
        for item in prefix.iterdir():
            target=ROOTFS/item.name
            if item.is_dir() and not item.is_symlink():
                shutil.copytree(item,target,dirs_exist_ok=True,symlinks=True)
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                if target.exists() or target.is_symlink():
                    if target.is_dir() and not target.is_symlink(): shutil.rmtree(target)
                    else: target.unlink()
                shutil.copy2(item,target,follow_symlinks=False)
    required = ["bin/mariadbd", "bin/mariadb-install-db", "bin/mariadb"]
    missing = [name for name in required if not (ROOTFS/name).is_file()]
    if missing:
        raise SystemExit("MariaDB runtime is incomplete; missing: " + ", ".join(missing))
    with (ROOTFS/"bin/mariadbd").open("rb") as f:
        if f.read(4) != b"\x7fELF":
            raise SystemExit("MariaDB daemon is not an ELF executable")
    (ROOTFS/"POCKETHOST_MARIADB_VERSION").write_text(
        "MariaDB " + mariadb["Version"] + "\nArchitecture: aarch64\nSource: Termux main repository\n"
    )
    archive=OUT/"mariadb-rootfs.tar.gz"
    with tarfile.open(archive,"w:gz",compresslevel=6) as tf:
        for item in ROOTFS.iterdir():
            tf.add(item,arcname=item.name,recursive=True)
    digest=hashlib.sha256(archive.read_bytes()).hexdigest()
    (OUT/"mariadb-rootfs.sha256").write_text(digest+"\n")
    print("Created",archive,"bytes",archive.stat().st_size,"sha256",digest)

if __name__=="__main__":
    main()
