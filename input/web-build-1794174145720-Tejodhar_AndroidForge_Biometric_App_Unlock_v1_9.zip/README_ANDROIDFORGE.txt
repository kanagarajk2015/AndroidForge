TEJODHAR SECURE ANDROID PROJECT - BIOMETRIC APP UNLOCK + HTTPS UPDATE
================================

Project layout includes:
- app/src/main/AndroidManifest.xml
- app/src/main/java/in/tejodhar/app/MainActivity.kt
- app/src/main/java/in/tejodhar/app/TokenVault.kt
- app/src/main/res/layout/activity_main.xml
- app/src/main/res/values/styles.xml
- settings.gradle.kts
- root build.gradle.kts
- gradle/libs.versions.toml
- app/build.gradle.kts

HTTPS / SSL BEHAVIOUR
--------------------
- The app starts at https://tejodhar.in/ (HTTPS only).
- In-app navigation to http://tejodhar.in or an owned *.tejodhar.in host is
  upgraded to HTTPS before the page is loaded.
- Plain HTTP is disabled by android:usesCleartextTraffic="false".
- SSL certificate errors are cancelled. The app never ignores certificate
  errors or accepts an invalid certificate.
- Third-party HTTP links are not loaded inside the app; they are handed to
  an external app/browser.
- The Android app does not repair the server certificate. Cloudflare and
  the hosting origin must still present a valid certificate.

APP LOCK BEHAVIOUR
------------------
On every cold app launch, the app requests a strong device biometric
(fingerprint or supported face authentication) before displaying the website.
This app-opening lock does not depend on the website biometric token being
registered. After the app is unlocked, the existing Tejodhar website login
still controls the account session; users can sign in with their existing
username/password and separately enable website biometric sign-in.

The website's existing native biometric login may request another biometric
scan to authenticate the PHP server session. This is separate from the app
opening lock. The app-lock scan alone does NOT create a PHP login session.

IMPORTANT LIMITATIONS
--------------------
- This is a source project ZIP, not a compiled APK. Version 1.6 (versionCode 7).
- The native app lock runs on every cold launch. A strong fingerprint or
  supported face biometric must be enrolled and available on the phone.
- If biometric hardware or enrollment is unavailable, the app stays locked;
  configure fingerprint/face unlock in Android Settings before opening Tejodhar.
- The app-lock prompt is an app-opening gate, not a replacement for the
  website's username/password, OTP, or server-side account authentication.
- Existing website username/password and PHP authentication are unchanged.
- Use AndroidForge's Android/Gradle build option to build the APK. After building, test both https://tejodhar.in and https://www.tejodhar.in on the phone. The app upgrades in-app HTTP links to HTTPS; it does not guarantee that the live server SSL certificate is valid.
- Test with a non-critical account before production rollout.

SECURITY NOTE
-------------
Do not commit database credentials, API keys, or GitHub tokens.
Rotate any credentials previously exposed in uploaded PHP source.


V1.7 STARTUP-LOCK CORRECTION
- On first launch, when no native biometric token is enrolled, the app opens the normal HTTPS website login.
- After the user signs in and enables the website's biometric sign-in feature, the native bridge stores the token in Android Keystore.
- On later launches, if the token exists, the WebView remains hidden until BiometricPrompt succeeds.
- Failed/cancelled biometric authentication does not load the website.
- This relies on the existing website bio_native_register flow calling TejodharBio.register(token, callback).
- App version: 1.7 (versionCode 8).


Version 1.8 correction: TokenVault.hasToken() now checks only for the encrypted
registration record and does not initialise a Keystore decryption cipher before
BiometricPrompt. Android requires user authentication before that cipher can be
initialised; doing so during the startup check could prevent the app-lock prompt
from being displayed. The token is still decrypted only after successful biometric
authentication using the CryptoObject returned by BiometricPrompt.


V1.9 APP LOCK ON EVERY START
- The app now asks for fingerprint / face (or the phone PIN/pattern/password as fallback) on EVERY app start,
  before any website content is loaded. It no longer depends on a website biometric token being registered.
- A lock screen with Unlock / Exit buttons stays visible if the prompt is cancelled; the website is never loaded while locked.
- Camera/microphone permission dialogs are now requested only after unlock (they used to appear at start and could cancel the biometric prompt).
- If the phone has no fingerprint, face or screen lock at all, the app opens normally (there is nothing to unlock with).
- The website's own biometric login (TejodharBio bridge) is unchanged.
- App version: 1.9 (versionCode 10).
