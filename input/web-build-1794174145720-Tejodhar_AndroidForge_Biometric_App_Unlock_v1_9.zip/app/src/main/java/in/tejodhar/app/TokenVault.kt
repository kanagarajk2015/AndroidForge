package in.tejodhar.app

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Keeps this phone's biometric login token. The site (index.php) keeps only a SHA-256
 * hash of it, so the token is the phone's proof of identity.
 *
 * The token is encrypted with an Android Keystore key that needs a fresh fingerprint /
 * face scan for every use. The cipher is only usable through BiometricPrompt (CryptoObject).
 * If fingerprints or faces are added or removed, the key is invalidated and the token is dropped.
 */
object TokenVault {

    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "tejodhar_bio_token_key"
    private const val TRANSFORM = "AES/GCM/NoPadding"
    private const val PREFS = "tejodhar_bio"
    private const val K_IV = "iv"
    private const val K_BLOB = "blob"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun keyStore(): KeyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }

    private fun existingKey(): SecretKey? =
        runCatching { keyStore().getKey(KEY_ALIAS, null) as? SecretKey }.getOrNull()

    private fun createKey(): SecretKey {
        val builder = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)        // every use needs a fresh scan
            .setInvalidatedByBiometricEnrollment(true)  // adding/removing a fingerprint kills the key

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Only a strong biometric (fingerprint / 3D face) may unlock this key, not the PIN.
            builder.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
        }

        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            .apply { init(builder.build()) }
            .generateKey()
    }

    private fun deleteKey() {
        runCatching { keyStore().deleteEntry(KEY_ALIAS) }
    }

    /** Cipher for encrypting a new token. Only usable after a biometric success. */
    fun encryptCipher(): Cipher = try {
        newEncryptCipher()
    } catch (e: KeyPermanentlyInvalidatedException) {
        deleteKey()
        newEncryptCipher()
    }

    private fun newEncryptCipher(): Cipher {
        val key = existingKey() ?: createKey()
        return Cipher.getInstance(TRANSFORM).apply { init(Cipher.ENCRYPT_MODE, key) }
    }

    /**
     * Cipher for reading the saved token. Null when nothing is saved.
     * Throws KeyPermanentlyInvalidatedException when fingerprints or faces changed.
     */
    fun decryptCipher(ctx: Context): Cipher? {
        val iv = prefs(ctx).getString(K_IV, null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return null
        val key = existingKey() ?: return null
        return Cipher.getInstance(TRANSFORM).apply {
            init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        }
    }

    /**
     * Checks only whether a registration record exists. IMPORTANT: do not initialise
     * the authentication-bound Keystore cipher here. On Android, init(DECRYPT_MODE)
     * can throw UserNotAuthenticatedException before BiometricPrompt is shown. That
     * made the launch gate fail before it could display the fingerprint prompt.
     * Actual token decryption happens only after BiometricPrompt returns its CryptoObject.
     */
    fun hasToken(ctx: Context): Boolean {
        val p = prefs(ctx)
        return p.contains(K_BLOB) && p.contains(K_IV)
    }

    /** Encrypts and stores the token using the cipher the biometric prompt just unlocked. */
    fun save(ctx: Context, cipher: Cipher, token: String) {
        val blob = cipher.doFinal(token.toByteArray(Charsets.UTF_8))
        prefs(ctx).edit()
            .putString(K_IV, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString(K_BLOB, Base64.encodeToString(blob, Base64.NO_WRAP))
            .apply()
    }

    /** Decrypts the saved token using the cipher the biometric prompt just unlocked. */
    fun read(ctx: Context, cipher: Cipher): String {
        val blob = Base64.decode(prefs(ctx).getString(K_BLOB, "") ?: "", Base64.NO_WRAP)
        return String(cipher.doFinal(blob), Charsets.UTF_8)
    }

    /** Forgets the token and its key on this phone. */
    fun clear(ctx: Context) {
        prefs(ctx).edit().remove(K_IV).remove(K_BLOB).apply()
        deleteKey()
    }
}
