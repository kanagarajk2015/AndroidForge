package com.pockethost.server

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import java.sql.DriverManager
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import kotlin.concurrent.thread

/**
 * Experimental local MariaDB service. Runtime is assembled in CI from the
 * Termux aarch64 MariaDB package and its declared runtime dependencies.
 * The database binds only to loopback; it is not exposed to the LAN.
 */
data class DatabaseCredential(
    val database: String,
    val username: String,
    val password: String,
    val host: String = "127.0.0.1",
    val port: Int = 3306
)

class MariaDbManager(private val context: Context) {
    companion object {
        private const val PORT = 3306
        private const val JDBC_URL = "jdbc:mariadb://127.0.0.1:$PORT/mysql?connectTimeout=1500&socketTimeout=3000"
        private const val MAX_RUNTIME_BYTES = 220L * 1024L * 1024L
    }

    private val prefix = File(context.filesDir, "mariadb-prefix")
    private val dataDir = File(context.filesDir, "mariadb-data")
    private val archive = File(context.cacheDir, "mariadb-rootfs.tar.gz")
    private val secretStore = DbSecretStore(context)
    @Volatile private var process: Process? = null
    @Volatile var status: String = "MariaDB not installed"
        private set
    val isInstalled: Boolean get() =
        File(prefix, "bin/mariadbd.pockethost-bin").isFile ||
        File(prefix, "bin/mysqld.pockethost-bin").isFile
    val isRunning: Boolean get() = process?.isAlive == true

    fun start(onComplete: (Boolean, String) -> Unit) {
        thread(name = "PocketHost-MariaDB-start") {
            try {
                status = "Preparing MariaDB runtime…"
                installRuntimeIfNeeded()
                dataDir.mkdirs()
                val initialized = File(dataDir, "mysql").isDirectory
                if (!initialized) {
                    status = "Initializing database system tables…"
                    initializeDatabase()
                }
                if (!isRunning) {
                    status = "Starting MariaDB on 127.0.0.1:$PORT…"
                    startProcess()
                }
                val saved = secretStore.read()
                if (saved == null) {
                    status = "Securing database administrator…"
                    val generated = generatePassword()
                    withConnection("", "mysql") { connection ->
                        connection.createStatement().use {
                            it.execute("ALTER USER 'root'@'localhost' IDENTIFIED BY '${sqlEscape(generated)}'")
                        }
                    }
                    secretStore.write(generated)
                }
                // Prove the stored administrator credential works.
                withConnection(secretStore.read().orEmpty(), "mysql") { connection ->
                    connection.createStatement().use { it.executeQuery("SELECT VERSION()").use { rs ->
                        check(rs.next()) { "MariaDB version query returned no row" }
                        status = "MariaDB running • ${rs.getString(1)} • 127.0.0.1:$PORT"
                    } }
                }
                onComplete(true, status)
            } catch (e: Exception) {
                status = "MariaDB start failed: ${e.message ?: e.javaClass.simpleName}"
                onComplete(false, status)
            }
        }
    }

    fun stop() {
        runCatching { process?.destroy() }
        process = null
        status = "MariaDB stopped"
    }

    fun listDatabases(): List<String> {
        val password = secretStore.read() ?: throw IllegalStateException("Start MariaDB first")
        return withConnection(password, "mysql") { connection ->
            connection.createStatement().use { st ->
                st.executeQuery("SHOW DATABASES").use { rs ->
                    buildList {
                        while (rs.next()) {
                            val name = rs.getString(1)
                            if (name !in setOf("information_schema", "mysql", "performance_schema", "sys")) add(name)
                        }
                    }
                }
            }
        }
    }

    fun createDatabase(name: String): DatabaseCredential {
        validateName(name)
        val adminPassword = secretStore.read() ?: throw IllegalStateException("Start MariaDB first")
        val username = (name.take(55) + "_user")
        val userPassword = generatePassword()
        withConnection(adminPassword, "mysql") { connection ->
            connection.createStatement().use { statement ->
                statement.execute("CREATE DATABASE `${name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
                statement.execute("CREATE USER '${username}'@'127.0.0.1' IDENTIFIED BY '${sqlEscape(userPassword)}'")
                statement.execute("GRANT ALL PRIVILEGES ON `${name}`.* TO '${username}'@'127.0.0.1'")
            }
        }
        secretStore.writeDatabasePassword(name, userPassword)
        return DatabaseCredential(name, username, userPassword)
    }

    fun dropDatabase(name: String) {
        validateName(name)
        require(name !in setOf("mysql", "information_schema", "performance_schema", "sys")) {
            "System databases cannot be deleted"
        }
        val password = secretStore.read() ?: throw IllegalStateException("Start MariaDB first")
        val username = name.take(55) + "_user"
        withConnection(password, "mysql") { connection ->
            connection.createStatement().use {
                it.execute("DROP DATABASE IF EXISTS `${name}`")
                it.execute("DROP USER IF EXISTS '${username}'@'127.0.0.1'")
            }
        }
        secretStore.deleteDatabasePassword(name)
    }

    fun databaseUsername(name: String): String = name.take(55) + "_user"
    fun databasePassword(name: String): String? = secretStore.readDatabasePassword(name)

    fun phpMysqlExtensionStatus(phpManager: PhpRuntimeManager): String =
        phpManager.mysqlExtensionStatus()

    private fun installRuntimeIfNeeded() {
        if (isInstalled) return
        val assetArchive = context.assets.open("mariadb-rootfs.tar.gz")
        val expected = context.assets.open("mariadb-rootfs.sha256").bufferedReader().use { it.readText().trim() }
        val tempArchive = File(context.cacheDir, "mariadb-rootfs.part")
        assetArchive.use { input -> FileOutputStream(tempArchive).use { output -> input.copyTo(output) } }
        val digest = MessageDigest.getInstance("SHA-256")
        val actual = FileInputStream(tempArchive).use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) { val n = input.read(buf); if (n < 0) break; digest.update(buf, 0, n) }
            digest.digest().joinToString("") { "%02x".format(it) }
        }
        check(actual == expected) { "MariaDB runtime archive SHA-256 mismatch" }
        check(tempArchive.length() <= MAX_RUNTIME_BYTES) { "MariaDB runtime archive exceeds size limit" }

        val staging = File(context.filesDir, "mariadb-prefix-staging")
        deleteTree(staging)
        staging.mkdirs()
        extractSafely(tempArchive, staging)
        prepareRuntimeExecutables(staging)
        check(File(staging, "bin/mariadbd.pockethost-bin").isFile ||
            File(staging, "bin/mysqld.pockethost-bin").isFile) {
            "MariaDB server executable missing from runtime package"
        }
        deleteTree(prefix)
        check(staging.renameTo(prefix)) { "Cannot activate MariaDB runtime directory" }
        tempArchive.delete()
    }

    private fun extractSafely(archive: File, destination: File) {
        val root = destination.canonicalFile.toPath()
        TarArchiveInputStream(GZIPInputStream(BufferedInputStream(FileInputStream(archive)))).use { tar ->
            val buffer = ByteArray(64 * 1024)
            var entry = tar.nextTarEntry
            while (entry != null) {
                val name = entry.name.replace('\\', '/').removePrefix("./")
                val parts = name.split('/').filter { it.isNotBlank() && it != "." }
                require(!name.startsWith("/") && parts.none { it == ".." }) { "Unsafe MariaDB archive path: ${entry.name}" }
                val path = root.resolve(parts.joinToString("/")).normalize()
                require(path.startsWith(root)) { "MariaDB archive path escaped runtime root" }
                val out = path.toFile()
                when {
                    entry.isDirectory -> out.mkdirs()
                    entry.isSymbolicLink -> {
                        val link = entry.linkName.replace('\\', '/')
                        require(!link.startsWith("/")) { "Absolute MariaDB symlink rejected" }
                        val target = (path.parent ?: root).resolve(link).normalize()
                        require(target.startsWith(root)) { "MariaDB symlink escaped runtime root" }
                        out.parentFile?.mkdirs()
                        runCatching { java.nio.file.Files.createSymbolicLink(path, (path.parent ?: root).relativize(target)) }
                    }
                    entry.isLink -> Unit
                    entry.isFile -> {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { output ->
                            while (true) { val n = tar.read(buffer); if (n <= 0) break; output.write(buffer, 0, n) }
                        }
                        out.setReadable(true, true)
                        out.setWritable(true, true)
                        out.setExecutable((entry.mode and 0b001001001) != 0, false)
                    }
                }
                entry = tar.nextTarEntry
            }
        }
    }

    /**
     * Android blocks execve() of app-downloaded ELF files from writable app
     * storage. Termux-style binaries are PIE; make shell wrappers that route
     * every executable through Android's system linker. This also lets the
     * upstream mariadb-install-db script invoke helper binaries consistently.
     */
    private fun prepareRuntimeExecutables(root: File) {
        for (folderName in listOf("bin", "sbin")) {
            val folder = File(root, folderName)
            if (!folder.isDirectory) continue
            folder.listFiles()?.filter {
                it.isFile && !java.nio.file.Files.isSymbolicLink(it.toPath()) && !it.name.endsWith(".so")
            }?.forEach { file ->
                if (!isElf(file)) return@forEach
                val real = File(file.parentFile, file.name + ".pockethost-bin")
                if (!real.exists() && !file.renameTo(real)) {
                    error("Cannot stage MariaDB executable ${file.name}")
                }
                val wrapper = File(file.parentFile, file.name)
                wrapper.writeText(
                    "#!/system/bin/sh\n" +
                    "exec /system/bin/linker64 \"\$PREFIX/${folderName}/${real.name}\" \"\$@\"\n"
                )
                wrapper.setReadable(true, true)
                wrapper.setExecutable(true, false)
            }
        }
    }

    private fun isElf(file: File): Boolean = runCatching {
        FileInputStream(file).use { it.read() == 0x7f && it.read() == 0x45 && it.read() == 0x4c && it.read() == 0x46 }
    }.getOrDefault(false)

    private fun initializeDatabase() {
        val script = File(prefix, "bin/mariadb-install-db")
        check(script.isFile) { "mariadb-install-db script is missing" }
        val args = listOf(
            "/system/bin/sh", script.absolutePath,
            "--basedir=${prefix.absolutePath}",
            "--datadir=${dataDir.absolutePath}",
            "--auth-root-authentication-method=normal",
            "--skip-test-db"
        )
        val result = runProcess(args, 120_000)
        check(result.first == 0) { "Database initialization exited ${result.first}: ${result.second.take(1200)}" }
        check(File(dataDir, "mysql").isDirectory) { "System database directory was not created" }
    }

    private fun startProcess() {
        val executable = listOf(
            File(prefix, "bin/mariadbd.pockethost-bin"),
            File(prefix, "bin/mysqld.pockethost-bin")
        ).firstOrNull { it.isFile } ?: error("MariaDB daemon not found")
        val socket = File(context.filesDir, "mariadb.sock")
        val log = File(context.filesDir, "mariadb-server.log")
        val args = listOf(
            "/system/bin/linker64", executable.absolutePath,
            "--no-defaults",
            "--basedir=${prefix.absolutePath}",
            "--datadir=${dataDir.absolutePath}",
            "--plugin-dir=${File(prefix, "lib/mariadb/plugin").absolutePath}",
            "--socket=${socket.absolutePath}",
            "--pid-file=${File(context.filesDir, "mariadb.pid").absolutePath}",
            "--log-error=${log.absolutePath}",
            "--port=$PORT",
            "--bind-address=127.0.0.1",
            "--skip-name-resolve",
            "--character-set-server=utf8mb4",
            "--collation-server=utf8mb4_unicode_ci"
        )
        val builder = ProcessBuilder(args).redirectErrorStream(true).redirectOutput(log)
        configureEnvironment(builder)
        process = builder.start()

        val deadline = System.currentTimeMillis() + 35_000
        while (System.currentTimeMillis() < deadline) {
            if (process?.isAlive != true) {
                val detail = runCatching { log.readText().take(1200) }.getOrDefault("")
                error("MariaDB daemon exited. $detail")
            }
            if (canConnectTcp()) return
            Thread.sleep(350)
        }
        process?.destroy()
        val detail = runCatching { log.readText().take(1200) }.getOrDefault("")
        error("MariaDB did not open port $PORT within 35 seconds. $detail")
    }

    private fun canConnectTcp(): Boolean = runCatching {
        Socket().use { it.connect(InetSocketAddress("127.0.0.1", PORT), 500) }
    }.isSuccess

    private fun configureEnvironment(builder: ProcessBuilder) {
        val env = builder.environment()
        env["PREFIX"] = prefix.absolutePath
        env["HOME"] = context.filesDir.absolutePath
        env["TMPDIR"] = context.cacheDir.absolutePath
        env["PATH"] = "${prefix.absolutePath}/bin:${prefix.absolutePath}/sbin:/system/bin"
        val libRoot = File(prefix, "lib")
        val libs = (listOf(
            libRoot,
            File(prefix, "lib/aarch64-linux-android"),
            File(prefix, "lib/mariadb"),
            File(prefix, "lib/mariadb/plugin")
        ) + if (libRoot.isDirectory) libRoot.walkTopDown().filter { it.isDirectory && it != libRoot }.toList() else emptyList())
            .filter { it.isDirectory }.distinct().joinToString(":") { it.absolutePath }
        env["LD_LIBRARY_PATH"] = libs
        env["MYSQL_HOME"] = prefix.absolutePath
        env["MARIADB_HOME"] = prefix.absolutePath
        env["TERM"] = "dumb"
    }

    private fun runProcess(command: List<String>, timeoutMs: Long): Pair<Int, String> {
        val builder = ProcessBuilder(command).redirectErrorStream(true)
        configureEnvironment(builder)
        val process = builder.start()
        val output = StringBuilder()
        val reader = thread(name = "PocketHost-MariaDB-init-output") {
            process.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { output.append(it).append('\n') }
            }
        }
        if (!process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)) {
            process.destroyForcibly()
            reader.join(1000)
            error("MariaDB initialization timed out")
        }
        reader.join(3000)
        return process.exitValue() to output.toString()
    }

    private fun <T> withConnection(password: String, database: String, block: (java.sql.Connection) -> T): T {
        val properties = java.util.Properties().apply {
            setProperty("user", "root")
            setProperty("password", password)
            setProperty("connectTimeout", "1500")
            setProperty("socketTimeout", "3000")
        }
        return DriverManager.getConnection("jdbc:mariadb://127.0.0.1:$PORT/$database", properties).use(block)
    }

    private fun generatePassword(): String {
        val bytes = ByteArray(24)
        SecureRandom().nextBytes(bytes)
        return android.util.Base64.encodeToString(bytes, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)
    }

    private fun sqlEscape(value: String) = value.replace("\\", "\\\\").replace("'", "''")
    private fun validateName(name: String) {
        require(name.matches(Regex("[A-Za-z][A-Za-z0-9_]{0,63}"))) {
            "Database names must start with a letter and contain only letters, numbers or underscores (max 64 characters)"
        }
    }

    private fun deleteTree(file: File) {
        if (file.isDirectory) file.listFiles()?.forEach { deleteTree(it) }
        runCatching { file.delete() }
    }
}
