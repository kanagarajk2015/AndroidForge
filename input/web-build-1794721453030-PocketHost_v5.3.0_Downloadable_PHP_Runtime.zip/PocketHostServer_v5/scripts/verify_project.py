from pathlib import Path
root = Path(".")
manager = (root / "app/src/main/java/com/pockethost/server/PhpRuntimeManager.kt").read_text()
main = (root / "app/src/main/java/com/pockethost/server/MainActivity.kt").read_text()
service = (root / "app/src/main/java/com/pockethost/server/HostingService.kt").read_text()
workflow = (root / ".github/workflows/android.yml").read_text()
gradle = (root / "app/build.gradle.kts").read_text()
assert "pmmp/PHP-Binaries/releases/download/pm5-php-8.4-latest" in manager
assert "d8867966340121f821591b9bb29c80a58ad77abd6cc8e0e44d1cbbb3aaedd70c" in manager
assert '"/system/bin/linker64"' in manager
assert "downloadVerified" in manager and "extractSafely" in manager
assert "Unsafe PHP archive path" in manager
assert "startSiteServer" in manager and "php.startSiteServer" in service
assert "Install PHP 8.4" in main
assert "Verify PHP is downloaded at runtime" in workflow
assert "lib/arm64-v8a/libphp.so" in workflow
assert "versionName = \"5.3.0\"" in gradle
print("PocketHost v5.3.0 source checks: PASS")
