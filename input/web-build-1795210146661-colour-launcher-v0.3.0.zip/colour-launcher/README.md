# Colour Launcher

An Android home-screen launcher with a ColorOS-inspired look: rounded icons, a dock, a
searchable app drawer, and colours taken from your wallpaper on Android 12 and later.

This is an independent project. It is not affiliated with OPPO or ColorOS.

> **Status:** early prototype (v0.3.0). It has not been compiled or tested on a device yet.

## Features

- Home screen with a clock and date header and a 4-column grid of apps
- Dock with up to four apps
- App drawer with search. Swipe up on the dock, or tap the handle below it, to open it
- Long-press any app for actions: add or remove from home, add or remove from dock, app info, uninstall
- Layout is saved between launches. Uninstalled apps are removed from the layout automatically
- Swipe up on the home screen (past the last row) to open the drawer; drag down at the top of the drawer to close it
- Settings sheet (gear icon, top right), saved between launches:
  - Wallpaper: pick any image and set it as the system wallpaper
  - Theme: system, light or dark, with an accent from the wallpaper (Android 12+) or Blue, Green, Pink, Orange
  - Icon packs: installed ADW/Nova-style packs (appfilter.xml). Apps the pack does not cover keep their own icon
  - 4 or 5 grid columns, icon shape (rounded, circle, square), icon size, app names on/off
- Wallpaper shows through the launcher. Accent colours come from the wallpaper (Android 12+)

## Not yet implemented

- Drag-to-reorder icons, folders, widgets and pages
- Notification badges, icon packs, and gestures

## Build

Requirements: Android Studio (Ladybug or newer) and JDK 17.

From the command line:

```sh
./gradlew assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/`.

To use it as your home app: install the APK, then open **Settings > Apps > Default apps > Home app** and pick Colour Launcher.

## Project layout

```
app/src/main/java/com/example/colourlauncher/
├── MainActivity.kt          Entry point; listens for package changes and HOME presses
├── LauncherViewModel.kt     Installed apps plus the home/dock layout
├── data/
│   ├── AppRepository.kt     Reads launchable apps from PackageManager
│   ├── LauncherApp.kt       App model (package, label, icon)
│   ├── LayoutStore.kt       Saves home and dock as JSON in SharedPreferences
│   ├── LauncherSettings.kt  Theme, accent, icon pack, columns, icon shape/size, labels
│   ├── IconPackRepository.kt Finds icon packs and reads appfilter.xml
│   └── SettingsStore.kt     Saves settings in SharedPreferences
├── ui/
│   ├── LauncherScreen.kt    Root: home screen, drawer, action sheet
│   ├── HomeScreen.kt        Clock, app grid, dock
│   ├── AppDrawer.kt         Searchable list of all apps
│   ├── AppComponents.kt     App icon, action sheet
│   ├── SettingsSheet.kt     Settings bottom sheet
│   ├── PullGesture.kt       Drag-past-the-end gesture for opening/closing the drawer
│   └── theme/Theme.kt       Material 3 theme with wallpaper colours
├── util/Intents.kt          Launch, app info, and uninstall intents
└── util/Wallpaper.kt        Sets the system wallpaper from a picked image
```

## Before publishing

- Change `applicationId` and `namespace` in `app/build.gradle.kts` from the `com.example` placeholder.
- Add a license file. None is included yet.

## Contributing

Issues and pull requests are welcome. Keep changes small and run `./gradlew assembleDebug` before opening a PR.
