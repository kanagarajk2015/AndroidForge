package com.example.colourlauncher.data

/** Shape used to clip app icons. */
enum class IconShape { Rounded, Circle, Square }

/** Light/dark behaviour of the launcher's own surfaces (drawer, dock, sheets). */
enum class ThemeMode { System, Light, Dark }

/** Where the accent colour comes from. [Wallpaper] needs Android 12+; older versions use Blue. */
enum class Accent { Wallpaper, Blue, Green, Pink, Orange }

/** User-adjustable look of the launcher. [iconPack] is a package name, or empty for system icons. */
data class LauncherSettings(
    val columns: Int = 4,
    val iconShape: IconShape = IconShape.Rounded,
    val iconSizeDp: Int = 56,
    val showLabels: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.System,
    val accent: Accent = Accent.Wallpaper,
    val iconPack: String = "",
)
