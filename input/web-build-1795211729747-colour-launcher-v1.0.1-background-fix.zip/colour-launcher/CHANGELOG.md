# Changelog

## 1.0.0
- Dedicated ColorOS 16-inspired style preset.
- Animated app-icon press feedback.
- Android 16 SDK 36 build configuration.
- No advertising SDKs or ad-network dependencies.
