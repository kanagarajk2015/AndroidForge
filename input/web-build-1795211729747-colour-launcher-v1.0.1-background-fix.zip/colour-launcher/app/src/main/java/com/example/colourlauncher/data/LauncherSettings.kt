package com.example.colourlauncher.data

/** Shape used to clip app icons. */
enum class IconShape { Rounded, Circle, Square }

/** Light/dark behaviour of the launcher's own surfaces (drawer, dock, sheets). */
enum class ThemeMode { System, Light, Dark }

/** Where the accent colour comes from. [Wallpaper] needs Android 12+; older versions use Blue. */
enum class Accent { Wallpaper, Blue, Green, Pink, Orange, Fluent }

/**
 * Overall layout presets: [ColorOS16] is the warm-accent floating dock, [Android17] is a pill
 * dock, [Classic] is the original dock + handle, and [Windows11] is a taskbar/start-menu panel.
 */
enum class LauncherStyle { Classic, Android17, ColorOS16, Windows11 }

/** User-adjustable look of the launcher. [iconPack] is a package name, or empty for system icons. */
data class LauncherSettings(
    val columns: Int = 4,
    val iconShape: IconShape = IconShape.Rounded,
    val iconSizeDp: Int = 56,
    val showLabels: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.System,
    val accent: Accent = Accent.Orange,
    val iconPack: String = "",
    val style: LauncherStyle = LauncherStyle.ColorOS16,
)
