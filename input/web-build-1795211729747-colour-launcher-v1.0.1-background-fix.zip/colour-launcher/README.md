# Colour Launcher 1.0.0

An independent Android home-screen launcher with a ColorOS 16-inspired visual preset,
rounded app icons, a floating dock/search pill, searchable app drawer, wallpaper-derived
Material You colours, and configurable icon packs.

This project is not affiliated with OPPO or ColorOS. It does not include advertising SDKs,
ad network dependencies, analytics SDKs, or ad placements.

## What's new in 1.0.0

- Added a dedicated **ColorOS 16** launcher preset and made it the default for fresh installs.
- The preset applies a warm orange accent, rounded icons, a four-column grid, and a floating
  rounded dock with an app-drawer search pill.
- Added spring-based press feedback to app icons and kept the existing animated drawer and
  quick-panel transitions.
- Updated Android Gradle Plugin to 8.10.0 and compile/target SDK to 36 for Android 16 builds.
- Increased version to 1.0.0 (versionCode 100).
- Retained Classic, Android 17-inspired, and Windows 11-inspired styles.
- Kept existing home/dock layout, app actions, icon-pack support, wallpaper picker, and quick controls.

## Features

- Home screen clock/date and configurable 4/5-column app grid.
- Floating dock with up to four apps and an app-drawer search pill in the ColorOS 16 preset.
- Searchable app drawer and long-press actions to add/remove apps from home or dock, open app
  info, or request uninstall.
- Persistent home/dock layout and settings.
- System, light, and dark themes; wallpaper-derived colours on Android 12+.
- Rounded, circular, or square app icons; adjustable icon size and labels.
- Installed ADW/Nova-style icon-pack discovery.
- Wallpaper picker and quick controls for flashlight, media volume, brightness, and shortcuts
  to Android system settings.
- Smooth app-icon press feedback and animated drawer/panel transitions.

## No-ad statement

There are no ad SDKs or ad-network dependencies in this source project. The launcher itself
does not display ads. This does not control ads shown by other apps, websites, or the Android
system.

## Build

Requirements: JDK 17, Android SDK Platform 36, and Gradle wrapper (included).

```sh
./gradlew assembleDebug
```

Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Install and choose as home app

Install the debug APK, then open Android **Settings → Apps → Default apps → Home app** and
select **Colour Launcher**.

## Before publishing

- Change the placeholder `applicationId` and `namespace` (`com.example.colourlauncher`) to a
  permanent unique package ID before publishing.
- Configure a release signing key securely; never commit signing passwords or keystores.
- Add a project license and store listing assets.
- Run a clean build and test on physical devices, including Android 16, before release.

## Known limitations

- Android restricts launchers from directly toggling Wi-Fi, Bluetooth, airplane mode, and
  location; the controls open the corresponding system settings instead.
- Drag-to-reorder, folders, widgets, multiple home pages, and notification badges are not
  implemented in this version.
- The project has not been executed through a complete Android build in this environment;
  verify the GitHub Actions build before installing or publishing.
