package com.Moto.fingerprint

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.view.View
import android.view.animation.LinearInterpolator

/** Plays one animation style. It runs only while the view is attached to a window. */
class AnimatedDialView(context: Context) : View(context) {

    /** The style to play. Setting it changes the preview. */
    var preview: PreviewStyle? = null
        set(value) {
            field = value
            invalidate()
        }

    /** Dial radius as a share of the view's shorter side. */
    var radiusShare: Float = 0.36f

    private var phase = 0f
    private var animator: ValueAnimator? = null

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // Always square, so each tile is a square cell.
        val side = View.MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(side, side)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (animator == null) {
            animator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = LOOP_MS
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    phase = it.animatedValue as Float
                    invalidate()
                }
            }
        }
        animator?.start()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val st = preview ?: return
        val side = minOf(width, height).toFloat()
        Effects.draw(canvas, st, width / 2f, height / 2f, side * radiusShare, phase)
    }

    companion object {
        private const val LOOP_MS = 2000L
    }
}
