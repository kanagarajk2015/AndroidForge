package com.Moto.fingerprint

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.sin

/**
 * The three unlock animations, drawn around a centre point. [t] runs 0..1 and every style is
 * periodic over that range, so each loop joins up without a jump.
 */
object Effects {
    private const val TAU = 6.2831855f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    private val YELLOW = Color.rgb(0xE9, 0xB3, 0x3A)
    private val PURPLE = Color.rgb(0x8E, 0x63, 0xC2)
    private val RED = Color.rgb(0xF0, 0x55, 0x3E)
    private val BLUE = Color.rgb(0x2D, 0x9C, 0xD8)
    private val TEAL = Color.rgb(0x17, 0xA5, 0x8E)
    private val PALETTE = intArrayOf(YELLOW, PURPLE, RED, BLUE, TEAL)

    fun draw(c: Canvas, s: PreviewStyle, cx: Float, cy: Float, r: Float, t: Float) {
        when (s.effect) {
            Effect.RADIAL_WAVES -> radialWaves(c, cx, cy, r, t)
            Effect.BOOMERANG -> boomerang(c, cx, cy, r, t)
            Effect.CHROMA_DIAL -> chromaDial(c, cx, cy, r, t)
        }
    }

    private fun withAlpha(col: Int, a: Float): Int =
        Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(col), Color.green(col), Color.blue(col))

    private fun stroke(col: Int, a: Float, width: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = width
        paint.strokeCap = Paint.Cap.ROUND
        paint.shader = null
        paint.color = withAlpha(col, a)
    }

    /** Draws an arc, or a full circle when [sweep] is 360. */
    private fun arc(c: Canvas, cx: Float, cy: Float, radius: Float, start: Float, sweep: Float) {
        rect.set(cx - radius, cy - radius, cx + radius, cy + radius)
        c.drawArc(rect, start, sweep, false, paint)
    }

    /** Concentric rings of coloured arcs that spin in alternating directions. */
    private fun chromaDial(c: Canvas, cx: Float, cy: Float, r: Float, t: Float) {
        for (ring in 0 until 5) {
            val radius = r * (1f - ring * 0.15f)
            val direction = if (ring % 2 == 0) 1f else -1f
            val turns = if (ring % 3 == 0) 1f else 2f
            val spin = direction * 360f * turns * t
            for (k in 0 until 3) {
                stroke(PALETTE[(ring + k) % 5], 1f, r * 0.09f)
                arc(c, cx, cy, radius, spin + k * 120f + ring * 37f, 70f + ring * 8f)
            }
        }
    }

    /** Rings that grow out from the centre and fade. */
    private fun radialWaves(c: Canvas, cx: Float, cy: Float, r: Float, t: Float) {
        for (k in 0 until 4) {
            val p = (t + k / 4f) % 1f
            stroke(if (k % 2 == 0) TEAL else BLUE, 1f - p, r * (0.03f + 0.05f * (1f - p)))
            arc(c, cx, cy, r * (0.15f + 0.85f * p), 0f, 360f)
        }
    }

    /** Two arcs swing out and back in opposite directions, each with a fading trail. */
    private fun boomerang(c: Canvas, cx: Float, cy: Float, r: Float, t: Float) {
        for (arm in 0 until 2) {
            val colour = if (arm == 0) TEAL else YELLOW
            val radius = r * (if (arm == 0) 0.85f else 0.6f)
            for (trail in 0 until 6) {
                val tt = (t - trail * 0.02f + 1f) % 1f
                val swing = sin(tt * TAU) * 100f
                val centre = if (arm == 0) -90f + swing else 90f - swing
                stroke(colour, 1f - trail / 6f, r * 0.09f)
                arc(c, cx, cy, radius, centre - 30f, 60f)
            }
        }
    }
}
