package com.Moto.fingerprint

import android.content.Context

/** Converts density-independent pixels to real pixels. */
fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
