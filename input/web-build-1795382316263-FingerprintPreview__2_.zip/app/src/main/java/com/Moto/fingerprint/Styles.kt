package com.Moto.fingerprint

/** The three unlock animations listed on the phone's Animation styles screen. */
enum class Effect { RADIAL_WAVES, BOOMERANG, CHROMA_DIAL }

data class PreviewStyle(val name: String, val effect: Effect)

object Styles {
    val ALL: List<PreviewStyle> = listOf(
        PreviewStyle("Radial waves", Effect.RADIAL_WAVES),
        PreviewStyle("Boomerang", Effect.BOOMERANG),
        PreviewStyle("Chroma dial", Effect.CHROMA_DIAL)
    )
}
