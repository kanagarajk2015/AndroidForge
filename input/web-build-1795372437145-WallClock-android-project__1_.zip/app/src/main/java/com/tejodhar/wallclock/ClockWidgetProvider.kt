package com.tejodhar.wallclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.RemoteViews
import java.util.Calendar
import kotlin.math.max

class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(ctx, it) }
        scheduleNext(ctx)
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle) {
        updateOne(ctx, id)
    }

    override fun onEnabled(ctx: Context) = scheduleNext(ctx)

    override fun onDisabled(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(tickIntent(ctx))
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        ids.forEach { Prefs.clear(ctx, it) }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_TICK, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> updateAll(ctx)
        }
    }

    companion object {
        const val ACTION_TICK = "com.tejodhar.wallclock.TICK"

        private fun tickIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, ClockWidgetProvider::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun scheduleNext(ctx: Context) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val t = Calendar.getInstance().apply {
                add(Calendar.MINUTE, 1)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val pi = tickIntent(ctx)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC, t, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC, t, pi)
                }
            } catch (e: SecurityException) {
                am.set(AlarmManager.RTC, t, pi)
            }
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ClockWidgetProvider::class.java))
            ids.forEach { updateOne(ctx, it) }
            if (ids.isNotEmpty()) scheduleNext(ctx)
        }

        /** Refresh one widget, or all widgets when id is INVALID (editing the default look). */
        fun refresh(ctx: Context, id: Int) {
            if (id == AppWidgetManager.INVALID_APPWIDGET_ID) updateAll(ctx) else updateOne(ctx, id)
        }

        fun updateOne(ctx: Context, id: Int) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val s = Prefs.load(ctx, id)
            val o = mgr.getAppWidgetOptions(id)
            val d = ctx.resources.displayMetrics.density
            var wp = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0) * d).toInt()
            var hp = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0) * d).toInt()
            if (wp <= 0 || hp <= 0) { wp = 800; hp = 360 }
            val m = max(wp, hp)
            if (m > 900) {
                val f = 900f / m
                wp = (wp * f).toInt(); hp = (hp * f).toInt()
            }
            wp = max(wp, 100); hp = max(hp, 50)

            val bmp = ClockRenderer.render(ctx, s, Calendar.getInstance(), wp, hp)
            val rv = RemoteViews(ctx.packageName, R.layout.widget_clock)
            rv.setImageViewBitmap(R.id.clock_img, bmp)
            val open = Intent(ctx, MainActivity::class.java)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            val pi = PendingIntent.getActivity(
                ctx, id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.root, pi)
            mgr.updateAppWidget(id, rv)
        }
    }
}
