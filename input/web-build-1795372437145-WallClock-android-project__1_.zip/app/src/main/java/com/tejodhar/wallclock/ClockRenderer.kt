package com.tejodhar.wallclock

import android.content.Context
import android.graphics.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws the clock shape as a white mask, then fills the mask with
 * wallpaper / solid / gradient / rainbow (DST_IN), so the wallpaper shows inside the digits.
 */
object ClockRenderer {

    fun render(ctx: Context, s: ClockSettings, cal: Calendar, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        if (s.card) {
            val cp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000 }
            c.drawRoundRect(0f, 0f, w.toFloat(), h.toFloat(), h * 0.16f, h * 0.16f, cp)
        }

        val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        drawClock(Canvas(mask), s, cal, w, h, Color.WHITE)

        if (s.shadow) {
            val blur = Paint().apply {
                maskFilter = BlurMaskFilter(max(2f, h * 0.015f), BlurMaskFilter.Blur.NORMAL)
            }
            val off = IntArray(2)
            val alpha = mask.extractAlpha(blur, off)
            val sp = Paint().apply { color = 0xB3000000L.toInt() }
            c.drawBitmap(alpha, off[0].toFloat(), off[1] + h * 0.012f, sp)
            alpha.recycle()
        }

        val fill = makeFill(ctx, s, w, h)
        val dstIn = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
        Canvas(fill).drawBitmap(mask, 0f, 0f, dstIn)
        c.drawBitmap(fill, 0f, 0f, null)
        mask.recycle()
        fill.recycle()
        return out
    }

    private fun makeFill(ctx: Context, s: ClockSettings, w: Int, h: Int): Bitmap {
        if (s.fill == FillMode.WALLPAPER) {
            return WallpaperSource.load(ctx, s, w, h).copy(Bitmap.Config.ARGB_8888, true)
        }
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        when (s.fill) {
            FillMode.SOLID -> p.color = s.solid
            FillMode.GRADIENT -> {
                val g = Palettes.gradients[s.grad.coerceIn(0, Palettes.gradients.size - 1)]
                p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), g, null, Shader.TileMode.CLAMP)
            }
            else -> p.shader = LinearGradient(0f, 0f, w.toFloat(), 0f, Palettes.rainbow, null, Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        return b
    }

    // ---------- helpers ----------

    private fun bounds(p: Paint, t: String): Rect = Rect().also { p.getTextBounds(t, 0, t.length, it) }

    private fun fit(p: Paint, ref: String, maxW: Float, maxH: Float, k: Float): Float {
        p.textSize = 100f
        val b = bounds(p, ref)
        val sc = min(maxW / b.width(), maxH / b.height())
        return 100f * sc * k
    }

    private fun xFor(a: ClockAlign, w: Int, pad: Float, tw: Float): Float = when (a) {
        ClockAlign.LEFT -> pad
        ClockAlign.CENTER -> (w - tw) / 2f
        ClockAlign.RIGHT -> w - pad - tw
    }

    private fun put(c: Canvas, p: Paint, t: String, ref: String, a: ClockAlign, w: Int, pad: Float, cy: Float) {
        val b = bounds(p, t)
        val r = bounds(p, ref)
        val x = xFor(a, w, pad, b.width().toFloat()) - b.left
        val base = cy - (r.top + r.bottom) / 2f
        c.drawText(t, x, base, p)
    }

    // ---------- clock layouts ----------

    private fun drawClock(c: Canvas, s: ClockSettings, cal: Calendar, w: Int, h: Int, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            typeface = Palettes.typeface(s.font)
        }
        val pad = w * 0.05f
        val maxW = w - 2 * pad
        val maxH = h - 2 * pad
        val cy = h / 2f
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val h12 = if (hour % 12 == 0) 12 else hour % 12
        val hh = if (s.is24) hour.toString().padStart(2, '0') else h12.toString()
        val mm = cal.get(Calendar.MINUTE).toString().padStart(2, '0')

        when (s.style) {
            ClockStyle.DIGITAL -> {
                p.textSize = fit(p, "00:00", maxW, maxH, s.scale)
                put(c, p, "$hh:$mm", "00:00", s.align, w, pad, cy)
            }

            ClockStyle.STACKED -> {
                p.textSize = fit(p, "00", maxW, maxH * 0.46f, s.scale)
                val bh = bounds(p, "00").height()
                val off = bh / 2f + maxH * 0.03f
                put(c, p, hh.padStart(2, '0'), "00", s.align, w, pad, cy - off)
                put(c, p, mm, "00", s.align, w, pad, cy + off)
            }

            ClockStyle.BIG_HOUR -> {
                val gapF = 0.08f
                var hs = fit(p, "00", maxW * 0.62f, maxH, s.scale)
                fun totalW(size: Float): Float {
                    p.textSize = size
                    val a = bounds(p, hh).width()
                    p.textSize = size * 0.42f
                    val b = bounds(p, mm).width()
                    return a + b + size * gapF
                }
                var tw = totalW(hs)
                if (tw > maxW) {
                    hs *= maxW / tw
                    tw = totalW(hs)
                }
                p.textSize = hs
                val bh = bounds(p, hh)
                val ref = bounds(p, "00")
                val x0 = xFor(s.align, w, pad, tw)
                val base = cy - (ref.top + ref.bottom) / 2f
                c.drawText(hh, x0 - bh.left, base, p)
                p.textSize = hs * 0.42f
                val bm = bounds(p, mm)
                c.drawText(mm, x0 + bh.width() + hs * gapF - bm.left, base, p)
            }

            ClockStyle.DATE -> {
                p.textSize = fit(p, "00:00", maxW, maxH * 0.62f, s.scale)
                val bt = bounds(p, "00:00").height()
                val dp = Paint(p).apply {
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    letterSpacing = 0.12f
                }
                val dateRef = "WED, 28 MAY"
                val dateText = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(cal.time).uppercase()
                dp.textSize = min(p.textSize * 0.34f, fit(dp, dateRef, maxW, maxH * 0.2f, s.scale))
                val bd = bounds(dp, dateRef).height()
                val gap = maxH * 0.06f
                val top = cy - (bt + gap + bd) / 2f
                put(c, p, "$hh:$mm", "00:00", s.align, w, pad, top + bt / 2f)
                put(c, dp, dateText, dateRef, s.align, w, pad, top + bt + gap + bd / 2f)
            }

            ClockStyle.ANALOG -> {
                val r = min(maxW, maxH) / 2f * s.scale
                val cx = when (s.align) {
                    ClockAlign.LEFT -> pad + r
                    ClockAlign.CENTER -> w / 2f
                    ClockAlign.RIGHT -> w - pad - r
                }
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = r * 0.07f
                c.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
                for (i in 0 until 12) {
                    val a = i * 30.0 * PI / 180.0
                    val major = i % 3 == 0
                    val inner = r * (if (major) 0.74f else 0.84f)
                    val outer = r * 0.92f
                    p.strokeWidth = r * (if (major) 0.07f else 0.045f)
                    c.drawLine(
                        cx + (inner * sin(a)).toFloat(), cy - (inner * cos(a)).toFloat(),
                        cx + (outer * sin(a)).toFloat(), cy - (outer * cos(a)).toFloat(), p
                    )
                }
                val minute = cal.get(Calendar.MINUTE)
                val ha = ((hour % 12) + minute / 60f) * 30.0 * PI / 180.0
                val ma = minute * 6.0 * PI / 180.0
                p.strokeWidth = r * 0.1f
                c.drawLine(cx, cy, cx + (r * 0.5f * sin(ha)).toFloat(), cy - (r * 0.5f * cos(ha)).toFloat(), p)
                p.strokeWidth = r * 0.07f
                c.drawLine(cx, cy, cx + (r * 0.76f * sin(ma)).toFloat(), cy - (r * 0.76f * cos(ma)).toFloat(), p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.07f, p)
            }
        }
    }
}
