package com.tejodhar.wallclock

import android.appwidget.AppWidgetManager
import android.content.Context
import android.graphics.Typeface

enum class ClockStyle(val label: String) {
    DIGITAL("Digital"), STACKED("Stacked"), BIG_HOUR("Big hour"), DATE("Time + date"), ANALOG("Analog")
}

enum class ClockAlign(val label: String) { LEFT("Left"), CENTER("Centre"), RIGHT("Right") }

enum class FillMode(val label: String) {
    WALLPAPER("Wallpaper"), SOLID("Solid"), GRADIENT("Gradient"), RAINBOW("Rainbow")
}

enum class WallSource(val label: String) {
    SUNSET("Sunset"), OCEAN("Ocean"), AURORA("Aurora"), NEON("Neon"), FOREST("Forest"),
    GALAXY("Galaxy"), PEACH("Peach"), MIDNIGHT("Midnight"), GALLERY("Gallery"), SYSTEM("Current")
}

data class ClockSettings(
    val style: ClockStyle = ClockStyle.DIGITAL,
    val align: ClockAlign = ClockAlign.CENTER,
    val fill: FillMode = FillMode.WALLPAPER,
    val wall: WallSource = WallSource.SUNSET,
    val solid: Int = 0xFFFFFFFF.toInt(),
    val grad: Int = 0,
    val font: Int = 1,
    val is24: Boolean = false,
    val shadow: Boolean = true,
    val card: Boolean = false,
    val scale: Float = 1f,
    val uri: String = ""
)

private fun c(v: Long) = v.toInt()

object Palettes {
    val wall: Map<WallSource, IntArray> = mapOf(
        WallSource.SUNSET to intArrayOf(c(0xFFFF512F), c(0xFFF09819), c(0xFFDD2476), c(0xFF5B247A)),
        WallSource.OCEAN to intArrayOf(c(0xFF00C6FF), c(0xFF0072FF), c(0xFF00D2B4), c(0xFF023E8A)),
        WallSource.AURORA to intArrayOf(c(0xFF00F5A0), c(0xFF00D9F5), c(0xFF7B2FF7), c(0xFF0F2027)),
        WallSource.NEON to intArrayOf(c(0xFFFF00CC), c(0xFF3333FF), c(0xFF00FFD5), c(0xFFFFEE00)),
        WallSource.FOREST to intArrayOf(c(0xFF134E5E), c(0xFF71B280), c(0xFFA8E063), c(0xFF0B3D2E)),
        WallSource.GALAXY to intArrayOf(c(0xFF0F0C29), c(0xFF302B63), c(0xFF8E2DE2), c(0xFFFF6A88)),
        WallSource.PEACH to intArrayOf(c(0xFFFFC3A0), c(0xFFFF9A9E), c(0xFFFECFEF), c(0xFFFFD86F)),
        WallSource.MIDNIGHT to intArrayOf(c(0xFF232526), c(0xFF414345), c(0xFF1CB5E0), c(0xFF000046))
    )

    val gradients: List<IntArray> = listOf(
        intArrayOf(c(0xFFFF512F), c(0xFFF09819)),
        intArrayOf(c(0xFF00C6FF), c(0xFF0072FF)),
        intArrayOf(c(0xFF11998E), c(0xFF38EF7D)),
        intArrayOf(c(0xFFFC466B), c(0xFF3F5EFB)),
        intArrayOf(c(0xFFF953C6), c(0xFFB91D73)),
        intArrayOf(c(0xFFFFE259), c(0xFFFFA751)),
        intArrayOf(c(0xFF8E2DE2), c(0xFF4A00E0)),
        intArrayOf(c(0xFFFFFFFF), c(0xFF7F8C8D))
    )

    val solids: List<Int> = listOf(
        c(0xFFFFFFFF), c(0xFFFFEB3B), c(0xFFFF9800), c(0xFFFF5252), c(0xFFFF4081), c(0xFFE040FB),
        c(0xFF7C4DFF), c(0xFF448AFF), c(0xFF18FFFF), c(0xFF69F0AE), c(0xFFB2FF59), c(0xFF000000)
    )

    val rainbow: IntArray = intArrayOf(
        c(0xFFFF3B30), c(0xFFFF9500), c(0xFFFFCC00), c(0xFF34C759),
        c(0xFF00C7BE), c(0xFF007AFF), c(0xFFAF52DE)
    )

    val fontNames = listOf("Bold", "Black", "Condensed", "Thin", "Serif", "Mono", "Script")

    fun typeface(i: Int): Typeface = when (i) {
        0 -> Typeface.create("sans-serif", Typeface.BOLD)
        1 -> Typeface.create("sans-serif-black", Typeface.NORMAL)
        2 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
        3 -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
        4 -> Typeface.create("serif", Typeface.BOLD)
        5 -> Typeface.create("monospace", Typeface.BOLD)
        else -> Typeface.create("cursive", Typeface.BOLD)
    }
}

object Prefs {
    private const val INVALID = AppWidgetManager.INVALID_APPWIDGET_ID
    private fun sp(ctx: Context) = ctx.getSharedPreferences("clock", Context.MODE_PRIVATE)
    private fun pre(id: Int) = if (id == INVALID) "d_" else "w${id}_"

    private inline fun <reified T : Enum<T>> enumOf(n: String?, d: T): T =
        try { enumValueOf<T>(n ?: "") } catch (e: Exception) { d }

    fun load(ctx: Context, id: Int): ClockSettings {
        val sp = sp(ctx)
        var p = pre(id)
        if (!sp.contains(p + "style")) p = "d_"
        val d = ClockSettings()
        return ClockSettings(
            style = enumOf(sp.getString(p + "style", null), d.style),
            align = enumOf(sp.getString(p + "align", null), d.align),
            fill = enumOf(sp.getString(p + "fill", null), d.fill),
            wall = enumOf(sp.getString(p + "wall", null), d.wall),
            solid = sp.getInt(p + "solid", d.solid),
            grad = sp.getInt(p + "grad", d.grad),
            font = sp.getInt(p + "font", d.font),
            is24 = sp.getBoolean(p + "is24", d.is24),
            shadow = sp.getBoolean(p + "shadow", d.shadow),
            card = sp.getBoolean(p + "card", d.card),
            scale = sp.getFloat(p + "scale", d.scale),
            uri = sp.getString(p + "uri", "") ?: ""
        )
    }

    fun save(ctx: Context, id: Int, s: ClockSettings) {
        val p = pre(id)
        sp(ctx).edit()
            .putString(p + "style", s.style.name)
            .putString(p + "align", s.align.name)
            .putString(p + "fill", s.fill.name)
            .putString(p + "wall", s.wall.name)
            .putInt(p + "solid", s.solid)
            .putInt(p + "grad", s.grad)
            .putInt(p + "font", s.font)
            .putBoolean(p + "is24", s.is24)
            .putBoolean(p + "shadow", s.shadow)
            .putBoolean(p + "card", s.card)
            .putFloat(p + "scale", s.scale)
            .putString(p + "uri", s.uri)
            .apply()
    }

    fun clear(ctx: Context, id: Int) {
        val sp = sp(ctx)
        val e = sp.edit()
        sp.all.keys.filter { it.startsWith("w${id}_") }.forEach { e.remove(it) }
        e.apply()
    }
}
