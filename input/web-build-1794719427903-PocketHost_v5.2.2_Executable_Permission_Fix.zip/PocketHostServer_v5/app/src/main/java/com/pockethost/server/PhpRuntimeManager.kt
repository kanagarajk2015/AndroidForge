package com.pockethost.server

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream
import kotlin.concurrent.thread

/**
 * Experimental PHP 8.4 ARM64 runtime installer.
 * The downloaded package is pinned by URL and SHA-256. PHP runtime is downloaded
 * on demand rather than increasing the APK size.
 */
class PhpRuntimeManager(private val context: Context) {
    @Volatile var status: String = "Not installed"
        private set
    @Volatile var phpExecutable: File? = null
        private set

    private val siteProcesses = ConcurrentHashMap<String, Process>()
    private val sitePorts = ConcurrentHashMap<String, Int>()

    init {
        phpExecutable = findPhp(File(context.filesDir, "php-runtime"))
        if (phpExecutable != null) status = "PHP 8.4 installed • detected"
    }

    fun install(onComplete: (Boolean, String) -> Unit) {
        thread(name = "PocketHost-PHP-install") {
            try {
                status = "Downloading PHP 8.4 ARM64…"
                val base = File(context.filesDir, "php-runtime")
                val archive = File(context.cacheDir, "php-8.4-android-arm64.tar.gz")
                base.mkdirs()
                downloadVerified(archive)
                status = "Extracting PHP runtime…"
                val staging = File(context.filesDir, "php-runtime-staging")
                staging.deleteRecursively()
                staging.mkdirs()
                extractSafely(archive, staging)
                val php = findPhp(staging) ?: throw IllegalStateException(
                    "PHP executable not found in the downloaded package"
                )
                ensureExecutable(php)
                val probeBuilder = ProcessBuilder(php.absolutePath, "-v").redirectErrorStream(true)
                configureEnvironment(probeBuilder, staging, php)
                val probe = probeBuilder.start()
                val output = probe.inputStream.bufferedReader().use { it.readText() }
                if (!probe.waitFor().let { it == 0 }) {
                    throw IllegalStateException("PHP runtime test failed: ${output.take(500)}")
                }
                val finalDir = File(context.filesDir, "php-runtime")
                finalDir.deleteRecursively()
                if (!staging.renameTo(finalDir)) {
                    copyDirectory(staging, finalDir)
                    staging.deleteRecursively()
                }
                val finalPhp = findPhp(finalDir) ?: throw IllegalStateException("Installed PHP executable missing")
                ensureExecutable(finalPhp)
                phpExecutable = finalPhp
                archive.delete()
                status = "PHP 8.4 installed • ${output.lineSequence().firstOrNull() ?: "Ready"}"
                onComplete(true, status)
            } catch (e: Exception) {
                status = "Install failed: ${e.message ?: e.javaClass.simpleName}"
                onComplete(false, status)
            }
        }
    }

    fun startSiteServer(siteDir: File): Int {
        val php = phpExecutable ?: findPhp(File(context.filesDir, "php-runtime"))?.also {
            phpExecutable = it
        } ?: throw IllegalStateException("Install PHP runtime first")
        val key = siteDir.canonicalPath
        val existing = siteProcesses[key]
        val existingPort = sitePorts[key]
        if (existing != null && existing.isAlive && existingPort != null) return existingPort

        val port = 18000 + (siteDir.name.hashCode().toLong().and(0x7fffffff) % 10000).toInt()
        val log = File(siteDir, ".pockethost-php.log")
        val builder = ProcessBuilder(
            php.absolutePath, "-S", "127.0.0.1:$port", "-t", siteDir.absolutePath
        ).redirectErrorStream(true).redirectOutput(log)
        configureEnvironment(builder, File(context.filesDir, "php-runtime"), php)
        val process = builder.start()

        Thread.sleep(350)
        if (!process.isAlive) {
            throw IllegalStateException("PHP server failed to start. Check ${log.name}")
        }
        siteProcesses[key] = process
        sitePorts[key] = port
        return port
    }

    fun stopAll() {
        siteProcesses.values.forEach { runCatching { it.destroy() } }
        siteProcesses.clear()
        sitePorts.clear()
    }

    private fun downloadVerified(destination: File) {
        val url = URL(PHP_URL)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 60000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "PocketHost-Android/5.2")
        }
        try {
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("PHP download HTTP ${connection.responseCode}")
            }
            connection.inputStream.use { input ->
                FileOutputStream(destination).use { output -> input.copyTo(output) }
            }
        } finally {
            connection.disconnect()
        }
        val digest = MessageDigest.getInstance("SHA-256")
        destination.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        val actual = digest.digest().joinToString("") { "%02x".format(it) }
        if (!actual.equals(PHP_SHA256, ignoreCase = true)) {
            destination.delete()
            throw SecurityException("PHP package checksum mismatch")
        }
    }

private fun extractSafely(archive: File, destination: File) {
        val root = destination.canonicalFile.toPath()
        TarArchiveInputStream(GZIPInputStream(BufferedInputStream(FileInputStream(archive)))).use { tar ->
            val buffer = ByteArray(64 * 1024)
            var entry = tar.nextTarEntry
            while (entry != null) {
                // Tar archives commonly prefix entries with "./". Remove only that
                // harmless prefix; reject absolute paths and parent traversal.
                val normalizedName = entry.name.replace('\\', '/')
                    .replace(Regex("^(\\\\./)+"), "")
                val nameParts = normalizedName.split('/').filter { it.isNotEmpty() && it != "." }
                if (normalizedName.startsWith("/") || nameParts.any { it == ".." }) {
                    throw SecurityException("Unsafe archive entry path: ${entry.name}")
                }
                val out = root.resolve(nameParts.joinToString("/")).normalize()
                if (!out.startsWith(root)) {
                    throw SecurityException("Unsafe archive entry path: ${entry.name}")
                }
                val outFile = out.toFile()

                when {
                    entry.isDirectory -> outFile.mkdirs()

                    // The Android PHP build is statically linked. Symlinks are optional
                    // package metadata; ignore absolute/out-of-root links instead of
                    // failing the entire install. Safe relative links are retained.
                    entry.isSymbolicLink -> {
                        val linkName = entry.linkName.replace('\\', '/')
                        val parent = out.parent ?: root
                        val target = if (linkName.startsWith("/")) null
                            else parent.resolve(linkName).normalize()
                        if (target != null && target.startsWith(root)) {
                            outFile.parentFile?.mkdirs()
                            runCatching {
                                java.nio.file.Files.createSymbolicLink(
                                    out, parent.relativize(target)
                                )
                            }
                        }
                    }

                    entry.isLink -> {
                        val linkName = entry.linkName.replace('\\', '/')
                        val targetParts = linkName.split('/').filter { it.isNotEmpty() && it != "." }
                        val target = if (linkName.startsWith("/") || targetParts.any { it == ".." }) null
                            else root.resolve(targetParts.joinToString("/")).normalize()
                        if (target != null && target.startsWith(root) &&
                            java.nio.file.Files.exists(target)) {
                            outFile.parentFile?.mkdirs()
                            runCatching { java.nio.file.Files.createLink(out, target) }
                        }
                    }

                    entry.isFile -> {
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile).use { output ->
                            while (true) {
                                val n = tar.read(buffer)
                                if (n <= 0) break
                                output.write(buffer, 0, n)
                            }
                        }
                        if ((entry.mode and 0b001001001) != 0) outFile.setExecutable(true, true)
                    }
                }
                entry = tar.nextTarEntry
            }
        }
    }
    private fun ensureExecutable(file: File) {
        // Some tar packages mark the interpreter executable using mode bits that
        // are not preserved consistently by all Android filesystems.
        if (!file.setExecutable(true, true) || !file.canExecute()) {
            runCatching { android.system.Os.chmod(file.absolutePath, 0b111101101) }
        }
        if (!file.canExecute()) {
            throw IllegalStateException(
                "Android storage does not allow executing the PHP binary at ${file.absolutePath}"
            )
        }
    }

    private fun findPhp(root: File): File? {
        val candidates = root.walkTopDown().filter {
            it.isFile && it.name in setOf("php", "php8", "php84")
        }.toList()
        return candidates.firstOrNull { it.canExecute() } ?: candidates.firstOrNull()
    }

    private fun configureEnvironment(builder: ProcessBuilder, runtimeRoot: File, php: File) {
        val env = builder.environment()
        env["HOME"] = context.filesDir.absolutePath
        env["TMPDIR"] = context.cacheDir.absolutePath
        env["PATH"] = (php.parentFile?.absolutePath ?: "") + ":" + (env["PATH"] ?: "")
        env["LD_LIBRARY_PATH"] = collectLibraryDirs(runtimeRoot)
    }

    private fun collectLibraryDirs(start: File): String {
        val dirs = if (start.exists()) start.walkTopDown()
            .filter { it.isFile && it.name.endsWith(".so") }
            .mapNotNull { it.parentFile?.absolutePath }.distinct().toList() else emptyList()
        return (listOf(start.absolutePath) + dirs).distinct().joinToString(":")
    }

    private fun copyDirectory(from: File, to: File) {
        from.walkTopDown().forEach { src ->
            val dest = File(to, src.relativeTo(from).path)
            if (src.isDirectory) dest.mkdirs()
            else {
                dest.parentFile?.mkdirs()
                src.copyTo(dest, overwrite = true)
                if (src.canExecute()) dest.setExecutable(true, true)
            }
        }
    }

    companion object {
        // PMMP PHP-Binaries Android arm64 asset. Pin both release URL and digest.
        private const val PHP_URL =
            "https://github.com/pmmp/PHP-Binaries/releases/download/pm5-php-8.4-latest/PHP-8.4-Android-arm64-PM5.tar.gz"
        private const val PHP_SHA256 =
            "d8867966340121f821591b9bb29c80a58ad77abd6cc8e0e44d1cbbb3aaedd70c"
    }
}