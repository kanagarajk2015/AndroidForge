# HDMI Live TV (Android TV)

Shows live video from HDMI 1/2/3 using Android's TV Input Framework (TvView).

- Open in Android Studio and run on an Android TV device.
- Auto-detects HDMI sources: ports with a signal are marked ●; plugging in or powering on a source switches to it automatically.
- Press MENU / DPAD-DOWN to show the input bar; pick HDMI 1, 2 or 3.
- CH+ / CH- change tuner channels; on HDMI they pass to the connected box via HDMI-CEC (if enabled on your TV).
- Volume +/- and mute work from the remote; DPAD up/down also zaps tuner channels when the bar is hidden.

Notes
- Works on Android TV devices/TVs that expose HDMI inputs (not on emulators or most set-top boxes without HDMI-in).
- HDMI inputs are pass-through: the connected box (cable/satellite) controls its own channels.
- Reading tuner channels needs READ_EPG_DATA, which many TVs only grant to system apps; if denied, only HDMI inputs show.

## Digital TV (DVB / ATSC / ISDB)
- Scan channels first: TV Settings → Channels → Auto scan.
- Bar → "Digital TV" (or GUIDE / DPAD-left) opens the channel list; OK tunes.
- CH+/CH-, DPAD up/down, or type a number (use . or - for 7.1).
- Needs READ_EPG_DATA; if the TV denies it, only HDMI inputs are available.

### Scanning
- Bar → "Scan channels" (or RED button) opens the TV's own scan screen; when it finishes, the channel list is built and the first channel plays.
- GREEN / GUIDE open the channel list. OK selects, CH+/CH- and number keys change channels.
- If channel access is denied, use "System Live TV" to open the TV's built-in Live Channels app.
