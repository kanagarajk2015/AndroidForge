package com.example.hdmilivetv

import android.app.Activity
import android.content.Intent
import android.media.AudioManager
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.media.tv.TvView
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var tvView: TvView
    private lateinit var bar: LinearLayout
    private lateinit var status: TextView
    private lateinit var tvm: TvInputManager
    private lateinit var audio: AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private val hideBar = Runnable { bar.visibility = View.GONE; status.visibility = View.GONE }

    // HDMI state
    private var hdmiInputs: List<TvInputInfo> = emptyList()
    private val lastState = mutableMapOf<String, Int>()   // inputId -> INPUT_STATE_*
    private var currentInputId: String? = null

    // Digital TV (DVB / ATSC / ISDB tuner) state
    data class Channel(val id: Long, val inputId: String, val number: String, val name: String)
    private lateinit var channelList: ListView
    private var channels: List<Channel> = emptyList()
    private var channelIndex = 0
    private var onTuner = false
    private var hasTuner = false
    private val REQ_SCAN = 100
    private val digitBuffer = StringBuilder()
    private val commitDigits = Runnable { jumpToTypedChannel() }

    // Fires when an HDMI source is plugged in / unplugged / powered on or off
    private val inputCallback = object : TvInputManager.TvInputCallback() {
        override fun onInputStateChanged(inputId: String, state: Int) {
            val info = hdmiInputs.firstOrNull { it.id == inputId }
            val wasConnected = lastState[inputId] == TvInputManager.INPUT_STATE_CONNECTED
            lastState[inputId] = state
            refreshInputs()
            if (info == null) return
            val nowConnected = state == TvInputManager.INPUT_STATE_CONNECTED
            if (nowConnected && !wasConnected) {
                // New source detected: switch to it automatically
                tuneHdmi(info)
                flash("${labelFor(info, 0)} detected")
            } else if (!nowConnected && wasConnected) {
                flash("${labelFor(info, 0)} disconnected")
                if (currentInputId == inputId) {
                    // Fall back to another connected HDMI input, if any
                    hdmiInputs.firstOrNull { isConnected(it) }?.let { tuneHdmi(it) }
                }
            }
        }
        override fun onInputAdded(inputId: String) = refreshInputs()
        override fun onInputRemoved(inputId: String) = refreshInputs()
        override fun onInputUpdated(inputId: String) = refreshInputs()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvView = findViewById(R.id.tvView)
        bar = findViewById(R.id.bar)
        channelList = findViewById(R.id.channelList)
        status = findViewById(R.id.status)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        tvm = getSystemService(TV_INPUT_SERVICE) as TvInputManager

        channelList.setOnItemClickListener { _, _, pos, _ -> tuneChannel(pos); hideChannelList() }
        refreshInputs()

        // Start on the first HDMI input that has a signal (or the first HDMI input)
        (hdmiInputs.firstOrNull { isConnected(it) } ?: hdmiInputs.firstOrNull())?.let { tuneHdmi(it) }
        if (hdmiInputs.isEmpty()) status.text = "No HDMI inputs found on this device."
        bar.getChildAt(0)?.requestFocus()
        if (hasTuner && channels.isEmpty()) {
            showBar()
            flash("No digital channels yet. Choose Scan channels (or press RED).")
        }
    }

    override fun onStart() {
        super.onStart()
        tvm.registerCallback(inputCallback, handler)
        loadChannels()
        refreshInputs()
    }

    override fun onStop() {
        tvm.unregisterCallback(inputCallback)
        super.onStop()
    }

    private fun isConnected(info: TvInputInfo) =
        tvm.getInputState(info.id) == TvInputManager.INPUT_STATE_CONNECTED

    /** Re-reads all inputs and rebuilds the selector bar, marking HDMI ports that have a signal. */
    private fun refreshInputs() {
        val inputs = tvm.tvInputList
        // TvInputInfo.getHdmiDeviceInfo() is a hidden API, so label by the TV's own names
        hdmiInputs = inputs.filter { it.type == TvInputInfo.TYPE_HDMI }.sortedBy { labelFor(it, 0) }
        hdmiInputs.forEach { lastState.getOrPut(it.id) { tvm.getInputState(it.id) } }

        hasTuner = inputs.any { it.type == TvInputInfo.TYPE_TUNER }

        val hadFocus = bar.hasFocus()
        bar.removeAllViews()
        hdmiInputs.forEachIndexed { i, info ->
            val connected = isConnected(info)
            val label = labelFor(info, i + 1)
            val isCurrent = info.id == currentInputId && !onTuner
            addButton(
                text = (if (isCurrent) "▶ " else "") + label + if (connected) "  ●" else "  (no signal)",
                dim = !connected
            ) { tuneHdmi(info) }
        }
        if (hasTuner) {
            addButton("Digital TV", false) {
                if (channels.isEmpty()) flash("No channels yet. Choose Scan channels.")
                else { tuneChannel(channelIndex); showChannelList() }
            }
            addButton("Scan channels", false) { startScan() }
            if (channels.isEmpty()) addButton("System Live TV", false) { openSystemLiveTv() }
        }
        if (hadFocus) bar.getChildAt(0)?.requestFocus()
    }

    private fun labelFor(info: TvInputInfo, fallbackNumber: Int): String {
        val custom = info.loadCustomLabel(this)?.toString()
        val label = custom?.takeIf { it.isNotBlank() } ?: info.loadLabel(this)?.toString()
        return label?.takeIf { it.isNotBlank() } ?: "HDMI $fallbackNumber"
    }

    private fun addButton(text: String, dim: Boolean, onClick: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            textSize = 20f
            alpha = if (dim) 0.55f else 1f
            isFocusable = true
            setOnClickListener { onClick(); scheduleHide() }
        }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(16, 0, 16, 0)
        bar.addView(b, lp)
    }

    private fun tuneHdmi(info: TvInputInfo) {
        onTuner = false
        currentInputId = info.id
        tvView.tune(info.id, TvContract.buildChannelUriForPassthroughInput(info.id))
        flash(labelFor(info, 0))
        refreshInputs()
    }

    /** Reads the scanned digital channels (DVB-T/T2/C/S, ATSC, ISDB, DTMB...) from the TV database. */
    private fun loadChannels() {
        val tunerIds = tvm.tvInputList.filter { it.type == TvInputInfo.TYPE_TUNER }.map { it.id }.toSet()
        if (tunerIds.isEmpty()) { channels = emptyList(); return }
        val list = mutableListOf<Channel>()
        try {
            contentResolver.query(
                TvContract.Channels.CONTENT_URI,
                arrayOf(
                    TvContract.Channels._ID,
                    TvContract.Channels.COLUMN_INPUT_ID,
                    TvContract.Channels.COLUMN_DISPLAY_NUMBER,
                    TvContract.Channels.COLUMN_DISPLAY_NAME
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val input = c.getString(1) ?: continue
                    if (input !in tunerIds) continue
                    list += Channel(c.getLong(0), input, c.getString(2) ?: "", c.getString(3) ?: "")
                }
            }
        } catch (e: SecurityException) {
            // READ_EPG_DATA not granted on this device
        }
        // Sort naturally by number: 2, 7.1, 7.2, 10, 11 ...
        channels = list.sortedWith(compareBy({ numPart(it.number, 0) }, { numPart(it.number, 1) }))
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            channels.map { "${it.number}   ${it.name}" })
        channelList.adapter = adapter
        if (channelIndex >= channels.size) channelIndex = 0
    }

    private fun numPart(number: String, i: Int): Int =
        number.split(Regex("[^0-9]+")).filter { it.isNotEmpty() }.getOrNull(i)?.toIntOrNull() ?: 0

    private fun tuneChannel(index: Int) {
        if (channels.isEmpty()) return
        onTuner = true
        channelIndex = (index + channels.size) % channels.size
        val ch = channels[channelIndex]
        currentInputId = ch.inputId
        tvView.tune(ch.inputId, TvContract.buildChannelUri(ch.id))
        channelList.setItemChecked(channelIndex, true)
        flash("${ch.number}   ${ch.name}")
    }

    /** Typed channel numbers like 5, 12 or 7.1 (use the . or - key for sub-channels). */
    private fun typeDigit(ch: Char) {
        digitBuffer.append(ch)
        status.text = digitBuffer.toString()
        status.visibility = View.VISIBLE
        handler.removeCallbacks(commitDigits)
        handler.postDelayed(commitDigits, 1500)
    }

    private fun jumpToTypedChannel() {
        val typed = digitBuffer.toString().replace('-', '.')
        digitBuffer.clear()
        val idx = channels.indexOfFirst { it.number.replace('-', '.') == typed }
        if (idx >= 0) tuneChannel(idx) else flash("No channel $typed")
    }

    /** Opens the TV's own channel-scan screen (DVB-T/T2/C/S, ATSC, ISDB...) for the built-in tuner. */
    private fun startScan() {
        val intent = tvm.tvInputList
            .filter { it.type == TvInputInfo.TYPE_TUNER }
            .firstNotNullOfOrNull { it.createSetupIntent() }
        if (intent == null) {
            flash("Scan not available here. Use TV Settings → Channels → Auto scan.")
            return
        }
        try {
            startActivityForResult(intent, REQ_SCAN)
        } catch (e: Exception) {
            flash("Could not open scan. Use TV Settings → Channels → Auto scan.")
        }
    }

    /** Fallback when this app can't read the channel database: open the TV's own Live Channels app. */
    private fun openSystemLiveTv() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI))
        } catch (e: Exception) {
            flash("System Live TV app not found.")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SCAN) return
        loadChannels()
        refreshInputs()
        if (channels.isNotEmpty()) {
            flash("${channels.size} channels found")
            tuneChannel(0)
            showChannelList()
        } else {
            flash("No channels found or access denied. Try System Live TV.")
        }
    }

    private fun showChannelList() {
        channelList.visibility = View.VISIBLE
        channelList.setSelection(channelIndex)
        channelList.requestFocus()
        handler.removeCallbacks(hideBar)
    }

    private fun hideChannelList() {
        channelList.visibility = View.GONE
        scheduleHide()
    }

    override fun onBackPressed() {
        if (channelList.visibility == View.VISIBLE) hideChannelList() else super.onBackPressed()
    }

    private fun flash(msg: String) {
        status.text = msg
        status.visibility = View.VISIBLE
        scheduleHide()
    }

    // Remote control handling
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        // Volume always works
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> { adjustVolume(AudioManager.ADJUST_RAISE); return true }
            KeyEvent.KEYCODE_VOLUME_DOWN -> { adjustVolume(AudioManager.ADJUST_LOWER); return true }
            KeyEvent.KEYCODE_VOLUME_MUTE -> { adjustVolume(AudioManager.ADJUST_TOGGLE_MUTE); return true }
        }
        // While the channel list is open, let the list handle D-pad/OK
        if (channelList.visibility == View.VISIBLE) return super.onKeyDown(keyCode, event)

        when (keyCode) {
            KeyEvent.KEYCODE_MENU -> { showBar(); return true }
            KeyEvent.KEYCODE_PROG_RED -> if (hasTuner) { startScan(); return true }
            KeyEvent.KEYCODE_PROG_GREEN -> if (channels.isNotEmpty()) { showChannelList(); return true }

            // GUIDE / LIST / DPAD-LEFT open the digital channel list
            KeyEvent.KEYCODE_GUIDE ->
                if (channels.isNotEmpty()) { showChannelList(); return true }
            KeyEvent.KEYCODE_DPAD_LEFT ->
                if (onTuner && bar.visibility != View.VISIBLE) { showChannelList(); return true }

            // On HDMI the channel keys are not consumed, so the TV can pass them on via HDMI-CEC
            KeyEvent.KEYCODE_CHANNEL_UP ->
                if (onTuner) { tuneChannel(channelIndex + 1); return true }
            KeyEvent.KEYCODE_CHANNEL_DOWN ->
                if (onTuner) { tuneChannel(channelIndex - 1); return true }
            KeyEvent.KEYCODE_DPAD_UP ->
                if (onTuner && bar.visibility != View.VISIBLE) { tuneChannel(channelIndex + 1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN ->
                if (bar.visibility != View.VISIBLE) {
                    if (onTuner) tuneChannel(channelIndex - 1) else showBar()
                    return true
                }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER ->
                if (bar.visibility != View.VISIBLE) {
                    if (onTuner) showChannelList() else showBar()
                    return true
                }

            // Number keys: 0-9, and . or - for sub-channels (7.1)
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 ->
                if (onTuner) { typeDigit('0' + (keyCode - KeyEvent.KEYCODE_0)); return true }
            KeyEvent.KEYCODE_PERIOD, KeyEvent.KEYCODE_NUMPAD_DOT, KeyEvent.KEYCODE_MINUS ->
                if (onTuner) { typeDigit('.'); return true }
        }
        scheduleHide()
        return super.onKeyDown(keyCode, event)
    }

    private fun adjustVolume(direction: Int) {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun showBar() {
        bar.visibility = View.VISIBLE
        bar.getChildAt(0)?.requestFocus()
        scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideBar)
        handler.postDelayed(hideBar, 6000)
    }

    override fun onDestroy() {
        tvView.reset()
        super.onDestroy()
    }
}
