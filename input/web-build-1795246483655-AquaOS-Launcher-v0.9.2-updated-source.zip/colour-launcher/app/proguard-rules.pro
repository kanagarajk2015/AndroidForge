# Project-specific ProGuard/R8 rules go here.
# Compose and AndroidX ship their own consumer rules, so none are needed yet.
