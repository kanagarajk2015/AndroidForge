package com.example.colourlauncher.data

import android.content.Context

/** Saves [LauncherSettings] in SharedPreferences. Bad or missing values fall back to defaults. */
class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): LauncherSettings {
        val d = LauncherSettings()
        return LauncherSettings(
            columns = prefs.getInt(KEY_COLUMNS, d.columns).coerceIn(4, 5),
            iconShape = readEnum(KEY_SHAPE, d.iconShape),
            iconSizeDp = prefs.getInt(KEY_SIZE, d.iconSizeDp).coerceIn(48, 64),
            showLabels = prefs.getBoolean(KEY_LABELS, d.showLabels),
            themeMode = readEnum(KEY_THEME, d.themeMode),
            accent = readEnum(KEY_ACCENT, d.accent),
            iconPack = prefs.getString(KEY_ICON_PACK, "") ?: "",
            style = readEnum(KEY_STYLE, d.style),
            lockHome = prefs.getBoolean(KEY_LOCK_HOME, d.lockHome),
        )
    }

    fun save(s: LauncherSettings) {
        prefs.edit()
            .putInt(KEY_COLUMNS, s.columns)
            .putString(KEY_SHAPE, s.iconShape.name)
            .putInt(KEY_SIZE, s.iconSizeDp)
            .putBoolean(KEY_LABELS, s.showLabels)
            .putString(KEY_THEME, s.themeMode.name)
            .putString(KEY_ACCENT, s.accent.name)
            .putString(KEY_ICON_PACK, s.iconPack)
            .putString(KEY_STYLE, s.style.name)
            .putBoolean(KEY_LOCK_HOME, s.lockHome)
            .apply()
    }

    private inline fun <reified T : Enum<T>> readEnum(key: String, default: T): T =
        runCatching { enumValueOf<T>(prefs.getString(key, "") ?: "") }.getOrDefault(default)

    private companion object {
        const val KEY_COLUMNS = "columns"
        const val KEY_SHAPE = "icon_shape"
        const val KEY_SIZE = "icon_size_dp"
        const val KEY_LABELS = "show_labels"
        const val KEY_THEME = "theme_mode"
        const val KEY_ACCENT = "accent"
        const val KEY_ICON_PACK = "icon_pack"
        const val KEY_STYLE = "style"
        const val KEY_LOCK_HOME = "lock_home"
    }
}
