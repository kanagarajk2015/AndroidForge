package com.example.colourlauncher.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import com.example.colourlauncher.R

/** Opens an app's launcher activity, or shows a message if that is not possible. */
fun Context.launchPackage(packageName: String) {
    val intent = packageManager.getLaunchIntentForPackage(packageName)
    if (intent == null) {
        Toast.makeText(this, R.string.app_cannot_open, Toast.LENGTH_SHORT).show()
        return
    }
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(this, R.string.app_cannot_open, Toast.LENGTH_SHORT).show()
    }
}

/** Opens a system settings screen by action, or shows a message if the device has none. */
fun Context.openSettingsScreen(action: String) {
    try {
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(this, R.string.settings_unavailable, Toast.LENGTH_SHORT).show()
    }
}

fun Context.openAppInfo(packageName: String) {
    startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
    )
}

/** Asks the system to uninstall the package. The system shows its own confirmation. */
fun Context.uninstallPackage(packageName: String) {
    startActivity(
        Intent(Intent.ACTION_DELETE, Uri.fromParts("package", packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
    )
}

/**
 * Opens a Play Store search for icon packs. Falls back to the Play Store website in a browser
 * if the Play Store app is missing. Packs the user installs show up in the launcher settings
 * on their own, because the launcher rescans whenever an app is installed.
 */
fun Context.openIconPackStore() {
    val query = Uri.encode("icon pack")
    val candidates = listOf(
        Uri.parse("market://search?q=$query&c=apps"),
        Uri.parse("https://play.google.com/store/search?q=$query&c=apps"),
    )
    for (uri in candidates) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (e: ActivityNotFoundException) {
            // Try the next way of getting to the store.
        }
    }
    Toast.makeText(this, R.string.icon_pack_store_unavailable, Toast.LENGTH_SHORT).show()
}
