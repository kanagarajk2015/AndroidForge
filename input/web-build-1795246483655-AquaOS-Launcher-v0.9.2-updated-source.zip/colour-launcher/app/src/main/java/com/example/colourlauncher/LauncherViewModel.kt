package com.example.colourlauncher

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.colourlauncher.data.AppRepository
import com.example.colourlauncher.data.IconPackInfo
import com.example.colourlauncher.data.IconPackRepository
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.data.LauncherSettings
import com.example.colourlauncher.data.LayoutStore
import com.example.colourlauncher.data.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Maximum number of apps shown in the dock. */
const val DOCK_CAPACITY = 4

/** Number of apps placed on the home grid before the user has arranged it. */
private const val DEFAULT_HOME_SIZE = 16

/** Holds the installed apps and the user's home/dock layout. */
class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val layoutStore = LayoutStore(application)
    private val settingsStore = SettingsStore(application)
    private val iconPackRepository = IconPackRepository(application)

    private val _apps = MutableStateFlow<List<LauncherApp>>(emptyList())
    val apps: StateFlow<List<LauncherApp>> = _apps.asStateFlow()

    /**
     * Home screen cells in reading order. A package name fills a cell and null leaves it empty,
     * so icons can sit anywhere on the grid. The list never ends with an empty cell.
     */
    private val _home = MutableStateFlow<List<String?>>(emptyList())
    val home: StateFlow<List<String?>> = _home.asStateFlow()

    /** Package names in the dock, in display order. */
    private val _dock = MutableStateFlow<List<String>>(emptyList())
    val dock: StateFlow<List<String>> = _dock.asStateFlow()

    private val _settings = MutableStateFlow(settingsStore.load())
    val settings: StateFlow<LauncherSettings> = _settings.asStateFlow()

    private val _iconPacks = MutableStateFlow<List<IconPackInfo>>(emptyList())
    val iconPacks: StateFlow<List<IconPackInfo>> = _iconPacks.asStateFlow()

    init {
        reload()
    }

    /**
     * Re-reads the installed apps and reconciles the saved layout with them.
     * Runs on start and whenever a package is added, removed or updated.
     */
    fun reload() {
        viewModelScope.launch {
            _iconPacks.value = withContext(Dispatchers.IO) { iconPackRepository.findPacks() }
            val installed = repository.loadLauncherApps(_settings.value.iconPack)
            if (installed.isEmpty()) return@launch
            _apps.value = installed

            val installedPackages = installed.map { it.packageName }
            val dockPackages = (layoutStore.loadDock() ?: installedPackages.take(DOCK_CAPACITY))
                .filter { it in installedPackages }
                .take(DOCK_CAPACITY)
            // An uninstalled app leaves an empty cell behind. Auto arrange closes that gap.
            val homeCells: List<String?> = (
                layoutStore.loadHome()?.map { cell -> cell?.takeIf { it in installedPackages } }
                    ?: installedPackages.filterNot { it in dockPackages }.take(DEFAULT_HOME_SIZE)
                )
                .trimmed()

            _dock.value = dockPackages
            _home.value = homeCells
            layoutStore.saveDock(dockPackages)
            layoutStore.saveHome(homeCells)
        }
    }

    fun updateSettings(change: (LauncherSettings) -> LauncherSettings) {
        val old = _settings.value
        _settings.value = change(old)
        settingsStore.save(_settings.value)
        if (_settings.value.iconPack != old.iconPack) reload()
        // Cell positions depend on the column count, so changing it packs the icons again.
        if (_settings.value.columns != old.columns && _home.value.isNotEmpty()) {
            updateHome { it.filterNotNull() }
        }
    }

    /** Puts the app in the first empty cell, or after the last icon if there is no gap. */
    fun addToHome(packageName: String) = updateHome { current ->
        if (packageName in current) {
            current
        } else {
            val empty = current.indexOf(null)
            if (empty >= 0) {
                current.toMutableList().also { it[empty] = packageName }
            } else {
                current + packageName
            }
        }
    }

    /** Removes the app from the home screen and leaves its cell empty. */
    fun removeFromHome(packageName: String) = updateHome { current ->
        current.map { if (it == packageName) null else it }
    }

    /** Closes the gaps: icons keep their current order and fill the grid from the top. */
    fun autoArrangeHome() {
        if (_settings.value.lockHome) return
        updateHome { it.filterNotNull() }
    }

    /**
     * Drops [packageName] onto the home cell [slot]. An empty cell takes the icon. An occupied
     * cell swaps places with it. Ignored if the layout is locked.
     */
    fun dropHome(packageName: String, slot: Int) {
        if (_settings.value.lockHome || slot < 0) return
        updateHome { current ->
            val from = current.indexOf(packageName)
            if (from < 0 || from == slot) {
                current
            } else {
                val cells = current.toMutableList()
                while (cells.size <= slot) cells.add(null)
                val displaced = cells[slot]
                cells[slot] = packageName
                cells[from] = displaced
                cells
            }
        }
    }

    /** Returns false if the dock is full or the app is already docked. */
    fun addToDock(packageName: String): Boolean {
        val current = _dock.value
        if (packageName in current || current.size >= DOCK_CAPACITY) return false
        updateDock(current + packageName)
        return true
    }

    fun removeFromDock(packageName: String) = updateDock(_dock.value - packageName)

    /** Drops empty cells at the end, so the saved layout ends with the last icon. */
    private fun List<String?>.trimmed(): List<String?> = dropLastWhile { it == null }

    private fun updateHome(change: (List<String?>) -> List<String?>) {
        _home.value = change(_home.value).trimmed()
        layoutStore.saveHome(_home.value)
    }

    private fun updateDock(packages: List<String>) {
        _dock.value = packages
        layoutStore.saveDock(packages)
    }
}
