package com.example.colourlauncher.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.data.LauncherStyle
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.colourlauncher.DOCK_CAPACITY
import com.example.colourlauncher.LauncherViewModel
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.util.launchPackage
import com.example.colourlauncher.util.openAppInfo
import com.example.colourlauncher.util.setWallpaperFromUri
import com.example.colourlauncher.util.uninstallPackage
import kotlinx.coroutines.launch

/** Windows 11 flyouts grow out of the taskbar on a spring and shrink back quickly. */
private val PanelOrigin = TransformOrigin(0.5f, 1f)
private val PanelEnter = fadeIn(tween(160)) +
    slideInVertically(spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)) { it / 6 } +
    scaleIn(spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow), initialScale = 0.92f, transformOrigin = PanelOrigin)
private val PanelExit = fadeOut(tween(120)) +
    slideOutVertically(tween(180)) { it / 8 } +
    scaleOut(tween(180), targetScale = 0.95f, transformOrigin = PanelOrigin)

/**
 * Root of the launcher: the home screen, with the app drawer slid up on top of it.
 *
 * [homeSignal] changes whenever the system sends HOME again while the launcher is
 * already open. That closes the drawer.
 */
@Composable
fun LauncherScreen(viewModel: LauncherViewModel, homeSignal: Int) {
    val context = LocalContext.current
    val apps by viewModel.apps.collectAsStateWithLifecycle()
    val homePackages by viewModel.home.collectAsStateWithLifecycle()
    val dockPackages by viewModel.dock.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val iconPacks by viewModel.iconPacks.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = context.setWallpaperFromUri(uri)
                Toast.makeText(
                    context,
                    if (ok) R.string.wallpaper_set else R.string.wallpaper_failed,
                    Toast.LENGTH_SHORT,
                ).show()
            }
        }
    }

    var drawerOpen by rememberSaveable { mutableStateOf(false) }
    var actionTarget by remember { mutableStateOf<LauncherApp?>(null) }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }
    var controlsOpen by rememberSaveable { mutableStateOf(false) }
    // Arrange mode: icons on the home screen can be dragged to new positions.
    var arranging by rememberSaveable { mutableStateOf(false) }

    // Back closes the drawer. On the home screen it is consumed, so the launcher never exits.
    BackHandler {
        drawerOpen = false
        controlsOpen = false
        arranging = false
    }
    LaunchedEffect(homeSignal) {
        drawerOpen = false
        controlsOpen = false
        arranging = false
    }
    // Locking the layout ends any arranging in progress.
    LaunchedEffect(settings.lockHome) {
        if (settings.lockHome) arranging = false
    }

    val launch: (String) -> Unit = { packageName ->
        drawerOpen = false
        context.launchPackage(packageName)
    }
    val openActions: (LauncherApp) -> Unit = { actionTarget = it }

    CompositionLocalProvider(LocalLauncherSettings provides settings) {
        Box(modifier = Modifier.fillMaxSize()) {
            HomeScreen(
                apps = apps,
                homePackages = homePackages,
                dockPackages = dockPackages,
                onLaunch = launch,
                onLongPress = openActions,
                onOpenDrawer = { drawerOpen = true },
                onOpenSettings = { settingsOpen = true },
                onOpenControls = { controlsOpen = true },
                arranging = arranging,
                onDrop = viewModel::dropHome,
                onDoneArranging = { arranging = false },
            )

            if (settings.style == LauncherStyle.Windows11) {
                // Quick-settings flyout above the taskbar's clock. Tapping outside closes it.
                AnimatedVisibility(
                    visible = controlsOpen,
                    modifier = Modifier.fillMaxSize(),
                    enter = PanelEnter,
                    exit = PanelExit,
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { controlsOpen = false },
                    ) {
                        Surface(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .navigationBarsPadding()
                                .padding(end = 12.dp, bottom = TaskbarHeight + 20.dp)
                                .widthIn(max = 380.dp)
                                .fillMaxWidth()
                                .heightIn(max = 560.dp)
                                .pointerInput(Unit) { detectTapGestures { } },
                            shape = RoundedCornerShape(30.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            shadowElevation = 12.dp,
                        ) {
                            ControlContent(onClose = { controlsOpen = false })
                        }
                    }
                }

                // Start menu: a floating panel above the taskbar. Tapping outside it closes it.
                AnimatedVisibility(
                    visible = drawerOpen,
                    modifier = Modifier.fillMaxSize(),
                    enter = PanelEnter,
                    exit = PanelExit,
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { drawerOpen = false },
                    ) {
                        AppDrawer(
                            apps = apps,
                            onLaunch = launch,
                            onLongPress = openActions,
                            onClose = { drawerOpen = false },
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .navigationBarsPadding()
                                .padding(start = 12.dp, end = 12.dp, bottom = TaskbarHeight + 20.dp)
                                .fillMaxWidth()
                                .fillMaxHeight(0.72f)
                                // Swallow taps so only the area outside the panel closes it.
                                .pointerInput(Unit) { detectTapGestures { } },
                            panel = true,
                            onOpenSettings = {
                                drawerOpen = false
                                settingsOpen = true
                            },
                        )
                    }
                }
            } else {
                AnimatedVisibility(
                    visible = drawerOpen,
                    modifier = Modifier.fillMaxSize(),
                    enter = slideInVertically(initialOffsetY = { it }),
                    exit = slideOutVertically(targetOffsetY = { it }),
                ) {
                    AppDrawer(
                        apps = apps,
                        onLaunch = launch,
                        onLongPress = openActions,
                        onClose = { drawerOpen = false },
                    )
                }
            }
        }
    }

    if (controlsOpen && settings.style != LauncherStyle.Windows11) {
        ControlSheet(onDismiss = { controlsOpen = false })
    }

    if (settingsOpen) {
        SettingsSheet(
            settings = settings,
            iconPacks = iconPacks,
            onChange = viewModel::updateSettings,
            onPickWallpaper = { wallpaperPicker.launch("image/*") },
            onAutoArrange = { viewModel.autoArrangeHome() },
            onFreeArrange = {
                settingsOpen = false
                arranging = true
            },
            onDismiss = { settingsOpen = false },
        )
    }

    actionTarget?.let { app ->
        val pkg = app.packageName
        val addHomeLabel = stringResource(R.string.action_add_to_home)
        val removeHomeLabel = stringResource(R.string.action_remove_from_home)
        val addDockLabel = stringResource(R.string.action_add_to_dock)
        val removeDockLabel = stringResource(R.string.action_remove_from_dock)
        val appInfoLabel = stringResource(R.string.action_app_info)
        val uninstallLabel = stringResource(R.string.action_uninstall)

        val moveLabel = stringResource(R.string.action_move_icons)

        val actions = buildList<MenuAction> {
            // With the home screen locked, nothing that changes the layout is offered.
            if (!settings.lockHome) {
                if (pkg in homePackages) {
                    add(MenuAction(moveLabel) {
                        drawerOpen = false
                        arranging = true
                    })
                    add(MenuAction(removeHomeLabel) { viewModel.removeFromHome(pkg) })
                } else {
                    add(MenuAction(addHomeLabel) { viewModel.addToHome(pkg) })
                }
                if (pkg in dockPackages) {
                    add(MenuAction(removeDockLabel) { viewModel.removeFromDock(pkg) })
                } else if (dockPackages.size < DOCK_CAPACITY) {
                    add(MenuAction(addDockLabel) { viewModel.addToDock(pkg) })
                }
            }
            add(MenuAction(appInfoLabel) { context.openAppInfo(pkg) })
            add(MenuAction(uninstallLabel) { context.uninstallPackage(pkg) })
        }

        AppActionSheet(app = app, actions = actions, onDismiss = { actionTarget = null })
    }
}
