package com.example.colourlauncher.data

import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.util.Xml
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.toBitmap
import org.xmlpull.v1.XmlPullParser

/** An installed icon pack the user can choose. */
data class IconPackInfo(val packageName: String, val label: String)

/** Finds installed icon packs (ADW and Nova style) and reads their appfilter.xml. */
class IconPackRepository(private val context: Context) {

    private val packageManager = context.packageManager

    fun findPacks(): List<IconPackInfo> =
        PACK_ACTIONS
            .flatMap { action -> packageManager.queryIntentActivities(Intent(action), 0) }
            .distinctBy { it.activityInfo.packageName }
            .map { IconPackInfo(it.activityInfo.packageName, it.loadLabel(packageManager).toString()) }
            .sortedBy { it.label.lowercase() }

    /** Null if the pack is gone or has no readable appfilter.xml. */
    fun load(packageName: String): IconPack? = runCatching {
        val resources = packageManager.getResourcesForApplication(packageName)
        IconPack(resources, packageName, parseAppFilter(resources, packageName))
    }.getOrNull()

    private fun parseAppFilter(resources: Resources, packageName: String): Map<String, String> {
        val xmlId = resources.getIdentifier("appfilter", "xml", packageName)
        val parser: XmlPullParser = if (xmlId != 0) {
            resources.getXml(xmlId)
        } else {
            Xml.newPullParser().apply { setInput(resources.assets.open("appfilter.xml"), "utf-8") }
        }
        val mapping = HashMap<String, String>()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "item") {
                val component = parser.getAttributeValue(null, "component")
                val drawable = parser.getAttributeValue(null, "drawable")
                if (component != null && drawable != null && component.startsWith("ComponentInfo{")) {
                    // One icon per package, matching the launcher's one-entry-per-package model.
                    mapping.putIfAbsent(component.removePrefix("ComponentInfo{").substringBefore("/"), drawable)
                }
            }
            event = parser.next()
        }
        return mapping
    }

    private companion object {
        val PACK_ACTIONS = listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME")
    }
}

/** Icons from one icon pack, looked up by the app's package name. */
class IconPack(
    private val resources: Resources,
    private val packName: String,
    private val mapping: Map<String, String>,
) {
    /** Null when the pack has no icon for [packageName], so callers keep the app's own icon. */
    fun iconFor(packageName: String, sizePx: Int): ImageBitmap? = runCatching {
        val name = mapping[packageName] ?: return@runCatching null
        val id = resources.getIdentifier(name, "drawable", packName)
        if (id == 0) return@runCatching null
        ResourcesCompat.getDrawable(resources, id, null)?.toBitmap(sizePx, sizePx)?.asImageBitmap()
    }.getOrNull()
}
