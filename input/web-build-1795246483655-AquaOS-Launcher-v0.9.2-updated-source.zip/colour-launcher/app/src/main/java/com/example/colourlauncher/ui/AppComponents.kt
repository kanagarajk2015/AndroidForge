package com.example.colourlauncher.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import com.example.colourlauncher.data.LauncherStyle
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.data.IconShape
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.data.LauncherSettings
import com.example.colourlauncher.ui.theme.aquaGlassFill

/** Soft shadow that keeps white labels readable over bright wallpapers. */
internal val LauncherTextShadow = Shadow(color = Color.Black.copy(alpha = 0.45f), blurRadius = 6f)

/** The current launcher settings, provided once by LauncherScreen. */
val LocalLauncherSettings = staticCompositionLocalOf { LauncherSettings() }

internal fun IconShape.toShape(): Shape = when (this) {
    IconShape.Rounded -> RoundedCornerShape(percent = 29)
    IconShape.Circle -> CircleShape
    IconShape.Square -> RoundedCornerShape(6.dp)
}

/**
 * Springy press feedback: shrinks to [target] while pressed and bounces back on release.
 * [source] must be the same interaction source the clickable uses.
 */
@Composable
internal fun Modifier.pressScale(source: InteractionSource, target: Float = 0.9f): Modifier {
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) target else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "pressScale",
    )
    return this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

/** One row in the app action sheet. */
data class MenuAction(val label: String, val onClick: () -> Unit)

/** A rounded app icon that launches on tap and opens the action sheet on long press. */
// combinedClickable is still marked experimental in the Compose Foundation version this project uses.
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: LauncherApp,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
    showLabel: Boolean = true,
    labelColor: Color = Color.White,
) {
    val settings = LocalLauncherSettings.current
    val labelVisible = showLabel && settings.showLabels
    val win11 = settings.style == LauncherStyle.Windows11
    val oxygen = settings.style == LauncherStyle.OxygenOS
    val source = remember { MutableInteractionSource() }
    Column(
        modifier = modifier
            // Windows 11 icons spring when pressed.
            .then(if (win11) Modifier.pressScale(source, 0.88f) else Modifier)
            .combinedClickable(
                interactionSource = source,
                indication = LocalIndication.current,
                onClick = onClick,
                onLongClick = onLongClick,
            )
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val shape = settings.iconShape.toShape()
        val iconDescription = if (labelVisible) null else app.label
        if (win11) {
            // Fluent-style glass tile: the icon sits on a soft, rimmed plate with a gentle shadow.
            val tileSize = settings.iconSizeDp.dp
            Box(
                modifier = Modifier
                    .size(tileSize)
                    .shadow(4.dp, shape, clip = false)
                    .clip(shape)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.72f))
                    .border(1.dp, Color.White.copy(alpha = 0.16f), shape),
                contentAlignment = Alignment.Center,
            ) {
                Image(
                    bitmap = app.icon,
                    // The label below names the icon, so only unlabelled icons need their own description.
                    contentDescription = iconDescription,
                    modifier = Modifier
                        .size(tileSize * 0.74f)
                        .clip(shape),
                )
            }
        } else if (oxygen) {
            // OxygenOS 16: a glossy white circular plate with the icon set inside it.
            val plateSize = settings.iconSizeDp.dp
            Box(
                modifier = Modifier
                    .size(plateSize)
                    .shadow(6.dp, CircleShape, clip = false)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center,
            ) {
                Image(
                    bitmap = app.icon,
                    contentDescription = iconDescription,
                    modifier = Modifier
                        .size(plateSize * 0.82f)
                        .clip(CircleShape),
                )
            }
        } else {
            Image(
                bitmap = app.icon,
                // The label below names the icon, so only unlabelled icons need their own description.
                contentDescription = iconDescription,
                modifier = Modifier
                    .size(settings.iconSizeDp.dp)
                    .clip(shape),
            )
        }
        if (labelVisible) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = app.label,
                color = labelColor,
                style = MaterialTheme.typography.labelMedium.copy(shadow = LauncherTextShadow),
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 76.dp),
            )
        }
    }
}

/** Bottom sheet of actions for one app, shown on long press. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppActionSheet(
    app: LauncherApp,
    actions: List<MenuAction>,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = aquaGlassFill()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = null,
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp)),
            )
            Spacer(Modifier.width(16.dp))
            Text(text = app.label, style = MaterialTheme.typography.titleMedium)
        }

        actions.forEach { action ->
            ListItem(
                headlineContent = { Text(action.label) },
                modifier = Modifier.clickable {
                    onDismiss()
                    action.onClick()
                },
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}
