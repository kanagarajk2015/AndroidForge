package com.example.colourlauncher.util

import android.app.WallpaperManager
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import kotlin.math.max
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Longest side of the decoded image. Keeps big photos from exhausting memory. */
private const val MAX_WALLPAPER_SIDE = 3000

/** Sets the system wallpaper from an image the user picked. Returns false on any failure. */
suspend fun Context.setWallpaperFromUri(uri: Uri): Boolean = withContext(Dispatchers.IO) {
    runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_WALLPAPER_SIDE) sample *= 2

        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
            ?: return@runCatching false
        WallpaperManager.getInstance(this@setWallpaperFromUri).setBitmap(bitmap)
        true
    }.getOrDefault(false)
}
