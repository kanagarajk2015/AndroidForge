package com.example.colourlauncher.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherApp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

/** Height of the Windows 11 style taskbar, not counting the system navigation bar. */
val TaskbarHeight: Dp = 56.dp

private val TaskbarTime: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val TaskbarDate: DateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")

@Composable
private fun rememberNow(): State<LocalDateTime> = produceState(initialValue = LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(10_000L)
    }
}

/**
 * Windows 11 style taskbar: a floating, curved capsule with the Start button and the dock apps
 * centred and the clock on the right. The Start button opens the Start-menu panel (the app drawer).
 */
@Composable
fun Taskbar(
    apps: List<LauncherApp>,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    onStart: () -> Unit,
    onOpenControls: () -> Unit,
) {
    val now by rememberNow()
    val shape = RoundedCornerShape(30.dp)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(start = 12.dp, end = 12.dp, bottom = 8.dp),
        shape = shape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.84f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.16f)),
        shadowElevation = 8.dp,
    ) {
        Row(
            modifier = Modifier
                .height(TaskbarHeight)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                StartButton(onClick = onStart)
                apps.forEach { app -> TaskbarIcon(app, onLaunch, onLongPress) }
            }
            // The clock area opens the quick controls, like the system tray in Windows 11.
            val traySource = remember { MutableInteractionSource() }
            Column(
                modifier = Modifier
                    .pressScale(traySource, 0.94f)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(
                        interactionSource = traySource,
                        indication = LocalIndication.current,
                        onClickLabel = stringResource(R.string.controls_title),
                        onClick = onOpenControls,
                    )
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.End,
            ) {
                Text(
                    text = now.format(TaskbarTime),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.End,
                )
                Text(
                    text = now.format(TaskbarDate),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.End,
                )
            }
        }
    }
}

/** A 2x2 tile grid in graded accent tones, with a springy press. */
@Composable
private fun StartButton(onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val source = remember { MutableInteractionSource() }
    val tones = listOf(
        listOf(scheme.primary, scheme.primary.copy(alpha = 0.82f)),
        listOf(scheme.primary.copy(alpha = 0.82f), scheme.primary.copy(alpha = 0.64f)),
    )
    Box(
        modifier = Modifier
            .size(46.dp)
            .pressScale(source, 0.86f)
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = source,
                indication = LocalIndication.current,
                onClickLabel = stringResource(R.string.start_menu),
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            tones.forEach { rowTones ->
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    rowTones.forEach { tone ->
                        Box(Modifier.size(11.dp).background(tone, RoundedCornerShape(3.dp)))
                    }
                }
            }
        }
    }
}

// combinedClickable is still marked experimental in the Compose Foundation version this project uses.
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TaskbarIcon(
    app: LauncherApp,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
) {
    val shape = LocalLauncherSettings.current.iconShape.toShape()
    val source = remember { MutableInteractionSource() }
    Box(
        modifier = Modifier
            .size(46.dp)
            .pressScale(source, 0.84f)
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(
                interactionSource = source,
                indication = LocalIndication.current,
                onClick = { onLaunch(app.packageName) },
                onLongClick = { onLongPress(app) },
            ),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .size(30.dp)
                .clip(shape),
        )
        // Windows 11's small accent dash under a pinned app.
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 2.dp)
                .size(width = 12.dp, height = 3.dp)
                .background(MaterialTheme.colorScheme.primary, CircleShape),
        )
    }
}
