package com.example.colourlauncher.data

import androidx.compose.ui.graphics.ImageBitmap

/** An app the launcher can open. There is one entry per package. */
data class LauncherApp(
    val packageName: String,
    val label: String,
    val icon: ImageBitmap,
)
