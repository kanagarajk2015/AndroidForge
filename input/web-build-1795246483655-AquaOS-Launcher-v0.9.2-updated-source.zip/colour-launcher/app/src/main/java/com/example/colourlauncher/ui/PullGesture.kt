package com.example.colourlauncher.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.Velocity

/**
 * Fires [onTrigger] when the user keeps dragging past the end of a scrollable list.
 *
 * [upward] = true reacts to a drag up past the bottom (or on a list that does not scroll);
 * false reacts to a drag down past the top. Attach the result with Modifier.nestedScroll.
 */
@Composable
fun rememberPullConnection(upward: Boolean, threshold: Dp, onTrigger: () -> Unit): NestedScrollConnection {
    val thresholdPx = with(LocalDensity.current) { threshold.toPx() }
    val currentTrigger by rememberUpdatedState(onTrigger)
    return remember(upward, thresholdPx) {
        object : NestedScrollConnection {
            private var pulled = 0f

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source != NestedScrollSource.UserInput) return Offset.Zero
                val delta = if (upward) -available.y else available.y
                if (delta > 0f) {
                    pulled += delta
                    if (pulled > thresholdPx) {
                        pulled = 0f
                        currentTrigger()
                    }
                } else if (delta < 0f) {
                    pulled = 0f
                }
                return Offset.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                pulled = 0f
                return Velocity.Zero
            }
        }
    }
}
