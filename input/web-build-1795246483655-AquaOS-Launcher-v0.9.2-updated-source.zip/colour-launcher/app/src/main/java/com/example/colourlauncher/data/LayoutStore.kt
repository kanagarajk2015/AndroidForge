package com.example.colourlauncher.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Saves the home screen and the dock.
 *
 * The home screen is a list of cells in reading order: a package name fills a cell, and null
 * leaves it empty. Layouts saved before free placement contain no nulls, so they load unchanged.
 * The dock is a plain ordered list of package names.
 */
class LayoutStore(context: Context) {

    private val prefs = context.getSharedPreferences("layout", Context.MODE_PRIVATE)

    /** Null until the user's layout has been saved, so callers can apply defaults. */
    fun loadHome(): List<String?>? = readCells(KEY_HOME)

    fun saveHome(cells: List<String?>) {
        val array = JSONArray()
        cells.forEach { array.put(it ?: JSONObject.NULL) }
        prefs.edit().putString(KEY_HOME, array.toString()).apply()
    }

    fun loadDock(): List<String>? = read(KEY_DOCK)

    fun saveDock(packages: List<String>) {
        write(KEY_DOCK, packages)
    }

    /** Returns null for missing or corrupt data, which falls back to the defaults. */
    private fun read(key: String): List<String>? {
        val raw = prefs.getString(key, null) ?: return null
        return runCatching {
            val array = JSONArray(raw)
            List(array.length()) { array.getString(it) }
        }.getOrNull()
    }

    /** Like [read], but JSON null entries come back as null cells. */
    private fun readCells(key: String): List<String?>? {
        val raw = prefs.getString(key, null) ?: return null
        return runCatching {
            val array = JSONArray(raw)
            List(array.length()) { index -> if (array.isNull(index)) null else array.getString(index) }
        }.getOrNull()
    }

    private fun write(key: String, packages: List<String>) {
        prefs.edit().putString(key, JSONArray(packages).toString()).apply()
    }

    private companion object {
        const val KEY_HOME = "home"
        const val KEY_DOCK = "dock"
    }
}
