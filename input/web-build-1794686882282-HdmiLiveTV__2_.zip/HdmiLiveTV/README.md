# HDMI Live TV (Android TV)

Shows live video from HDMI 1/2/3 using Android's TV Input Framework (TvView).

- Open in Android Studio and run on an Android TV device.
- Press MENU / DPAD-DOWN to show the input bar; pick HDMI 1, 2 or 3.
- CH+ / CH- change tuner channels; on HDMI they pass to the connected box via HDMI-CEC (if enabled on your TV).
- Volume +/- and mute work from the remote; DPAD up/down also zaps tuner channels when the bar is hidden.

Notes
- Works on Android TV devices/TVs that expose HDMI inputs (not on emulators or most set-top boxes without HDMI-in).
- HDMI inputs are pass-through: the connected box (cable/satellite) controls its own channels.
- Reading tuner channels needs READ_EPG_DATA, which many TVs only grant to system apps; if denied, only HDMI inputs show.
