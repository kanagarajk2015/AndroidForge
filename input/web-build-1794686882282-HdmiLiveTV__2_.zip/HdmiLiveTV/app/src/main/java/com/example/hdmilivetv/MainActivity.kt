package com.example.hdmilivetv

import android.app.Activity
import android.media.AudioManager
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.media.tv.TvView
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var tvView: TvView
    private lateinit var bar: LinearLayout
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val hideBar = Runnable { bar.visibility = View.GONE; status.visibility = View.GONE }

    // Built-in tuner (antenna/cable/satellite) state
    private var tunerInput: TvInputInfo? = null
    private var tunerChannels: List<Uri> = emptyList()
    private var channelIndex = 0
    private var onTuner = false   // true while a tuner channel (not HDMI) is playing
    private lateinit var audio: AudioManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvView = findViewById(R.id.tvView)
        bar = findViewById(R.id.bar)
        status = findViewById(R.id.status)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager

        val tvm = getSystemService(TV_INPUT_SERVICE) as TvInputManager
        val inputs = tvm.tvInputList

        // HDMI 1 / 2 / 3 ... labelled by the TV's own names, sorted by label
        // (TvInputInfo.getHdmiDeviceInfo() is a hidden API, so we use loadLabel instead)
        val hdmi = inputs.filter { it.type == TvInputInfo.TYPE_HDMI }
            .sortedBy { labelFor(it, 0) }

        hdmi.forEachIndexed { i, info ->
            val label = labelFor(info, i + 1)
            addButton(label) { tuneHdmi(info, label) }
        }

        // Optional: built-in tuner with channel list
        tunerInput = inputs.firstOrNull { it.type == TvInputInfo.TYPE_TUNER }
        tunerInput?.let { t ->
            tunerChannels = loadChannels(t.id)
            if (tunerChannels.isNotEmpty()) {
                addButton("Live TV") { tuneChannel(0) }
            }
        }

        if (bar.childCount == 0) {
            status.text = "No HDMI inputs found on this device."
        } else {
            bar.getChildAt(0).requestFocus()
            // Auto-start first HDMI input
            hdmi.firstOrNull()?.let { tuneHdmi(it, labelFor(it, 1)) }
        }
    }

    private fun labelFor(info: TvInputInfo, fallbackNumber: Int): String {
        val custom = info.loadCustomLabel(this)?.toString()
        val label = custom?.takeIf { it.isNotBlank() } ?: info.loadLabel(this)?.toString()
        return label?.takeIf { it.isNotBlank() } ?: "HDMI $fallbackNumber"
    }

    private fun addButton(label: String, onClick: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 20f
            isFocusable = true
            setOnClickListener { onClick(); scheduleHide() }
        }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(16, 0, 16, 0)
        bar.addView(b, lp)
    }

    private fun tuneHdmi(info: TvInputInfo, label: String) {
        onTuner = false
        tvView.tune(info.id, TvContract.buildChannelUriForPassthroughInput(info.id))
        status.text = label
        status.visibility = View.VISIBLE
    }

    private fun loadChannels(inputId: String): List<Uri> = try {
        val list = mutableListOf<Uri>()
        contentResolver.query(
            TvContract.buildChannelsUriForInput(inputId),
            arrayOf(TvContract.Channels._ID), null, null, null
        )?.use { c ->
            while (c.moveToNext()) list += TvContract.buildChannelUri(c.getLong(0))
        }
        list
    } catch (e: SecurityException) {
        emptyList() // READ_EPG_DATA not granted on this device
    }

    private fun tuneChannel(index: Int) {
        val t = tunerInput ?: return
        if (tunerChannels.isEmpty()) return
        onTuner = true
        channelIndex = (index + tunerChannels.size) % tunerChannels.size
        tvView.tune(t.id, tunerChannels[channelIndex])
        status.text = "Channel ${channelIndex + 1}"
        status.visibility = View.VISIBLE
    }

    // Remote control handling
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MENU -> { showBar(); return true }

            // Volume: handled here so it always works and shows the TV's volume bar
            KeyEvent.KEYCODE_VOLUME_UP -> { adjustVolume(AudioManager.ADJUST_RAISE); return true }
            KeyEvent.KEYCODE_VOLUME_DOWN -> { adjustVolume(AudioManager.ADJUST_LOWER); return true }
            KeyEvent.KEYCODE_VOLUME_MUTE -> { adjustVolume(AudioManager.ADJUST_TOGGLE_MUTE); return true }

            // Channels: tuner channels are changed here. On HDMI we do NOT consume the key,
            // so the TV can pass it to the connected box over HDMI-CEC.
            KeyEvent.KEYCODE_CHANNEL_UP ->
                if (onTuner) { tuneChannel(channelIndex + 1); return true }
            KeyEvent.KEYCODE_CHANNEL_DOWN ->
                if (onTuner) { tuneChannel(channelIndex - 1); return true }
            KeyEvent.KEYCODE_DPAD_UP ->
                if (onTuner && bar.visibility != View.VISIBLE) { tuneChannel(channelIndex + 1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN ->
                if (bar.visibility != View.VISIBLE) {
                    if (onTuner) tuneChannel(channelIndex - 1) else showBar()
                    return true
                }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER ->
                if (bar.visibility != View.VISIBLE) { showBar(); return true }

            // Number keys jump straight to a tuner channel (1 = first channel)
            in KeyEvent.KEYCODE_1..KeyEvent.KEYCODE_9 ->
                if (onTuner) { tuneChannel(keyCode - KeyEvent.KEYCODE_1); return true }
        }
        scheduleHide()
        return super.onKeyDown(keyCode, event)
    }

    private fun adjustVolume(direction: Int) {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun showBar() {
        bar.visibility = View.VISIBLE
        bar.getChildAt(0)?.requestFocus()
        scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideBar)
        handler.postDelayed(hideBar, 6000)
    }

    override fun onDestroy() {
        tvView.reset()
        super.onDestroy()
    }
}
