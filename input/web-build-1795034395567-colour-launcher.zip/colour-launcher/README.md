# Colour Launcher

An Android home-screen launcher with a ColorOS-inspired look: rounded icons, a dock, a
searchable app drawer, and colours taken from your wallpaper on Android 12 and later.

This is an independent project. It is not affiliated with OPPO or ColorOS.

> **Status:** early prototype (v0.1.0). It has not been compiled or tested on a device yet.

## Features

- Home screen with a clock and date header and a 4-column grid of apps
- Dock with up to four apps
- App drawer with search. Swipe up on the dock, or tap the handle below it, to open it
- Long-press any app for actions: add or remove from home, add or remove from dock, app info, uninstall
- Layout is saved between launches. Uninstalled apps are removed from the layout automatically
- Wallpaper shows through the launcher. Accent colours come from the wallpaper (Android 12+)

## Not yet implemented

- Drag-to-reorder icons, folders, widgets, pages, and a settings screen
- Swipe-down to close the app drawer (back and Home both close it)
- Notification badges, icon packs, and gestures

## Build

Requirements: Android Studio (Ladybug or newer) and JDK 17.

From the command line:

```sh
./gradlew assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/`.

To use it as your home app: install the APK, then open **Settings > Apps > Default apps > Home app** and pick Colour Launcher.

## Project layout

```
app/src/main/java/com/example/colourlauncher/
├── MainActivity.kt          Entry point; listens for package changes and HOME presses
├── LauncherViewModel.kt     Installed apps plus the home/dock layout
├── data/
│   ├── AppRepository.kt     Reads launchable apps from PackageManager
│   ├── LauncherApp.kt       App model (package, label, icon)
│   └── LayoutStore.kt       Saves home and dock as JSON in SharedPreferences
├── ui/
│   ├── LauncherScreen.kt    Root: home screen, drawer, action sheet
│   ├── HomeScreen.kt        Clock, app grid, dock
│   ├── AppDrawer.kt         Searchable list of all apps
│   ├── AppComponents.kt     App icon, action sheet
│   └── theme/Theme.kt       Material 3 theme with wallpaper colours
└── util/Intents.kt          Launch, app info, and uninstall intents
```

## Before publishing

- Change `applicationId` and `namespace` in `app/build.gradle.kts` from the `com.example` placeholder.
- Add a license file. None is included yet.

## Contributing

Issues and pull requests are welcome. Keep changes small and run `./gradlew assembleDebug` before opening a PR.
