package com.example.colourlauncher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.colourlauncher.DOCK_CAPACITY
import com.example.colourlauncher.LauncherViewModel
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.util.launchPackage
import com.example.colourlauncher.util.openAppInfo
import com.example.colourlauncher.util.uninstallPackage

/**
 * Root of the launcher: the home screen, with the app drawer slid up on top of it.
 *
 * [homeSignal] changes whenever the system sends HOME again while the launcher is
 * already open. That closes the drawer.
 */
@Composable
fun LauncherScreen(viewModel: LauncherViewModel, homeSignal: Int) {
    val context = LocalContext.current
    val apps by viewModel.apps.collectAsStateWithLifecycle()
    val homePackages by viewModel.home.collectAsStateWithLifecycle()
    val dockPackages by viewModel.dock.collectAsStateWithLifecycle()

    var drawerOpen by rememberSaveable { mutableStateOf(false) }
    var actionTarget by remember { mutableStateOf<LauncherApp?>(null) }

    // Back closes the drawer. On the home screen it is consumed, so the launcher never exits.
    BackHandler { drawerOpen = false }
    LaunchedEffect(homeSignal) { drawerOpen = false }

    val launch: (String) -> Unit = { packageName ->
        drawerOpen = false
        context.launchPackage(packageName)
    }
    val openActions: (LauncherApp) -> Unit = { actionTarget = it }

    Box(modifier = Modifier.fillMaxSize()) {
        HomeScreen(
            apps = apps,
            homePackages = homePackages,
            dockPackages = dockPackages,
            onLaunch = launch,
            onLongPress = openActions,
            onOpenDrawer = { drawerOpen = true },
        )

        AnimatedVisibility(
            visible = drawerOpen,
            modifier = Modifier.fillMaxSize(),
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
        ) {
            AppDrawer(apps = apps, onLaunch = launch, onLongPress = openActions)
        }
    }

    actionTarget?.let { app ->
        val pkg = app.packageName
        val addHomeLabel = stringResource(R.string.action_add_to_home)
        val removeHomeLabel = stringResource(R.string.action_remove_from_home)
        val addDockLabel = stringResource(R.string.action_add_to_dock)
        val removeDockLabel = stringResource(R.string.action_remove_from_dock)
        val appInfoLabel = stringResource(R.string.action_app_info)
        val uninstallLabel = stringResource(R.string.action_uninstall)

        val actions = buildList<MenuAction> {
            if (pkg in homePackages) {
                add(MenuAction(removeHomeLabel) { viewModel.removeFromHome(pkg) })
            } else {
                add(MenuAction(addHomeLabel) { viewModel.addToHome(pkg) })
            }
            if (pkg in dockPackages) {
                add(MenuAction(removeDockLabel) { viewModel.removeFromDock(pkg) })
            } else if (dockPackages.size < DOCK_CAPACITY) {
                add(MenuAction(addDockLabel) { viewModel.addToDock(pkg) })
            }
            add(MenuAction(appInfoLabel) { context.openAppInfo(pkg) })
            add(MenuAction(uninstallLabel) { context.uninstallPackage(pkg) })
        }

        AppActionSheet(app = app, actions = actions, onDismiss = { actionTarget = null })
    }
}
