package com.example.colourlauncher.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Reads the apps that have a launcher entry on this device. */
class AppRepository(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager

    /** Every launchable app except this launcher, sorted by label. Runs off the main thread. */
    suspend fun loadLauncherApps(): List<LauncherApp> = withContext(Dispatchers.IO) {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        packageManager.queryIntentActivities(query, 0)
            .asSequence()
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { info ->
                LauncherApp(
                    packageName = info.activityInfo.packageName,
                    label = info.loadLabel(packageManager).toString(),
                    icon = info.loadIcon(packageManager)
                        .toBitmap(ICON_SIZE_PX, ICON_SIZE_PX)
                        .asImageBitmap(),
                )
            }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    private companion object {
        /** Icons are drawn at about 56dp, so 144px stays sharp on 3x screens. */
        const val ICON_SIZE_PX = 144
    }
}
