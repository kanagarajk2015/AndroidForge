package com.example.colourlauncher

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.colourlauncher.data.AppRepository
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.data.LayoutStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Maximum number of apps shown in the dock. */
const val DOCK_CAPACITY = 4

/** Number of apps placed on the home grid before the user has arranged it. */
private const val DEFAULT_HOME_SIZE = 16

/** Holds the installed apps and the user's home/dock layout. */
class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val layoutStore = LayoutStore(application)

    private val _apps = MutableStateFlow<List<LauncherApp>>(emptyList())
    val apps: StateFlow<List<LauncherApp>> = _apps.asStateFlow()

    /** Package names on the home grid, in display order. */
    private val _home = MutableStateFlow<List<String>>(emptyList())
    val home: StateFlow<List<String>> = _home.asStateFlow()

    /** Package names in the dock, in display order. */
    private val _dock = MutableStateFlow<List<String>>(emptyList())
    val dock: StateFlow<List<String>> = _dock.asStateFlow()

    init {
        reload()
    }

    /**
     * Re-reads the installed apps and reconciles the saved layout with them.
     * Runs on start and whenever a package is added, removed or updated.
     */
    fun reload() {
        viewModelScope.launch {
            val installed = repository.loadLauncherApps()
            if (installed.isEmpty()) return@launch
            _apps.value = installed

            val installedPackages = installed.map { it.packageName }
            val dockPackages = (layoutStore.loadDock() ?: installedPackages.take(DOCK_CAPACITY))
                .filter { it in installedPackages }
                .take(DOCK_CAPACITY)
            val homePackages = (
                layoutStore.loadHome()
                    ?: installedPackages.filterNot { it in dockPackages }.take(DEFAULT_HOME_SIZE)
                )
                .filter { it in installedPackages }

            _dock.value = dockPackages
            _home.value = homePackages
            layoutStore.saveDock(dockPackages)
            layoutStore.saveHome(homePackages)
        }
    }

    fun addToHome(packageName: String) = updateHome { if (packageName in it) it else it + packageName }

    fun removeFromHome(packageName: String) = updateHome { it - packageName }

    /** Returns false if the dock is full or the app is already docked. */
    fun addToDock(packageName: String): Boolean {
        val current = _dock.value
        if (packageName in current || current.size >= DOCK_CAPACITY) return false
        updateDock(current + packageName)
        return true
    }

    fun removeFromDock(packageName: String) = updateDock(_dock.value - packageName)

    private fun updateHome(change: (List<String>) -> List<String>) {
        _home.value = change(_home.value)
        layoutStore.saveHome(_home.value)
    }

    private fun updateDock(packages: List<String>) {
        _dock.value = packages
        layoutStore.saveDock(packages)
    }
}
