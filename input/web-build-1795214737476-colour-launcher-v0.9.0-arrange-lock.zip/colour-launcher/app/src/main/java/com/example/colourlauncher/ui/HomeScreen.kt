package com.example.colourlauncher.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.zIndex
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.colourlauncher.DOCK_CAPACITY
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.data.LauncherStyle
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

/** How far the user must swipe up on the dock to open the app drawer. */
private val SwipeUpDistance = 48.dp

private val TimeFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val DateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM")
private val OxygenTimeFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("HH : mm")

/** The home screen: clock, a 4-column grid of apps, and the dock. */
@Composable
fun HomeScreen(
    apps: List<LauncherApp>,
    homePackages: List<String>,
    dockPackages: List<String>,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenControls: () -> Unit,
    arranging: Boolean = false,
    onMove: (from: String, to: String) -> Unit = { _, _ -> },
    onDoneArranging: () -> Unit = {},
) {
    val settings = LocalLauncherSettings.current
    val columns = settings.columns
    // Dragging up past the bottom of the grid (or on a grid that fits the screen) opens the drawer.
    val pullUp = rememberPullConnection(upward = true, threshold = 64.dp, onTrigger = onOpenDrawer)
    // Dragging down from the top of the home screen opens the quick controls.
    val pullDown = rememberPullConnection(upward = false, threshold = 64.dp, onTrigger = onOpenControls)
    val appsByPackage = remember(apps) { apps.associateBy { it.packageName } }
    val homeApps = homePackages.mapNotNull { appsByPackage[it] }
    val dockApps = dockPackages.mapNotNull { appsByPackage[it] }

    // Drag-to-rearrange state. The dragged icon follows the finger; the others slide aside.
    val gridState = rememberLazyGridState()
    val currentOnMove by rememberUpdatedState(onMove)
    var draggingKey by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    // Where the dragged icon sat when it last swapped. Stops a second swap before the grid has re-laid out.
    var swapGuard by remember { mutableStateOf<IntOffset?>(null) }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            state = gridState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .nestedScroll(pullUp)
                .nestedScroll(pullDown),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        ) {
            // The Windows 11 style shows the clock in its taskbar and the gear in the Start menu.
            // While arranging, a hint and a Done button replace the clock.
            if (arranging) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    ArrangeBar(onDone = onDoneArranging)
                }
            } else if (settings.style != LauncherStyle.Windows11) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    ClockHeader(
                        onOpenSettings = onOpenSettings,
                        oxygen = settings.style == LauncherStyle.OxygenOS,
                    )
                }
            }

            if (homeApps.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        text = stringResource(R.string.home_empty_hint),
                        color = Color.White,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }

            items(homeApps, key = { it.packageName }) { app ->
                if (arranging) {
                    val dragging = draggingKey == app.packageName
                    Box(
                        modifier = Modifier
                            .then(if (dragging) Modifier.zIndex(1f) else Modifier.animateItem())
                            .graphicsLayer {
                                if (dragging) {
                                    translationX = dragOffset.x
                                    translationY = dragOffset.y
                                    scaleX = 1.1f
                                    scaleY = 1.1f
                                }
                            }
                            .pointerInput(app.packageName) {
                                detectDragGestures(
                                    onDragStart = {
                                        draggingKey = app.packageName
                                        dragOffset = Offset.Zero
                                        swapGuard = null
                                    },
                                    onDragEnd = {
                                        draggingKey = null
                                        dragOffset = Offset.Zero
                                    },
                                    onDragCancel = {
                                        draggingKey = null
                                        dragOffset = Offset.Zero
                                    },
                                    onDrag = { change, amount ->
                                        change.consume()
                                        dragOffset += amount
                                        val items = gridState.layoutInfo.visibleItemsInfo
                                        val me = items.firstOrNull { it.key == app.packageName }
                                            ?: return@detectDragGestures
                                        if (swapGuard != null && me.offset == swapGuard) return@detectDragGestures
                                        swapGuard = null
                                        val centre = Offset(
                                            me.offset.x + me.size.width / 2f + dragOffset.x,
                                            me.offset.y + me.size.height / 2f + dragOffset.y,
                                        )
                                        val target = items.firstOrNull {
                                            it.key is String && it.key != app.packageName &&
                                                centre.x >= it.offset.x && centre.x < it.offset.x + it.size.width &&
                                                centre.y >= it.offset.y && centre.y < it.offset.y + it.size.height
                                        }
                                        if (target != null) {
                                            currentOnMove(app.packageName, target.key as String)
                                            // The icon takes the target's slot, so keep it under the finger.
                                            dragOffset += Offset(
                                                (me.offset.x - target.offset.x).toFloat(),
                                                (me.offset.y - target.offset.y).toFloat(),
                                            )
                                            swapGuard = me.offset
                                        }
                                    },
                                )
                            },
                    ) {
                        AppIcon(app = app, onClick = {}, onLongClick = {})
                    }
                } else {
                    AppIcon(
                        app = app,
                        onClick = { onLaunch(app.packageName) },
                        onLongClick = { onLongPress(app) },
                    )
                }
            }
        }

        if (settings.style == LauncherStyle.Windows11) {
            Taskbar(
                apps = dockApps,
                onLaunch = onLaunch,
                onLongPress = onLongPress,
                onStart = onOpenDrawer,
                onOpenControls = onOpenControls,
            )
        } else {
            DockBar(
                apps = dockApps,
                onLaunch = onLaunch,
                onLongPress = onLongPress,
                onOpenDrawer = onOpenDrawer,
            )
        }
    }
}

/** Shown above the grid while arranging icons. */
@Composable
private fun ArrangeBar(onDone: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, top = 24.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = stringResource(R.string.arrange_hint),
            style = MaterialTheme.typography.titleMedium.copy(shadow = LauncherTextShadow),
            color = Color.White,
            modifier = Modifier.weight(1f),
        )
        Button(onClick = onDone) { Text(stringResource(R.string.arrange_done)) }
    }
}

@Composable
private fun ClockHeader(onOpenSettings: () -> Unit, oxygen: Boolean = false) {
    val now by produceState(initialValue = LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(10_000L)
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 8.dp, top = 24.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            if (oxygen) {
                // OxygenOS 16 clock card: bold serif time on a white plate, label underneath.
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = Color.White,
                    shadowElevation = 6.dp,
                ) {
                    Text(
                        text = now.format(OxygenTimeFormat),
                        style = MaterialTheme.typography.displaySmall,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF111111),
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    )
                }
                Text(
                    text = now.format(DateFormat),
                    style = MaterialTheme.typography.labelLarge.copy(shadow = LauncherTextShadow),
                    color = Color.White,
                    modifier = Modifier.padding(start = 12.dp, top = 6.dp),
                )
            } else {
                Text(
                    text = now.format(TimeFormat),
                    style = MaterialTheme.typography.displayLarge.copy(shadow = LauncherTextShadow),
                    color = Color.White,
                    fontWeight = FontWeight.Light,
                )
                Text(
                    text = now.format(DateFormat),
                    style = MaterialTheme.typography.titleMedium.copy(shadow = LauncherTextShadow),
                    color = Color.White,
                )
            }
        }
        IconButton(onClick = onOpenSettings) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = stringResource(R.string.settings_open),
                tint = Color.White,
            )
        }
    }
}

/**
 * Up to [DOCK_CAPACITY] apps in a rounded panel. Swiping up on the dock, or tapping
 * the handle beneath it, opens the app drawer.
 */
@Composable
private fun DockBar(
    apps: List<LauncherApp>,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    onOpenDrawer: () -> Unit,
) {
    val style = LocalLauncherSettings.current.style
    val pill = style == LauncherStyle.Android17
    val oxygen = style == LauncherStyle.OxygenOS
    val swipeThreshold = with(LocalDensity.current) { SwipeUpDistance.toPx() }
    val currentOpenDrawer by rememberUpdatedState(onOpenDrawer)
    var dragTotal by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .pointerInput(swipeThreshold) {
                detectVerticalDragGestures(
                    onDragStart = { dragTotal = 0f },
                    onDragEnd = { if (dragTotal < -swipeThreshold) currentOpenDrawer() },
                ) { _, dragAmount -> dragTotal += dragAmount }
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (oxygen) {
            // Page indicator, as on OxygenOS. Decorative: the launcher has a single home page.
            Row(
                modifier = Modifier.padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                repeat(4) { i ->
                    Box(
                        Modifier
                            .size(7.dp)
                            .background(Color.White.copy(alpha = if (i == 0) 1f else 0.4f), CircleShape),
                    )
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(if (pill) 40.dp else 28.dp),
            // OxygenOS: no dock panel at all, the icons float on the wallpaper.
            color = if (oxygen) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerHigh.copy(
                alpha = if (pill) 0.92f else 0.85f,
            ),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = if (oxygen) 4.dp else 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                for (slot in 0 until DOCK_CAPACITY) {
                    val app = apps.getOrNull(slot)
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        if (app != null) {
                            AppIcon(
                                app = app,
                                showLabel = false,
                                onClick = { onLaunch(app.packageName) },
                                onLongClick = { onLongPress(app) },
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(if (pill) 8.dp else 4.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .clickable(onClickLabel = stringResource(R.string.all_apps), onClick = onOpenDrawer),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier
                    .size(width = if (oxygen) 130.dp else 40.dp, height = if (oxygen) 4.dp else 5.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.85f)),
            )
        }
    }
}
