package com.example.colourlauncher.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.colourlauncher.data.Accent
import com.example.colourlauncher.data.LauncherSettings
import com.example.colourlauncher.data.ThemeMode

private fun Accent.seed(): Color = when (this) {
    Accent.Wallpaper, Accent.Blue -> Color(0xFF4F7CFF)
    Accent.Green -> Color(0xFF3DA35D)
    Accent.Pink -> Color(0xFFE0577F)
    Accent.Orange -> Color(0xFFF08A24)
    Accent.Fluent -> Color(0xFF0067C0)
}

/**
 * Material 3 theme for the launcher's own surfaces. With the Wallpaper accent on Android 12+
 * the colours come from the wallpaper; otherwise a fixed accent is used.
 */
@Composable
fun ColourLauncherTheme(settings: LauncherSettings, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val dark = when (settings.themeMode) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Light -> false
        ThemeMode.Dark -> true
    }
    val useWallpaper = settings.accent == Accent.Wallpaper && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val scheme: ColorScheme = when {
        useWallpaper && dark -> dynamicDarkColorScheme(context)
        useWallpaper -> dynamicLightColorScheme(context)
        dark -> darkColorScheme(primary = settings.accent.seed())
        else -> lightColorScheme(primary = settings.accent.seed())
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
