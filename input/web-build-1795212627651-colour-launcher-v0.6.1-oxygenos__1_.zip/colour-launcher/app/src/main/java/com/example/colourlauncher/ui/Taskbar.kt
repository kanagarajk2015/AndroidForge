package com.example.colourlauncher.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherApp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

/** Height of the Windows 11 style taskbar, not counting the system navigation bar. */
val TaskbarHeight: Dp = 56.dp

private val TaskbarTime: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val TaskbarDate: DateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")

@Composable
private fun rememberNow(): State<LocalDateTime> = produceState(initialValue = LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(10_000L)
    }
}

/**
 * Windows 11 style taskbar: a Start button and the dock apps centred, the clock on the right.
 * The Start button opens the Start-menu panel (the app drawer).
 */
@Composable
fun Taskbar(
    apps: List<LauncherApp>,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    onStart: () -> Unit,
    onOpenControls: () -> Unit,
) {
    val now by rememberNow()

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.9f),
    ) {
        Row(
            modifier = Modifier
                .navigationBarsPadding()
                .height(TaskbarHeight)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                StartButton(onClick = onStart)
                apps.forEach { app -> TaskbarIcon(app, onLaunch, onLongPress) }
            }
            // The clock area opens the quick controls, like the system tray in Windows 11.
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable(onClickLabel = stringResource(R.string.controls_title), onClick = onOpenControls)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.End,
            ) {
                Text(
                    text = now.format(TaskbarTime),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.End,
                )
                Text(
                    text = now.format(TaskbarDate),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.End,
                )
            }
        }
    }
}

/** A plain 2x2 tile grid in the accent colour. */
@Composable
private fun StartButton(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClickLabel = stringResource(R.string.start_menu), onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            repeat(2) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    repeat(2) {
                        Box(
                            Modifier
                                .size(10.dp)
                                .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(1.dp)),
                        )
                    }
                }
            }
        }
    }
}

// combinedClickable is still marked experimental in the Compose Foundation version this project uses.
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TaskbarIcon(
    app: LauncherApp,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
) {
    val shape = LocalLauncherSettings.current.iconShape.toShape()
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(6.dp))
            .combinedClickable(
                onClick = { onLaunch(app.packageName) },
                onLongClick = { onLongPress(app) },
            ),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .size(28.dp)
                .clip(shape),
        )
    }
}
