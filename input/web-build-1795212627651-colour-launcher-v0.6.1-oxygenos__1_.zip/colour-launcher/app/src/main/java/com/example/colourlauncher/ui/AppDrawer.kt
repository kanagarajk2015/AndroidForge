package com.example.colourlauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.R
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.data.LauncherStyle

/**
 * List of every app, with a search field at the top. Full screen by default.
 * With [panel] set it is a rounded Start-menu panel sized by [modifier], and
 * [onOpenSettings] adds a settings button in a footer.
 */
@Composable
fun AppDrawer(
    apps: List<LauncherApp>,
    onLaunch: (String) -> Unit,
    onLongPress: (LauncherApp) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    panel: Boolean = false,
    onOpenSettings: (() -> Unit)? = null,
) {
    val columns = LocalLauncherSettings.current.columns
    val pullDown = rememberPullConnection(upward = false, threshold = 80.dp, onTrigger = onClose)
    var query by rememberSaveable { mutableStateOf("") }
    val results = remember(apps, query) {
        val needle = query.trim()
        if (needle.isEmpty()) apps else apps.filter { it.label.contains(needle, ignoreCase = true) }
    }

    val searchAtBottom = !panel && LocalLauncherSettings.current.style == LauncherStyle.OxygenOS
    val searchField: @Composable () -> Unit = {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            singleLine = true,
            shape = RoundedCornerShape(if (panel) 8.dp else 28.dp),
            placeholder = { Text(stringResource(R.string.search_apps)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        )
    }

    val base = if (panel) modifier.clip(RoundedCornerShape(12.dp)) else modifier.fillMaxSize()
    Column(
        modifier = base
            // Fully opaque: a translucent drawer lets the home screen (clock, icons, dock) ghost through.
            .background(MaterialTheme.colorScheme.surface)
            // Dragging down past the top of the grid closes the drawer.
            .nestedScroll(pullDown)
            // safeDrawing keeps the search box and grid clear of the status bar, nav bar and keyboard.
            // The panel sits above the taskbar, so it skips the insets.
            .then(if (panel) Modifier else Modifier.windowInsetsPadding(WindowInsets.safeDrawing)),
    ) {
        // OxygenOS puts the search bar at the bottom of the drawer, where the thumb is.
        if (!searchAtBottom) searchField()

        if (results.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center,
            ) {
                Text(text = stringResource(R.string.no_apps_found), color = MaterialTheme.colorScheme.onSurface)
            }
        } else {
            val gridState = rememberLazyGridState()
            val scope = rememberCoroutineScope()
            val letters = remember(results) { results.map { letterOf(it.label) }.distinct() }
            Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    state = gridState,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    items(results, key = { it.packageName }) { app ->
                        AppIcon(
                            app = app,
                            labelColor = MaterialTheme.colorScheme.onSurface,
                            onClick = { onLaunch(app.packageName) },
                            onLongClick = { onLongPress(app) },
                        )
                    }
                }
                // OxygenOS: A-Z index on the right edge. Tap or drag to jump through the list.
                if (searchAtBottom && letters.size > 1) {
                    LetterIndex(
                        letters = letters,
                        onSelect = { letter ->
                            val index = results.indexOfFirst { letterOf(it.label) == letter }
                            if (index >= 0) scope.launch { gridState.scrollToItem(index) }
                        },
                    )
                }
            }
        }

        if (searchAtBottom) searchField()

        if (onOpenSettings != null) {
            HorizontalDivider()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.End,
            ) {
                IconButton(onClick = onOpenSettings) {
                    Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = stringResource(R.string.settings_open),
                    )
                }
            }
        }
    }
}

/** Index bucket for an app label: its first letter, or '#' for digits and symbols. */
private fun letterOf(label: String): Char {
    val c = label.trim().firstOrNull()?.uppercaseChar() ?: return '#'
    return if (c.isLetter()) c else '#'
}

/** Thin vertical A-Z strip. Tapping or dragging over it reports the letter under the finger. */
@Composable
private fun LetterIndex(letters: List<Char>, onSelect: (Char) -> Unit) {
    var heightPx by remember { mutableIntStateOf(1) }
    val currentLetters by rememberUpdatedState(letters)
    val currentSelect by rememberUpdatedState(onSelect)
    fun pick(y: Float) {
        val list = currentLetters
        val i = (y / heightPx * list.size).toInt().coerceIn(0, list.lastIndex)
        currentSelect(list[i])
    }
    Column(
        modifier = Modifier
            .width(22.dp)
            .fillMaxHeight()
            .padding(end = 4.dp, top = 8.dp, bottom = 8.dp)
            .onSizeChanged { heightPx = it.height.coerceAtLeast(1) }
            .pointerInput(Unit) { detectTapGestures { pick(it.y) } }
            .pointerInput(Unit) { detectVerticalDragGestures { change, _ -> pick(change.position.y) } },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        letters.forEach { letter ->
            Text(
                text = letter.toString(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}
