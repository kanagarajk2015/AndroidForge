package com.example.colourlauncher.data

import android.content.Context
import org.json.JSONArray

/** Saves the home grid and the dock as ordered lists of package names. */
class LayoutStore(context: Context) {

    private val prefs = context.getSharedPreferences("layout", Context.MODE_PRIVATE)

    /** Null until the user's layout has been saved, so callers can apply defaults. */
    fun loadHome(): List<String>? = read(KEY_HOME)

    fun saveHome(packages: List<String>) {
        write(KEY_HOME, packages)
    }

    fun loadDock(): List<String>? = read(KEY_DOCK)

    fun saveDock(packages: List<String>) {
        write(KEY_DOCK, packages)
    }

    /** Returns null for missing or corrupt data, which falls back to the defaults. */
    private fun read(key: String): List<String>? {
        val raw = prefs.getString(key, null) ?: return null
        return runCatching {
            val array = JSONArray(raw)
            List(array.length()) { array.getString(it) }
        }.getOrNull()
    }

    private fun write(key: String, packages: List<String>) {
        prefs.edit().putString(key, JSONArray(packages).toString()).apply()
    }

    private companion object {
        const val KEY_HOME = "home"
        const val KEY_DOCK = "dock"
    }
}
