package com.example.colourlauncher.ui

import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.colourlauncher.R
import com.example.colourlauncher.util.openSettingsScreen
import kotlin.math.roundToInt

/** Quick controls as a bottom sheet (Classic and Android 17 styles). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ControlSheet(onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        ControlContent(onClose = onDismiss)
    }
}

/**
 * Quick controls: shortcuts to system settings, a working flashlight toggle, a media volume
 * slider and, once the user allows it, a brightness slider. Android does not let a launcher
 * switch Wi-Fi, Bluetooth, airplane mode or location directly, so those tiles open the
 * system screen for that setting.
 */
@Composable
fun ControlContent(onClose: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val torch = rememberTorch()
    val on = stringResource(R.string.control_on)
    val off = stringResource(R.string.control_off)

    val openAndClose: (String) -> Unit = { action ->
        context.openSettingsScreen(action)
        onClose()
    }
    val internetAction = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        Settings.Panel.ACTION_INTERNET_CONNECTIVITY
    } else {
        Settings.ACTION_WIFI_SETTINGS
    }

    val tiles = buildList {
        add(Tile(stringResource(R.string.control_internet), null, false) { openAndClose(internetAction) })
        add(Tile(stringResource(R.string.control_bluetooth), null, false) { openAndClose(Settings.ACTION_BLUETOOTH_SETTINGS) })
        if (torch.available) {
            add(Tile(stringResource(R.string.control_flashlight), if (torch.on) on else off, torch.on) { torch.set(!torch.on) })
        }
        add(Tile(stringResource(R.string.control_airplane), null, false) { openAndClose(Settings.ACTION_AIRPLANE_MODE_SETTINGS) })
        add(Tile(stringResource(R.string.control_location), null, false) { openAndClose(Settings.ACTION_LOCATION_SOURCE_SETTINGS) })
        add(Tile(stringResource(R.string.control_battery_saver), null, false) { openAndClose(Settings.ACTION_BATTERY_SAVER_SETTINGS) })
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, end = 24.dp, top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(text = stringResource(R.string.controls_title), style = MaterialTheme.typography.titleLarge)

        tiles.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { tile ->
                    TileButton(tile, Modifier.weight(1f))
                }
                // Keeps a lone last tile at half width instead of stretching it.
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        VolumeSlider()
        BrightnessControl()
    }
}

private class Tile(val label: String, val status: String?, val active: Boolean, val onClick: () -> Unit)

@Composable
private fun TileButton(tile: Tile, modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(16.dp)
    Surface(
        modifier = modifier
            .height(64.dp)
            .clip(shape)
            .clickable(onClick = tile.onClick),
        shape = shape,
        color = if (tile.active) scheme.primary else scheme.surfaceContainerHighest,
        contentColor = if (tile.active) scheme.onPrimary else scheme.onSurface,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            Text(text = tile.label, style = MaterialTheme.typography.titleSmall)
            if (tile.status != null) {
                Text(text = tile.status, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun VolumeSlider() {
    val context = LocalContext.current
    val audio = remember { context.getSystemService(AudioManager::class.java) }
    val max = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }

    Text(text = stringResource(R.string.control_volume), style = MaterialTheme.typography.labelLarge)
    Slider(
        value = volume,
        onValueChange = {
            volume = it
            runCatching { audio.setStreamVolume(AudioManager.STREAM_MUSIC, it.roundToInt(), 0) }
        },
        valueRange = 0f..max.toFloat(),
        steps = (max - 1).coerceAtLeast(0),
    )
}

/** A brightness slider if the user has allowed "modify system settings", otherwise a button to allow it. */
@Composable
private fun BrightnessControl() {
    val context = LocalContext.current
    val resolver = context.contentResolver
    val canWrite = remember { Settings.System.canWrite(context) }

    Text(text = stringResource(R.string.control_brightness), style = MaterialTheme.typography.labelLarge)
    if (canWrite) {
        var brightness by remember {
            mutableFloatStateOf(
                runCatching { Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS) }
                    .getOrDefault(128)
                    .toFloat(),
            )
        }
        Slider(
            value = brightness,
            onValueChange = {
                brightness = it
                runCatching {
                    // Manual mode, otherwise auto-brightness would immediately override the slider.
                    Settings.System.putInt(
                        resolver,
                        Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL,
                    )
                    Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, it.roundToInt())
                }
            },
            valueRange = 1f..255f,
        )
    } else {
        OutlinedButton(
            onClick = {
                context.startActivity(
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            },
        ) {
            Text(stringResource(R.string.control_allow_brightness))
        }
    }
}

private class Torch(val available: Boolean, val on: Boolean, val set: (Boolean) -> Unit)

/** The back camera's flash as a torch. It needs no permission. [Torch.on] follows changes made elsewhere. */
@Composable
private fun rememberTorch(): Torch {
    val context = LocalContext.current
    val manager = remember { context.getSystemService(CameraManager::class.java) }
    val cameraId = remember {
        runCatching {
            manager.cameraIdList.firstOrNull { id ->
                val c = manager.getCameraCharacteristics(id)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        }.getOrNull()
    }
    var on by remember { mutableStateOf(false) }

    DisposableEffect(manager, cameraId) {
        val callback = object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(id: String, enabled: Boolean) {
                if (id == cameraId) on = enabled
            }
        }
        if (cameraId != null) manager.registerTorchCallback(callback, Handler(Looper.getMainLooper()))
        onDispose { if (cameraId != null) manager.unregisterTorchCallback(callback) }
    }

    return Torch(available = cameraId != null, on = on) { enable ->
        if (cameraId != null) runCatching { manager.setTorchMode(cameraId, enable) }
    }
}
