package com.example.colourlauncher

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.colourlauncher.data.AppRepository
import com.example.colourlauncher.data.IconPackInfo
import com.example.colourlauncher.data.IconPackRepository
import com.example.colourlauncher.data.LauncherApp
import com.example.colourlauncher.data.LauncherSettings
import com.example.colourlauncher.data.LayoutStore
import com.example.colourlauncher.data.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Maximum number of apps shown in the dock. */
const val DOCK_CAPACITY = 4

/** Number of apps placed on the home grid before the user has arranged it. */
private const val DEFAULT_HOME_SIZE = 16

/** Holds the installed apps and the user's home/dock layout. */
class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val layoutStore = LayoutStore(application)
    private val settingsStore = SettingsStore(application)
    private val iconPackRepository = IconPackRepository(application)

    private val _apps = MutableStateFlow<List<LauncherApp>>(emptyList())
    val apps: StateFlow<List<LauncherApp>> = _apps.asStateFlow()

    /** Package names on the home grid, in display order. */
    private val _home = MutableStateFlow<List<String>>(emptyList())
    val home: StateFlow<List<String>> = _home.asStateFlow()

    /** Package names in the dock, in display order. */
    private val _dock = MutableStateFlow<List<String>>(emptyList())
    val dock: StateFlow<List<String>> = _dock.asStateFlow()

    private val _settings = MutableStateFlow(settingsStore.load())
    val settings: StateFlow<LauncherSettings> = _settings.asStateFlow()

    private val _iconPacks = MutableStateFlow<List<IconPackInfo>>(emptyList())
    val iconPacks: StateFlow<List<IconPackInfo>> = _iconPacks.asStateFlow()

    init {
        reload()
    }

    /**
     * Re-reads the installed apps and reconciles the saved layout with them.
     * Runs on start and whenever a package is added, removed or updated.
     */
    fun reload() {
        viewModelScope.launch {
            _iconPacks.value = withContext(Dispatchers.IO) { iconPackRepository.findPacks() }
            val installed = repository.loadLauncherApps(_settings.value.iconPack)
            if (installed.isEmpty()) return@launch
            _apps.value = installed

            val installedPackages = installed.map { it.packageName }
            val dockPackages = (layoutStore.loadDock() ?: installedPackages.take(DOCK_CAPACITY))
                .filter { it in installedPackages }
                .take(DOCK_CAPACITY)
            val homePackages = (
                layoutStore.loadHome()
                    ?: installedPackages.filterNot { it in dockPackages }.take(DEFAULT_HOME_SIZE)
                )
                .filter { it in installedPackages }

            _dock.value = dockPackages
            _home.value = homePackages
            layoutStore.saveDock(dockPackages)
            layoutStore.saveHome(homePackages)
        }
    }

    fun updateSettings(change: (LauncherSettings) -> LauncherSettings) {
        val old = _settings.value
        _settings.value = change(old)
        settingsStore.save(_settings.value)
        if (_settings.value.iconPack != old.iconPack) reload()
    }

    fun addToHome(packageName: String) = updateHome { if (packageName in it) it else it + packageName }

    fun removeFromHome(packageName: String) = updateHome { it - packageName }

    /** Sorts the current home-screen icons alphabetically by app name. */
    fun autoArrangeHome() {
        if (_settings.value.lockHome) return
        val labels = _apps.value.associate { it.packageName to it.label.lowercase() }
        updateHome { current -> current.sortedBy { labels[it] ?: it.lowercase() } }
    }

    /** Moves [from] to the slot currently held by [to] on the home screen. Ignored if the layout is locked. */
    fun moveHome(from: String, to: String) {
        if (_settings.value.lockHome) return
        updateHome { list ->
            val fromIndex = list.indexOf(from)
            val toIndex = list.indexOf(to)
            if (fromIndex < 0 || toIndex < 0 || fromIndex == toIndex) {
                list
            } else {
                list.toMutableList().apply { add(toIndex, removeAt(fromIndex)) }
            }
        }
    }

    /** Returns false if the dock is full or the app is already docked. */
    fun addToDock(packageName: String): Boolean {
        val current = _dock.value
        if (packageName in current || current.size >= DOCK_CAPACITY) return false
        updateDock(current + packageName)
        return true
    }

    fun removeFromDock(packageName: String) = updateDock(_dock.value - packageName)

    private fun updateHome(change: (List<String>) -> List<String>) {
        _home.value = change(_home.value)
        layoutStore.saveHome(_home.value)
    }

    private fun updateDock(packages: List<String>) {
        _dock.value = packages
        layoutStore.saveDock(packages)
    }
}
