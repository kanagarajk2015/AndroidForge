# Tejodhar Android App (WebView)

Android app wrapping https://www.tejodhar.in/ and https://tejodhar.in/.

- Package: `com.tejodhar.app`
- minSdk 24, targetSdk 34, Kotlin
- Both `tejodhar.in` and `www.tejodhar.in` (and subdomains) open inside the app; all other links open in the external browser.
- Pull-to-refresh, progress bar, offline/error screen with Retry, back-button navigation, file uploads, downloads, HTTPS-only.

## Build the APK

1. Install Android Studio (Koala or newer, JDK 17).
2. **File > Open** this folder; let Gradle sync (Android Studio generates the Gradle wrapper).
3. Debug APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
   Output: `app/build/outputs/apk/debug/app-debug.apk`

Or from a terminal (after the wrapper exists): `./gradlew assembleDebug`

## Release / Play Store

1. **Build > Generate Signed Bundle / APK** and create a keystore (keep it safe).
2. Choose APK (sideload) or AAB (Play Store).

## Customize

- Home URL: `HOME_URL` in `MainActivity.kt`
- Name: `res/values/strings.xml`
- Colors: `res/values/colors.xml` (set to your brand colors)
- Icon: right-click `res` > **New > Image Asset** and use your logo
