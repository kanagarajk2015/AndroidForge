# Keep WebView JS interfaces (none used currently)
-keepattributes JavascriptInterface
