plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tejodhar.mobilespeaker"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tejodhar.mobilespeaker"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // Java and Kotlin targets must match. Fixes AndroidForge build failure.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
