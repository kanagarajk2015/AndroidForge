# HDMI Live TV (Android TV)

Shows live video from HDMI 1/2/3 using Android's TV Input Framework (TvView).

- Open in Android Studio and run on an Android TV device.
- Press MENU / DPAD-DOWN to show the input bar; pick HDMI 1, 2 or 3.
- CH+ / CH- change channels on the built-in tuner (if the device allows channel access).

Notes
- Works on Android TV devices/TVs that expose HDMI inputs (not on emulators or most set-top boxes without HDMI-in).
- HDMI inputs are pass-through: the connected box (cable/satellite) controls its own channels.
- Reading tuner channels needs READ_EPG_DATA, which many TVs only grant to system apps; if denied, only HDMI inputs show.
