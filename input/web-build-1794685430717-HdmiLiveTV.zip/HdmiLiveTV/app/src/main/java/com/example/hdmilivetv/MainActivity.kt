package com.example.hdmilivetv

import android.app.Activity
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.media.tv.TvView
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var tvView: TvView
    private lateinit var bar: LinearLayout
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val hideBar = Runnable { bar.visibility = View.GONE; status.visibility = View.GONE }

    // Built-in tuner (antenna/cable/satellite) state
    private var tunerInput: TvInputInfo? = null
    private var tunerChannels: List<Uri> = emptyList()
    private var channelIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvView = findViewById(R.id.tvView)
        bar = findViewById(R.id.bar)
        status = findViewById(R.id.status)

        val tvm = getSystemService(TV_INPUT_SERVICE) as TvInputManager
        val inputs = tvm.tvInputList

        // HDMI 1 / 2 / 3 ... sorted by physical port
        val hdmi = inputs.filter { it.type == TvInputInfo.TYPE_HDMI }
            .sortedBy { it.hdmiDeviceInfo?.portId ?: Int.MAX_VALUE }

        hdmi.forEachIndexed { i, info ->
            val port = info.hdmiDeviceInfo?.portId?.takeIf { it > 0 } ?: (i + 1)
            addButton("HDMI $port") { tuneHdmi(info, "HDMI $port") }
        }

        // Optional: built-in tuner with channel list
        tunerInput = inputs.firstOrNull { it.type == TvInputInfo.TYPE_TUNER }
        tunerInput?.let { t ->
            tunerChannels = loadChannels(t.id)
            if (tunerChannels.isNotEmpty()) {
                addButton("Live TV") { tuneChannel(0) }
            }
        }

        if (bar.childCount == 0) {
            status.text = "No HDMI inputs found on this device."
        } else {
            bar.getChildAt(0).requestFocus()
            // Auto-start first HDMI input
            hdmi.firstOrNull()?.let {
                val port = it.hdmiDeviceInfo?.portId?.takeIf { p -> p > 0 } ?: 1
                tuneHdmi(it, "HDMI $port")
            }
        }
    }

    private fun addButton(label: String, onClick: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 20f
            isFocusable = true
            setOnClickListener { onClick(); scheduleHide() }
        }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(16, 0, 16, 0)
        bar.addView(b, lp)
    }

    private fun tuneHdmi(info: TvInputInfo, label: String) {
        tvView.tune(info.id, TvContract.buildChannelUriForPassthroughInput(info.id))
        status.text = label
        status.visibility = View.VISIBLE
    }

    private fun loadChannels(inputId: String): List<Uri> = try {
        val list = mutableListOf<Uri>()
        contentResolver.query(
            TvContract.buildChannelsUriForInput(inputId),
            arrayOf(TvContract.Channels._ID), null, null, null
        )?.use { c ->
            while (c.moveToNext()) list += TvContract.buildChannelUri(c.getLong(0))
        }
        list
    } catch (e: SecurityException) {
        emptyList() // READ_EPG_DATA not granted on this device
    }

    private fun tuneChannel(index: Int) {
        val t = tunerInput ?: return
        if (tunerChannels.isEmpty()) return
        channelIndex = (index + tunerChannels.size) % tunerChannels.size
        tvView.tune(t.id, tunerChannels[channelIndex])
        status.text = "Channel ${channelIndex + 1}"
        status.visibility = View.VISIBLE
    }

    // Remote: MENU/DPAD_DOWN shows the bar; CH +/- (or DPAD up/down when hidden) zaps tuner channels
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MENU -> { showBar(); return true }
            KeyEvent.KEYCODE_CHANNEL_UP -> { tuneChannel(channelIndex + 1); return true }
            KeyEvent.KEYCODE_CHANNEL_DOWN -> { tuneChannel(channelIndex - 1); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_DPAD_DOWN ->
                if (bar.visibility != View.VISIBLE) { showBar(); return true }
        }
        scheduleHide()
        return super.onKeyDown(keyCode, event)
    }

    private fun showBar() {
        bar.visibility = View.VISIBLE
        bar.getChildAt(0)?.requestFocus()
        scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideBar)
        handler.postDelayed(hideBar, 6000)
    }

    override fun onDestroy() {
        tvView.reset()
        super.onDestroy()
    }
}
