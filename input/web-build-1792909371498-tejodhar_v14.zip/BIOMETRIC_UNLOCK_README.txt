Tejodhar biometric unlock
- Outer (login-page) biometric unlock and Median splash screen removed.
- No second lock when the app opens.
- Native bridge: app/src/main/java/co/median/android/BiometricBridge.java (window.TejodharBio).
- Server side: website/index.php (bio_native_register / bio_native_login).
- Source change only; build with AndroidForge.
