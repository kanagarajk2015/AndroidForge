package com.tejodhar.hrportal

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.webkit.*
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    private lateinit var rootContainer: View
    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var lockScreen: View
    private lateinit var lockMessage: TextView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // App lock: shown on open and after the app has been in the background for a while.
    private var appLocked = false
    private var unlockInProgress = false
    private var lastBackgroundedAt = 0L

    // Set just before this app opens another screen (file picker, external link,
    // app settings) so that coming back from it does not ask for the fingerprint again.
    private var skipNextLock = false

    // Camera / microphone request from the web page, waiting for the Android prompt.
    private var pendingWebPermission: PermissionRequest? = null

    // Location request from the web page, waiting for the Android prompt.
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null

    // Asked only when a video/voice call actually starts, never at app launch.
    private val mediaPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val request = pendingWebPermission ?: return@registerForActivityResult
        pendingWebPermission = null

        val allowed = request.resources.filter { resource ->
            val permission = mediaPermissionFor(resource) ?: return@filter false
            hasPermission(permission)
        }
        if (allowed.isEmpty()) {
            request.deny()
        } else {
            request.grant(allowed.toTypedArray())
        }

        val permanentlyDenied = results.any { (permission, granted) ->
            !granted && !shouldShowRequestPermissionRationale(permission)
        }
        if (permanentlyDenied) {
            showOpenSettingsDialog(
                "Camera and microphone are turned off for Tejodhar HR Portal. " +
                    "Turn them on in app settings to make calls."
            )
        }
    }

    // Asked only when the web page asks for the device location.
    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val origin = pendingGeoOrigin
        val callback = pendingGeoCallback
        pendingGeoOrigin = null
        pendingGeoCallback = null

        val allowed = hasLocationPermission()
        callback?.invoke(origin, allowed, false)

        val permanentlyDenied = results.any { (permission, granted) ->
            !granted && !shouldShowRequestPermissionRationale(permission)
        }
        if (!allowed && permanentlyDenied) {
            showOpenSettingsDialog(
                "Location is turned off for Tejodhar HR Portal. " +
                    "Turn it on in app settings to use location features."
            )
        }
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (filePathCallback != null) {
            val intentData = result.data
            val results: Array<Uri>? = if (result.resultCode == RESULT_OK && intentData != null) {
                intentData.data?.let { arrayOf(it) }
            } else null
            filePathCallback?.onReceiveValue(results)
            filePathCallback = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Draw edge to edge, then pad the content by the system bars so the page's
        // top bar is never hidden under the status bar (and nothing hides under the
        // navigation bar or the keyboard).
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }

        rootContainer = findViewById(R.id.rootContainer)
        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        lockScreen = findViewById(R.id.lockScreen)
        lockMessage = findViewById(R.id.lockMessage)

        ViewCompat.setOnApplyWindowInsetsListener(rootContainer) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            view.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            WindowInsetsCompat.CONSUMED
        }

        findViewById<Button>(R.id.unlockButton).setOnClickListener { requestUnlock() }

        setupWebView()

        swipeRefresh.setOnRefreshListener {
            webView.reload()
        }

        webView.loadUrl("https://www.tejodhar.in/")

        // Lock on open when the phone has a fingerprint or screen lock set up.
        if (canUseBiometrics()) {
            showLockScreen()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    appLocked -> this@MainActivity.finish()
                    webView.canGoBack() -> webView.goBack()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        val awayLongEnough = lastBackgroundedAt > 0L &&
            SystemClock.elapsedRealtime() - lastBackgroundedAt > RELOCK_AFTER_MS
        if (awayLongEnough && !skipNextLock && canUseBiometrics()) {
            showLockScreen()
        }
        skipNextLock = false
    }

    override fun onStop() {
        super.onStop()
        lastBackgroundedAt = SystemClock.elapsedRealtime()
    }

    override fun onResume() {
        super.onResume()
        if (appLocked) requestUnlock()
    }

    // ---------------------------------------------------------------- App lock

    private fun showLockScreen() {
        appLocked = true
        lockMessage.text = "Unlock with your fingerprint to continue"
        lockScreen.visibility = View.VISIBLE
    }

    private fun hideLockScreen() {
        appLocked = false
        lockScreen.visibility = View.GONE
    }

    private fun requestUnlock() {
        if (!appLocked || unlockInProgress) return

        val status = BiometricManager.from(this).canAuthenticate(lockAuthenticators())
        if (status == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ||
            status == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE
        ) {
            // The phone no longer has a fingerprint or screen lock, so the lock cannot apply.
            hideLockScreen()
            return
        }

        unlockInProgress = true
        authenticate(
            title = "Unlock Tejodhar HR Portal",
            onSuccess = {
                unlockInProgress = false
                hideLockScreen()
            },
            onError = { message ->
                unlockInProgress = false
                lockMessage.text = message
            }
        )
    }

    /**
     * Fingerprint (or face) first. On Android 11+ the prompt also offers the
     * phone PIN/pattern as a fallback; that option cannot be combined with a
     * negative button, so the "Cancel" button is only shown on older Android.
     */
    private fun lockAuthenticators(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else {
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        }

    private fun canUseBiometrics(): Boolean =
        BiometricManager.from(this).canAuthenticate(lockAuthenticators()) ==
            BiometricManager.BIOMETRIC_SUCCESS

    private fun authenticate(
        title: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val authenticators = lockAuthenticators()
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle("Use your fingerprint to continue")
            .setAllowedAuthenticators(authenticators)
            .apply {
                if ((authenticators and BiometricManager.Authenticators.DEVICE_CREDENTIAL) == 0) {
                    setNegativeButtonText("Cancel")
                }
            }
            .build()

        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onError(errString.toString())
                }
            }
        )
        prompt.authenticate(promptInfo)
    }

    // ------------------------------------------------- Web page bridge (saved login)

    private fun triggerBiometricPrompt(callbackFunctionName: String?) {
        if (!canUseBiometrics()) {
            Toast.makeText(this, "Biometrics not available on this device", Toast.LENGTH_SHORT).show()
            notifyWeb(callbackFunctionName, false)
            return
        }
        authenticate(
            title = "Tejodhar HR Portal",
            onSuccess = {
                Toast.makeText(applicationContext, "Biometric Authentication Success", Toast.LENGTH_SHORT).show()
                notifyWeb(callbackFunctionName, true)
            },
            onError = { message ->
                Toast.makeText(applicationContext, "Auth Error: $message", Toast.LENGTH_SHORT).show()
                notifyWeb(callbackFunctionName, false)
            }
        )
    }

    private fun notifyWeb(callbackName: String?, success: Boolean) {
        val name = callbackName ?: return
        // Only a plain function name is evaluated, so the page cannot inject script.
        if (!SAFE_CALLBACK_NAME.matches(name)) return
        webView.post {
            webView.evaluateJavascript("$name($success)", null)
        }
    }

    inner class WebAppInterface {
        @JavascriptInterface
        fun promptBiometrics(callbackName: String) {
            runOnUiThread {
                triggerBiometricPrompt(callbackName)
            }
        }

        @JavascriptInterface
        fun isBiometricAvailable(): Boolean = this@MainActivity.canUseBiometrics()
    }

    // ------------------------------------------------------- Runtime permissions

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun hasLocationPermission(): Boolean =
        hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) ||
            hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)

    /** The Android runtime permission behind a WebView capture request, if any. */
    private fun mediaPermissionFor(resource: String): String? = when (resource) {
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
        else -> null
    }

    private fun showOpenSettingsDialog(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Permission needed")
            .setMessage(message)
            .setPositiveButton("Open settings") { _, _ ->
                skipNextLock = true
                startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", packageName, null)
                    )
                )
            }
            .setNegativeButton("Not now", null)
            .show()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT

            setGeolocationEnabled(true)
            setGeolocationDatabasePath(filesDir.path)

            // Inject TejodharApp identifier into User-Agent so website detects native app support
            val defaultUserAgent = userAgentString
            userAgentString = "$defaultUserAgent TejodharApp"
        }

        // Add JavaScript Interface so website JS can interact with Android Biometrics
        webView.addJavascriptInterface(WebAppInterface(), "TejodharAppBridge")
        webView.addJavascriptInterface(WebAppInterface(), "Android")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.contains("tejodhar.in")) {
                    return false
                }
                skipNextLock = true
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    true
                } catch (e: Exception) {
                    skipNextLock = false
                    false
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                swipeRefresh.isRefreshing = false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress < 100) {
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = newProgress
                } else {
                    progressBar.visibility = View.GONE
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                if (hasLocationPermission()) {
                    callback?.invoke(origin, true, false)
                    return
                }
                // Answer an earlier request that is still open before starting this one.
                pendingGeoCallback?.invoke(pendingGeoOrigin, false, false)
                pendingGeoOrigin = origin
                pendingGeoCallback = callback
                locationPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                val webRequest = request ?: return

                // The page may ask for camera and/or microphone (a video call asks for both).
                val supported = webRequest.resources.filter { mediaPermissionFor(it) != null }
                if (supported.isEmpty()) {
                    webRequest.deny()
                    return
                }

                val missing = supported
                    .mapNotNull { mediaPermissionFor(it) }
                    .distinct()
                    .filterNot { hasPermission(it) }
                if (missing.isEmpty()) {
                    webRequest.grant(supported.toTypedArray())
                    return
                }

                // Ask Android now, when the call starts; the result is handled above.
                pendingWebPermission?.deny()
                pendingWebPermission = webRequest
                mediaPermissionLauncher.launch(missing.toTypedArray())
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                val intent = fileChooserParams?.createIntent()
                return try {
                    if (intent != null) {
                        skipNextLock = true
                        fileChooserLauncher.launch(intent)
                    }
                    true
                } catch (e: Exception) {
                    skipNextLock = false
                    this@MainActivity.filePathCallback = null
                    false
                }
            }
        }
    }

    private companion object {
        const val RELOCK_AFTER_MS = 30_000L
        val SAFE_CALLBACK_NAME = Regex("[A-Za-z_][A-Za-z0-9_.]*")
    }
}
