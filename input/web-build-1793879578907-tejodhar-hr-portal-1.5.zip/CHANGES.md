# Tejodhar HR Portal 1.5 (versionCode 6)

## 1. App icon
- New launcher icon from the Tejodhar logo (white background, brand blue mark).
- Adaptive icon (Android 8+) plus legacy square and round PNGs for every density.
- `mipmap-anydpi-v26/ic_launcher*.xml` reference the adaptive layers.
- `/playstore-icon-512.png` (outside the project) is for the Play Console listing.

## 2. Biometric unlock (app lock)
- App locks on open and again after 30 seconds in the background.
- Unlock uses the fingerprint prompt. Android 11+ also offers the phone PIN/pattern.
- If the phone has no fingerprint or screen lock, the app lock is skipped.
- Returning from the file picker, external links or app settings does not re-lock.
- The saved-login bridge (`TejodharAppBridge.promptBiometrics`) uses the same prompt
  and no longer mismatches the check and the prompt settings.

## 3. Camera, microphone and location permissions
- Nothing is requested at app launch any more.
- Camera and microphone: requested when a video/voice call starts (WebView capture request).
- Location: requested when the web page asks for it.
- If a permission was denied permanently, the user is offered "Open settings".
- `MODIFY_AUDIO_SETTINGS` added for WebRTC audio.

## 4. Top toolbar / screen overlap
- Edge-to-edge with system bar insets: the page starts below the status bar and
  ends above the navigation bar and keyboard.
- The loading progress line is its own row above the page, not drawn over the top of it.

## Security note
- The page-to-app callback name is checked before it is evaluated.

## Build
- Not compiled in the build environment (no Android SDK available there).
  Run a Gradle assembleRelease and test on a phone before publishing.
